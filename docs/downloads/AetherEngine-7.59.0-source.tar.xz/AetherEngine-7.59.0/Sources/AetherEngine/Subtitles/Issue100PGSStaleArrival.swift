import Foundation

/// Holdback for PGS cues that arrive already behind the playhead (issue #100).
///
/// PGS compositions have no intrinsic end: FFmpeg reports `end_display_time = UINT32_MAX`, the
/// decoder stamps the cue with an open-ended placeholder window, and the SUCCESSOR composition's
/// trim closes it (`pgsTrimAt`). In steady state insert and trim land within a frame of each
/// other and nothing untoward shows. When the side reader catches up after starvation (the #96
/// class), the backlog arrives with multi-second decode gaps and every historical cue's open
/// window covers the playhead the moment it inserts, so ~seconds of stale subtitles flash
/// through the overlay one by one.
///
/// The gate holds a PGS event whose cues start more than `staleEpsilonSeconds` behind the
/// playhead (a catch-up signature; a live cue at a seek landing anchors at most ~2 s back and
/// passes straight through). The next PGS event or clear event resolves the hold: trimmed to the
/// successor's start, the cue publishes only if its true window covers the playhead (it is the
/// genuinely active subtitle), otherwise it is dropped silently. Trade-off, accepted: the LAST
/// backlog cue has no successor yet and stays held until the next composition arrives; missing
/// one line briefly beats replaying 80 s of history through the live overlay.
struct PGSStaleArrivalGate {
    let staleEpsilonSeconds: Double
    private(set) var heldCues: [SubtitleCue] = []

    /// #112 full umbau: set while the reader decodes the region behind a fresh seek target to reconstruct the
    /// active line. In this window compositions behind the playhead are held (not published) and only the line
    /// group active at the playhead is emitted, so the lead-in's earlier compositions cannot scroll through the
    /// overlay. Auto-cleared once the reader decodes a cue at/after the playhead.
    var reconstructing: Bool = false

    /// #112: during a reconstruction pass, the newest composition at/behind the playhead seen so far - the
    /// candidate active line. Held, not published. Publishing every self-contained composition in the lead-in as
    /// it decoded scrolled ~24 s of history through the frozen overlay (ijuniorfu: "the subtitles keep changing
    /// while paused"). Emitted as the active line when the decode reaches the playhead (a composition at or
    /// after it arrives), or dropped/superseded by a newer one first. #143: seeded from ANY decoded composition,
    /// not only self-contained ones; see `admitDuringReconstruction`. #146: a display set can carry multiple
    /// composition objects sharing one start PTS (forced sign + dialogue); the candidate is the whole same-start
    /// group, a single cue would silently drop the sibling objects at seek time.
    private(set) var reconstructionCandidates: [SubtitleCue] = []

    init(staleEpsilonSeconds: Double = 5.0) {
        self.staleEpsilonSeconds = staleEpsilonSeconds
    }

    var hasHeld: Bool { !heldCues.isEmpty || !reconstructionCandidates.isEmpty }

    /// #143 follow-up: a reconstruction pass has seeded an active-line candidate that has not yet
    /// been emitted. The drain uses this to decide the pass can be finalized when no successor is
    /// stored ahead; without a candidate a true gap (nothing decoded behind the playhead) must be
    /// left alone, not finalized into an empty emit.
    var hasReconstructionCandidate: Bool { !reconstructionCandidates.isEmpty }

    /// Resolve the held event against its successor's trim point. Returns the cues to publish
    /// NOW: the held cues trimmed to `trimAt`, filtered to those whose true window covers the
    /// playhead. History that ended before the playhead is dropped.
    ///
    /// #143: the trim also closes the reconstruction candidate's open window. Every PGS composition
    /// AND clear broadcasts its start as `pgsTrimAt`, but a clear carries no cues and never reaches
    /// `admit`; without this trim a line the author cleared before the playhead keeps its open
    /// placeholder window and resurrects as the "active" line at pass end.
    mutating func resolveHeld(trimAt: Double, playhead: Double) -> [SubtitleCue] {
        reconstructionCandidates = reconstructionCandidates.map { candidate in
            guard candidate.startTime < trimAt, candidate.endTime > trimAt else { return candidate }
            return candidate.with(endTime: trimAt)
        }
        guard !heldCues.isEmpty else { return [] }
        let resolved = heldCues.map { cue in
            cue.with(endTime: min(cue.endTime, trimAt))
        }
        heldCues = []
        return resolved.filter { $0.startTime <= playhead && playhead < $0.endTime }
    }

    /// Admit an incoming event's cues. Stale PGS arrivals (every cue starting more than the
    /// epsilon behind the playhead) are held for successor resolution and publish nothing yet;
    /// everything else passes through unchanged.
    ///
    /// #112 full umbau: `isSelfContained` marks an Acquisition Point / Epoch Start - a composition that rebuilds
    /// the visible line on its own. While `reconstructing` (decoding just behind a fresh seek target), admit is
    /// delegated to `admitDuringReconstruction`, which holds the lead-in's compositions and emits only the line
    /// group active at the playhead. Outside reconstruction the #100 stale hold governs: a catch-up backlog of
    /// arrivals behind the playhead is held for successor resolution and cannot flash through the overlay.
    /// #416: `groundIsRead` says whether the source between these cues and the playhead was
    /// actually read by some harvest run. Only a cue BEHIND the playhead needs it, and it needs it
    /// because that is the whole of its claim: a PGS set has no end of its own, so "still on screen
    /// at the playhead" means "nothing on this stream happened in between", and an empty store over
    /// unread ground is not evidence of that. False makes such a cue ineligible, here and in the
    /// reconstruction pass alike; a cue at or after the playhead is unaffected, it claims nothing
    /// about ground behind it. Defaults to true so every caller that cannot answer keeps the
    /// behaviour it had, which is also what an unreporting harvest path gets from the store.
    mutating func admit(cues: [SubtitleCue], isPGS: Bool, isSelfContained: Bool = false,
                        playhead: Double, groundIsRead: Bool = true) -> [SubtitleCue] {
        guard isPGS, !cues.isEmpty else { return cues }
        if reconstructing {
            return admitDuringReconstruction(cues: cues, isSelfContained: isSelfContained,
                                             playhead: playhead, groundIsRead: groundIsRead)
        }
        let stale = cues.allSatisfy { $0.startTime < playhead - staleEpsilonSeconds }
        guard stale else { return cues }
        // #416: a stale arrival publishes only if its window turns out to cover the playhead, which
        // is the same claim over the same unread ground. Nothing to hold it for.
        guard groundIsRead else { return [] }
        heldCues = cues
        return []
    }

    /// #112: admit during a reconstruction pass. Compositions at/behind the playhead update the candidate
    /// active-line group and publish nothing, so the lead-in's earlier lines never scroll through the frozen
    /// overlay. The first composition at or after the playhead ends the pass: the active line group (#146: all
    /// same-start objects of the newest composition behind the playhead) is emitted once, together with any cues
    /// ahead of the playhead (future, stored but not yet shown).
    ///
    /// #143: the candidate is seeded from ANY decoded composition behind the playhead. Requiring a self-contained
    /// composition (Acquisition Point / Epoch Start) for the FIRST seed dropped the seek-landing line on AP-less/
    /// sparse-authored streams: every lead-in composition is Normal there, so no candidate was ever seeded and the
    /// landing-span line, forced cues included, stayed dark until the next authored composition. A composition
    /// that decoded at all is renderable (the drain decoder is rebuilt fresh at the backscan start, so a set whose
    /// references are missing fails decode and never gets here), and the steady-state path outside reconstruction
    /// already publishes Normal compositions unconditionally. `isSelfContained` stays on the signature: callers
    /// keep reporting the PCS classification, which the epoch-start-aware backscan direction would need.
    private mutating func admitDuringReconstruction(cues: [SubtitleCue], isSelfContained: Bool,
                                                    playhead: Double,
                                                    groundIsRead: Bool = true) -> [SubtitleCue] {
        // #146: all objects of one display set arrive in a single decode event sharing a start, so
        // the candidate is the newest same-start GROUP behind the playhead; a same-start re-seed is
        // a re-decode of the same set and replaces the group wholesale.
        // #416: only a set whose ground up to the playhead was read can be that candidate. The
        // reporter's case is a set the harvest reached just before it was re-aimed somewhere else,
        // whose own clear sits in the stretch that was then skipped: it decodes at the landing, no
        // successor is stored between it and the playhead because nobody looked, and the pass emits
        // half a minute of history over the new scene. Refusing costs the landing line in the case
        // where the set really is still up and the proof is missing, which needs a dwell long
        // enough to span the whole unread stretch; publishing costs it in every case where it is
        // not, which is every normally authored set in that stretch.
        let behind = groundIsRead ? cues.filter { $0.startTime <= playhead } : []
        if let newestStart = behind.map(\.startTime).max(),
           reconstructionCandidates.first.map({ newestStart >= $0.startTime }) ?? true {
            reconstructionCandidates = behind.filter { $0.startTime == newestStart }
        }
        guard cues.contains(where: { $0.startTime >= playhead }) else {
            return []
        }
        reconstructing = false
        var out = cues.filter { $0.startTime > playhead }
        let active = reconstructionCandidates
        reconstructionCandidates = []
        // Round 8: close the emitted line at its successor's start. The successor's pgsTrimAt ran against the
        // store while this line was held here, so its open-ended placeholder survives; unclosed, both lines
        // cover the playhead from the successor's start until the NEXT composition trims, and two PGS bitmaps
        // stack on screen (ijuniorfu: "subtitles occasionally overlap"). With no published ahead cue the open
        // window stays and the store trim owns it, as before.
        let successorStart = out.map(\.startTime).min()
        for line in active where line.startTime <= playhead && playhead < line.endTime {
            out.append(line.with(endTime: min(line.endTime, successorStart ?? line.endTime)))
        }
        return out
    }

    /// #143 follow-up: end a reconstruction pass that never saw a composition at/after the playhead.
    /// `admitDuringReconstruction` flushes the candidate only when an at/after-playhead composition
    /// decodes (the pass-end trigger). A seek landing whose set is the newest composition in the drain
    /// window - the file's last line, or sparse/forced dialogue with the next line beyond the lead -
    /// has no such trigger, so the candidate would stay held and the overlay dark (tens of seconds, or
    /// forever at EOF). The drain calls this once it has confirmed a candidate is seeded and no
    /// successor is stored ahead in the lead window: the candidate active-line group (all same-start
    /// objects covering the playhead, #146) is emitted once and the pass ends. A candidate an author
    /// cleared before the playhead (trimmed by `resolveHeld`) no longer covers it and is not emitted,
    /// preserving the #143 no-resurrection invariant.
    mutating func finalizeReconstruction(playhead: Double) -> [SubtitleCue] {
        guard reconstructing else { return [] }
        reconstructing = false
        let active = reconstructionCandidates.filter { $0.startTime <= playhead && playhead < $0.endTime }
        reconstructionCandidates = []
        return active
    }

    /// Drop the hold without publishing (seek re-anchor, track switch, clear, stop).
    mutating func reset() {
        heldCues = []
        reconstructionCandidates = []
        reconstructing = false
    }
}
