import Darwin
import Foundation

// MARK: - Segment Provider Protocol

/// Source of HLS segment bytes for HLSLocalServer. Production implementation synthesizes segments lazily on AVPlayer fetch (2h 4K at 6s/10MB would otherwise require ~120 GB resident).
protocol HLSSegmentProvider: AnyObject {
    /// ftyp+moov init segment bytes. Nil until muxer produces one (live-audio bring-up).
    func initSegment() -> Data?

    /// Media segment bytes (0-based index). Nil if not yet available or out of range; server returns 404 for nil.
    func mediaSegment(at index: Int) -> Data?

    /// #93 round 3: like `mediaSegment(at:)`, but a serve that cannot deliver promptly invokes
    /// `onSlow` exactly once (and never after returning) so the server can emit an early chunked
    /// response header before AVPlayer's ~3.5 s time-to-first-byte -12889 window closes.
    /// Default forwards to `mediaSegment(at:)` without ever signalling.
    func mediaSegment(at index: Int, onSlow: (@Sendable () -> Void)?) -> Data?

    /// As above, but a VOD segment that is still being written may come back as a reader over it,
    /// which the server sends chunk by chunk (`LoadOptions.progressiveSegmentDelivery`). Default
    /// wraps `mediaSegment(at:onSlow:)`.
    func mediaSegmentSource(at index: Int, onSlow: (@Sendable () -> Void)?) -> SegmentSource?

    /// Optional file URL for disk-backed segments (cache adopt path). Server streams file -> socket bypassing Foundation Data; sendfile(2) was tried but SIGSYS'd on tvOS sandbox.
    /// Must name a file that exists: the server stats and opens it afterwards, and a URL whose file
    /// has gone is answered with an error response rather than the bytes the bookkeeping promised.
    func mediaSegmentURL(at index: Int) -> URL?

    /// AE#418 round 7: what became of a media-segment request. `delivered` is true once the whole
    /// response went out; false when it was refused or the write failed on a client that hung up.
    /// The axis is a statement about bytes in AVPlayer's timeline, so a placement composed from a
    /// request needs to know whether that request was answered. Default ignores it.
    func didServeMediaSegment(index: Int, delivered: Bool)

    /// One more chunk of a progressively delivered segment left the server: the request-counting
    /// wedge watchdog's evidence that AVPlayer is still reading. Default ignores it.
    func didDeliverProgressiveChunk(index: Int)

    var segmentCount: Int { get }
    func segmentDuration(at index: Int) -> Double

    /// True when segment i opens at a live PTS discontinuity; playlist builder prefixes #EXT-X-DISCONTINUITY so AVPlayer keeps its timeline continuous.
    func segmentIsDiscontinuous(at index: Int) -> Bool

    /// Init version a segment decodes against. 0 = session init; higher = SSAI program switch (ad creative changed codec params); playlist emits new EXT-X-MAP on change.
    func initVersionID(forSegment index: Int) -> Int

    func initSegment(versionID: Int) -> Data?

    var playlistType: HLSPlaylistType { get }

    /// Live cut-target seconds; playlist builder uses it as a TARGETDURATION floor so the first manifest (before seg0) doesn't yield TD=1 and -12888 on high-bitrate sources. Nil for VOD/EVENT.
    var liveTargetSegmentDuration: Double? { get }

    /// False for bursty ingest sources that can't honor the LL-HLS blocking-reload contract (held reloads only resolve on the next upstream batch; -15410).
    var liveBlockingReloadEnabled: Bool { get }

    /// Real upstream arrival cadence for bursty sources; raises TARGETDURATION so AVPlayer's 1.5x patience covers the inter-batch gap.
    var liveTargetDurationFloorSeconds: Double? { get }

    /// Session-stable TARGETDURATION for a live playlist. Production providers seal the first resolved
    /// value so later cadence or visible-segment growth cannot mutate RFC 8216 playlist timing.
    func liveTargetDurationSeconds(maxSegmentDuration: Double) -> Int
    var livePlaylistGeneration: Int { get }
    func livePlaylistEndIndex(generation: Int) -> Int?
    func liveTargetDurationSeconds(maxSegmentDuration: Double, generation: Int) -> Int

    /// #316: a master to serve VERBATIM instead of building one from the metadata below. The remote-HLS
    /// subtitle proxy fills this with the origin's own master, rewritten to absolute URIs plus the
    /// injected SUBTITLES renditions: its variants live at the origin, so there is nothing here to
    /// describe them with. Nil on every producer-backed provider, which builds its master as before.
    var staticMasterPlaylistBody: String? { get }

    /// Master-playlist metadata. When masterCodecs is non-nil the server publishes master.m3u8; nil means media-playlist-only.
    var masterCodecs: String? { get }
    var masterResolution: (width: Int, height: Int)? { get }
    var masterVideoRange: HLSVideoRange? { get }
    /// REQ-VIDEO-LAYOUT on EXT-X-STREAM-INF ("CH-STEREO" for a stereo session); nil omits it.
    var masterVideoLayout: String? { get }
    var masterBandwidth: Int? { get }

    /// SUPPLEMENTAL-CODECS on EXT-X-STREAM-INF. DV P8.1 = "dvh1.08.LL/db1p", P8.4 = "dvh1.08.LL/db4h"; P5 is nil (dvh1.05.LL goes in primary CODECS). AVPlayer's master-level codec filter silently drops variants whose primary CODECS it can't fall back to; bare dvh1 master stalled at fetch 2-3 without advancing to media.m3u8.
    var masterSupplementalCodecs: String? { get }

    var masterFrameRate: Double? { get }
    var masterAverageBandwidth: Int? { get }
    /// HDCP-LEVEL TYPE-1 required for resolutions >1920x1080 in HDR/DV (Apple Tech Talk 501).
    var masterHDCPLevel: String? { get }
    var masterClosedCaptions: String? { get }

    /// AE#458: the muxed audio track's language (ISO 639-2/T) and display NAME for the master's
    /// EXT-X-MEDIA:TYPE=AUDIO tag. Nil leaves the master without an audio group, which is what an
    /// untagged source gets. A muxed rendition carries no URI: the audio is inside the variant.
    /// AE#726: `language` is nil for an untagged E-AC-3 JOC track, which still gets a rendition because
    /// its CHANNELS is the only place the master can declare object audio.
    var masterAudioRendition: (language: String?, name: String)? { get }

    /// CHANNELS for that same EXT-X-MEDIA tag, nil to omit it. Apple's HLS Authoring Spec makes the
    /// attribute REQUIRED on an audio rendition, and Dolby's DD+ delivery kit makes it the ONLY
    /// playlist-level statement that a rendition carries objects: `"<n>/JOC"` (n = the JOC object
    /// count, `complexity_index_type_a`) for E-AC-3 + JOC, a bare channel count otherwise. Without it
    /// AVFoundation has nothing above the segment layer that says "object audio" and settles on the
    /// bed, which is how an Atmos stream-copy reached an Atmos-capable receiver as 5.1 PCM.
    var masterAudioChannels: String? { get }

    /// Native subtitle renditions (#15): one per text track, for the master EXT-X-MEDIA:TYPE=SUBTITLES tags
    /// and the /subs_{N} endpoints. Empty unless prepareNativeSubtitles is on and the cue stores are threaded.
    /// NAMEs must be unique within the group (duplicates collapse AVFoundation's legible options).
    var nativeSubtitleRenditions: [(ordinal: Int, language: String?, name: String, isForced: Bool)] { get }
    /// Ordinal advertised as DEFAULT=YES in the master SUBTITLES group (Sodalite#32).
    var nativeSubtitleDefaultOrdinal: Int { get }
    /// Serve the SUBTITLES rendition as one whole-program .vtt (single VOD segment) instead of per-video-segment (Sodalite#32).
    var nativeSubtitleWholeProgram: Bool { get }
    /// WebVTT body for one subtitle SEGMENT (#15): cues whose window overlaps video segment `segmentIndex` of
    /// `ordinal`. nil if either index is out of range. The subtitle media playlist mirrors the video media
    /// playlist one segment per video segment, so the embedded reader (parked ~90s ahead of the playhead)
    /// has the cues for a segment in the store by the time AVPlayer fetches it.
    func nativeSubtitleVTT(ordinal: Int, segmentIndex: Int) -> String?

    /// AE#682: true when this session lists an I-frame rendition in its master. The two calls below
    /// answer `iframe_init.mp4` and `iframe{N}.mp4`; both may block on a source read.
    var iFrameRenditionServed: Bool { get }
    /// What the rendition carries; nil reads as `.keyframes`.
    var iFrameRenditionFormat: IFrameRenditionFormat? { get }
    func iFrameInitSegment() -> Data?
    func iFrameSegment(at index: Int) -> Data?

    /// Atomic snapshot at the top of each playlist build. discontinuitySequence = EXT-X-DISCONTINUITY-tagged segments that slid out of the window (RFC 8216 §6.2.2 requires incrementing it; omission slips AVPlayer's discontinuity tracking one window per boundary). firstVisible in the same snapshot: a separate lock acquisition let a concurrent slide produce MEDIA-SEQUENCE newer than the count.
    func notePlaylistBuild() -> (visibleCount: Int, firstVisible: Int, refreshCounter: Int, endlistAdded: Bool, discontinuitySequence: Int)

    /// Index of the first segment visible in the current window (0 for VOD/EVENT; advances for live). Use notePlaylistBuild for playlist construction; this is for diagnostics.
    var firstVisibleSegmentIndex: Int { get }

    /// Block until at least one live segment is ready or timeout elapses. Holds the first live response so AVPlayer never sees an empty playlist (-12888).
    func waitForFirstLiveSegment(timeout: TimeInterval) -> Bool

    /// `LoadOptions.liveEdgeCushionSeconds` as validated: raises the served `HOLD-BACK` and, with it,
    /// the first-serve gate's depth and deadline. nil keeps `3 x TARGETDURATION`.
    var liveEdgeCushionSeconds: Double? { get }

    /// LL-HLS blocking reload: block until segment at absolute index exists. Holds AVPlayer's ?_HLS_msn= reload open so it receives the new segment the instant it is cut, not a poll-interval late.
    func waitForLiveSegment(index: Int, timeout: TimeInterval) -> Bool

    /// Sequential append playlist: block until the startup segments are finalized (or timeout).
    /// Same rationale as the live gate - AVPlayer treats an empty first playlist as a broken asset.
    func waitForSequentialStartupSegments(timeout: TimeInterval) -> Bool

    /// AE#446 round 2: the live source has stopped and the consumer still has resident segments ahead
    /// of it, so the served window is a finite asset until the source comes back. See
    /// `VideoSegmentProvider.liveOutageEndlist` for why nothing short of ENDLIST keeps AVPlayer fetching.
    var liveOutageEndlist: Bool { get }

    /// AE#454: which segment a rejoin wants the NEXT item to start on, and how far into it. nil on
    /// every build except the ones between an in-place rejoin swap and the item it placed running.
    var liveRejoinStart: (segmentIndex: Int, secondsIntoSegment: Double)? { get }

    /// AE#454 round 2: tell the provider what this build actually served for that placement, and from
    /// which first segment, so the item's axis is a statement rather than a later reconstruction.
    func noteServedLiveRejoinPlacement(timeOffset: Double, firstVisible: Int)

    /// AE#446 round 5: tell the provider which segment this build listed first, so the item loading it
    /// gets its axis from the manifest that placed it rather than from a later reconstruction. Every
    /// live build, not only the ones that also carry a rejoin placement.
    func noteServedLiveItemAxis(firstVisible: Int)

    /// Upper bound on how long a blocking reload may hold before the 503. Production providers derive
    /// it from the sealed TARGETDURATION (3 x TD, the HOLD-BACK depth) so a fastZap session (TD=2)
    /// times out in 6 s instead of 18 s — a hold that outlives AVPlayer's forward buffer guarantees
    /// the stall it was meant to prevent.
    var liveBlockingReloadHoldSeconds: TimeInterval { get }
}

extension HLSSegmentProvider {
    var livePlaylistGeneration: Int { 0 }
    func livePlaylistEndIndex(generation: Int) -> Int? { nil }
    func liveTargetDurationSeconds(maxSegmentDuration: Double, generation: Int) -> Int {
        liveTargetDurationSeconds(maxSegmentDuration: maxSegmentDuration)
    }

    func mediaSegment(at index: Int, onSlow: (@Sendable () -> Void)?) -> Data? { mediaSegment(at: index) }
    func mediaSegmentSource(at index: Int, onSlow: (@Sendable () -> Void)?) -> SegmentSource? {
        mediaSegment(at: index, onSlow: onSlow).map { .data($0) }
    }
    func mediaSegmentURL(at index: Int) -> URL? { nil }
    func didServeMediaSegment(index: Int, delivered: Bool) {}
    func didDeliverProgressiveChunk(index: Int) {}
    var staticMasterPlaylistBody: String? { nil }
    var firstVisibleSegmentIndex: Int { 0 }
    func segmentIsDiscontinuous(at index: Int) -> Bool { false }
    func initVersionID(forSegment index: Int) -> Int { 0 }
    func initSegment(versionID: Int) -> Data? { versionID == 0 ? initSegment() : nil }
    var masterCodecs: String? { nil }
    var masterResolution: (width: Int, height: Int)? { nil }
    var masterVideoRange: HLSVideoRange? { nil }
    var masterVideoLayout: String? { nil }
    var masterBandwidth: Int? { nil }
    var masterSupplementalCodecs: String? { nil }
    var masterFrameRate: Double? { nil }
    var masterAverageBandwidth: Int? { nil }
    var masterHDCPLevel: String? { nil }
    var masterClosedCaptions: String? { nil }
    var masterAudioRendition: (language: String?, name: String)? { nil }
    var masterAudioChannels: String? { nil }
    var nativeSubtitleRenditions: [(ordinal: Int, language: String?, name: String, isForced: Bool)] { [] }
    var nativeSubtitleDefaultOrdinal: Int { 0 }
    var nativeSubtitleWholeProgram: Bool { false }
    func nativeSubtitleVTT(ordinal: Int, segmentIndex: Int) -> String? { nil }
    var iFrameRenditionServed: Bool { false }
    var iFrameRenditionFormat: IFrameRenditionFormat? { nil }
    func iFrameInitSegment() -> Data? { nil }
    func iFrameSegment(at index: Int) -> Data? { nil }
    var liveTargetSegmentDuration: Double? { nil }
    var liveRejoinStart: (segmentIndex: Int, secondsIntoSegment: Double)? { nil }
    func noteServedLiveRejoinPlacement(timeOffset: Double, firstVisible: Int) {}
    func noteServedLiveItemAxis(firstVisible: Int) {}
    var liveBlockingReloadEnabled: Bool { true }
    var liveTargetDurationFloorSeconds: Double? { nil }
    func liveTargetDurationSeconds(maxSegmentDuration: Double) -> Int {
        LiveEdgePolicy.targetDurationSeconds(
            maxSegmentDuration: maxSegmentDuration,
            cutTargetSeconds: liveTargetSegmentDuration,
            cadenceFloorSeconds: liveTargetDurationFloorSeconds
        )
    }
    func waitForFirstLiveSegment(timeout: TimeInterval) -> Bool { true }
    var liveEdgeCushionSeconds: Double? { nil }
    func waitForLiveSegment(index: Int, timeout: TimeInterval) -> Bool { true }
    func waitForSequentialStartupSegments(timeout: TimeInterval) -> Bool { true }
    var liveBlockingReloadHoldSeconds: TimeInterval { 18.0 }
    var liveOutageEndlist: Bool { false }
    func notePlaylistBuild() -> (visibleCount: Int, firstVisible: Int, refreshCounter: Int, endlistAdded: Bool, discontinuitySequence: Int) {
        return (visibleCount: segmentCount, firstVisible: 0, refreshCounter: 0, endlistAdded: false, discontinuitySequence: 0)
    }
}

enum HLSPlaylistType: Equatable {
    /// EXT-X-PLAYLIST-TYPE:EVENT, no ENDLIST. Append-only; segments never removed (audio-append path). NOT for sliding live (EVENT forbids removal).
    case event
    /// EXT-X-PLAYLIST-TYPE:VOD, ENDLIST present. Finite-duration video files.
    case vod
    /// No PLAYLIST-TYPE tag, no ENDLIST; MEDIA-SEQUENCE advances as old segments fall off (RFC 8216 §4.3.3.5: EVENT forbids removal, VOD implies finished; sliding window must omit the tag).
    case live
}

enum HLSVideoRange: String {
    case sdr = "SDR"
    case pq = "PQ"
    case hlg = "HLG"
}

/// A served master's DV form (#98). `.primary` is the DV/HDR master start() chose. `.reducedHDR` drops
/// SUPPLEMENTAL-CODECS (DV signaling) but keeps the source range and the SUBTITLES renditions, for the
/// #35 cold-DV-start gate on an HDR TV. (An SDR-forcing variant was tried and reverted: VIDEO-RANGE=SDR
/// does not fool the external-display compatibility gate, so HDR/DV on an SDR display stays media-only.)
enum MasterPlaylistVariant: Equatable {
    case primary
    case reducedHDR
}

// MARK: - Local HLS Server

/// Loopback HTTP/BSD-socket server feeding HLS-fMP4 to AVPlayer. Uses Darwin BSD sockets, not NWConnection: NWConnection's send path retained segment bytes across contentProcessed causing ~3 MB/sec RSS growth on 4K HEVC (AetherEngine#4). BSD + mmap-backed Data gives kernel-to-kernel copy with zero heap allocation per segment.
///
/// Endpoints: /master.m3u8 (when provider has master metadata; required for DV VIDEO-RANGE=PQ on EXT-X-STREAM-INF), /media.m3u8, /init.mp4, /seg{N}.mp4. Threading: one acceptQueue loop, concurrent workQueue handlers with blocking recv/send. Listens on 127.0.0.1; IP literal avoids DNS resolver dependency.
final class HLSLocalServer: @unchecked Sendable {

    // MARK: - Provider

    private weak var provider: HLSSegmentProvider?

    // MARK: - Public state

    /// Per-session capability token, first component of every path this server answers.
    /// The listener binds 0.0.0.0 so an AirPlay receiver can reach it over the LAN (#86), which
    /// also puts it in front of every other host on that network. The endpoint names are fixed,
    /// so without this the ephemeral port is the only thing between a stranger's port scan and
    /// the stream. It costs nothing to carry: playlist URIs are relative, so they resolve under
    /// the prefix on their own, and only the three entry-point accessors below have to name it.
    let pathToken: String = {
        var bytes = [UInt8](repeating: 0, count: 16)
        var generator = SystemRandomNumberGenerator()
        for i in bytes.indices { bytes[i] = UInt8.random(in: UInt8.min...UInt8.max, using: &generator) }
        return bytes.map { String(format: "%02x", $0) }.joined()
    }()

    /// The request path with the session token removed, or nil when the request does not carry it.
    /// Static and internal so the check is unit-testable without a live socket.
    static func pathAfterToken(_ token: String, in path: String) -> String? {
        let prefix = "/" + token
        guard path.hasPrefix(prefix) else { return nil }
        let rest = String(path.dropFirst(prefix.count))
        guard rest.hasPrefix("/") else { return nil }
        return rest
    }

    /// The request line as it is logged: the route after the session token, never the token itself
    /// (audit SUB-107).
    static func requestLineForLog(method: Substring, routePath: String, query: String,
                                  version: Substring?) -> String {
        var line = "\(method) \(routePath)"
        if !query.isEmpty { line += "?\(query)" }
        if let version { line += " \(version)" }
        return escapedForLog(line)
    }

    /// The headers whose values the first-request dump shows: the capability headers it exists for
    /// (#50), and the address the client used (#86). Nothing that carries a credential.
    static let loggedRequestHeaderValues: Set<String> = [
        "accept", "host", "range", "user-agent", "x-playback-session-id",
    ]

    /// Audit Vcred-102: on the #316 / AE#495 stand-in route AVPlayer sends the host's own headers to
    /// this server too, credentials included (measured), so the dump names every header and prints a
    /// value only where `loggedRequestHeaderValues` says it answers a question.
    static func requestHeadersForLog(_ headerLines: [String]) -> String {
        headerLines.map { line -> String in
            guard let colon = line.firstIndex(of: ":") else { return "?" }
            let name = line[..<colon].trimmingCharacters(in: .whitespaces)
            let shown = loggedRequestHeaderValues.contains(name.lowercased()) ? line : name
            return escapedForLog(shown, limit: maximumStrangerText)
        }.joined(separator: " | ")
    }

    /// Longest stretch of a stranger's request text a log line carries. A head may be 8 KB, and one
    /// line of that per interval would still crowd a small log ring.
    static let maximumStrangerText = 256

    /// Request text as a log line may carry it: C0 controls and DEL escaped, so a bare LF cannot forge
    /// a line of its own (audit NET-111), and cut after `limit` characters. Done here rather than in
    /// `EngineLog`, which passes the multi-line playlist bodies this server logs on purpose.
    static func escapedForLog(_ text: String, limit: Int = .max) -> String {
        var out = ""
        var count = 0
        for scalar in text.unicodeScalars {
            if count >= limit {
                out += "..."
                break
            }
            if scalar.value < 0x20 || scalar.value == 0x7F {
                out += String(format: "\\x%02X", scalar.value)
            } else {
                out.unicodeScalars.append(scalar)
            }
            count += 1
        }
        return out
    }

    /// Kernel-assigned ephemeral port. Zero until start() succeeds.
    private(set) var port: UInt16 = 0

    /// URL passed to AVPlayer. Points at master.m3u8 when the provider has master metadata, else media.m3u8.
    var playlistURL: URL? {
        stateLock.lock()
        defer { stateLock.unlock() }
        guard port > 0 else { return nil }
        // #316: a static master has no masterCodecs of its own (its variants live at the origin), but it
        // is still the playlist AVPlayer must open, or the injected renditions never reach media selection.
        let hasMaster = provider?.masterCodecs != nil || provider?.staticMasterPlaylistBody != nil
        let path = hasMaster ? "master.m3u8" : "media.m3u8"
        return URL(string: "http://127.0.0.1:\(port)/\(pathToken)/\(livePlaylistPrefix)\(path)")
    }

    private var livePlaylistPrefix: String {
        let generation = provider?.livePlaylistGeneration ?? 0
        return generation == 0 ? "" : "live-\(generation)/"
    }

    func renewedLivePlaylistURL(replacing url: URL) -> URL? {
        stateLock.lock(); defer { stateLock.unlock() }
        guard port > 0, provider?.playlistType == .live,
              url.port == Int(port), Self.pathAfterToken(pathToken, in: url.path) != nil else { return nil }
        var components = URLComponents(url: url, resolvingAgainstBaseURL: false)
        components?.path = "/\(pathToken)/\(livePlaylistPrefix)\(url.lastPathComponent)"
        return components?.url
    }

    static func livePlaylistRoute(_ path: String) -> (path: String, generation: Int) {
        let parts = path.split(separator: "/", maxSplits: 1)
        guard parts.count == 2, parts[0].hasPrefix("live-"),
              let generation = Int(parts[0].dropFirst(5)), generation > 0 else { return (path, 0) }
        return ("/" + parts[1], generation)
    }

    /// Direct media.m3u8 URL, bypassing master-playlist variant selection (used when the DV/HDR handshake is unavailable so AVPlayer doesn't try to match a dvh1 master on an SDR panel).
    var mediaPlaylistURL: URL? {
        stateLock.lock()
        defer { stateLock.unlock() }
        guard port > 0 else { return nil }
        return URL(string: "http://127.0.0.1:\(port)/\(pathToken)/\(livePlaylistPrefix)media.m3u8")
    }

    /// HDR-preserving reduced master (#98): source VIDEO-RANGE kept, no SUPPLEMENTAL-CODECS
    /// (DV dropped), subtitle renditions kept, for the #35 cold-DV-start gate on an HDR TV.
    var reducedHDRMasterPlaylistURL: URL? {
        stateLock.lock()
        defer { stateLock.unlock() }
        guard port > 0, provider?.masterCodecs != nil else { return nil }
        return URL(string: "http://127.0.0.1:\(port)/\(pathToken)/\(livePlaylistPrefix)master_hdr.m3u8")
    }

    /// Numeric address of the peer on an accepted connection, or nil if the socket is already gone (#227 diag).
    static func peerAddress(of fd: Int32) -> String? {
        var storage = sockaddr_storage()
        var length = socklen_t(MemoryLayout<sockaddr_storage>.size)
        let named = withUnsafeMutablePointer(to: &storage) { pointer in
            pointer.withMemoryRebound(to: sockaddr.self, capacity: 1) { getpeername(fd, $0, &length) == 0 }
        }
        guard named else { return nil }
        var host = [CChar](repeating: 0, count: Int(NI_MAXHOST))
        let resolved = withUnsafePointer(to: &storage) { pointer in
            pointer.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                getnameinfo($0, length, &host, socklen_t(host.count), nil, 0, NI_NUMERICHOST)
            }
        }
        guard resolved == 0 else { return nil }
        let terminator = host.firstIndex(of: 0) ?? host.endIndex
        return String(decoding: host[..<terminator].map { UInt8(bitPattern: $0) }, as: UTF8.self)
    }

    /// The device's active LAN IPv4 address for the AirPlay LAN-host swap (#86), or nil (caller keeps
    /// 127.0.0.1). DrHurt's caveat: en0 isn't always the active interface on multi-NIC / Ethernet devices.
    /// We scan `en*` interfaces (WiFi + wired Ethernet/Thunderbolt; cellular pdp_ip*, VPN utun*, AirDrop awdl*
    /// are excluded by the prefix) and prefer en0 (WiFi on Apple devices), falling back to the lowest-numbered
    /// wired en* otherwise. Synchronous getifaddrs (NWPathMonitor is async and would stall the reload path);
    /// the rare both-WiFi-and-Ethernet case picks WiFi, which is the usual AirPlay route.
    static func localActiveIPAddress() -> String? {
        var ifaddr: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&ifaddr) == 0, let first = ifaddr else { return nil }
        defer { freeifaddrs(ifaddr) }
        var byInterface: [String: String] = [:]
        for ptr in sequence(first: first, next: { $0.pointee.ifa_next }) {
            let flags = Int32(ptr.pointee.ifa_flags)
            guard (flags & (IFF_UP | IFF_RUNNING | IFF_LOOPBACK)) == (IFF_UP | IFF_RUNNING),
                  let sa = ptr.pointee.ifa_addr, sa.pointee.sa_family == UInt8(AF_INET) else { continue }
            let name = String(cString: ptr.pointee.ifa_name)
            guard name.hasPrefix("en") else { continue }
            var host = [CChar](repeating: 0, count: Int(NI_MAXHOST))
            if getnameinfo(sa, socklen_t(sa.pointee.sa_len), &host, socklen_t(host.count),
                           nil, 0, NI_NUMERICHOST) == 0 {
                byInterface[name] = host.withUnsafeBufferPointer { String(cString: $0.baseAddress!) }
            }
        }
        if let wifi = byInterface["en0"] { return wifi }
        return byInterface.keys.sorted().compactMap { byInterface[$0] }.first
    }

    /// Number of segments currently published.
    var segmentCount: Int {
        provider?.segmentCount ?? 0
    }

    // MARK: - Private state

    private var listenFd: Int32 = -1
    private var shouldStop = false
    /// Bumped by every start and stop, so an accept loop from an earlier start exits even when a
    /// later start has cleared `shouldStop` again.
    private var listenGeneration: UInt64 = 0
    private var clientFds = Set<Int32>()

    /// Audit SUB-107: whether `pathToken` is registered with the log redactor. The token is the
    /// capability that keeps LAN strangers off the stream, and every line that prints a server URL
    /// (`load url=`, `asset.url=`, the #316 serving line) would otherwise hand it to a shared log
    /// for as long as the session lives.
    private var tokenRegistered = false

    /// Active connection count; engine memory probe watches for unexpectedly rising accumulation (AVPlayer normally holds 1-3 connections).
    var activeConnectionCount: Int {
        stateLock.lock()
        defer { stateLock.unlock() }
        return clientFds.count
    }

    /// Lifetime bytes sent (all responses). Compared against muxer's muxBytesMB in the engine memprobe to confirm no duplicate sends or dropped bytes.
    private let byteCounterLock = NSLock()
    private var _lifetimeBytesSent: Int = 0
    var lifetimeBytesSent: Int {
        byteCounterLock.lock()
        defer { byteCounterLock.unlock() }
        return _lifetimeBytesSent
    }
    private var _requestCount: Int = 0
    var requestCount: Int {
        byteCounterLock.lock()
        defer { byteCounterLock.unlock() }
        return _requestCount
    }
    private func bumpBytesSent(_ n: Int) {
        guard n > 0 else { return }
        byteCounterLock.lock()
        _lifetimeBytesSent &+= n
        byteCounterLock.unlock()
    }

    /// Lifetime bytes sent via the file-streaming fast path (file -> socket, no Swift Data). Used to verify the fast path is taken.
    private var _lifetimeSendfileBytes: Int = 0
    var lifetimeSendfileBytes: Int {
        byteCounterLock.lock()
        defer { byteCounterLock.unlock() }
        return _lifetimeSendfileBytes
    }
    private func bumpSendfileBytes(_ n: Int) {
        guard n > 0 else { return }
        byteCounterLock.lock()
        _lifetimeSendfileBytes &+= n
        byteCounterLock.unlock()
    }

    private var loggedMasterPlaylist = false
    /// #227: set the first time any media byte is served this session (init segment or a media segment).
    /// The AirPlay progress watchdog needs to tell "the receiver refused the manifest" from "the clock is
    /// not moving for some other reason", and a receiver that refuses never asks for a segment at all.
    private var servedMediaBytes = false
    /// True once the session has served an init or media segment to anyone (#227).
    var hasServedMediaSegment: Bool {
        stateLock.lock()
        defer { stateLock.unlock() }
        return servedMediaBytes
    }

    /// AE#682: how long `iframe.m3u8` waits for the first media segment request when the rendition is
    /// SDR JPEG next to an HDR variant. AVPlayer asks for the main variant's segments before the I-frame
    /// playlist; one that refused the HDR variant never asks for a segment, and would otherwise play the
    /// stills as the video instead of failing into the media-playlist fallback.
    static let iFrameMainVariantWaitSeconds: TimeInterval = 3

    private var _iFrameRenditionWithheld = false
    /// True once `iframe.m3u8` was answered 404 because no media segment was requested: AVPlayer refused
    /// the HDR variant, and the item fails with the 404's -1100 instead of a display rejection code.
    var iFrameRenditionWithheld: Bool {
        stateLock.lock(); defer { stateLock.unlock() }
        return _iFrameRenditionWithheld
    }

    /// True once a media segment was requested, waiting up to `iFrameMainVariantWaitSeconds`.
    private func waitForMainVariant() -> Bool {
        let deadline = Date().addingTimeInterval(Self.iFrameMainVariantWaitSeconds)
        while true {
            stateLock.lock()
            let served = servedMediaBytes, stopping = shouldStop
            stateLock.unlock()
            if served { return true }
            guard !stopping, Date() < deadline else {
                stateLock.lock(); _iFrameRenditionWithheld = !stopping; stateLock.unlock()
                return false
            }
            Thread.sleep(forTimeInterval: 0.025)
        }
    }

    private var loggedReducedMasterPlaylist = false
    private var loggedMediaPlaylist = false
    private var loggedRequestHeaders = false
    /// #227 diag: every distinct client address seen this session, logged once each. AirPlay is supposed to
    /// hand the playlist URL to the receiver, so a receiver address must show up here while AirPlaying; only
    /// ever seeing the sender's own address would mean the sender pulls the media and the LAN-IP rewrite is
    /// solving a problem that does not exist.
    private var loggedPeers: Set<String> = []
    private var mediaPlaylistBuildCount = 0  // periodic re-log of live playlist head/tail

    private let stateLock = NSLock()  // guards all mutable fields; never held across blocking syscalls

    /// The accept loop and every connection handler run on threads this server owns, not on
    /// dispatch queues. Both block by design: accept sits in a syscall for the server's whole life,
    /// and a handler blocks in `UpstreamPump` while the origin feeds it. A queue hands that work a
    /// GLOBAL POOL worker, and the pool hands out a worker only once one is free, so a process
    /// whose pool workers are all in a blocking wait leaves a connection unserved for as long as
    /// that lasts: the client then reads a dead server. Measured with 192 pool workers blocked, a
    /// `DispatchQueue.global().async` block had not started after 35 s while a detached thread ran
    /// in 3 ms. Same reason the pump owns its thread since AE#286.
    static let maxConcurrentConnections = 32
    private var liveConnectionThreads = 0

    /// Audit NET-6: the listener has to answer the LAN while an AirPlay receiver fetches from it
    /// (#86), and the session token is only read once a whole request head has arrived. So a peer
    /// that is not loopback may hold at most this many of the slots, and the rest stay free for
    /// the local player however many connections a LAN host opens.
    static let maxNonLoopbackConnections = 24
    private var liveNonLoopbackConnections = 0

    /// Audit NET-6: a connection that has not yet presented this session's token has this long,
    /// from accept, to deliver a whole request head. Without it a trickling or idle LAN peer holds
    /// its slot for as long as it keeps sending a byte inside the per-recv timeout.
    static let unauthenticatedHeadSeconds: TimeInterval = 10
    /// Once a request's first byte has arrived, the rest of its head must follow within this long,
    /// on a connection that already authenticated too. The idle wait before that byte stays at
    /// `keepAliveIdleSeconds`, which AVPlayer's keep-alive gaps need.
    static let requestHeadSeconds: TimeInterval = 10
    static let keepAliveIdleSeconds: TimeInterval = 60

    /// Audit NET-13: one line per failed accept, when the process is out of descriptors, is a busy
    /// loop that floods the host's log ring. Failures back off and their line is rate limited.
    private static let acceptFailureBackoffMicroseconds: useconds_t = 100_000
    /// How long the accept loop waits for a connection before it checks for a stop again. Also the
    /// longest a stopped server keeps its port.
    static let acceptPollMilliseconds: Int32 = 100
    private var acceptFailureLog = LogThrottle(interval: 5)
    private var refusalLog = LogThrottle(interval: 5)
    /// Audit NET-111: every line a connection that never presented the token can cause shares this, so
    /// a LAN peer looping short connections costs the host's log one line per interval, not two per
    /// request.
    private var strangerLog = LogThrottle(interval: 5)

    // MARK: - Init

    /// When set (e.g. `aether-engine://engine/`), segment URIs in the playlist are absolute custom-scheme URLs routed through AVAssetResourceLoader. Nil emits relative URIs for the aetherctl HTTP workflow.
    private let subResourceBaseURL: URL?

    /// AE#495: fetches a remote origin on this server's behalf. Mounted when a host has set
    /// `EngineTLS.serverTrustEvaluator`, so the https handshake happens where that answer is
    /// read instead of inside AVPlayer's own networking.
    let relay: HLSOriginRelay?

    /// A relay-only server has no provider: nothing here produces segments, every byte comes
    /// from the origin, and the master is whatever the origin served.
    init(provider: HLSSegmentProvider? = nil, subResourceBaseURL: URL? = nil,
         relay: HLSOriginRelay? = nil,
         unauthenticatedHeadSeconds: TimeInterval = HLSLocalServer.unauthenticatedHeadSeconds) {
        self.provider = provider
        self.subResourceBaseURL = subResourceBaseURL
        self.relay = relay
        self.unauthenticatedHeadDeadline = unauthenticatedHeadSeconds
    }

    private let unauthenticatedHeadDeadline: TimeInterval

    /// Allows `origin` on the relay and returns the address standing in for it, for a player
    /// pointed at the relay rather than at a provider's playlists. Grants no credentials: that is
    /// the caller's decision, for a URL the host handed over (audit NET-109). Nil before `start()`
    /// or with no relay mounted.
    func relayURL(for origin: URL) -> URL? {
        guard let relay, relay.allow(origin) != nil else { return nil }
        stateLock.lock()
        let listeningPort = port
        stateLock.unlock()
        guard listeningPort > 0 else { return nil }
        return relay.localURL(for: origin, port: listeningPort, token: pathToken)
    }

    // MARK: - Lifecycle

    func start() throws {
        // SOCK_STREAM = TCP, IPPROTO_TCP = 6.
        let fd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)
        guard fd >= 0 else {
            throw HLSLocalServerError.socketCreate(errno: errno)
        }

        // SO_REUSEADDR avoids "Address already in use" when the
        // previous server's TIME_WAIT entries haven't cleared yet.
        var on: Int32 = 1
        _ = setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &on,
                       socklen_t(MemoryLayout<Int32>.size))
        // SO_NOSIGPIPE prevents SIGPIPE when the client closes the
        // socket mid-write. Without this a closed peer kills the
        // process. send() returns EPIPE instead, which we handle.
        _ = setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &on,
                       socklen_t(MemoryLayout<Int32>.size))

        var addr = sockaddr_in()
        addr.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
        addr.sin_family = sa_family_t(AF_INET)
        addr.sin_port = 0 // kernel picks ephemeral
        // Bind all interfaces (not just loopback) so an AirPlay receiver can reach the stream over the LAN
        // via the device's WiFi IP (#86, DrHurt). Local playback still uses 127.0.0.1; the URL host is only
        // swapped to the LAN IP while external playback is active. Ephemeral port, serves the current stream only.
        // Audit NET-6 kept this rather than binding loopback until AirPlay engages: the wireless edge reloads
        // onto a new server, but a readiness-gate swap (`airPlayHostSwapped`) and a held edge re-read after a
        // reload hand the LAN URL to the server already listening. LAN exposure is bounded instead by the
        // head deadlines and the loopback reserve in the accept loop.
        addr.sin_addr.s_addr = inet_addr("0.0.0.0")

        let bindResult = withUnsafePointer(to: &addr) { ptr -> Int32 in
            ptr.withMemoryRebound(to: sockaddr.self, capacity: 1) { sa in
                Darwin.bind(fd, sa, socklen_t(MemoryLayout<sockaddr_in>.size))
            }
        }
        guard bindResult == 0 else {
            let err = errno
            close(fd)
            throw HLSLocalServerError.bind(errno: err)
        }

        // backlog=16 is plenty: AVPlayer typically opens 1-3 conns.
        guard listen(fd, 16) == 0 else {
            let err = errno
            close(fd)
            throw HLSLocalServerError.listen(errno: err)
        }

        // Read back the assigned port.
        var actual = sockaddr_in()
        var actualLen = socklen_t(MemoryLayout<sockaddr_in>.size)
        let getNameResult = withUnsafeMutablePointer(to: &actual) { ptr -> Int32 in
            ptr.withMemoryRebound(to: sockaddr.self, capacity: 1) { sa in
                getsockname(fd, sa, &actualLen)
            }
        }
        guard getNameResult == 0 else {
            let err = errno
            close(fd)
            throw HLSLocalServerError.getsockname(errno: err)
        }
        let assignedPort = UInt16(bigEndian: actual.sin_port)

        stateLock.lock()
        listenFd = fd
        port = assignedPort
        shouldStop = false
        listenGeneration &+= 1
        let generation = listenGeneration
        if !tokenRegistered {
            tokenRegistered = LogRedaction.register(pathToken)
        }
        stateLock.unlock()

        EngineLog.emit("[HLSLocalServer] Listening on port \(assignedPort)",
                       category: .hlsServer)

        let accepter = Thread { [weak self] in
            guard let self else { close(fd); return }
            self.acceptLoop(listenFd: fd, generation: generation)
        }
        accepter.name = "com.aetherengine.hls.accept"
        accepter.qualityOfService = .userInitiated
        accepter.start()
    }

    func stop() {
        stateLock.lock()
        shouldStop = true
        listenFd = -1
        listenGeneration &+= 1
        let closingPort = port
        port = 0
        loggedMasterPlaylist = false
        loggedReducedMasterPlaylist = false
        loggedMediaPlaylist = false
        mediaPlaylistBuildCount = 0
        // Under the lock: a handler removes its fd here before it closes it, so a number still in the
        // set is still that handler's. Shut down outside the lock, the handler could close in between
        // and the number go to another socket in the process, whose connection this then ended
        // (an origin read with no response, a body cut short).
        for fd in clientFds { shutdown(fd, SHUT_RDWR) }
        let clientCount = clientFds.count
        clientFds.removeAll()
        let unregisterToken = tokenRegistered
        tokenRegistered = false
        stateLock.unlock()
        // Last, so a line still in flight from a connection being shut down is redacted too; the
        // token opens nothing once the listener is gone.
        defer { if unregisterToken { LogRedaction.unregister(pathToken) } }
        // AE#597: the one line that says a listener went away. Without it a log cannot tell a
        // server that was released from one that outlived its session on a port of its own.
        EngineLog.emit(
            "[HLSLocalServer] stop: port \(closingPort) released, \(clientCount) connection(s) "
            + "shut down", category: .hlsServer)
        // The listen fd is not closed here: the accept loop owns it and closes it on its way out.
        // Closing it from this thread freed the number while that loop could still call accept on
        // it, and the next socket in the process to get the number lost a connection to it.
        // shutdown() does not wake a blocked accept on Darwin, so the loop polls instead.
    }

    // MARK: - Accept loop

    private func acceptLoop(listenFd fd: Int32, generation: UInt64) {
        defer { close(fd) }
        while true {
            stateLock.lock()
            let current = !shouldStop && listenGeneration == generation
            stateLock.unlock()
            if !current { return }

            var pfd = pollfd(fd: fd, events: Int16(POLLIN), revents: 0)
            let ready = poll(&pfd, 1, Self.acceptPollMilliseconds)
            if ready == 0 { continue }
            if ready < 0 {
                if errno == EINTR { continue }
                return
            }

            var clientAddr = sockaddr_in()
            var clientLen = socklen_t(MemoryLayout<sockaddr_in>.size)
            let clientFd = withUnsafeMutablePointer(to: &clientAddr) { ptr -> Int32 in
                ptr.withMemoryRebound(to: sockaddr.self, capacity: 1) { sa in
                    accept(fd, sa, &clientLen)
                }
            }
            if clientFd < 0 {
                let err = errno
                if err == EBADF || err == EINVAL {
                    return
                }
                // EINTR / EAGAIN: spurious wakeup, retry. ECONNABORTED:
                // a backlogged connection was torn down before accept
                // picked it up (normal during stop()); retry quietly, the
                // loop-top stop check exits if we're shutting down.
                if err == EINTR || err == EAGAIN || err == ECONNABORTED {
                    continue
                }
                // EMFILE / ENFILE leave the connection in the backlog, so the next accept fails at
                // once; without the pause this thread spins.
                stateLock.lock()
                let logLine = acceptFailureLog.admit(now: Self.uptimeSeconds())
                stateLock.unlock()
                if let suppressed = logLine {
                    EngineLog.emit("[HLSLocalServer] accept failed errno=\(err)"
                                   + (suppressed > 0 ? " (\(suppressed) more since the last line)" : "")
                                   + ", backing off", category: .hlsServer)
                }
                usleep(Self.acceptFailureBackoffMicroseconds)
                continue
            }
            let isLoopbackPeer = clientAddr.sin_family == sa_family_t(AF_INET)
                && (UInt32(bigEndian: clientAddr.sin_addr.s_addr) >> 24) == 127

            // SO_NOSIGPIPE on the accepted socket too, otherwise a
            // closed-peer send still raises SIGPIPE on iOS.
            var on: Int32 = 1
            _ = setsockopt(clientFd, SOL_SOCKET, SO_NOSIGPIPE, &on,
                           socklen_t(MemoryLayout<Int32>.size))
            let acceptedAt = Self.uptimeSeconds()

            stateLock.lock()
            // A thread per connection has no ceiling of its own, where the pool's 64 workers were
            // one. AVPlayer keeps a handful open, so anything near this number is a client that
            // has stopped making sense and gets the socket closed rather than a thread.
            let atCapacity = liveConnectionThreads >= Self.maxConcurrentConnections
                || (!isLoopbackPeer && liveNonLoopbackConnections >= Self.maxNonLoopbackConnections)
            var refusalLine: Int?
            if !atCapacity {
                liveConnectionThreads += 1
                if !isLoopbackPeer { liveNonLoopbackConnections += 1 }
                clientFds.insert(clientFd)
            } else {
                refusalLine = refusalLog.admit(now: acceptedAt)
            }
            stateLock.unlock()

            if atCapacity {
                if let suppressed = refusalLine {
                    EngineLog.emit(
                        "[HLSLocalServer] refusing fd=\(clientFd) (\(isLoopbackPeer ? "loopback" : "LAN") peer): "
                        + "connection slots full"
                        + (suppressed > 0 ? " (\(suppressed) more refused since the last line)" : ""),
                        category: .hlsServer)
                }
                close(clientFd)
                continue
            }

            EngineLog.emit("[HLSLocalServer] conn opened fd=\(clientFd)",
                           category: .hlsServer, level: .verbose)

            let worker = Thread { [weak self] in
                defer {
                    self?.stateLock.lock()
                    self?.liveConnectionThreads -= 1
                    if !isLoopbackPeer { self?.liveNonLoopbackConnections -= 1 }
                    self?.stateLock.unlock()
                }
                self?.handleConnection(clientFd, acceptedAt: acceptedAt)
            }
            worker.name = "com.aetherengine.hls.conn.\(clientFd)"
            worker.qualityOfService = .userInitiated
            worker.start()
        }
    }

    // MARK: - Per-connection handler

    private func handleConnection(_ fd: Int32, acceptedAt: TimeInterval) {
        defer {
            stateLock.lock()
            clientFds.remove(fd)
            stateLock.unlock()
            close(fd)
            EngineLog.emit("[HLSLocalServer] conn closed fd=\(fd)",
                           category: .hlsServer, level: .verbose)
        }

        // HTTP/1.1 keep-alive loop: AVPlayer reuses connections across segment fetches. Connection:close per-request tried 2026-05-20; Instruments showed it shifted the leak from libnetwork into a 570 MiB Malloc heap bucket instead (strictly worse; reverted).
        // Every request that comes back true passed the session token check in `processRequest`,
        // so after the first one the connection has shown it was handed a URL by this engine.
        var authenticated = false
        while true {
            stateLock.lock()
            let stopping = shouldStop
            stateLock.unlock()
            if stopping { return }
            let firstByteDeadline = authenticated
                ? Self.uptimeSeconds() + Self.keepAliveIdleSeconds
                : acceptedAt + unauthenticatedHeadDeadline
            guard let request = readHTTPRequest(
                fd, firstByteDeadline: firstByteDeadline, authenticated: authenticated) else { return }
            guard processRequest(request, on: fd, authenticated: authenticated) else { return }
            authenticated = true
        }
    }

    /// Read until end of HTTP headers (`\r\n\r\n`). Returns the raw
    /// request bytes (headers only, no body, since we only accept
    /// GET). Returns nil on EOF, error, oversize, or a missed deadline.
    ///
    /// The deadlines are totals rather than per-recv timeouts (audit NET-6): the first byte must
    /// arrive by `firstByteDeadline`, and the whole head within `requestHeadSeconds` of it, and an
    /// unauthenticated connection also by `firstByteDeadline`. A peer sending one byte a minute
    /// used to keep a slot for as long as the head had room.
    private func readHTTPRequest(_ fd: Int32, firstByteDeadline: TimeInterval,
                                 authenticated: Bool) -> Data? {
        var buffer = Data()
        var chunk = [UInt8](repeating: 0, count: 4096)
        var deadline = firstByteDeadline
        while true {
            let remaining = deadline - Self.uptimeSeconds()
            guard remaining > 0, Self.setReceiveTimeout(fd, seconds: remaining) else {
                // A stranger that never finished a head is expected noise on a LAN listener, and
                // one line each would let it scroll the host's log ring.
                EngineLog.emit("[HLSLocalServer] request head deadline passed fd=\(fd) bytes=\(buffer.count)"
                               + (authenticated ? "" : " (connection never authenticated)"),
                               category: .hlsServer, level: authenticated ? .info : .verbose)
                return nil
            }
            let n = chunk.withUnsafeMutableBufferPointer { ptr -> Int in
                recv(fd, ptr.baseAddress, ptr.count, 0)
            }
            if n == 0 {
                if buffer.isEmpty { return nil }
                emitRequestProblem("[HLSLocalServer] peer EOF mid-request fd=\(fd)",
                                   authenticated: authenticated)
                return nil
            }
            if n < 0 {
                let err = errno
                if err == EINTR { continue }
                if err == EAGAIN || err == EWOULDBLOCK {
                    EngineLog.emit("[HLSLocalServer] recv timeout fd=\(fd)",
                                   category: .hlsServer, level: authenticated ? .info : .verbose)
                    return nil
                }
                emitRequestProblem("[HLSLocalServer] recv error fd=\(fd) errno=\(err)",
                                   authenticated: authenticated)
                return nil
            }
            if buffer.isEmpty {
                deadline = min(deadline, Self.uptimeSeconds() + Self.requestHeadSeconds)
            }
            buffer.append(chunk, count: n)
            if let end = findHeadersTerminator(buffer) {
                return buffer.prefix(end + 4)
            }
            if buffer.count > 8192 {
                emitRequestProblem("[HLSLocalServer] request too large fd=\(fd) bytes=\(buffer.count)",
                                   authenticated: authenticated)
                return nil
            }
        }
    }

    private static func setReceiveTimeout(_ fd: Int32, seconds: TimeInterval) -> Bool {
        let whole = Int(seconds)
        var timeout = timeval(
            tv_sec: whole, tv_usec: Int32(max(1, (seconds - Double(whole)) * 1_000_000)))
        return setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &timeout,
                          socklen_t(MemoryLayout<timeval>.size)) == 0
    }

    private static func uptimeSeconds() -> TimeInterval {
        Double(clock_gettime_nsec_np(CLOCK_UPTIME_RAW)) / 1_000_000_000
    }

    private func findHeadersTerminator(_ buf: Data) -> Int? {
        guard buf.count >= 4 else { return nil }
        let needle: [UInt8] = [0x0D, 0x0A, 0x0D, 0x0A]
        return buf.withUnsafeBytes { (raw: UnsafeRawBufferPointer) -> Int? in
            guard let base = raw.bindMemory(to: UInt8.self).baseAddress else { return nil }
            for i in 0...(buf.count - 4) {
                if base[i] == needle[0] && base[i + 1] == needle[1]
                    && base[i + 2] == needle[2] && base[i + 3] == needle[3] {
                    return i
                }
            }
            return nil
        }
    }

    /// A line caused by a connection that has not presented the token: throttled, since anyone on the
    /// LAN can cause it (audit NET-111). An authenticated connection's lines go out as they come.
    private func emitRequestProblem(_ line: String, authenticated: Bool) {
        guard !authenticated else {
            EngineLog.emit(line, category: .hlsServer)
            return
        }
        stateLock.lock()
        let admitted = strangerLog.admit(now: Self.uptimeSeconds())
        stateLock.unlock()
        guard let suppressed = admitted else { return }
        EngineLog.emit(
            line + (suppressed > 0
                ? " (\(suppressed) more from unauthenticated connections since the last line)" : ""),
            category: .hlsServer)
    }

    private func processRequest(_ request: Data, on fd: Int32, authenticated: Bool) -> Bool {
        byteCounterLock.lock()
        _requestCount &+= 1
        byteCounterLock.unlock()
        guard let text = String(data: request, encoding: .utf8) else {
            emitRequestProblem("[HLSLocalServer] non-UTF8 request bytes (\(request.count)B)",
                               authenticated: authenticated)
            return false
        }
        let firstLine = text.components(separatedBy: "\r\n").first ?? ""
        let parts = firstLine.split(separator: " ", maxSplits: 2,
                                    omittingEmptySubsequences: true)
        guard parts.count >= 2 else {
            emitRequestProblem(
                "[HLSLocalServer] malformed request line: "
                    + "'\(Self.escapedForLog(firstLine, limit: Self.maximumStrangerText))'",
                authenticated: authenticated)
            return false
        }
        let rawTarget = String(parts[1])
        // Split path + query: AVPlayer appends ?_HLS_msn=N for LL-HLS blocking reloads; route match on path alone.
        let path: String
        let query: String
        if let q = rawTarget.firstIndex(of: "?") {
            path = String(rawTarget[..<q])
            query = String(rawTarget[rawTarget.index(after: q)...])
        } else {
            path = rawTarget
            query = ""
        }
        // Reject anything that does not carry this session's token before it reaches the router.
        // The listener is reachable from the whole LAN, so an unprefixed request is a scan or a
        // stale URL, never AVPlayer following a playlist we handed out.
        guard let routePath = Self.pathAfterToken(pathToken, in: path) else {
            // One line for the rejection and the 404 together: the path is the stranger's text.
            emitRequestProblem(
                "[HLSLocalServer] rejected request without a valid session token, -> 404: "
                    + Self.escapedForLog(firstLine, limit: Self.maximumStrangerText),
                authenticated: authenticated)
            _ = send404(fd: fd, path: path, reason: "bad session token", logged: false)
            return false
        }
        let route = Self.livePlaylistRoute(routePath)
        guard route.generation <= (provider?.livePlaylistGeneration ?? 0) else {
            return send404(fd: fd, path: routePath, reason: "unknown playlist generation")
        }
        let normalizedPath = (route.path == "/audio.m3u8") ? "/media.m3u8" : route.path
        let loggedRequest = Self.requestLineForLog(
            method: parts[0], routePath: routePath, query: query,
            version: parts.count > 2 ? parts[2] : nil)

        // #50 diag: promoted to .info so the host mirror names the failing path without a verbose build. Revert once #50 is root-caused.
        // AE#446: the fd is what says whether a blocking-reload hold is parking the connection the
        // next segment request needs. Same fd on both, and the segment could not be read until the
        // hold returned; different fds, and the client chose not to fetch.
        EngineLog.emit("[HLSLocalServer] \(loggedRequest) fd=\(fd)", category: .hlsServer)
        // #227 diag: name each distinct client once, so an AirPlay session shows whether the receiver fetches
        // for itself (its own LAN address appears) or the sender pulls everything (only 127.0.0.1 / own IP).
        if let peer = Self.peerAddress(of: fd) {
            stateLock.lock()
            let isNewPeer = loggedPeers.insert(peer).inserted
            stateLock.unlock()
            if isNewPeer {
                EngineLog.emit("[HLSLocalServer] #227 client \(peer) first request: \(loggedRequest)", category: .hlsServer)
            }
        }
        // Dump request headers once per session; AVPlayer capability headers (Accept, Range, X-Playback-Session-Id) can influence silent variant rejection.
        stateLock.lock()
        let dumpHeaders = !loggedRequestHeaders
        if dumpHeaders { loggedRequestHeaders = true }
        stateLock.unlock()
        if dumpHeaders {
            let allLines = text.components(separatedBy: "\r\n")
            let headers = Self.requestHeadersForLog(Array(allLines.dropFirst().prefix(while: { !$0.isEmpty })))
            // #50 diag: once-per-session, promoted to .info to surface any
            // Range / capability header that explains the 404. Revert with the
            // arrival-line promotion above once #50 is root-caused.
            EngineLog.emit("[HLSLocalServer] first request headers fd=\(fd): \(headers)", category: .hlsServer)  // #50 diag: .info, revert post-root-cause
        }

        if normalizedPath == HLSOriginRelay.route {
            guard let relay else {
                return send404(fd: fd, path: normalizedPath, reason: "no relay mounted")
            }
            stateLock.lock()
            let listeningPort = port
            stateLock.unlock()
            let headerLines = Array(text.components(separatedBy: "\r\n").dropFirst())
            // The media body is written from here as it arrives rather than after it has all
            // landed: buffering a segment puts its whole download in front of the player's first
            // byte and hands AVPlayer's throughput estimate a loopback burst to pick the next
            // rendition from.
            let sink = HLSOriginRelay.Sink(
                head: { [weak self] status, contentType, contentRange, contentLength in
                    guard let self else { return false }
                    let header = Self.relayResponseHeader(
                        status: status, contentType: contentType, contentRange: contentRange,
                        contentLength: contentLength)
                    EngineLog.emit(
                        "[HLSLocalServer] -> \(status) relay stream bytes=\(contentLength) "
                            + "type=\(contentType)", category: .hlsServer, level: .verbose)
                    return self.writeAll(fd: fd, data: Data(header.utf8),
                                         path: "\(normalizedPath) [header]")
                },
                body: { [weak self] chunk in
                    guard let self else { return false }
                    return self.writeAll(fd: fd, data: chunk, path: normalizedPath)
                })
            switch relay.respond(
                query: query,
                host: Self.requestHeader(named: "host", in: headerLines),
                range: Self.requestHeader(named: "range", in: headerLines),
                port: listeningPort, token: pathToken, sink: sink)
            {
            case nil:
                return send404(fd: fd, path: normalizedPath, reason: "relay names no origin")
            case .answer(let answer):
                return sendRelay(fd: fd, path: normalizedPath, answer: answer)
            case .streamed(let ok):
                return ok
            }
        }

        switch normalizedPath {
        case "/master.m3u8":
            if provider?.masterCodecs != nil || provider?.staticMasterPlaylistBody != nil {
                let body = buildMasterPlaylist()
                stateLock.lock()
                let firstTime = !loggedMasterPlaylist
                if firstTime { loggedMasterPlaylist = true }
                stateLock.unlock()
                if firstTime {
                    EngineLog.emit("[HLSLocalServer] master.m3u8 body:\n\(body)",
                                   category: .hlsServer)
                }
                return send200(fd: fd, path: normalizedPath,
                               data: Data(body.utf8),
                               contentType: "application/vnd.apple.mpegurl")
            }
            return send404(fd: fd, path: normalizedPath, reason: "no masterCodecs")

        case "/master_hdr.m3u8":
            // #98: HDR-preserving reduced master (DV signaling dropped, source range + subtitle
            // renditions kept), served by the #35 cold-DV-start gate on an HDR TV.
            if provider?.masterCodecs != nil {
                let body = buildReducedMasterPlaylist(.reducedHDR)
                stateLock.lock()
                let firstTime = !loggedReducedMasterPlaylist
                if firstTime { loggedReducedMasterPlaylist = true }
                stateLock.unlock()
                if firstTime {
                    EngineLog.emit("[HLSLocalServer] \(normalizedPath) body:\n\(body)",
                                   category: .hlsServer)
                }
                return send200(fd: fd, path: normalizedPath,
                               data: Data(body.utf8),
                               contentType: "application/vnd.apple.mpegurl")
            }
            return send404(fd: fd, path: normalizedPath, reason: "no masterCodecs")

        case "/media.m3u8":
            // For live: hold until at least one segment exists (-12888 fires immediately on empty live playlist; AVPlayer never re-polls).
            if let p = provider, p.playlistType == .live {
                if let msn = Self.parseHLSMsn(query) {
                    // LL-HLS blocking reload: hold until segment msn is cut so AVPlayer receives it the instant it exists, not a reload-interval late. Gated on liveBlockingReloadEnabled: bursty ingest sources can't honor the contract and withheld it.
                    if p.liveBlockingReloadEnabled {
                        // Unsatisfiable hold (producer halted/stalled, or timeout): 503, never the
                        // unchanged playlist. A 200 without the requested MSN after a hold is "Invalid
                        // server blocking reload behavior" (-15410) to AVPlayer (#167 follow-up;
                        // RFC 8216bis requires the 503 here).
                        if !p.waitForLiveSegment(index: msn, timeout: p.liveBlockingReloadHoldSeconds) {
                            return send503(fd: fd, path: normalizedPath,
                                           reason: "blocking reload msn=\(msn) unsatisfiable")
                        }
                    }
                } else {
                    _ = p.waitForFirstLiveSegment(timeout: LiveEdgePolicy.firstServeTimeoutSeconds(
                        edgeCushionSeconds: p.liveEdgeCushionSeconds))
                }
            } else if let p = provider, p.playlistType == .event {
                // Sequential append playlist: hold until the startup segments exist. A fast
                // archive origin cuts them within ~a second; the timeout only covers a source
                // that dies before its first cut (the playlist then renders empty and AVPlayer
                // surfaces the failure instead of hanging).
                _ = p.waitForSequentialStartupSegments(timeout: 30.0)
            }
            let body = buildMediaPlaylist(generation: route.generation)
            stateLock.lock()
            let firstTime = !loggedMediaPlaylist
            if firstTime { loggedMediaPlaylist = true }
            mediaPlaylistBuildCount += 1
            let isLivePlaylist = (provider?.playlistType == .live)
            let periodic = isLivePlaylist && (mediaPlaylistBuildCount % 10 == 0)
            stateLock.unlock()
            if firstTime || periodic {
                let lines = body.split(separator: "\n", omittingEmptySubsequences: false)
                let head = lines.prefix(8).joined(separator: "\n")
                let tail = lines.suffix(6).joined(separator: "\n")
                EngineLog.emit("[HLSLocalServer] media.m3u8 head:\n\(head)",
                               category: .hlsServer, level: .verbose)
                EngineLog.emit("[HLSLocalServer] media.m3u8 tail:\n\(tail)",
                               category: .hlsServer, level: .verbose)
            }
            return send200(fd: fd, path: normalizedPath,
                           data: Data(body.utf8),
                           contentType: "application/vnd.apple.mpegurl")

        case let p where p.hasPrefix("/subs_") && p.hasSuffix(".m3u8"):
            // #15: windowed subtitle media playlist, one WebVTT segment per video segment.
            guard let parsed = Self.parseSubsPath(p), let prov = provider else {
                return send404(fd: fd, path: normalizedPath, reason: "unparseable subtitle playlist path")
            }
            EngineLog.emit("[HLSLocalServer] subtitle rendition selected: subs_\(parsed.ordinal).m3u8 fetched", category: .hlsServer)
            let subBody = Self.buildSubtitleMediaPlaylistText(ordinal: parsed.ordinal, provider: prov, generation: route.generation)
            return send200(fd: fd, path: normalizedPath,
                           data: Data(subBody.utf8),
                           contentType: "application/vnd.apple.mpegurl")

        case let p where p.hasPrefix("/subs_") && p.hasSuffix(".vtt"):
            // #15: one WebVTT segment built on demand from the cue store's window for this video segment.
            guard let parsed = Self.parseSubsPath(p), let seg = parsed.segment,
                  let vtt = provider?.nativeSubtitleVTT(ordinal: parsed.ordinal, segmentIndex: seg) else {
                return send404(fd: fd, path: normalizedPath, reason: "no subtitle segment for \(normalizedPath)")
            }
            // Sodalite#156: an EMPTY segment is the reported defect and a populated one is routine, so
            // only the empty case is worth a line a reporter will see. AVKit takes the whole forward
            // window in one burst (~45 segments) and never re-fetches, so logging every one of them at
            // a visible level would push the surrounding evidence out of the 300-line ring, and it is
            // exactly the surrounding evidence that says WHY a segment came out empty.
            let cues = vtt.components(separatedBy: "-->").count - 1
            if cues == 0 {
                EngineLog.emit("[HLSLocalServer] served an EMPTY subtitle .vtt ord=\(parsed.ordinal) "
                               + "seg=\(seg) bytes=\(vtt.utf8.count); the receiver caches this segment "
                               + "as it is and never asks again", category: .hlsServer)
            } else {
                EngineLog.emit("[HLSLocalServer] served subtitle .vtt ord=\(parsed.ordinal) seg=\(seg) "
                               + "bytes=\(vtt.utf8.count) cues=\(cues)", category: .hlsServer, level: .verbose)
            }
            return send200(fd: fd, path: normalizedPath,
                           data: Data(vtt.utf8),
                           contentType: "text/vtt")

        case "/iframe.m3u8":
            guard let prov = provider, prov.iFrameRenditionServed else {
                return send404(fd: fd, path: normalizedPath, reason: "no I-frame rendition")
            }
            if case .jpeg = prov.iFrameRenditionFormat, !waitForMainVariant() {
                EngineLog.emit("[HLSLocalServer] i-frame rendition withheld: no media segment requested within "
                               + "\(Self.iFrameMainVariantWaitSeconds)s, so the HDR variant was refused",
                               category: .hlsServer)
                return send404(fd: fd, path: normalizedPath, reason: "main variant not playing")
            }
            let body = Self.buildIFramePlaylistText(provider: prov, subResourceBaseURL: subResourceBaseURL)
            return send200(fd: fd, path: normalizedPath, data: Data(body.utf8),
                           contentType: "application/vnd.apple.mpegurl")

        case "/iframe_init.mp4":
            guard let data = provider?.iFrameInitSegment(), !data.isEmpty else {
                return send404(fd: fd, path: normalizedPath, reason: "I-frame init unavailable")
            }
            return send200(fd: fd, path: normalizedPath, data: data, contentType: "video/mp4")

        case let p where p.hasPrefix("/iframe") && p.hasSuffix(".mp4"):
            guard let index = Self.parseIFramePath(p),
                  let data = provider?.iFrameSegment(at: index), !data.isEmpty else {
                return send404(fd: fd, path: normalizedPath, reason: "no I-frame for \(normalizedPath)")
            }
            return send200(fd: fd, path: normalizedPath, data: data, contentType: "video/mp4")

        case "/init.mp4":
            stateLock.lock(); servedMediaBytes = true; stateLock.unlock()
            let data = provider?.initSegment() ?? Data()
            if data.isEmpty {
                return send404(fd: fd, path: normalizedPath,
                               reason: "init.mp4 empty (provider not ready?)")
            }
            return send200(fd: fd, path: normalizedPath, data: data,
                           contentType: "video/mp4")

        default:
            // Versioned init for SSAI program switches: /init<N>.mp4 (N>0).
            if normalizedPath.hasPrefix("/init"),
               normalizedPath.hasSuffix(".mp4") {
                let vStr = normalizedPath.dropFirst("/init".count).dropLast(".mp4".count)
                if let v = Int(vStr), v > 0 {
                    let data = provider?.initSegment(versionID: v) ?? Data()
                    if data.isEmpty {
                        return send404(fd: fd, path: normalizedPath,
                                       reason: "init\(v).mp4 not available")
                    }
                    return send200(fd: fd, path: normalizedPath, data: data,
                                   contentType: "video/mp4")
                }
            }
            if normalizedPath.hasPrefix("/seg"),
               normalizedPath.hasSuffix(".mp4") {
                stateLock.lock(); servedMediaBytes = true; stateLock.unlock()
                let indexStr = normalizedPath.dropFirst(4).dropLast(4)
                if let index = Int(indexStr), index >= 0 {
                    // AE#418 round 7: every exit from this branch says what became of the request, so
                    // a placement composed from it can tell "not delivered yet" from "never arriving".
                    func delivered(_ ok: Bool) -> Bool {
                        provider?.didServeMediaSegment(index: index, delivered: ok)
                        return ok
                    }
                    func refused(_ responseWritten: Bool) -> Bool {
                        provider?.didServeMediaSegment(index: index, delivered: false)
                        return responseWritten
                    }
                    // File-backed fast path: stream page cache -> socket without Data materialization.
                    if let url = provider?.mediaSegmentURL(at: index) {
                        let outcome = send200File(fd: fd, path: normalizedPath,
                                                  fileURL: url,
                                                  contentType: "video/mp4",
                                                  segmentIndex: index)
                        // A cache entry can outlive its file, and that answer is a retriable 503: the
                        // request is not answered yet, so it says nothing about the placement.
                        switch outcome.body {
                        case .segment: return delivered(outcome.writeSucceeded)
                        case .refusal: return refused(outcome.writeSucceeded)
                        case .retry: return outcome.writeSucceeded
                        }
                    }
                    // #93 round 3: a serve outliving the provider's slow threshold (wedge-window
                    // restart, 25-50 s worst case) emits response headers NOW as a chunked
                    // transfer; the body follows when the segment lands. Without this, AVPlayer's
                    // ~3.5 s time-to-first-byte watchdog logs -12889 per silent request and three
                    // strikes fail the item (failedToPlayToEndTime, terminal from the couch).
                    let early = EarlyHeaderState()
                    let source = provider?.mediaSegmentSource(at: index, onSlow: { [weak self] in
                        guard let self, early.markSentOnce() else { return }
                        EngineLog.emit(
                            "[HLSLocalServer] seg\(index): slow serve, sending early chunked header",
                            category: .hlsServer)
                        _ = self.writeAll(fd: fd,
                                          data: Self.chunkedResponseHeader(contentType: "video/mp4"),
                                          path: "\(normalizedPath) [early header]")
                    })
                    // A segment being written: commit the chunked header (unless the slow-serve
                    // signal already did) and send each fragment as it lands. An abandoned segment
                    // ends the connection without the final chunk, so AVPlayer retries it rather
                    // than taking the partial bytes for a whole segment.
                    if case .progressive(let reader) = source {
                        if early.markSentOnce() {
                            guard writeAll(fd: fd, data: Self.chunkedResponseHeader(contentType: "video/mp4"),
                                           path: "\(normalizedPath) [progressive header]") else {
                                return refused(false)
                            }
                        }
                        return delivered(sendProgressiveBody(fd: fd, path: normalizedPath, reader: reader))
                    }
                    let data: Data? = {
                        if case .data(let d) = source { return d }
                        return nil
                    }()
                    if early.wasSent {
                        guard let data, !data.isEmpty else {
                            // Headers are committed; abort so AVPlayer sees a truncated transfer
                            // and retries, instead of a cacheable empty 200.
                            EngineLog.emit(
                                "[HLSLocalServer] seg\(index): early-header serve missed; "
                                + "closing connection for AVPlayer retry",
                                category: .hlsServer)
                            return refused(false)
                        }
                        return delivered(sendChunkedBody(fd: fd, path: normalizedPath, data: data))
                    }
                    if let data, !data.isEmpty {
                        return delivered(send200(fd: fd, path: normalizedPath, data: data,
                                                 contentType: "video/mp4"))
                    }
                    let providerCount = provider?.segmentCount ?? -1
                    let reason = "segment[\(index)] empty (segmentCount=\(providerCount))"
                    switch Self.classifySegmentResponse(
                        index: index, segmentCount: providerCount, hasData: false) {
                    case .serve:
                        // Unreachable: hasData is false here.
                        return refused(send404(fd: fd, path: normalizedPath, reason: reason))
                    case .retryLater:
                        // A 503 is retriable, so the request is not answered yet; the placement waits
                        // for the retry rather than concluding from it.
                        return send503(fd: fd, path: normalizedPath, reason: reason)
                    case .notFound:
                        return refused(send404(fd: fd, path: normalizedPath, reason: reason))
                    }
                }
                return send404(fd: fd, path: normalizedPath,
                               reason: "unparseable seg index '\(indexStr)'")
            }
            return send404(fd: fd, path: normalizedPath, reason: "unknown path")
        }
    }

    // MARK: - HTTP framing

    /// #93 round 3: once-latch for the early chunked header. The provider guarantees `onSlow`
    /// never runs after `mediaSegment(at:onSlow:)` returns (SlowServeSignal's complete() barrier),
    /// so the handler thread's `wasSent` read is ordered after any header write.
    private final class EarlyHeaderState: @unchecked Sendable {
        private let lock = NSLock()
        private var sent = false
        func markSentOnce() -> Bool {
            lock.lock(); defer { lock.unlock() }
            if sent { return false }
            sent = true
            return true
        }
        var wasSent: Bool { lock.lock(); defer { lock.unlock() }; return sent }
    }

    /// #93 round 3: chunked 200 header for a serve that cannot deliver within the slow threshold.
    /// No Content-Length (the segment size is unknown until produced); keep-alive is preserved,
    /// chunked framing delimits the message.
    static func chunkedResponseHeader(contentType: String) -> Data {
        var header = "HTTP/1.1 200 OK\r\n"
        header += "Content-Type: \(contentType)\r\n"
        header += "Transfer-Encoding: chunked\r\n"
        header += "Access-Control-Allow-Origin: *\r\n"
        header += "Cache-Control: no-cache\r\n"
        header += "Connection: keep-alive\r\n\r\n"
        return Data(header.utf8)
    }

    /// Chunk-size line: hex byte count + CRLF (RFC 9112 §7.1).
    static func chunkFrameHeader(size: Int) -> Data {
        Data("\(String(size, radix: 16))\r\n".utf8)
    }

    static let chunkFrameTrailer = Data("\r\n".utf8)
    static let chunkedFinal = Data("0\r\n\r\n".utf8)

    /// Body for a progressively delivered segment: one chunk per read (usually the fragment the muxer
    /// just flushed), the final chunk once the sealed segment is read to its end. Returns false
    /// without the final chunk when the producer abandons the segment.
    private func sendProgressiveBody(fd: Int32, path: String, reader: ProgressiveSegmentReader) -> Bool {
        let provider = self.provider
        var sent = 0
        while true {
            switch reader.next() {
            case .bytes(let data):
                guard writeAll(fd: fd, data: Self.chunkFrameHeader(size: data.count), path: "\(path) [chunk size]"),
                      writeAll(fd: fd, data: data, path: path),
                      writeAll(fd: fd, data: Self.chunkFrameTrailer, path: "\(path) [chunk trailer]") else {
                    return false
                }
                sent += data.count
                provider?.didDeliverProgressiveChunk(index: reader.index)
            case .finished:
                EngineLog.emit(
                    "[HLSLocalServer] -> 200 \(path) bytes=\(sent) type=video/mp4 [progressive]",
                    category: .hlsServer, level: .verbose)
                return writeAll(fd: fd, data: Self.chunkedFinal, path: "\(path) [chunk final]")
            case .abandoned:
                EngineLog.emit(
                    "[HLSLocalServer] \(path): the producer abandoned this segment after \(sent) B sent; "
                    + "closing so AVPlayer asks for it again",
                    category: .hlsServer)
                return false
            }
        }
    }

    /// Body for an early-header serve: the whole segment as one chunk. Four separate send()
    /// calls so mmap-backed segment Data is never copied into a Swift heap buffer.
    private func sendChunkedBody(fd: Int32, path: String, data: Data) -> Bool {
        EngineLog.emit(
            "[HLSLocalServer] -> 200 \(path) bytes=\(data.count) type=video/mp4 [chunked, early header]",
            category: .hlsServer, level: .verbose)
        guard writeAll(fd: fd, data: Self.chunkFrameHeader(size: data.count), path: "\(path) [chunk size]"),
              writeAll(fd: fd, data: data, path: path),
              writeAll(fd: fd, data: Self.chunkFrameTrailer, path: "\(path) [chunk trailer]"),
              writeAll(fd: fd, data: Self.chunkedFinal, path: "\(path) [chunk final]") else {
            return false
        }
        return true
    }

    /// Shared response-header builder. Header and body are sent in two separate send() calls: data may be mmap-backed and must NOT be copied via Data.append (would materialize segment into Swift heap, defeating the BSD-socket rewrite).
    private static func responseHeader(
        status: String, contentLength: Int, contentType: String?
    ) -> Data {
        var header = "HTTP/1.1 \(status)\r\n"
        if let contentType {
            header += "Content-Type: \(contentType)\r\n"
        }
        header += "Content-Length: \(contentLength)\r\n"
        if contentType != nil {
            header += "Access-Control-Allow-Origin: *\r\n"
            header += "Cache-Control: no-cache\r\n"
        }
        header += "Connection: keep-alive\r\n\r\n"
        return Data(header.utf8)
    }

    private func send200(fd: Int32, path: String, data: Data, contentType: String) -> Bool {
        let headerData = Self.responseHeader(status: "200 OK", contentLength: data.count, contentType: contentType)

        EngineLog.emit("[HLSLocalServer] -> 200 \(path) bytes=\(data.count) type=\(contentType)",
                       category: .hlsServer, level: .verbose)

        guard writeAll(fd: fd, data: headerData, path: "\(path) [header]") else {
            return false
        }
        return writeAll(fd: fd, data: data, path: path)
    }

    /// What a file-backed serve answered with, alongside whether the write went through. AE#418
    /// round 7 needs the two apart: a 503 for a cache entry whose file is gone is a request still
    /// waiting for its retry, and a write that succeeded on it delivered no segment.
    enum FileServeBody { case segment, refusal, retry }

    private func send200File(fd: Int32, path: String, fileURL: URL, contentType: String,
                             segmentIndex: Int? = nil) -> (body: FileServeBody, writeSucceeded: Bool) {
        let fsAttrs = try? FileManager.default.attributesOfItem(atPath: fileURL.path)
        let fileSize = (fsAttrs?[.size] as? Int) ?? 0
        if fileSize == 0 {
            let reason = "file \(fileURL.lastPathComponent) missing or empty"
            // #50 / AE#451: the in-range-is-never-404 rule belongs to the index, not to the path
            // that answers it. A cache entry can outlive its file (a sibling session's stale-dir
            // sweep, the OS reclaiming tmp), and a 404 on an in-range VOD segment is terminal for
            // AVPlayer, where a 503 lets the producer make it again.
            if let segmentIndex,
               Self.classifySegmentResponse(index: segmentIndex,
                                            segmentCount: provider?.segmentCount ?? -1,
                                            hasData: false) == .retryLater {
                return (.retry, send503(fd: fd, path: path, reason: reason))
            }
            return (.refusal, send404(fd: fd, path: path, reason: reason))
        }

        let headerData = Self.responseHeader(status: "200 OK", contentLength: fileSize, contentType: contentType)

        EngineLog.emit("[HLSLocalServer] -> 200 \(path) bytes=\(fileSize) type=\(contentType) [filestream]",
                       category: .hlsServer, level: .verbose)

        guard writeAll(fd: fd, data: headerData, path: "\(path) [header]") else {
            return (.segment, false)
        }
        return (.segment, streamFileToSocket(fileURL: fileURL, socketFd: fd, path: path,
                                             expectedLength: fileSize))
    }

    static func requestHeader(named name: String, in lines: [String]) -> String? {
        let wanted = name.lowercased() + ":"
        for line in lines where line.lowercased().hasPrefix(wanted) {
            return line.dropFirst(wanted.count).trimmingCharacters(in: .whitespaces)
        }
        return nil
    }

    /// Writes a relayed answer. Separate from `send200` because this is the only path that
    /// passes a status through from somewhere else and the only one that answers 206, which
    /// a ranged segment fetch upstream comes back as.
    private func sendRelay(fd: Int32, path: String, answer: HLSOriginRelay.Response) -> Bool {
        let header = Self.relayResponseHeader(
            status: answer.status, contentType: answer.contentType,
            contentRange: answer.contentRange, contentLength: answer.body.count)

        EngineLog.emit(
            "[HLSLocalServer] -> \(answer.status) relay bytes=\(answer.body.count) "
                + "type=\(answer.contentType)", category: .hlsServer, level: .verbose)
        guard writeAll(fd: fd, data: Data(header.utf8), path: "\(path) [header]") else {
            return false
        }
        return answer.body.isEmpty ? true : writeAll(fd: fd, data: answer.body, path: path)
    }

    /// The response head for a relayed answer, whether it is written whole or streamed. One writer,
    /// because a streamed answer states its length before the body exists and the two framings have
    /// to agree.
    static func relayResponseHeader(status: Int, contentType: String, contentRange: String?,
                                    contentLength: Int) -> String {
        var header = "HTTP/1.1 \(status) \(reasonPhrase(status))\r\n"
        header += "Content-Length: \(contentLength)\r\n"
        header += "Content-Type: \(headerValue(contentType))\r\n"
        if let contentRange {
            header += "Content-Range: \(headerValue(contentRange))\r\n"
        }
        header += "Accept-Ranges: bytes\r\n"
        header += "Cache-Control: no-cache\r\n"
        header += "Connection: keep-alive\r\n\r\n"
        return header
    }

    /// A header value written from somewhere else, made safe to concatenate into a response.
    ///
    /// Every other writer here builds its values itself; the relay mirrors what an origin sent.
    /// A CR or LF inside one of those ends the header early and the rest of the value is read as
    /// the next header, or as the start of the body, so an origin could write a second response
    /// into this one. Control characters go, and the value is bounded.
    static func headerValue(_ raw: String) -> String {
        let cleaned = raw.unicodeScalars.filter { $0.value >= 0x20 && $0.value != 0x7F }
        return String(String.UnicodeScalarView(cleaned.prefix(512)))
    }

    static func reasonPhrase(_ status: Int) -> String {
        switch status {
        case 200: return "OK"
        case 206: return "Partial Content"
        case 400: return "Bad Request"
        case 403: return "Forbidden"
        case 404: return "Not Found"
        case 416: return "Range Not Satisfiable"
        case 502: return "Bad Gateway"
        default: return "Status \(status)"
        }
    }

    private func send404(fd: Int32, path: String, reason: String, logged: Bool = true) -> Bool {
        let response = Self.responseHeader(status: "404 Not Found", contentLength: 0, contentType: nil)
        if logged {
            EngineLog.emit("[HLSLocalServer] -> 404 \(path) reason=\(reason)",
                           category: .hlsServer)
        }
        return writeAll(fd: fd, data: response, path: path)
    }

    /// 503 for an in-range segment not yet produced (#50). AVPlayer treats a 404 on a VOD segment as terminal loadFailed; 503+Retry-After keeps it recoverable so VideoSegmentProvider.serveSegment can nudge the producer back.
    private func send503(fd: Int32, path: String, reason: String) -> Bool {
        var header = "HTTP/1.1 503 Service Unavailable\r\n"
        header += "Content-Length: 0\r\n"
        header += "Retry-After: 1\r\n"
        header += "Cache-Control: no-cache\r\n"
        header += "Connection: keep-alive\r\n\r\n"
        EngineLog.emit("[HLSLocalServer] -> 503 \(path) reason=\(reason)",
                       category: .hlsServer)
        return writeAll(fd: fd, data: Data(header.utf8), path: path)
    }

    /// How to answer a `/seg{N}.mp4` request, given whether the provider
    /// produced bytes and the currently advertised segment count. Pure so
    /// the #50 in-range-is-never-404 rule is unit-testable without sockets.
    enum SegmentResponseKind: Equatable {
        /// Bytes are in hand; serve 200.
        case serve
        /// In-range (0 ..< segmentCount) but not produced yet; serve a
        /// retriable 503, never a 404.
        case retryLater
        /// Index is out of range (past the advertised count) or the count
        /// is unknown; a genuine 404.
        case notFound
    }

    static func classifySegmentResponse(index: Int, segmentCount: Int, hasData: Bool) -> SegmentResponseKind {
        if hasData { return .serve }
        if index >= 0, segmentCount > 0, index < segmentCount { return .retryLater }
        return .notFound
    }

    /// Blocking send loop. Uses withUnsafeBytes so mmap-backed Data stays mmap-backed (kernel page-faults in only the bytes copied to the socket send buffer, no heap accumulation).
    private func writeAll(fd: Int32, data: Data, path: String) -> Bool {
        var written = 0
        let total = data.count
        if total == 0 { return true }
        while written < total {
            let result = data.withUnsafeBytes { (raw: UnsafeRawBufferPointer) -> Int in
                guard let base = raw.baseAddress else { return -1 }
                let remaining = total - written
                return send(fd, base.advanced(by: written), remaining, 0)
            }
            if result < 0 {
                let err = errno
                if err == EINTR { continue }
                EngineLog.emit("[HLSLocalServer] send failed for \(path): errno=\(err)",
                               category: .hlsServer)
                return false
            }
            if result == 0 {
                EngineLog.emit("[HLSLocalServer] send returned 0 for \(path)",
                               category: .hlsServer)
                return false
            }
            written += result
        }
        bumpBytesSent(total)
        return true
    }

    /// Chunked file -> socket stream (256 KB buffer). sendfile(2) tried first but is SIGSYS'd by tvOS sandbox; reverted to read+send. expectedLength must match Content-Length exactly: a file that grew or shrank between stat and read would shift HTTP framing on the keep-alive connection. Short file fails the response (closes connection) rather than leaving the client waiting.
    private func streamFileToSocket(fileURL: URL, socketFd: Int32, path: String,
                             expectedLength: Int) -> Bool {
        let handle: FileHandle
        do {
            handle = try FileHandle(forReadingFrom: fileURL)
        } catch {
            EngineLog.emit("[HLSLocalServer] file open failed \(path): \(error)",
                           category: .hlsServer)
            return false
        }
        let fileFd = handle.fileDescriptor
        defer { try? handle.close() }

        let chunkSize = 256 * 1024
        let buffer = UnsafeMutablePointer<UInt8>.allocate(capacity: chunkSize)
        defer { buffer.deallocate() }

        var totalSent: Int = 0
        while true {
            if totalSent >= expectedLength {
                // File grew after stat; do not send excess bytes.
                bumpBytesSent(totalSent)
                bumpSendfileBytes(totalSent)
                return true
            }
            let want = min(chunkSize, expectedLength - totalSent)
            let nRead = read(fileFd, buffer, want)
            if nRead == 0 {
                // File shrank after stat; fail to avoid framing desync.
                EngineLog.emit(
                    "[HLSLocalServer] short file \(path): sent=\(totalSent) expected=\(expectedLength)",
                    category: .hlsServer
                )
                return false
            }
            if nRead < 0 {
                let err = errno
                if err == EINTR { continue }
                EngineLog.emit("[HLSLocalServer] file read failed \(path): errno=\(err) sent=\(totalSent)",
                               category: .hlsServer)
                return false
            }
            var written = 0
            while written < nRead {
                let n = send(socketFd, buffer.advanced(by: written), nRead - written, 0)
                if n < 0 {
                    let err = errno
                    if err == EINTR { continue }
                    EngineLog.emit("[HLSLocalServer] send failed \(path): errno=\(err) sent=\(totalSent + written)",
                                   category: .hlsServer)
                    return false
                }
                if n == 0 {
                    EngineLog.emit("[HLSLocalServer] send returned 0 \(path) sent=\(totalSent + written)",
                                   category: .hlsServer)
                    return false
                }
                written += n
            }
            totalSent += nRead
        }
    }

    // MARK: - Playlist construction

    private func buildMasterPlaylist() -> String {
        guard let provider = provider else { return "#EXTM3U\n" }
        // #316: the remote-HLS proxy hands over a finished master; there is nothing to build.
        if let staticBody = provider.staticMasterPlaylistBody { return staticBody }
        return Self.buildMasterPlaylistText(provider: provider,
                                             subResourceBaseURL: subResourceBaseURL)
    }

    private func buildReducedMasterPlaylist(_ variant: MasterPlaylistVariant) -> String {
        guard let provider = provider else { return "#EXTM3U\n" }
        return Self.buildMasterPlaylistText(provider: provider,
                                             subResourceBaseURL: subResourceBaseURL,
                                             variant: variant)
    }

    private func buildMediaPlaylist(generation: Int) -> String {
        guard let provider = provider else { return "#EXTM3U\n" }
        return Self.buildMediaPlaylistText(provider: provider,
                                            subResourceBaseURL: subResourceBaseURL,
                                            generation: generation)
    }

    /// Parse ?_HLS_msn=N from the request query. _HLS_part ignored (segment-level blocking only, no partial segments). Returns nil for absent or unparseable (treated as plain reload).
    static func parseHLSMsn(_ query: String) -> Int? {
        guard !query.isEmpty else { return nil }
        for pair in query.split(separator: "&") {
            let kv = pair.split(separator: "=", maxSplits: 1)
            if kv.count == 2, kv[0] == "_HLS_msn", let n = Int(kv[1]), n >= 0 {
                return n
            }
        }
        return nil
    }

    /// Pure playlist builders callable without a live server instance. subResourceBaseURL emits absolute URIs for AVAssetResourceLoader; nil emits relative URIs for the HTTP workflow.
    static func buildMasterPlaylistText(provider: HLSSegmentProvider,
                                         subResourceBaseURL: URL? = nil,
                                         variant: MasterPlaylistVariant = .primary) -> String {
        guard let codecs = provider.masterCodecs else {
            return "#EXTM3U\n"
        }
        var lines: [String] = []
        lines.append("#EXTM3U")
        // A REQ- attribute needs version 12: under 7 AVPlayer refuses the master (-12642, measured on
        // macOS 27 and the visionOS 27 simulator). Every other master keeps the version it always had.
        lines.append(provider.masterVideoLayout != nil ? "#EXT-X-VERSION:12" : "#EXT-X-VERSION:7")
        lines.append("#EXT-X-INDEPENDENT-SEGMENTS")

        // EXT-X-STREAM-INF attribute order per Apple's HLS Authoring Spec Appendixes: BANDWIDTH, AVERAGE-BANDWIDTH, CODECS, SUPPLEMENTAL-CODECS, RESOLUTION/FRAME-RATE/VIDEO-RANGE, HDCP-LEVEL/CLOSED-CAPTIONS.
        var streamInfAttrs: [String] = []
        let bandwidth = provider.masterBandwidth ?? 5_000_000
        streamInfAttrs.append("BANDWIDTH=\(bandwidth)")
        if let avg = provider.masterAverageBandwidth {
            streamInfAttrs.append("AVERAGE-BANDWIDTH=\(avg)")
        }
        streamInfAttrs.append("CODECS=\"\(codecs)\"")
        // #98 Stage 1.5: a reduced master drops the DV SUPPLEMENTAL-CODECS so the variant reads as
        // plain HDR/SDR HEVC; the segment sample entries still drive decoding.
        if variant == .primary, let supplemental = provider.masterSupplementalCodecs {
            streamInfAttrs.append("SUPPLEMENTAL-CODECS=\"\(supplemental)\"")
        }
        if let resolution = provider.masterResolution {
            streamInfAttrs.append("RESOLUTION=\(resolution.width)x\(resolution.height)")
        }
        if let frameRate = provider.masterFrameRate {
            streamInfAttrs.append("FRAME-RATE=\(String(format: "%.3f", frameRate))")
        }
        if let range = provider.masterVideoRange {
            streamInfAttrs.append("VIDEO-RANGE=\(range.rawValue)")
        }
        if let hdcp = provider.masterHDCPLevel {
            streamInfAttrs.append("HDCP-LEVEL=\(hdcp)")
        }
        if let layout = provider.masterVideoLayout {
            streamInfAttrs.append("REQ-VIDEO-LAYOUT=\"\(layout)\"")
        }
        // AE#458: the audio is muxed into the variant, so its rendition carries no URI (RFC 8216 4.3.4.2.1).
        // That tag is the ONLY place AVFoundation reads an audio language from on an HLS asset: measured on
        // macOS 26, an fMP4 whose mdhd reads "deu" still reports languageCode=nil and builds no audible
        // selection group at all, so every UI over that group (AVKit's audio menu) shows "Not Specified".
        // MP4SegmentMuxer writes the mdhd too, but that is not what fixes the label.
        let audioRendition = provider.masterAudioRendition
        if audioRendition != nil {
            streamInfAttrs.append("AUDIO=\"aud\"")
        }
        if let cc = provider.masterClosedCaptions {
            streamInfAttrs.append("CLOSED-CAPTIONS=\(cc)")
        }
        if let audio = audioRendition {
            var audioAttrs = ["TYPE=AUDIO", "GROUP-ID=\"aud\"", "NAME=\"\(audio.name)\""]
            if let language = audio.language { audioAttrs.append("LANGUAGE=\"\(language)\"") }
            audioAttrs.append(contentsOf: ["DEFAULT=YES", "AUTOSELECT=YES"])
            // CHANNELS is where object audio is declared to AVFoundation. The CODECS string stays
            // `ec-3` (#34: never `ec+3`), and the per-segment `dec3` box is below the playlist layer,
            // so this tag is the only place the master can say the rendition is Atmos. Dolby's DD+
            // Online Delivery Kit and the Apple HLS Authoring Spec both spell it
            // `CHANNELS="16/JOC"`; a non-JOC track gets its plain bed count.
            if let channels = provider.masterAudioChannels {
                audioAttrs.append("CHANNELS=\"\(channels)\"")
            }
            lines.append("#EXT-X-MEDIA:\(audioAttrs.joined(separator: ","))")
        }

        // #15: native WebVTT subtitle renditions (separate from the A/V variant; in-band timed text is
        // non-conformant for HLS). Orthogonal to the video VIDEO-RANGE/CODECS attributes.
        // Sodalite#32: DEFAULT=NO,AUTOSELECT=NO so AVKit never auto-selects a subtitle rendition in fullscreen
        // (the on-frame overlay owns fullscreen subtitles). The host explicitly selects the matching rendition
        // only on PiP entry and deselects it on PiP exit, so the two never double up.
        let subRenditions = provider.nativeSubtitleRenditions
        for r in subRenditions {
            var mediaAttrs = ["TYPE=SUBTITLES", "GROUP-ID=\"subs\"", "NAME=\"\(r.name)\""]
            if let lang = r.language { mediaAttrs.append("LANGUAGE=\"\(lang)\"") }
            mediaAttrs.append(contentsOf: ["DEFAULT=NO", "AUTOSELECT=NO"])
            // Deliberately NO FORCED=YES, even for a source-forced track: AVKit force-displays a FORCED
            // rendition whose language matches the selected audio regardless of DEFAULT/AUTOSELECT and the
            // user's CC-off preference, which self-engages a rendition and contradicts the invariant above
            // (the on-frame overlay owns fullscreen subtitles; the host selects a rendition only on PiP).
            // A source-forced German track on German audio then rendered with subtitles off (Sodalite#38
            // follow-on, DV-master path). Same-language forced/full pairs are disambiguated by NAME, not
            // FORCED. `r.isForced` still rides the published track list so the host can label/pick it.
            mediaAttrs.append("URI=\"subs_\(r.ordinal).m3u8\"")
            lines.append("#EXT-X-MEDIA:\(mediaAttrs.joined(separator: ","))")
        }
        if !subRenditions.isEmpty {
            streamInfAttrs.append("SUBTITLES=\"subs\"")
        }
        lines.append("#EXT-X-STREAM-INF:\(streamInfAttrs.joined(separator: ","))")
        lines.append("media.m3u8")
        if provider.iFrameRenditionServed,
           case .jpeg(let width, let height, let jpegBandwidth) = provider.iFrameRenditionFormat {
            // AE#682: AVKit shows no scrub thumbnail from a PQ or Dolby Vision keyframe, so an HDR
            // session lists SDR stills, the shape of Apple's own motion JPEG trick-play tier.
            let iFrameAttrs = ["BANDWIDTH=\(jpegBandwidth)", "CODECS=\"mjpg\"", "RESOLUTION=\(width)x\(height)",
                               "VIDEO-RANGE=SDR", "URI=\"iframe.m3u8\""]
            lines.append("#EXT-X-I-FRAME-STREAM-INF:\(iFrameAttrs.joined(separator: ","))")
        } else if provider.iFrameRenditionServed {
            // AE#682: BANDWIDTH is the variant's, an honest ceiling (one keyframe cannot outweigh the
            // segment it opens). A value below the real peak logs -12318 on every fetch.
            var iFrameAttrs = ["BANDWIDTH=\(bandwidth)", "CODECS=\"\(videoCodecs(of: codecs))\""]
            if variant == .primary, let supplemental = provider.masterSupplementalCodecs {
                iFrameAttrs.append("SUPPLEMENTAL-CODECS=\"\(supplemental)\"")
            }
            if let resolution = provider.masterResolution {
                iFrameAttrs.append("RESOLUTION=\(resolution.width)x\(resolution.height)")
            }
            if let range = provider.masterVideoRange {
                iFrameAttrs.append("VIDEO-RANGE=\(range.rawValue)")
            }
            iFrameAttrs.append("URI=\"iframe.m3u8\"")
            lines.append("#EXT-X-I-FRAME-STREAM-INF:\(iFrameAttrs.joined(separator: ","))")
        }
        return lines.joined(separator: "\n") + "\n"
    }

    /// The video entry of a master CODECS list. An I-frame variant carries no audio, and a CODECS
    /// that names one makes AVPlayer look for a track the fragments do not have.
    static func videoCodecs(of codecs: String) -> String {
        let videoPrefixes = ["avc1", "avc3", "hvc1", "hev1", "dvh1", "dvhe", "av01", "vp09"]
        let video = codecs.split(separator: ",")
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { entry in videoPrefixes.contains { entry.hasPrefix($0) } }
        return video.isEmpty ? codecs : video.joined(separator: ",")
    }

    /// "/iframe{N}.mp4" -> N. nil for the init, for a negative or non-numeric index, and for any
    /// other path.
    static func parseIFramePath(_ path: String) -> Int? {
        guard path.hasPrefix("/iframe"), path.hasSuffix(".mp4") else { return nil }
        let digits = path.dropFirst("/iframe".count).dropLast(".mp4".count)
        guard !digits.isEmpty, digits.allSatisfy(\.isNumber) else { return nil }
        return Int(digits)
    }

    /// AE#682: one entry per plan segment, each a single keyframe in its own resource. Same count,
    /// EXTINF and TARGETDURATION as the VOD media playlist, so both renditions describe one timeline.
    /// VOD only; the caller never lists this rendition for a live or event session.
    static func buildIFramePlaylistText(provider: HLSSegmentProvider,
                                        subResourceBaseURL: URL? = nil) -> String {
        let count = provider.segmentCount
        var maxDuration: Double = 0
        for i in 0..<count { maxDuration = max(maxDuration, provider.segmentDuration(at: i)) }
        let targetDuration = LiveEdgePolicy.targetDurationSeconds(
            maxSegmentDuration: maxDuration, cutTargetSeconds: nil, cadenceFloorSeconds: nil)
        let prefix: String
        if let base = subResourceBaseURL {
            let baseStr = base.absoluteString
            prefix = baseStr.hasSuffix("/") ? baseStr : baseStr + "/"
        } else {
            prefix = ""
        }
        var lines = ["#EXTM3U", "#EXT-X-VERSION:7", "#EXT-X-I-FRAMES-ONLY",
                     "#EXT-X-TARGETDURATION:\(targetDuration)", "#EXT-X-MEDIA-SEQUENCE:0",
                     "#EXT-X-PLAYLIST-TYPE:VOD", "#EXT-X-MAP:URI=\"\(prefix)iframe_init.mp4\""]
        for i in 0..<count {
            lines.append("#EXTINF:\(String(format: "%.3f", provider.segmentDuration(at: i))),")
            lines.append("\(prefix)iframe\(i).mp4")
        }
        lines.append("#EXT-X-ENDLIST")
        return lines.joined(separator: "\n") + "\n"
    }

    /// Windowed WebVTT subtitle media playlist (#15): MIRRORS the video media playlist one-for-one.
    ///
    /// The native subtitle path is embedded-only and its reader parks ~90s ahead of the playhead
    /// (playhead-paced), filling the cue store incrementally; the store never holds the
    /// whole program at once. A single VOD .vtt fetched once would be truncated for embedded subs. Instead we
    /// emit ONE .vtt segment per video segment (same count, same per-segment EXTINF, same MEDIA-SEQUENCE,
    /// same PLAYLIST-TYPE/ENDLIST as the video) using the SAME `notePlaylistBuild()` snapshot so the two
    /// playlists stay consistent. AVPlayer fetches `subs_{ord}_{i}.vtt` around when it plays `seg{i}.mp4`, by
    /// which point the ~90s-ahead reader has that window's cues in the store. WebVTT segments carry no init
    /// segment, so no EXT-X-MAP.
    static func buildSubtitleMediaPlaylistText(ordinal: Int, provider: HLSSegmentProvider,
                                                generation: Int? = nil) -> String {
        let snapshot = provider.notePlaylistBuild()
        let requestedGeneration = generation ?? provider.livePlaylistGeneration
        let retiredEnd = provider.livePlaylistEndIndex(generation: requestedGeneration)
        var count = min(snapshot.visibleCount, retiredEnd ?? snapshot.visibleCount)
        let firstVisible = min(snapshot.firstVisible, count)

        // Sodalite#32: whole-program shape, ONE VOD segment spanning the full duration, one .vtt with all cues.
        // The only AVPlayer-reliable sideload structure; the per-segment window made AVKit fetch a couple of
        // sparse segments and never render. TARGETDURATION/EXTINF = full program length (Apple rules 5.5/8.7).
        if provider.nativeSubtitleWholeProgram {
            var total = 0.0
            for i in firstVisible..<count { total += provider.segmentDuration(at: i) }
            var lines: [String] = ["#EXTM3U", "#EXT-X-VERSION:7"]
            let wholeProgramTarget = LiveEdgePolicy.targetDurationSeconds(
                maxSegmentDuration: total, cutTargetSeconds: nil, cadenceFloorSeconds: nil)
            lines.append("#EXT-X-TARGETDURATION:\(wholeProgramTarget)")
            lines.append("#EXT-X-MEDIA-SEQUENCE:0")
            lines.append("#EXT-X-PLAYLIST-TYPE:VOD")
            // No trailing comma on EXTINF: the proven-working whole-file sideload omits it ("seems to break it"
            // otherwise), and AVKit accepts it here. Sodalite#32.
            lines.append("#EXTINF:\(String(format: "%.3f", total))")
            lines.append("subs_\(ordinal)_0.vtt")
            lines.append("#EXT-X-ENDLIST")
            return lines.joined(separator: "\n") + "\n"
        }
        let typeIsEvent = (provider.playlistType == .event && !snapshot.endlistAdded)
        // AE#446 round 2: a rendition has to end with the video playlist it belongs to, or AVPlayer
        // keeps reloading a live subtitle track beside a finished asset.
        let liveOutage = (provider.playlistType == .live && !snapshot.endlistAdded
                          && (retiredEnd != nil
                              || provider.liveOutageEndlist))
        let typeIsLive = (provider.playlistType == .live && !snapshot.endlistAdded && !liveOutage)

        var maxDuration: Double = 0
        for i in firstVisible..<count {
            maxDuration = max(maxDuration, provider.segmentDuration(at: i))
        }
        // AE#447 follow-up: the SEALED value, the same one the video playlist carries. This rebuilt the
        // derivation by hand instead, so it read the live cadence floor on every render and could hand a
        // subtitle rendition a TARGETDURATION that grew mid-session. RFC 8216 forbids that in any Media
        // Playlist, and AE#209 measured the cost on the video one: an item that reached readyToPlay,
        // showed a first frame, and then sat at `waitingToPlay` at time zero for the rest of the session.
        // A rendition is a Media Playlist like any other, and it is built from this provider's own
        // segments, so the two values are the same number and may as well come from the same place.
        let targetDuration = (typeIsLive || liveOutage)
            ? provider.liveTargetDurationSeconds(maxSegmentDuration: maxDuration,
                generation: requestedGeneration)
            : LiveEdgePolicy.targetDurationSeconds(maxSegmentDuration: maxDuration,
                                                   cutTargetSeconds: nil, cadenceFloorSeconds: nil)

        if typeIsLive || liveOutage {
            count = (firstVisible..<count).first {
                !LiveTargetDurationSeal.accepts(provider.segmentDuration(at: $0), target: targetDuration)
            } ?? count
        }
        var lines: [String] = []
        lines.append("#EXTM3U")
        lines.append("#EXT-X-VERSION:7")
        lines.append("#EXT-X-TARGETDURATION:\(targetDuration)")
        lines.append("#EXT-X-MEDIA-SEQUENCE:\(firstVisible)")
        if typeIsLive {
            lines.append("#EXT-X-DISCONTINUITY-SEQUENCE:\(snapshot.discontinuitySequence)")
        } else if typeIsEvent {
            lines.append("#EXT-X-PLAYLIST-TYPE:EVENT")
        } else {
            lines.append("#EXT-X-PLAYLIST-TYPE:VOD")
        }
        for i in firstVisible..<count {
            if typeIsLive && provider.segmentIsDiscontinuous(at: i) {
                lines.append("#EXT-X-DISCONTINUITY")
            }
            let dur = provider.segmentDuration(at: i)
            lines.append("#EXTINF:\(String(format: "%.3f", dur)),")
            lines.append("subs_\(ordinal)_\(i).vtt")
        }
        if !typeIsLive && (snapshot.endlistAdded || !typeIsEvent || liveOutage) {
            lines.append("#EXT-X-ENDLIST")
        }
        return lines.joined(separator: "\n") + "\n"
    }

    /// Parse a subtitle endpoint path. "/subs_{ord}.m3u8" -> (ord, nil); "/subs_{ord}_{seg}.vtt" -> (ord, seg).
    /// nil when the path is not a well-formed subs_ endpoint. #15.
    static func parseSubsPath(_ path: String) -> (ordinal: Int, segment: Int?)? {
        let name = path.hasPrefix("/") ? String(path.dropFirst()) : path
        guard name.hasPrefix("subs_") else { return nil }
        var body = String(name.dropFirst("subs_".count))
        if let dot = body.lastIndex(of: ".") { body = String(body[..<dot]) }
        let parts = body.split(separator: "_", maxSplits: 1, omittingEmptySubsequences: false)
        guard let first = parts.first, let ord = Int(first) else { return nil }
        if parts.count == 2 {
            guard let seg = Int(parts[1]) else { return nil }
            return (ord, seg)
        }
        return (ord, nil)
    }

    static func buildMediaPlaylistText(provider: HLSSegmentProvider,
                                        subResourceBaseURL: URL? = nil, generation: Int? = nil) -> String {
        // Atomic snapshot from notePlaylistBuild(); a separate lock acquisition for visibleCount vs firstVisible let a concurrent window slide produce a trapping range.
        let snapshot = provider.notePlaylistBuild()
        let requestedGeneration = generation ?? provider.livePlaylistGeneration
        let retiredEnd = provider.livePlaylistEndIndex(generation: requestedGeneration)
        var count = min(snapshot.visibleCount, retiredEnd ?? snapshot.visibleCount)
        let firstVisible = min(snapshot.firstVisible, count)
        let typeIsEvent = (provider.playlistType == .event && !snapshot.endlistAdded)
        // AE#446 round 2: a live source that has stopped delivering, with a consumer still holding
        // resident segments ahead of it. The window is then a finite asset and is served as one:
        // ENDLIST is the only thing measured to keep AVPlayer fetching a playlist whose tail has
        // stopped moving (a changed byte does not, and neither does a changed MEDIA-SEQUENCE).
        let liveOutage = (provider.playlistType == .live && !snapshot.endlistAdded
                          && (retiredEnd != nil
                              || provider.liveOutageEndlist))
        // Sliding live: no PLAYLIST-TYPE tag and no ENDLIST (EVENT forbids removal; VOD implies finished asset).
        let typeIsLive = (provider.playlistType == .live && !snapshot.endlistAdded && !liveOutage)

        // TARGETDURATION must be >= every EXTINF (HLS spec). For live it is also floored by ceil(1.5 x cut
        // target) (widens AVPlayer's unchanged-playlist patience, anti -12888: (1) empty first manifest,
        // (2) transcode warm-up stall) and by the observed upstream arrival cadence (bursty ingest). The
        // SAME derivation feeds the startup cushion (LiveEdgePolicy.startupCushionSatisfied), so the depth
        // the cushion builds to matches the holdback AVPlayer computes from this value.
        var maxDuration: Double = 0
        for i in firstVisible..<count {
            maxDuration = max(maxDuration, provider.segmentDuration(at: i))
        }
        let targetDuration = (typeIsLive || liveOutage)
            ? provider.liveTargetDurationSeconds(maxSegmentDuration: maxDuration,
                generation: requestedGeneration)
            : LiveEdgePolicy.targetDurationSeconds(
                maxSegmentDuration: maxDuration,
                cutTargetSeconds: nil,
                cadenceFloorSeconds: nil
            )

        if typeIsLive || liveOutage {
            count = (firstVisible..<count).first {
                !LiveTargetDurationSeal.accepts(provider.segmentDuration(at: $0), target: targetDuration)
            } ?? count
        }
        var lines: [String] = []
        lines.append("#EXTM3U")
        lines.append("#EXT-X-VERSION:7")
        if typeIsLive {
            var serverControl: [String] = []
            // CAN-BLOCK-RELOAD: AVPlayer sends ?_HLS_msn=N and the server holds the response until that segment is cut (see waitForLiveSegment), so AVPlayer gets each segment the instant it exists instead of a poll-interval late. Segment-level only (no EXT-X-PART). Gated on liveBlockingReloadEnabled: bursty sources can't honor the contract (-15410 and periodic stalls on device repro 2026-06-11); they fall back to plain reloads with a raised TARGETDURATION.
            if provider.liveBlockingReloadEnabled {
                serverControl.append("CAN-BLOCK-RELOAD=YES")
            }
            // HOLD-BACK: pin the live-edge holdback to 3 x TARGETDURATION (the RFC 8216bis floor, and
            // AVPlayer's implicit default made explicit). Without it AVPlayer restarts inside its own
            // stall-danger zone (-16832) whenever the served window carries less than 3 x TD behind the
            // edge (AE#189: 5.76s long-GOP segments -> TD=6 -> 18s holdback vs a 9.6s startup window). The
            // startup cushion is built to exactly this depth, so the advertised value is always satisfiable.
            // A host's `liveEdgeCushionSeconds` raises both together.
            let holdBack = LiveEdgePolicy.holdBackSeconds(targetDuration: targetDuration,
                                                          edgeCushionSeconds: provider.liveEdgeCushionSeconds)
            serverControl.append("HOLD-BACK=\(String(format: "%.3f", holdBack))")
            lines.append("#EXT-X-SERVER-CONTROL:\(serverControl.joined(separator: ","))")
        }
        lines.append("#EXT-X-TARGETDURATION:\(targetDuration)")
        lines.append("#EXT-X-MEDIA-SEQUENCE:\(firstVisible)")
        // AE#446 round 5: the axis this build places the item on, stated where it is known exactly.
        // MEDIA-SEQUENCE above is the same fact addressed by index; this records the seconds it stands
        // for, and only an item's FIRST playlist decides (the latch is armed once per item attach).
        if (typeIsLive || liveOutage) && retiredEnd == nil {
            provider.noteServedLiveItemAxis(firstVisible: firstVisible)
        }
        if typeIsLive || liveOutage {
            // RFC 8216 §6.2.2: EXT-X-DISCONTINUITY-SEQUENCE must advance when discontinuity-tagged segments slide out of the window; omitting it shifts AVPlayer's discontinuity numbering one window after each program boundary.
            lines.append("#EXT-X-DISCONTINUITY-SEQUENCE:\(snapshot.discontinuitySequence)")
        }
        // AE#454: a rejoin's placement, in the manifest the fresh item loads rather than as a seek
        // 150 ms after it already started playing somewhere else. Recomputed on every build, so a
        // window that slid between arming and this fetch still names the same content.
        if typeIsLive, let rejoin = provider.liveRejoinStart,
           let offset = LiveEdgePolicy.rejoinStartTimeOffset(
               segmentIndex: rejoin.segmentIndex,
               secondsIntoSegment: rejoin.secondsIntoSegment,
               firstVisible: firstVisible,
               visibleCount: count,
               targetDuration: targetDuration,
               segmentDuration: { provider.segmentDuration(at: $0) }) {
            let tag = "#EXT-X-START:TIME-OFFSET=\(String(format: "%.3f", offset)),PRECISE=YES"
            lines.append(tag)
            // The served value, so a field log can say whether the placement was actually offered and
            // at what depth. Bounded by the arm: this is off on every build except the ones between a
            // rejoin swap and the item it placed running.
            EngineLog.emit(
                "[HLSLocalServer] #454 serving \(tag) for segment \(rejoin.segmentIndex) + "
                + "\(String(format: "%.2f", rejoin.secondsIntoSegment))s, \(count - firstVisible) "
                + "segment(s) listed from seg\(firstVisible)",
                category: .session)
            // AE#454 round 2: the same build knows the axis it just placed the item on, which is where
            // the playlist it served begins. Stating it is the whole fix; measuring it afterwards is
            // what put a correctly placed item through a correcting seek.
            provider.noteServedLiveRejoinPlacement(timeOffset: offset, firstVisible: firstVisible)
        }
        if typeIsLive {
            // Refresh counter keeps consecutive polls byte-distinct, which is worth having against any
            // cache in the path. It is NOT what keeps AVPlayer's unchanged-playlist patience (-12888)
            // from firing, though it was added believing so: measured on the harness, two polls 4 s
            // apart differing in this line alone still drew -12888 on every reload, because the
            // unchanged test reads the parsed playlist and skips a tag AVPlayer does not know. The
            // window is what it reads; see VideoSegmentProvider.stalledWindowFirstVisible (AE#446).
            lines.append("#EXT-X-SODALITE-REFRESH:\(snapshot.refreshCounter)")
        } else if typeIsEvent {
            lines.append("#EXT-X-PLAYLIST-TYPE:EVENT")
            lines.append("#EXT-X-SODALITE-REFRESH:\(snapshot.refreshCounter)")
        } else if liveOutage {
            // No PLAYLIST-TYPE: the session may still come back, and VOD is a claim about the asset
            // rather than about this window. ENDLIST alone is what stops the reload loop.
        } else {
            // EXT-X-PLAYLIST-TYPE:VOD lets AVPlayer prune fetched segments past the buffer-behind window; without it RSS grows linearly with segment count for the whole playback.
            lines.append("#EXT-X-PLAYLIST-TYPE:VOD")
        }
        // Absolute custom-scheme URIs route sub-resources through AVAssetResourceLoader; relative URIs go through CFNetwork (aetherctl workflow).
        let initURI: (Int) -> String
        let segURI: (Int) -> String
        if let base = subResourceBaseURL {
            let baseStr = base.absoluteString
            let baseWithSlash = baseStr.hasSuffix("/") ? baseStr : baseStr + "/"
            initURI = { v in v == 0 ? "\(baseWithSlash)init.mp4" : "\(baseWithSlash)init\(v).mp4" }
            segURI = { idx in "\(baseWithSlash)seg\(idx).mp4" }
        } else {
            initURI = { v in v == 0 ? "init.mp4" : "init\(v).mp4" }
            segURI = { idx in "seg\(idx).mp4" }
        }
        // Initial EXT-X-MAP emitted before the loop so a discontinuity on seg0 is still directly before its #EXTINF (RFC/Apple: session map precedes first segment's tags).
        var lastInitVersion = provider.initVersionID(forSegment: firstVisible)
        lines.append("#EXT-X-MAP:URI=\"\(initURI(lastInitVersion))\"")
        for i in firstVisible..<count {
            if provider.segmentIsDiscontinuous(at: i) {
                lines.append("#EXT-X-DISCONTINUITY")
            }
            // SSAI mid-stream init change: emit new EXT-X-MAP after discontinuity, before #EXTINF (verified order AVPlayer accepts for mid-stream init + resolution change).
            let v = provider.initVersionID(forSegment: i)
            if v != lastInitVersion {
                lines.append("#EXT-X-MAP:URI=\"\(initURI(v))\"")
                lastInitVersion = v
            }
            let dur = provider.segmentDuration(at: i)
            // A zero-duration entry is a plan index the producer skipped outright (sequential
            // sessions: a long GOP spanning two boundaries); no media file exists for it. Scoped
            // to the append playlist on purpose: dropping a URI shifts every later segment's
            // implicit media sequence number by one, which is exactly what a live blocking
            // reload (?_HLS_msn=) resolves against, and a zero on live or plain VOD is a
            // different bug that should stay visible rather than be rendered away.
            if provider.playlistType == .event, dur <= 0 { continue }
            lines.append("#EXTINF:\(String(format: "%.3f", dur)),")
            lines.append(segURI(i))
        }
        // ENDLIST for VOD/completed EVENT, and for a live window whose source has stopped (AE#446);
        // never for a sliding live playlist that is still gaining segments (AVPlayer must keep re-polling).
        if !typeIsLive && (snapshot.endlistAdded || !typeIsEvent || liveOutage) {
            lines.append("#EXT-X-ENDLIST")
        }
        return lines.joined(separator: "\n") + "\n"
    }
}

// MARK: - Errors

enum HLSLocalServerError: Error, CustomStringConvertible, LocalizedError {
    case socketCreate(errno: Int32)
    case bind(errno: Int32)
    case listen(errno: Int32)
    case getsockname(errno: Int32)

    var description: String {
        switch self {
        case .socketCreate(let e): return "HLSLocalServer: socket() failed (errno=\(e))"
        case .bind(let e):         return "HLSLocalServer: bind() failed (errno=\(e))"
        case .listen(let e):       return "HLSLocalServer: listen() failed (errno=\(e))"
        case .getsockname(let e):  return "HLSLocalServer: getsockname() failed (errno=\(e))"
        }
    }

    var errorDescription: String? { description }
}

/// Lets one line through per `interval` and counts the ones it held back, so a condition that
/// repeats per connection or per accept costs the log one line with a tally instead of one each.
/// Not thread safe; the owner serializes it.
struct LogThrottle {
    let interval: TimeInterval
    private var lastEmitted: TimeInterval?
    private var suppressed = 0

    init(interval: TimeInterval) {
        self.interval = interval
    }

    /// The number of lines suppressed since the last one that went out, when this one may go
    /// out; nil when it is to be dropped.
    mutating func admit(now: TimeInterval) -> Int? {
        if let lastEmitted, now - lastEmitted < interval {
            suppressed += 1
            return nil
        }
        lastEmitted = now
        defer { suppressed = 0 }
        return suppressed
    }
}
