import Foundation
import Darwin.Mach
import QuartzCore
import CoreMedia
import CoreVideo
import AVFoundation
import Combine
import AetherLibavformat
import AetherLibavcodec
import AetherLibavutil

#if canImport(UIKit)
import UIKit
#endif
import MediaPlayer

/// AetherEngine, format-agnostic video muxer that feeds AVPlayer.
///
/// Open-source LGPL 3.0 engine that takes any source (HTTP, file://,
/// MKV / MP4 / TS containers; AVC / HEVC / VP9 / AV1 codecs) and
/// streams it as HLS-fMP4 over a loopback HTTP server to an internal
/// AVPlayer. The host embeds a single `AetherPlayerView` and calls
/// `engine.load(url:options:)`; the engine handles demux, fMP4 mux,
/// HDMI HDR-mode handshake, frame-rate matching, AVPlayer wiring, and
/// per-frame HDR metadata forwarding.
///
/// ## Architecture
///
/// ```
/// URL → FFmpeg Demuxer → HLS-fMP4 Mux (libavformat) → loopback HTTP
///   → AVPlayer → AVPlayerLayer (hosted by AetherPlayerView)
/// ```
///
/// Audio is stream-copied into the fMP4 when the codec is legal there
/// (AAC, AC3, EAC3 incl. JOC Atmos, FLAC, ALAC, MP3, Opus). Codecs
/// that aren't legal in fMP4 (TrueHD, DTS, etc.) bridge through the
/// engine's FLAC re-encoder so AVPlayer plays them as lossless FLAC.
///
/// ## Quick Start
///
/// ```swift
/// let engine = try AetherEngine()
/// let view = AetherPlayerView()
/// engine.bind(view: view)
/// try await engine.load(url: myVideoURL, options: .init())
/// engine.play()
/// ```
///
/// ## License
///
/// LGPL 3.0, App Store compatible when dynamically linked.
@MainActor
public final class AetherEngine: ObservableObject {

    // MARK: - Public State

    @Published public internal(set) var state: PlaybackState = .idle {
        didSet {
            // #376: the classification belongs to the failure the state carries, so it lives and dies
            // with it. Set before `.error` is published (see `publishError`), dropped by any move off it.
            if case .error = state {} else { errorInfo = nil }
            recomputePlaybackPhase()
            resolveLoadingStashedSeek(from: oldValue)
            if upscaleNativeReturnOwed != nil { settleOwedUpscaleNativeReturn() }
            if Self.backgroundPolicyIsOwedOnResume(
                isBackgrounded: isBackgrounded, retainsPausedPipeline: retainsVideoPipelineWhenBackgrounded,
                from: oldValue, to: state
            ) {
                // AE#870: a retained paused session skipped the background policy, so a resume in the
                // background (lock screen, Control Center, AVKit) owes the playing-session decision.
                // A seek or reload can resume while in flight, so it owes the settled decision too.
                backgroundActionOwed = true
            }
            settleOwedBackgroundAction()
            // A renderer path has no player for the Atmos output activator to observe; it follows this.
            atmosOutputActivator?.refresh()
            if let logTag { EngineLog.emit("[AetherEngine:\(logTag)] state=\(state)", category: .engine) }
        }
    }

    /// Machine-readable companion to the message inside `state`'s `.error` (#376): a stable
    /// `PlaybackErrorKind` plus the underlying `NSError` domain and code where a Foundation /
    /// AVFoundation failure is involved. nil whenever `state` is not `.error`.
    ///
    /// It exists because the message cannot classify: on the native paths it is
    /// `AVPlayerItem.error.localizedDescription` forwarded verbatim, so it changes with the device's
    /// language, and the domain and code are gone by the time a host reads it. Assigned BEFORE `state`,
    /// so a `$state` sink can read `errorInfo` synchronously and see this failure's own.
    @Published public internal(set) var errorInfo: PlaybackErrorInfo? = nil

    /// Mid-playback rebuffer flag. `state` stays `.playing` across a rebuffer to avoid icon flicker;
    /// gate on this when you need to distinguish a stall from real playback (AetherEngine#35).
    /// Always false during initial load spin-up (`state == .loading`). On the AVPlayer paths a wait
    /// AVPlayer spends evaluating its buffering rate (every resume from pause) does not count.
    @Published public internal(set) var isBuffering: Bool = false {
        didSet { recomputePlaybackPhase() }
    }

    /// Where the loopback segment cache or software VOD packet cache holds picture right now,
    /// with selected audio coverage required for software A/V, on the same 0-based display axis as
    /// `currentTime`, `duration` and `seek(to:)`. An empty array is the nil-equivalent, and live
    /// sessions publish one always: their rewind depth is `clock.seekableLiveRange`, a different
    /// contract. Residency is not a promise that a seek inside a range will be instant; the player may
    /// still need to re-anchor and decode at the target.
    @Published public internal(set) var residentRanges: [ClosedRange<Double>] = []

    /// Byte-source seekability learned during this load. Nil means the source has not been
    /// probed, or AVFoundation owns it directly. A duration alone never establishes seekability.
    @Published public internal(set) var isSourceSeekable: Bool? = nil {
        didSet {
            guard oldValue != isSourceSeekable, let isSourceSeekable else { return }
            EngineLog.emit("[SourceOpen] phase=capability seekability=\(isSourceSeekable ? "seekable" : "forward-only")", category: .demux)
        }
    }

    /// Whether the active session accepts a seek. Live playback requires a DVR window;
    /// forward-only VOD never advertises arbitrary seeking even when its duration is known.
    /// Remote HLS uses the native item's measured range instead of container metadata.
    public var canSeek: Bool {
        guard isSessionReady else { return false }
        switch state {
        case .idle, .loading, .ended, .error: return false
        default: break
        }
        if isLive { return seekableLiveRange != nil }
        guard !loadedOptions.sequentialOrigin, isSourceSeekable != false,
              duration.isFinite, duration > 0 else { return false }
        if videoRoute == .remoteBypass {
            guard let nativeHost else { return false }
            return nativeHost.seekableEnd > nativeHost.seekableStart
        }
        return isSourceSeekable == true
    }

    /// The same spans as `residentRanges`, unfolded, on the producer's playlist axis. Held because the
    /// fold onto the display axis moves when the producer publishes a new shift, and a shift change is
    /// not a cache change: without the raw spans the band would keep the retired epoch's offset until
    /// the next segment happened to land.
    var residentPlaylistRanges: [ClosedRange<Double>] = []

    /// True from seek entry until physical landing, covering programmatic seeks, native AVKit scrubs and
    /// seeks the session could not take yet (#127/#178 stash). Unlike `state == .seeking` (optimistically
    /// flipped to `.playing`), this spans the real loopback-HLS landing, which resolves seconds after the
    /// call (AetherEngine#38). Paired with `seekTarget`.
    ///
    /// A LEVEL signal: it says a seek is in flight, never why it stopped being one. Observe `seekEvents`
    /// where the falling edge itself carries weight (landed vs gave up vs superseded, and which target).
    @Published public internal(set) var isSeeking: Bool = false {
        didSet { recomputePlaybackPhase() }
    }

    /// Source-PTS seek destination, or nil when idle. Cleared on landing. For native scrubs, set to the
    /// out-of-range segment time AVPlayer requested (AetherEngine#38). Follows the most authoritative
    /// in-flight source (programmatic > scrub > deferred), so it never publishes a settled seek's target
    /// while a different one is in flight.
    @Published public internal(set) var seekTarget: Double? = nil

    /// Seek-lifecycle events: one value per transition, carrying the outcome and the target it belongs to
    /// (AetherEngine#38 follow-up). See `SeekEvent` for the contract, including the late `.landed` that
    /// can follow a `.stalled` and that `isSeeking` structurally cannot express.
    public var seekEvents: AnyPublisher<SeekEvent, Never> { seekEventSubject.eraseToAnyPublisher() }

    private let seekEventSubject = PassthroughSubject<SeekEvent, Never>()

    /// #800: true while the software host holds the clock at rate 0 until the decoder has caught up
    /// with its position. The clock standing still in that window is not a stall. See `ClockHoldEvent`.
    @Published public internal(set) var isClockHeld = false

    /// #800: one value per hold of the clock and per release, with how it ended. See `ClockHoldEvent`.
    public var clockHoldEvents: AnyPublisher<ClockHoldEvent, Never> { clockHoldSubject.eraseToAnyPublisher() }

    private let clockHoldSubject = PassthroughSubject<ClockHoldEvent, Never>()

    /// The `AudioOutput` generation of the newest hold transition applied. The host reports off main and
    /// each report hops here in its own task, so one that arrives behind a newer one is dropped.
    private var clockHoldGeneration = -1

    func applyClockHoldTransition(_ transition: AudioOutput.PrerollTransition) {
        guard transition.generation >= clockHoldGeneration else { return }
        if transition.generation == clockHoldGeneration, transition.event == .began { return }
        clockHoldGeneration = transition.generation
        let held = transition.event == .began
        guard held != isClockHeld else { return }
        isClockHeld = held
        clockHoldSubject.send(transition.event)
    }

    /// Ends a hold with its session: the host's own cancellation arrives after the host is gone.
    func endClockHold() {
        clockHoldGeneration = -1
        guard isClockHeld else { return }
        isClockHeld = false
        clockHoldSubject.send(.released(.cancelled))
    }

    /// AE#792: the origin refused the session's credentials mid-session. One value per header set,
    /// the HTTP status (401 or 403), sent on the first refusal of that set, so a host can renew a
    /// lapsed or revoked token and hand it over with `updateRequestHeaders(_:)` while the reader is
    /// still retrying. See `updateRequestHeaders(_:)` for what happens if it does not.
    public var sourceAuthorizationRefused: AnyPublisher<Int, Never> {
        sourceAuthorizationRefusedSubject.eraseToAnyPublisher()
    }

    /// Forwards a refusal from the current session's header store to `sourceAuthorizationRefused`. The store holds
    /// this closure, so it holds the store weakly: a strong capture kept every session's store (and its headers)
    /// alive after the session ended.
    func relayCredentialRefusals(of store: RequestHeaderStore) {
        store.onCredentialRefusal = { [weak self, weak store] status in
            Task { @MainActor [weak self, weak store] in
                guard let self, let store, self.sessionRequestHeaders === store else { return }
                EngineLog.emit("[AetherEngine] AE#792: source refused the request headers (HTTP \(status))",
                               category: .engine)
                self.sourceAuthorizationRefusedSubject.send(status)
            }
        }
    }

    let sourceAuthorizationRefusedSubject = PassthroughSubject<Int, Never>()

    /// Monotonic id source for `SeekEvent`. Deliberately NOT `seekGeneration`: that counter is the
    /// supersede fence every in-flight finalize checks itself against, so a rejected or stashed seek must
    /// not be able to move it (it would make a live seek believe it lost and return without finalizing).
    private var seekEventCounter: UInt64 = 0

    /// Single source of truth for what playback is doing right now (#85), derived from
    /// `state` / `isBuffering` / `isSeeking` / the reader network phase. Recomputed on every input change;
    /// never a parallel state machine. Hosts should observe this instead of stitching the raw signals or
    /// regex-matching `EngineLog`.
    @Published public internal(set) var playbackPhase: PlaybackPhase = .idle

    /// AE#440: whether this load's transport has actually rolled once. Feeds `playbackPhase`.
    ///
    /// `state` is intent: every autostart writes `.playing` the moment it has called `play()`, and on
    /// the AVPlayer paths the rate can take seconds after that to roll (a live join holding to minimize
    /// stalls presents a first frame and then stands still). Until this is true, `playbackPhase` reports
    /// `.loading` rather than `.playing`, so a host keying chrome on the phase drops its spinner on
    /// motion instead of on intent. Latched by the transport-status sinks on the first real `.playing`;
    /// the paths that publish no transport status set it when their host is wired, so nothing about them
    /// changes. Reset with the session.
    var hasTransportRolled = false {
        didSet { recomputePlaybackPhase() }
    }

    /// Whether a `.paused` transport reading is this session's own pause, or the status its mount is
    /// still carrying (AE#440 follow-up).
    ///
    /// AE#440 held the pre-roll `.paused` back: AVPlayer delivers it AFTER the autostart has written
    /// `.playing`, so latching it published a millisecond of `.paused` on every native start. A host
    /// that pauses a session before its rate ever rolled produces the same status with the opposite
    /// meaning, and the roll gate alone swallowed that one too. The durable #122 intent tells them
    /// apart: a pause the engine was asked for has already cleared it, a mount that means to play
    /// has not.
    nonisolated static func publishesTransportPause(hasTransportRolled: Bool,
                                                    transportIntentIsPlaying: Bool) -> Bool {
        hasTransportRolled || !transportIntentIsPlaying
    }

    /// Whether an AVPlayer wait is a rebuffer (Sodalite#168).
    ///
    /// Every resume from pause passes through `waitingToPlay` with `evaluatingBufferingRate` for a frame
    /// or two while AVPlayer checks a buffer it already holds. Counting that as a rebuffer published
    /// `.rebuffering` on each Play press, and a host that raises a spinner on it flashed its chrome away
    /// and back. A wait that is really short of media moves on to `toMinimizeStalls`, which still counts,
    /// as does any other or missing reason.
    nonisolated static func nativeWaitIsRebuffer(status: AVPlayer.TimeControlStatus,
                                                 reason: AVPlayer.WaitingReason?) -> Bool {
        status == .waitingToPlayAtSpecifiedRate && reason != .evaluatingBufferingRate
    }

    /// Reader source-fetch axis feeding `playbackPhase`. Updated off the demux thread via
    /// `setReaderNetworkPhase`. `didSet` keeps `playbackPhase` in sync (#85).
    private var readerStall: ReaderNetworkPhase = .flowing {
        didSet { recomputePlaybackPhase() }
    }

    /// Idempotent: assigns `playbackPhase` only when the derived value actually changes, so a flapping
    /// origin or redundant input write never fires a spurious `objectWillChange`.
    private func recomputePlaybackPhase() {
        let next = PlaybackPhase.derive(state: state,
                                        isBuffering: isBuffering,
                                        isSeeking: isSeeking,
                                        stall: readerStall,
                                        transportHasRolled: hasTransportRolled)
        if playbackPhase != next { playbackPhase = next }
    }

    /// Main-actor entry point for the demuxer's `@Sendable onNetworkPhaseChanged` callback (#85).
    ///
    /// #433: transitions are logged. This axis is the only signal a host has for "the source is delivering",
    /// it moves a handful of times per session, and when it latched there was nothing in the diagnostic log
    /// that named the state or the moment it stopped moving: the report had to reconstruct it from the
    /// reader's generation counters.
    func setReaderNetworkPhase(_ phase: ReaderNetworkPhase) {
        guard readerStall != phase else { return }
        EngineLog.emit(
            "[AetherEngine] source network axis \(readerStall) -> \(phase)",
            category: .session
        )
        readerStall = phase
    }

    /// Bumped at every `seek(to:)` entry; a seek finalizes isSeeking only when its generation still matches,
    /// preventing a superseded seek from clobbering a newer one.
    private var seekGeneration: UInt64 = 0

    /// Read-only seek fence for diagnostics and queued resume work.
    var currentSeekGeneration: UInt64 { seekGeneration }

    /// Every actual reposition, including a live-only edge seek, invalidates prior work.
    func advanceSeekGeneration() -> UInt64 {
        seekGeneration &+= 1
        return seekGeneration
    }

    /// Three independent seek-in-flight flags that isSeeking OR-s over. Programmatic and native scrub
    /// seeks are NOT mutually exclusive: a far programmatic seek triggers the same producer-restart as a
    /// scrub. `deferred` is a seek stashed before the session could take it (#127/#178). Tracked
    /// separately so none can drop isSeeking before the others settle. Routed through
    /// `setProgrammaticSeek`/`setNativeScrubSeek`/`setDeferredSeek`.
    private var programmaticSeekInFlight = false
    private var nativeScrubSeekInFlight = false
    private var deferredSeekInFlight = false

    /// Per-source targets behind the published `seekTarget`. Kept apart because one fold over "the last
    /// non-nil target written" published a finished programmatic seek's destination while a scrub was in
    /// flight toward a different one, and a consumer broadcasting `seekTarget` broadcast the wrong place.
    private var programmaticSeekTarget: Double?
    private var nativeScrubSeekTarget: Double?
    private var deferredSeekTarget: Double?

    /// Event-side bookkeeping for one seek: the id its `.began` carried and the target it aims at. An
    /// open ticket IS the "not yet reported" state, so closing it is what prevents a double report.
    /// Deliberately outlives `programmaticSeekInFlight` on the give-up path: a seek reported `.stalled`
    /// stays alive inside AVPlayer as recovery intent, and the late landing that finally settles it has to
    /// arrive under the SAME id (AE#38 follow-up).
    struct SeekTicket {
        let id: UInt64
        let target: Double
        let origin: SeekEvent.Origin
    }

    var programmaticSeekTicket: SeekTicket?
    var nativeScrubSeekTicket: SeekTicket?
    private var deferredSeekTicket: SeekTicket?

    /// Armed scrub landing watch and its give-up timer; see `setNativeScrubSeek`.
    var pendingScrubLanding: PendingScrubLanding?
    var scrubLandingWatchdog: Task<Void, Never>?

    /// Was the in-flight restart run caused by a programmatic seek rather than a user scrub? Captured at
    /// the rising edge, because by the drain the programmatic seek may already have finalized.
    var scrubRestartOwnedByProgrammaticSeek = false

    private func nextSeekEventID() -> UInt64 {
        seekEventCounter &+= 1
        return seekEventCounter
    }

    /// Publishes one `SeekEvent` and logs it. The log line is the device-side record: a host that has not
    /// wired the stream still gets the same statement in `EngineLog`.
    func emitSeekEvent(id: UInt64, origin: SeekEvent.Origin, outcome: SeekEvent.Outcome, target: Double) {
        let event = SeekEvent(id: id, origin: origin, outcome: outcome, target: target)
        EngineLog.emit("[AetherEngine] \(event)", category: .engine)
        seekEventSubject.send(event)
    }

    /// Opens a ticket and publishes its `.began`.
    private func beginSeekTicket(origin: SeekEvent.Origin, target: Double) -> SeekTicket {
        let ticket = SeekTicket(id: nextSeekEventID(), target: target, origin: origin)
        emitSeekEvent(id: ticket.id, origin: origin, outcome: .began, target: target)
        return ticket
    }

    /// Terminates a ticket: emits the outcome under the id its `.began` carried, then closes it. A closed
    /// ticket is what keeps the late-landing hook from double-reporting a seek the finalize already
    /// settled, so every terminal path must run through here.
    func closeSeekTicket(_ ticket: inout SeekTicket?, with outcome: SeekEvent.Outcome) {
        guard let open = ticket else { return }
        emitSeekEvent(id: open.id, origin: open.origin, outcome: outcome, target: open.target)
        ticket = nil
    }

    /// The give-up contract: the seek drops out of `isSeeking`, but it is still alive inside AVPlayer as
    /// recovery intent, so its ticket stays OPEN and the late `.landed` arrives under the same id when the
    /// source finally serves the target (AE#38 follow-up, the case a level signal cannot express).
    func reportSeekStalled() {
        guard let open = programmaticSeekTicket else { return }
        emitSeekEvent(id: open.id, origin: open.origin, outcome: .stalled, target: open.target)
    }

    /// Recomputes isSeeking/seekTarget from the in-flight flags. Idempotent to avoid redundant Combine emissions.
    private func recomputeSeekSignal() {
        let seeking = programmaticSeekInFlight || nativeScrubSeekInFlight || deferredSeekInFlight
        // #240: a seek owns the link until it lands. Set unconditionally (not inside the
        // change guard) so the gate cannot drift from the flags it mirrors.
        sideReaderLinkGate.setSeeking(seeking)
        if isSeeking != seeking { isSeeking = seeking }
        let target = programmaticSeekTarget ?? nativeScrubSeekTarget ?? deferredSeekTarget
        if seekTarget != target { seekTarget = target }
    }

    private func setProgrammaticSeek(inFlight: Bool, target: Double?) {
        programmaticSeekInFlight = inFlight
        programmaticSeekTarget = inFlight ? target : nil
        recomputeSeekSignal()
    }

    /// #127/#178: a seek stashed before the session can take it. The engine publishes the target on
    /// `clock.currentTime` up front so scrub UI follows, which is exactly the position a consumer must NOT
    /// treat as reached, so the stash window carries the seek signal like any other in-flight seek.
    private func setDeferredSeek(inFlight: Bool, target: Double?) {
        deferredSeekInFlight = inFlight
        deferredSeekTarget = inFlight ? target : nil
        recomputeSeekSignal()
    }

    /// Opens (or replaces) the deferred stash entry. A second stashed seek supersedes the first, matching
    /// `pendingPreReadySeek`'s own latest-wins rule.
    func beginDeferredSeek(target: Double) {
        closeSeekTicket(&deferredSeekTicket, with: .superseded)
        deferredSeekTicket = beginSeekTicket(origin: .deferred, target: target)
        setDeferredSeek(inFlight: true, target: target)
    }

    /// Ends the deferred stash window. `.superseded` when the replay hands it to a real seek, `.rejected`
    /// when the load died under it. No-op without an open stash.
    func endDeferredSeek(_ outcome: SeekEvent.Outcome) {
        guard deferredSeekInFlight || deferredSeekTicket != nil else { return }
        closeSeekTicket(&deferredSeekTicket, with: outcome)
        setDeferredSeek(inFlight: false, target: nil)
    }

    /// AE#412: run `preparedSeekLanding` off the main actor. It parks on the pump while a re-cut
    /// opens its gate, and a seek must not hold the main actor for that (AE#422).
    private static func prepareSeekLanding(
        session: HLSVideoEngine?, itemSeconds: Double
    ) async -> Double {
        guard let session else { return itemSeconds }
        return await BlockingWork.detached(priority: .userInitiated) {
            session.preparedSeekLanding(itemSeconds: itemSeconds)
        }.value
    }

    /// Rejection path: the seek never reached a host, so it gets a standalone event and no `.began`.
    func emitSeekRejected(_ reason: SeekEvent.Rejection, target: Double) {
        emitSeekEvent(id: nextSeekEventID(), origin: .programmatic, outcome: .rejected(reason), target: target)
    }

    /// Complete the seek state after a late async recovery landing settled the clock through the
    /// `$renderedTime` sink. The deadline loop holds the clock at the target and returns without
    /// finalizing when a pathologically slow source has not served the target GOP within the whole
    /// extension budget (spinner-at-target rather than the old revert + flap). When the re-anchored
    /// producer finally serves the target, the sink settles the clock onto it; clear the
    /// programmatic-seek gate and reconcile the transport here so `state`/`isSeeking` leave `.seeking`
    /// instead of parking a spinner over a now-live frame.
    ///
    /// The event half runs even when the gate is already closed, which is the whole point: a seek that
    /// exhausted its budget was reported `.stalled` and dropped out of `isSeeking`, but it stayed alive
    /// as recovery intent, and this is where its real landing finally becomes observable. A level signal
    /// has no edge left to spend there, so the ticket carries it (AE#38 follow-up).
    func finalizeLateRecoverySeekLanding(rendered: Double) {
        closeSeekTicket(&programmaticSeekTicket, with: .landed(renderedTime: rendered))
        guard programmaticSeekInFlight else { return }
        setProgrammaticSeek(inFlight: false, target: nil)
        if let nativeHost {
            reconcileNativeSeekTransport(host: nativeHost, isStarved: false)
        }
    }

    /// Wired to `HLSVideoEngine.onSeekStateChanged`; see `requestRestart`. `target` is on the display
    /// axis; nil on the falling edge.
    ///
    /// The falling edge from the coalescer means "the producer is now producing at the new index", NOT
    /// "AVPlayer rendered it": the picture arrives a fetch and a decode later, measured at 1.4 s on a WAN
    /// source by the host this signal exists for. Clearing there published a landing that had not
    /// happened. Instead the scrub stays in flight and a landing watch on `$renderedTime` closes it when
    /// the picture actually reaches the target, bounded by `nativeScrubLandingBudgetSeconds` so a source
    /// that never serves it degrades to `.stalled` rather than latching the signal (AE#38 follow-up).
    func setNativeScrubSeek(inFlight: Bool, target: Double?) {
        if inFlight {
            // A restart that a programmatic seek caused is that seek's business: it owns the landing, its
            // own target is where the picture will end up, and the restart segment can sit a segment below
            // it (probe: restart 84.0, landing 90.0). Watching for a landing at the RESTART target there
            // would report a miss on a seek that landed fine, so this restart keeps the old drain-edge
            // semantics and the programmatic ticket carries the outcome.
            scrubRestartOwnedByProgrammaticSeek = programmaticSeekInFlight
            guard let target else {
                // No resolvable segment time (index outside the plan): keep the flag honest but publish no
                // target, and leave the landing watch unarmed.
                nativeScrubSeekInFlight = true
                nativeScrubSeekTarget = nil
                recomputeSeekSignal()
                return
            }
            if let open = nativeScrubSeekTicket, open.target != target {
                closeSeekTicket(&nativeScrubSeekTicket, with: .superseded)
            }
            // No ticket for a programmatic seek's own restart: that seek's events are the authority, and a
            // second pair reporting a landing at the RESTART target (a segment below where the picture
            // ends up) would contradict them. The level flag is still set, exactly as before.
            if nativeScrubSeekTicket == nil, !scrubRestartOwnedByProgrammaticSeek {
                nativeScrubSeekTicket = beginSeekTicket(origin: .nativeScrub, target: target)
            }
            nativeScrubSeekInFlight = true
            nativeScrubSeekTarget = target
            // A fresh restart run supersedes any armed watch; its watchdog must not outlive it and trip
            // the next one's window.
            pendingScrubLanding = nil
            scrubLandingWatchdog?.cancel()
            scrubLandingWatchdog = nil
            recomputeSeekSignal()
            return
        }
        // Coalesced restart run drained. Hand the falling edge to the landing watch when this restart was
        // a user scrub with a target and a native host to watch; otherwise settle now, exactly as before.
        guard !scrubRestartOwnedByProgrammaticSeek,
              let watchTarget = nativeScrubSeekTarget,
              let host = nativeHost else {
            // AE#270: the event's `target` is on the display axis, so its landing has to be too.
            let renderedTime = isLive && videoRoute == .loopback
                ? (nativeHost?.renderedTime ?? nativeClockSeconds) + liveSessionShiftSeconds
                    + liveItemAxisOffsetSeconds
                : PresentationAxis.display(sourcePTS: clock.sourceTime,
                                           origin: sourcePresentationOrigin)
            finishNativeScrubSeek(.landed(renderedTime: renderedTime))
            return
        }
        pendingScrubLanding = PendingScrubLanding(
            displayTarget: watchTarget,
            playlistTarget: isLive && videoRoute == .loopback
                ? watchTarget - liveSessionShiftSeconds - liveItemAxisOffsetSeconds
                : PresentationAxis.source(displayTime: watchTarget,
                                          origin: sourcePresentationOrigin) - playlistShiftSeconds,
            frozenRendered: host.renderedTime
        )
        // The watch runs on `$renderedTime`, which goes silent while AVPlayer waits to play, so the
        // give-up cannot be tick-driven.
        scrubLandingWatchdog?.cancel()
        let budget = Self.nativeScrubLandingBudgetSeconds
        scrubLandingWatchdog = Task { @MainActor [weak self] in
            try? await Task.sleep(nanoseconds: UInt64(budget * 1_000_000_000))
            guard !Task.isCancelled, let self, self.pendingScrubLanding != nil else { return }
            EngineLog.emit(
                "[AetherEngine] scrub landing watch expired after \(String(format: "%.0f", budget))s; "
                + "reporting stalled",
                category: .engine
            )
            self.finishNativeScrubSeek(.stalled)
        }
        checkPendingScrubLanding(rendered: host.renderedTime)
    }

    /// Closes the scrub's in-flight window and its ticket, and disarms the landing watch.
    func finishNativeScrubSeek(_ outcome: SeekEvent.Outcome) {
        pendingScrubLanding = nil
        scrubLandingWatchdog?.cancel()
        scrubLandingWatchdog = nil
        closeSeekTicket(&nativeScrubSeekTicket, with: outcome)
        nativeScrubSeekInFlight = false
        nativeScrubSeekTarget = nil
        recomputeSeekSignal()
    }

    /// `$renderedTime` hook for the scrub landing watch. No-op unless a watch is armed.
    func checkPendingScrubLanding(rendered: Double) {
        guard let watch = pendingScrubLanding else { return }
        guard Self.nativeScrubLanded(rendered: rendered,
                                     target: watch.playlistTarget,
                                     frozen: watch.frozenRendered) else { return }
        let renderedTime = isLive && videoRoute == .loopback
            ? rendered + liveSessionShiftSeconds + liveItemAxisOffsetSeconds
            : PresentationAxis.display(sourcePTS: rendered + playlistShiftSeconds,
                                       origin: sourcePresentationOrigin)
        finishNativeScrubSeek(.landed(renderedTime: renderedTime))
    }

    /// Armed when a coalesced scrub restart drains; retired when the picture reaches the target or the
    /// watchdog expires. `playlistTarget` is the AVPlayer-axis twin of `displayTarget`, because
    /// `renderedTime` is on the playlist axis.
    struct PendingScrubLanding {
        let displayTarget: Double
        let playlistTarget: Double
        let frozenRendered: Double
    }

    /// Budget for the scrub landing watch. Same order as the programmatic seek's reconcile budget: past
    /// it, "not landed" is the honest report.
    static let nativeScrubLandingBudgetSeconds: Double = 8.0

    /// High-frequency playback clock (currentTime, sourceTime, live-edge). Separate ObservableObject:
    /// its ~10 Hz ticks must not fire objectWillChange on the engine or every SwiftUI view re-renders per
    /// tick, causing tvOS Menu flicker (AetherEngine#29). Observe only in leaf views that render time.
    public let clock = PlaybackClock()

    /// Forwarder; for push updates subscribe to `clock.$currentTime` (objectWillChange does NOT fire on ticks).
    public var currentTime: Double { clock.currentTime }

    /// Deactivate the shared `AVAudioSession` when playback is torn down for good. Default `false`.
    ///
    /// Opt in only if your app owns the audio session. On an E-AC-3/Atmos BITSTREAM PASSTHROUGH route the
    /// HDMI sink keeps its own decode ring, and with the session still active it can loop the last MAT
    /// frame after the player is released (audio keeps stuttering after leaving the video, even off-screen).
    /// Deactivating on final teardown closes that ring.
    ///
    /// It is off by default because the native path deliberately never *activates* the session -- AVKit
    /// does that per playback (#24) -- so switching this on makes the engine mutate process-global state it
    /// did not create, using `.notifyOthersOnDeactivation`. An app that plays its own audio (UI sounds, TTS,
    /// an `AVAudioEngine`, a background music player) would have its session torn out from under it. Only
    /// a genuine final teardown honours this: `stop()` (with `resetDisplayCriteria: true`), never a
    /// handoff, reload, or retune.
    ///
    /// Applies to every backend, not just the native one. The software and audio renderer paths bypass
    /// AVKit and activate the session themselves (`activateRendererAudioSession`), so for those the
    /// deactivation is the engine releasing what the engine took.
    ///
    /// The release runs just after the teardown rather than inside it. `setActive(false)` is an XPC round
    /// trip that takes roughly half a second on an Atmos MAT passthrough route, which inline would be half
    /// a second of frozen UI before the host's dismiss can start. A `load()` that follows cancels a release
    /// that has not run yet, so a stop/load pair never loses its session, and a stop that lands while a
    /// software or audio-only load is still activating releases the session after that activation (AE#538).
    public var deactivatesAudioSessionOnStop: Bool = false

    /// Sodalite#175: a short name for this instance ("tile2") carried by the shared-output lines and the
    /// state transitions, so a log with several engines in it can be read. nil for a lone engine.
    public var logTag: String?

    @Published public internal(set) var duration: Double = 0

    /// Forwarder; see `clock.progress`.
    public var progress: Float { clock.progress }

    // internal(set): syncPublishedAudioStateFromNativeSession replaces the probe-derived list with side-demuxer
    // tracks for demuxed-audio live sources after load completes.
    @Published public internal(set) var audioTracks: [TrackInfo] = []
    // internal(set): the disc title-switch reload republishes the new title's tracks from AetherEngine+Loading.
    @Published public internal(set) var subtitleTracks: [TrackInfo] = []
    /// Container metadata (tags + cover). Populated from the probe demuxer before backend dispatch; nil while idle.
    @Published public private(set) var metadata: MediaMetadata?
    /// Active audio stream index (matches TrackInfo.id), or nil when no audio is wired. Updated synchronously
    /// on `selectAudioTrack` reload so the picker reflects the actual muxed track.
    @Published public internal(set) var activeAudioTrackIndex: Int?
    @Published public internal(set) var videoFormat: VideoFormat = .sdr

    /// Source video format before panel clamping. Differs from `videoFormat` when the panel can't present the
    /// source (e.g. DV on SDR panel): `videoFormat` reads `.sdr` (what's on screen), this stays `.dolbyVision`.
    /// Use for media-attribute labels (Stats for Nerds); use `videoFormat` for panel-rendering UI.
    /// Late HDR10+ T.35 SEI upgrades flip this independently of `videoFormat`'s panel guard.
    @Published public internal(set) var sourceVideoFormat: VideoFormat = .sdr

    /// Dolby Vision profile number (5, 7, 8, 10) of the source, or nil when not DV. Companion to
    /// `sourceVideoFormat` for Stats-for-Nerds labels ("Dolby Vision P5"); read from the dvcC record.
    @Published public internal(set) var sourceDVProfile: Int? = nil

    /// The Dolby Vision profile rewrite applied to the served stream, nil when the session serves the source's
    /// own profile (or no Dolby Vision). `.profile7ToProfile81` on every Profile 7 source not served as its
    /// base layer, whatever the display; `sourceDVProfile` keeps 7.
    @Published public internal(set) var dolbyVisionConversion: DolbyVisionConversion? = nil

    /// A HDR10+ (ST 2094-40) T.35 payload was seen in this session's video, whatever the source's format.
    /// `sourceVideoFormat` records it only for an HDR10 source, so a Dolby Vision source carrying both kinds
    /// of dynamic metadata would otherwise lose it the moment a late panel proof republishes the label.
    var sourceCarriesHDR10PlusMetadata = false

    /// AE#461: base-layer signal compatibility ID from the same dvcC/dvvC record as `sourceDVProfile`
    /// (0 = IPT-only, no compatible base layer). Kept because a decode-path correction has to decide
    /// whether the software path can represent this source BEFORE it tears the session down, and by
    /// then the probe stream that carried the record is long gone. Read alongside
    /// `sourceDolbyVisionBaseLayerPresentable` when offering source-specific playback choices.
    /// nil means unavailable; reset on load and stop. This is source metadata, not display output.
    /// Assigned before `sourceVideoFormat` / `sourceDVProfile`, so their publisher callbacks read it current.
    public internal(set) var sourceDVBLCompatID: Int? = nil

    /// AE#532: the profile the loaded source's own RPU reports, when the record was contradicted enough
    /// to be worth checking (`DolbyVisionRecordAudit`). nil for every other source, including one whose
    /// RPU could not be read. Held for the same reason as `sourceDVBLCompatID`: a reload has to judge the
    /// source after the probe that measured it is gone.
    var sourceDolbyVisionRPUProfile: Int? = nil

    /// AE#541: the two load-time terms of the HDR route that a reload cannot take again. The criteria
    /// readout is only an answer around the handshake, and an in-place rebuild runs none, so an audio
    /// pick that routed from the raw `panelIsInHDRMode` alone dropped an HDR title from the master to
    /// the media playlist on the panel the load had just proven. nil readout means suppressed, as at
    /// the load.
    var sessionPanelHDRReadout: Bool? = nil

    /// AE#535: the display table this session composed its route from, kept for the same reason as the
    /// readout above. `displayCapabilities` answers at call time, and a reporter measured the platform
    /// revoking every term of it (`hdr=false hdr10=false hlg=false dv=false`, alongside the user's own
    /// Match-Content preference reading `off`) while the app was backgrounded, 0.7 s after the
    /// transition and restored 133 ms after it came back, in one process. A route-death rebuild inside
    /// that window would otherwise clamp an HDR title to SDR and withhold its master against a display
    /// the load had just read as DV-capable. nil means no load has composed one yet.
    var sessionObservedDisplayCaps: DisplayCapabilities? = nil

    /// What the route asks of the display, which is the OBSERVED term: a host's Dolby Vision assertion
    /// claims DV (and the HDR that entails) for the served stream, it does not make the panel eligible.
    /// Deriving it keeps the load's answer and the rebuild's the same value rather than two.
    var sessionDisplayEligibleForHDR: Bool { sessionObservedDisplayCaps?.supportsHDR ?? false }

    /// Enhancement layer type for Profile 7 streams ("FEL" or "MEL") extracted from the first RPU.
    var sourceElType: String? = nil

    /// #846: the upscale plan the load decided, carried to every software host this session builds.
    var sourceUpscalePlan: UpscalePlan? = nil

    /// #846: set when the session's stage disabled itself, so no later host of the session builds one again.
    var sourceUpscaleDisabled: UpscaleStatus? = nil

    /// #846: the source frame rate the upscale decision read, which the failure memory is keyed with.
    var sourceUpscaleFrameRate: Double? = nil

    /// #846: the routing would have played this session natively, and only the upscale route took it to software.
    var sourceSoftwareOnlyForUpscale = false

    /// #846: the load generation whose disabled stage still owes the return to the native path.
    var upscaleNativeReturnOwed: UInt64? = nil

    /// Whether the loaded source's Dolby Vision has a base layer `LoadOptions.dolbyVisionHandling =
    /// .baseLayerOnly` can present (`VideoRoutingPolicy.dolbyVisionBaseLayerIsPresentable`), decided
    /// on the probe stream for the same reason as `sourceDVBLCompatID`: a correction that turns the
    /// base layer on and moves to software in one step is judged before the teardown, when the VUI it
    /// rests on is gone. Reset to false on load and stop. This describes the engine's base-layer
    /// route eligibility, not the panel's output or a guarantee that a reload will be accepted.
    public internal(set) var sourceDolbyVisionBaseLayerPresentable: Bool = false

    /// Nominal source frame rate (fps) from the container's `avg_frame_rate` (falling back to `r_frame_rate`),
    /// or nil when the source has no video or libavformat couldn't derive one. Companion to `sourceVideoFormat`
    /// for Stats-for-Nerds. `LiveTelemetry.observedFps` measures the live rate but is nil on the native AVPlayer
    /// path (no usable counter); this nominal value fills that gap for the on-screen readout.
    @Published public internal(set) var sourceVideoFrameRate: Double? = nil

    /// AE#983: progressive or interlaced, and the field order, resolved at load from the evidence the
    /// routing reads: the probe's field order, the H.264 SPS when that is open (#150), and the #232
    /// frame sample, which turns a declared-interlaced source with progressive pictures into
    /// `.progressive`. `.unknown` before load, on the probe-free remote-HLS bypass and when nothing
    /// settles it. Whether a deinterlacer actually runs is `decodedVideoFormat?.deinterlace`.
    @Published public internal(set) var sourceVideoScan: VideoScan = .unknown

    /// Declared source video bitrate in bits/second (0 when the container declares none). From the video
    /// stream's `codecpar.bit_rate`, or the Matroska `BPS` statistics tag when that is 0 (mkvmerge). Static
    /// container info for Stats-for-Nerds; the live per-second rate lives in `LiveTelemetry`.
    @Published public internal(set) var sourceVideoBitrate: Int64 = 0

    /// Source video codec in the libavcodec vocabulary ("hevc", "h264", "av1", "mpeg2video"), nil before
    /// load and when the source has no video track. On the probe-free native HLS bypass it is mapped back
    /// from the item's video sample type, so one field means one thing on every path. Companion to
    /// `sourceVideoFormat` for Stats-for-Nerds; `activeVideoDecoder` names what is decoding it, which is a
    /// different question (a codec has more than one decoder, and the answer changes with hardware).
    @Published public internal(set) var sourceVideoCodecName: String? = nil

    /// AE#658: the source video stream's pixel format, bit depth, colour description and profile as the
    /// container and the probe's decoder declared them, nil before load and on sources without video.
    /// Companion to `decodedVideoFormat`, which is what the engine's own decoder actually produced.
    ///
    /// On the probe-free native HLS bypass it is read back from AVPlayer's item video track once that
    /// resolves: colour from the format description's extensions, profile, bit depth and pixel format from
    /// its avcC / hvcC record where it carries one (nil otherwise, AV1 and VP9 included). That is the
    /// DELIVERED stream, which under a server-side transcode is not the file the host's library holds.
    @Published public internal(set) var sourceVideoStreamFormat: VideoStreamFormat? = nil

    /// AE#658: the format the engine's software decoder produced and the display buffer it went into,
    /// updated when either changes mid-stream. nil whenever the engine does not decode the picture
    /// itself, which on the native path is always: AVPlayer decodes there, and its frames never pass
    /// through the engine, so `sourceVideoStreamFormat` is the only description a host has.
    @Published public internal(set) var decodedVideoFormat: DecodedVideoFormat? = nil

    /// Container libavformat opened ("matroska,webm", "mpegts", "mov,mp4,m4a,3gp,3g2,mj2"), nil before load
    /// and on the native HLS bypass (AVFoundation opens that one, there is no libav context to ask). This is
    /// the container that ARRIVED: on a remux or transcode session it differs from the one the host's library
    /// holds, and that difference is the thing a stats panel exists to show.
    @Published public internal(set) var sourceContainerFormat: String? = nil

    // MARK: - Disc titles / chapters (#67)

    /// Selectable titles on the loaded disc image (Blu-ray playlists / DVD titles), longest first so
    /// id 0 is the main feature. Empty for non-disc sources. Populated from the probe demuxer at load.
    @Published public internal(set) var discTitles: [TitleInfo] = []
    /// The disc title currently playing, or nil for a non-disc source. Updated on `selectTitle` reload.
    @Published public internal(set) var selectedDiscTitle: TitleInfo?
    /// Chapters of the selected title. Empty until Blu-ray chapter parsing ships (Phase 2); declared
    /// now so hosts can bind the picker against a stable API.
    @Published public internal(set) var discChapters: [ChapterInfo] = []
    /// Container (Matroska/MP4) chapters of the loaded source. Empty when the container declares none and
    /// for disc sources (whose chapters publish on `discChapters` with title-relative seek semantics).
    ///
    /// `startSeconds` and `durationSeconds` are on the same 0-based axis as `currentTime`, `duration` and
    /// `seek(to:)`: the container's own chapter time minus the container start the playback clock begins
    /// at. So `seek(to: mediaChapters[i].startSeconds)` lands on that chapter, on either backend. A chapter
    /// that ends before the content starts (a pre-roll before a container start of 5 s) is not published.
    /// The raw container times are not on this axis; `sourceTime` is the one that reads them.
    @Published public internal(set) var mediaChapters: [ChapterInfo] = []
    /// The container chapters behind `mediaChapters`, on the source axis, snapshotted at probe time. Kept
    /// apart from the published list so the list can be rebased when the backend (and with it the origin)
    /// is settled, and so a reopen of the same source rebuilds it without re-probing.
    var containerChapterSource: Demuxer.ContainerChapterSource?
    /// The session zero the software host's clock actually anchored on, once it has re-anchored on its
    /// first sample (a source starting past the 2 s tolerance). Nil until then, and for any other backend.
    var softwareClockSessionZero: Double?
    /// The id of the title the disc demuxer should (re)open with. Mirrors `selectedDiscTitle?.id` but
    /// kept as plain state so it survives the stopInternal inside a reload and threads into audio-switch /
    /// background-resume reopens (a URL-disc reopen with no id would silently revert to the main title).
    var activeDiscTitleID: Int?

    /// Source start PTS (seconds) the software host anchors its clock on: the demuxer's resolved origin
    /// (`Demuxer.resolvedSourceStartOrigin`: the container start, backed up by the video stream's own
    /// start when the container states none). `PresentationAxis.discChapterSeekTarget` needs the same
    /// origin the host derives its session zero from, so the part of it the zero did not take can be
    /// added to a DVD chapter's title-relative (0-based) target. 0 when unknown (#67).
    var sourceStartSeconds: Double = 0

    /// Active playback backend: `.native` (AVPlayer) or `.software` (SoftwarePlaybackHost/dav1d/libavcodec).
    /// Exposed for diagnostic overlays; hosts should not branch on it. Branch on `videoRoute` instead,
    /// which also separates the two native pipelines (#321).
    @Published public internal(set) var playbackBackend: PlaybackBackend = .none {
        didSet {
            recomputeVideoRoute(); recomputeAudioDelivery(); recomputeAirPlayPictureStaysLocal()
            // The chapter origin depends on the backend; a backend that is not settled yet keeps the list.
            if playbackBackend != .none { republishMediaChapters() }
        }
    }

    /// True while a wireless AirPlay receiver holds the audio route and the session's picture cannot
    /// follow it, so the receiver plays the sound and the picture stays on this device.
    ///
    /// That is the software host (VP9, AV1 without a hardware decoder, deinterlaced MPEG-2 / VC-1 /
    /// H.264, a host's `preferredDecodePath = .software`): it draws into an `AVSampleBufferDisplayLayer`,
    /// and only its `AVSampleBufferAudioRenderer` follows the route. Nothing fails, so without this a host
    /// has no way to tell the viewer why the TV shows no picture. iOS only; false everywhere else, and
    /// false on the native paths, where AVPlayer hands the receiver the stream. False too while the host
    /// reports the screen as mirrored (`setScreenMirrored(_:)`), because the mirror carries the layer.
    @Published public internal(set) var airPlayPictureStaysLocal = false

    nonisolated static func airPlayPictureStaysLocal(backend: PlaybackBackend,
                                                     wirelessAirPlayRoute: Bool,
                                                     screenMirrored: Bool = false) -> Bool {
        // A mirrored screen carries the layer to the receiver, so the picture is not local.
        wirelessAirPlayRoute && backend == .software && !screenMirrored
    }

    /// iOS: whether the system is mirroring this screen, as the host reports it
    /// (`UITraitCollection.sceneCaptureState` is `.active`). Only `airPlayPictureStaysLocal` reads it.
    private(set) var screenMirrored = false

    /// Tell the engine whether the screen is being mirrored. A mirror carries the software host's layer
    /// to the receiver, so `airPlayPictureStaysLocal` reads false while it is on. The engine has no scene
    /// of its own to read, so the host passes it on from `sceneCaptureState` (a recording reads as
    /// captured too; pass `true` only for a mirror). Has no effect off iOS.
    public func setScreenMirrored(_ mirrored: Bool) {
        guard screenMirrored != mirrored else { return }
        screenMirrored = mirrored
        recomputeAirPlayPictureStaysLocal()
    }

    /// iOS: whether the AirPlay receiver on the audio route shows video (an Apple TV or a TV), as the host
    /// reports it. False, the default, means an audio-only output or unknown. There is no public way for
    /// the engine to tell the two apart: the audio session reports every AirPlay output as the same port
    /// type. See `setAirPlayReceiverShowsVideo(_:)`.
    private(set) var airPlayReceiverShowsVideo = false

    /// Tell the engine whether the AirPlay receiver the viewer picked shows video. While one does, a
    /// Profile 7 FEL source loads on the native route (8.1 where the display takes Dolby Vision, the
    /// enhancement layer is lost) so the receiver gets a picture: the dual-layer route draws into a local
    /// layer that no receiver picks up. An audio-only output such as a HomePod keeps the dual-layer route,
    /// because the picture is on the device anyway. The engine cannot learn this itself, so the value is
    /// whatever the host knows: the viewer's own choice (a "playing to a TV" control), or a host-owned
    /// `AVPlayer`'s `isExternalPlaybackActive`. Read at each load. On a URL source, `reloadAtCurrentPosition()`
    /// decides again; a custom source keeps the route it loaded with until the next `load()`. Has no
    /// effect off iOS.
    public func setAirPlayReceiverShowsVideo(_ shows: Bool) {
        guard airPlayReceiverShowsVideo != shows else { return }
        airPlayReceiverShowsVideo = shows
        let effect = shows ? "a FEL source takes the native route" : "a FEL source keeps the dual-layer route"
        EngineLog.emit("[AirPlay] host reports the receiver \(shows ? "shows" : "does not show") video: \(effect) at the next load",
            category: .engine)
    }

    /// Whether the dual-layer decision should yield to a receiver: a wireless AirPlay output holds the
    /// audio route and the host says it shows video.
    nonisolated static func airPlayVideoReceiverHoldsRoute(wirelessAirPlayRoute: Bool,
                                                           receiverShowsVideo: Bool) -> Bool {
        wirelessAirPlayRoute && receiverShowsVideo
    }

    /// Idempotent, and logged on each change, so a report shows when the receiver lost the picture.
    func recomputeAirPlayPictureStaysLocal() {
        let next = Self.airPlayPictureStaysLocal(backend: playbackBackend,
                                                 wirelessAirPlayRoute: Self.isWirelessAirPlayRoute(),
                                                 screenMirrored: screenMirrored)
        guard airPlayPictureStaysLocal != next else { return }
        airPlayPictureStaysLocal = next
        EngineLog.emit(
            next
                ? "[AirPlay] wireless receiver holds the audio route, but the software path draws the "
                  + "picture on this device: the receiver plays sound only"
                : "[AirPlay] picture and audio route agree again",
            category: .engine)
    }

    /// Pipeline actually serving this session (#321), including the reroutes the host never asked for.
    /// Derived from `playbackBackend` + `loadedOptions.nativeRemoteHLS`, the two properties every reroute
    /// site already writes, so it cannot desync from them. See `VideoRoute` for the transitions.
    @Published public internal(set) var videoRoute: VideoRoute = .none

    /// Idempotent: assigns only on a real change, so options writes that leave the route alone (the
    /// per-reopen replay) do not flap the publisher. Logs every route the session takes; the drop to
    /// `.none` is teardown, which carries no route information and is already loud in the log.
    private func recomputeVideoRoute() {
        let next = VideoRoute.derive(backend: playbackBackend,
                                     nativeRemoteHLS: loadedOptions.nativeRemoteHLS)
        guard videoRoute != next else { return }
        videoRoute = next
        if next != .none {
            EngineLog.emit("[AetherEngine] #321: effective video route = \(next.rawValue)", category: .engine)
        }
    }

    /// How this session's audio reaches the renderer (AE#462), above all whether a source that HAS
    /// audio is playing video-only because no pipeline could be built for it (`.droppedNoPipeline`,
    /// the value a fallback ladder demotes on). Derived from `playbackBackend` + `loadedOptions` +
    /// the live pipeline's own classification, so it cannot drift from the running session.
    @Published public internal(set) var audioDelivery: AudioDelivery = .none

    /// The classification the pipeline serving this session made about itself, or nil while none is
    /// live. Read through the backend rather than by probing all four hosts, so a host left behind by
    /// a teardown cannot answer for the session that replaced it.
    private var livePipelineAudioDelivery: (loopback: AudioDelivery?,
                                            software: AudioDelivery?,
                                            audioOnly: AudioDelivery?) {
        (loopback: nativeVideoSession?.audioDelivery,
         software: softwareHost?.audioDelivery,
         // Neither audio-only host can reach video-only: AVPlayer owns the selection on the native
         // one, and the software one throws out of its load when the decoder does not open.
         audioOnly: audioAVPlayerHost != nil ? .playerManaged : (audioHost != nil ? .decoded : nil))
    }

    /// Idempotent for the same reason as the route above. Logged on every change, including the drop
    /// to `.none`, so a diagnostic pull answers "did this session deliver audio" without the reader
    /// having to reconstruct it from the cascade's own lines.
    func recomputeAudioDelivery() {
        let pipeline = livePipelineAudioDelivery
        let next = AudioDelivery.derive(backend: playbackBackend,
                                        nativeRemoteHLS: loadedOptions.nativeRemoteHLS,
                                        loopbackSession: pipeline.loopback,
                                        softwareHost: pipeline.software,
                                        audioOnlyHost: pipeline.audioOnly)
        recomputeAudioShapingState()
        guard audioDelivery != next else { return }
        audioDelivery = next
        if next != .none {
            EngineLog.emit("[AetherEngine] AE#462: audio delivery = \(next.rawValue)", category: .engine)
        }
    }

    /// AE#923: whether this session's audio is shaped as `audioShaping` asks. Derived next to
    /// `audioDelivery`, from the pipeline's own report, for the same reason.
    @Published public internal(set) var audioShapingState: AudioShapingState = .off

    /// Whether the pipeline serving the session carries shaping: true when it does, false when this
    /// session cannot (AVPlayer owns the audio, or there is no audio to shape), nil while no pipeline
    /// is live or the live one was built before the value changed and its rebuild is on the way.
    private var livePipelineAppliesShaping: Bool? {
        func engineOwned(applied: Bool?, delivery: AudioDelivery?) -> Bool? {
            guard let applied, let delivery else { return nil }
            if applied { return true }
            return delivery == .noAudioInSource || delivery == .droppedNoPipeline ? false : nil
        }
        switch playbackBackend {
        case .none, .aether: return nil
        case .native:
            if loadedOptions.nativeRemoteHLS { return false }
            return engineOwned(applied: nativeVideoSession?.audioShapingApplied,
                               delivery: nativeVideoSession?.audioDelivery)
        case .software:
            return engineOwned(applied: softwareHost?.audioShapingApplied, delivery: softwareHost?.audioDelivery)
        case .audio:
            if audioAVPlayerHost != nil { return false }
            return audioHost.flatMap { $0.audioShaping.isActive ? true : nil }
        }
    }

    func recomputeAudioShapingState() {
        let next = AudioShapingState.derive(shaping: loadedOptions.audioShaping,
                                            pipelineApplies: livePipelineAppliesShaping)
        guard audioShapingState != next else { return }
        audioShapingState = next
        EngineLog.emit("[AetherEngine] AE#923: audio shaping \(next.rawValue) (\(loadedOptions.audioShaping.summary))",
                       category: .engine)
    }

    /// Timing adjustment for subtitles composited into software PiP frames, in media seconds.
    /// Positive values delay subtitles; negative values advance them. Host overlays must apply
    /// the same value against `clock.sourceTime`. Native AVPlayer renditions are not affected.
    /// Persists across loads on this engine, like a host presentation preference.
    public private(set) var softwareSubtitleDelaySeconds: Double = 0

    /// Updates software subtitle composition without reopening media or shifting the A/V clock.
    /// Non-finite values are ignored. Takes effect on the next composited video frame.
    public func setSoftwareSubtitleDelay(_ seconds: Double) {
        guard seconds.isFinite, seconds != softwareSubtitleDelaySeconds else { return }
        softwareSubtitleDelaySeconds = seconds
        softwareHost?.updateSubtitleCompositor(cues: subtitleCues + secondarySubtitleCues,
            enabled: pictureInPictureActive, delaySeconds: seconds)
        EngineLog.emit("[AetherEngine] software subtitle delay=\(seconds)s", category: .engine)
    }

    /// Master enable for background playback (iOS: PiP + background audio; tvOS: PiP keepalive). Default on.
    public var backgroundPlaybackEnabled = true

    /// Whether renderer paths activate the shared audio session during load and interruption recovery.
    /// Disable before loading when the host owns activation across several inline players.
    /// The category is still declared once per process; pair with `deactivatesAudioSessionOnStop = false`
    /// when the host also owns final deactivation. Native AVKit activation is unaffected.
    public var rendererAudioSessionActivationEnabled = true

    /// Keep a paused video session through background suspension instead of releasing its pipeline.
    /// Off by default: the system may invalidate decoders while suspended, requiring a reload.
    /// This does not enable background playback or change the policy for a playing session.
    public var retainsVideoPipelineWhenBackgrounded = false
    /// Set by the host from its PiP delegate (iOS: AVKit; tvOS: host-built AVPictureInPictureController);
    /// the keepalive policy + pause-safety read it.
    public var pictureInPictureActive = false {
        didSet {
            #if os(macOS)
            updatePictureInPictureTracking()
            #endif
            updatePictureFit()
            nativeHost?.pictureInPictureActive = pictureInPictureActive
            // SW-PiP Phase C: flip the frame compositor with the PiP state so subtitles appear in the
            // window and never double-draw under the fullscreen host overlay.
            softwareHost?.updateSubtitleCompositor(cues: subtitleCues + secondarySubtitleCues, enabled: pictureInPictureActive, delaySeconds: softwareSubtitleDelaySeconds)
            noteVideoPresentationToHost()
            #if os(tvOS)
            // PiP window closed while backgrounded: nothing keeps the app running anymore, so the
            // wedge-safe teardown is due before idle suspension (mirrors the iOS pause-while-backgrounded path).
            if closingPictureInPictureOwesBackgroundDecision(wasActive: oldValue) {
                settleBackgroundDecisionAfterPictureInPictureClosed()
            }
            #endif
        }
    }
    /// True while `stopInternal` clears `pictureInPictureActive` itself.
    var isResettingPictureInPictureForStop = false
    /// Whether the PiP flag going false is a window closing that owes the background decision. Not when
    /// `stopInternal` is the one clearing it: that is the teardown the decision would schedule, and it
    /// is half done at that point.
    func closingPictureInPictureOwesBackgroundDecision(wasActive: Bool) -> Bool {
        wasActive && !pictureInPictureActive && !isResettingPictureInPictureForStop
    }
    /// #127: seconds a PAUSED session survives backgrounding (iOS) before the wedge-safe teardown runs,
    /// held under a background-task assertion so a quick app switch resumes without a pipeline rebuild.
    /// 0 restores the immediate teardown. Ignored on tvOS. Keep well under the ~30 s system allowance,
    /// the teardown itself needs ~3.5 s of drain before suspension.
    public var backgroundTeardownGraceSeconds: Double = 15

    /// #127: true once the active session's transport is ready to accept seeks and report real time
    /// (native: AVPlayerItem readyToPlay; SW/audio hosts publish readiness at session start). Hosts
    /// gate corrective actions (restore watchdogs, position clamps) on this instead of inferring
    /// readiness from currentTime being pinned at 0.
    @Published public internal(set) var isSessionReady = false

    /// #315: the running path has a first frame ready for display, for the media this `load()`
    /// opened. This is the edge a black cover comes off on; `isSessionReady` is not that edge and
    /// cannot be made into one.
    ///
    /// `isSessionReady` is `AVPlayerItem.readyToPlay`, which AVFoundation reaches before the layer
    /// holds a picture and which stays true across a seek. Measured on a loopback origin, the
    /// player's layer reports its first frame ~0.05 s into a load and `timeControlStatus` follows
    /// at ~0.10 s; on a slow origin those separate by as much as the source is slow, and a load
    /// opened paused never produces the second one at all. Hosts approximating presentation from
    /// `phase == .playing/.paused && isSessionReady` therefore lift the cover onto black.
    ///
    /// What backs it: `AVPlayerLayer.isReadyForDisplay` on the native path,
    /// `AVSampleBufferDisplayLayer.isReadyForDisplay` on the software one (on visionOS 1.0, where that
    /// property does not exist, the software path falls back to the first frame handed to the
    /// renderer, one hop earlier than presentation). Audio-only sessions have
    /// nothing to display and leave it false.
    ///
    /// Two things it does NOT claim:
    ///
    /// - **Not "the viewer sees it".** It is the pipeline's own statement that a first frame is
    ///   ready. The engine's layer reaches it even when it is in no view hierarchy (measured), so
    ///   a host that never bound a surface still gets true here while showing nothing (#298), and
    ///   an `AVPlayerViewController` host presents through AVKit's own layer a frame or so later.
    /// - **Not a level.** It is latched for the load: false at every `load()` and at `stop()`, true
    ///   once and then held. What decides whether a swap surfaces is the entry point, not the
    ///   `inPlaceSwap` flag it is made with. The seams that reuse the running host by calling
    ///   `host.load(inPlaceSwap:)` themselves (media fallback, the wired-HDMI AirPlay master swap,
    ///   the #93 recovery reload) each drop the layer's picture for a few tens of milliseconds,
    ///   measured, and this holds true through them: reporting them would make a host re-cover a
    ///   seam it is deliberately not meant to see, and a falling edge would be ambiguous in exactly
    ///   the way `SeekEvent` was introduced to fix, since nothing in a level says why it fell.
    ///   Everything that enters through the engine's `load()` resets it instead, the AE#158
    ///   in-place handover and `reloadAtCurrentPosition()` (so the wireless-AirPlay route change)
    ///   included. The handover keeps the OUTGOING item attached across the teardown so a system
    ///   PiP window survives, but its content is new and has to reach its own first frame; holding
    ///   the latch across it would lift a host's cover onto the previous episode's frozen frame.
    ///
    /// - **Not a local frame while an external screen holds the picture.** Measured on a device
    ///   (iPhone -> Apple TV, 2026-08-09): with `isExternalPlaybackActive` true the local
    ///   `AVPlayerLayer` never reaches `isReadyForDisplay`, on any load of the session, so folding
    ///   only the layer would leave this false for the whole AirPlay session and hang a host that
    ///   waits for it. There is no local first frame coming and the engine cannot see the
    ///   receiver's screen, so past the item's readiness the picture is the receiver's business and
    ///   the flag latches there instead. Audio-only sessions still never arm it.
    ///
    /// For "has this seek reached the screen", the per-seek answer is `SeekEvent.landed`, not this
    /// flag: a seek keeps the previous frame up, so the layer never stops being ready for display.
    @Published public internal(set) var hasFirstFrameReadyForDisplay = false

    /// True while the running session has a host video-display signal to fold (#315). Set with the
    /// host sinks, cleared with the session, and what keeps the external-playback latch from arming
    /// an audio-only session, which has a picture nowhere.
    var sessionPublishesVideoDisplaySignal = false

    /// #361: how far the current startup has come, for a host driving a determinate loading bar.
    /// nil while no startup is running (before the first load, and after `stop()`).
    ///
    /// Every value is a checkpoint some piece of the load actually finished, so the number is honest
    /// in the only sense that matters to a bar: it never runs on a timer, and it never advances on
    /// an estimate. A startup that errors or is stopped simply never reaches the last checkpoint;
    /// nothing fakes an ending. Steady republishes are deduped, so a Combine sink on this fires once
    /// per real step. See `StartupProgress`.
    @Published public internal(set) var startupProgress: StartupProgress?

    /// #127: latest seek issued while the native item was pre-ready; replayed at readiness.
    ///
    /// AE#446 round 4: with the origin that asked for it. The replay goes back out through
    /// `seek(to:origin:)`, so a slot that only remembered a number handed the engine's own rejoin to
    /// the host scrubber's guard, which refused it on a session that advertises no DVR window.
    struct PendingPreReadySeek: Equatable {
        var seconds: Double
        var origin: SeekOrigin
        var exact = false
    }
    var pendingPreReadySeek: PendingPreReadySeek?
    /// AE#446 round 4: what separates the CURRENT item's own timeline from the session's, in seconds.
    ///
    /// AVPlayer places a live playlist's content by the PLAYLIST, so an item's zero is the first
    /// segment its playlist listed when it loaded, not the producer's first segment. The two coincide
    /// for the item a session starts with and stop coinciding for any item attached after the window
    /// has slid, which an in-place swap does routinely. Measured rather than assumed; see
    /// `measureLiveItemAxisOffset`. 0 on every path where the question does not arise.
    var liveItemAxisOffsetSeconds: Double = 0
    /// AE#446 round 5: the item generation the axis latch was armed for, recorded at the attach that
    /// armed it. A stated axis is only this item's if the arm that cleared the latch was its own.
    var liveItemAxisArmedGeneration: Int = -1
    /// The item generation `liveItemAxisOffsetSeconds` was measured for.
    var liveItemAxisOffsetGeneration: Int = -1
    /// AE#454 round 2: the item generation whose axis the playlist has already stated, so the
    /// statement is taken once rather than on every tick.
    var liveItemAxisStatedGeneration: Int = -1
    /// AE#454 round 2: the item generation a rejoin armed a manifest placement for.
    ///
    /// Only that item came up on an axis the playlist stated, so only for that item may the stated
    /// axis be believed over a measurement. Any later item loaded for an unrelated reason reads the
    /// producer as before.
    var liveRejoinPlacementGeneration: Int = -1
    /// AE#454: the item generation the session's published position describes, accepted at readiness.
    /// -1 until the first item of a session is ready, which is what keeps a cold join publishing
    /// exactly as before. See `liveItemPlacementPending`.
    var liveAcceptedItemGeneration: Int = -1
    /// AE#446 round 4: bounded audit after a rejoin swap. See `auditLiveRejoinPlacement`.
    var liveRejoinAuditUntil: Date?
    var liveRejoinAuditLastEmit: Date?
    /// One-shot host request: keep the running native item attached until the next `load()` can
    /// replace it atomically. A foreground playlist or episode change through a host-mounted
    /// `AVPlayerLayer` has the same nil-item exposure PiP does; this lets the host ask for the
    /// same protection without pretending Picture in Picture is active. Armed by
    /// `prepareForItemReplacement()`, consumed by the next `load()`, cleared by `stop()`.
    private var nextLoadRequestsInPlaceItemHandover = false
    /// AE#158: set by load() when the running item must survive until the new master attaches (PiP
    /// or host-requested next-episode handover); consumed and reset by the loopback host.load
    /// callsite (inPlaceSwap).
    var pendingInPlaceItemHandover = false
    /// SW-PiP bridge, the software-path analog of `currentAVPlayer`: set when a SW session has its
    /// display layer, nil on teardown. Hosts build their sample-buffer PiP ContentSource from it.
    @Published public internal(set) var softwarePiPSource: SoftwarePiPSource?

    /// #353: the size the software path's picture presents at, in pixels: the coded frame under the
    /// pixel aspect ratio the decoder attached. nil on every other path, before the first frame is
    /// built, and on sources with no video.
    ///
    /// What it is for is laying something out over the picture. A host derives the picture rect from
    /// an aspect under the active `videoGravity`, and `sourceVideoWidth`/`sourceVideoHeight` are the
    /// CODED dimensions, so anamorphic content lays out against the wrong rectangle: 720x576 at
    /// 64:45 presents as 1024x576, and an overlay sized 5:4 sits inside a 16:9 picture. There is
    /// nothing to measure on the layer either, since `AVSampleBufferDisplayLayer` has no `videoRect`
    /// the way `AVPlayerLayer` does.
    ///
    /// Nor can a host compute it. The ratio is resolved per frame across three sources, first sane
    /// wins (#177), and one whose display aspect is impossible is dropped in favour of square pixels
    /// (#290), so a host reconstructing it from container metadata disagrees with the screen in
    /// exactly the cases that policy exists for. This is read off the format description the
    /// renderer enqueues, so it is what the layer was handed rather than a second opinion about it.
    ///
    /// Mirrored, not latched, unlike `hasFirstFrameReadyForDisplay`: a live source that switches
    /// resolution mid-stream changes the shape of the picture under a host that already laid out
    /// against it, and it is cleared with the session so the next source cannot be laid out against
    /// this one's rectangle. The native and bypass paths mount an `AVPlayerLayer`, which measures its
    /// own `videoRect` and carries `AVPlayerItem.presentationSize`; this stays nil there.
    @Published public internal(set) var softwareDisplaySize: CGSize? {
        didSet {
            updatePictureFit()
            #if os(macOS)
            updatePictureInPictureAspect()
            #endif
        }
    }
    #if os(macOS)
    /// macOS: the content size of the system PiP window while a software session is in it, nil
    /// otherwise. The display layer is laid out to it (AE#810).
    var pictureInPictureArea: CGSize? {
        didSet { if oldValue != pictureInPictureArea { updatePictureFit() } }
    }
    var pictureInPictureAreaTracker: PictureInPictureAreaTracker?
    #endif

    /// #846: what the low-resolution upscale stage (`LoadOptions.upscalesLowResolutionVideo`) does for this
    /// session. Published on the first upscaled frame, not when the load decides the route, and again with
    /// `disabledReason` set if the stage switches itself off. nil when the stage is not running, and
    /// cleared with the session.
    @Published public internal(set) var activeUpscale: UpscaleStatus?

    /// #288: the native-path counterpart of `softwarePiPSource.layer`. `AVPictureInPictureController`
    /// wants the layer, not the player, so a host presenting its own PiP on the native path (tvOS has
    /// no reachable AVKit affordance behind suppressed chrome) cannot get there from `currentAVPlayer`.
    /// nil while no native session exists, which is also the honest signal for hiding a PiP button:
    /// a software session has no AVPlayerLayer, it has `softwarePiPSource`.
    ///
    /// Read it per session rather than caching it. The layer survives item swaps and the PiP
    /// next-episode handover (AE#158), but `stop()` tears the host down and the next `load()` builds
    /// a fresh layer. A host driving PiP must still set `pictureInPictureActive`, which arms both the
    /// keepalive policy and that in-place handover.
    ///
    /// nil while `LoadOptions.dualLayerRoute == .avPlayerOutput` is running (a Profile 7 FEL session on the
    /// AVPlayer-output route): AVPlayer's own picture is suppressed there and the composed picture is a
    /// layer of the bound `AetherPlayerView`, so a Picture in Picture window built on this layer would be
    /// blank. Picture in Picture is unavailable on that route.
    public var nativePlayerLayer: AVPlayerLayer? {
        #if DualLayerDolbyVision
        if dualLayerOutputRoute != nil { return nil }
        #endif
        return nativeHost?.playerLayer
    }
    /// True between didEnterBackground and didBecomeActive; gates the pause-while-backgrounded teardown
    /// (iOS) and the PiP-closed-while-backgrounded teardown (tvOS). Never set on macOS.
    private var isBackgrounded = false
    /// Audit CORE-2: didEnterBackground (or a background PiP close) ran while a load or seek was in flight.
    private var backgroundActionOwed = false
    /// Audit LIF-101: the generation of the `load()` or `reloadWithAudioOverride` still running. A
    /// load passes through `.paused` long before it returns (native readiness during the play gate),
    /// so its state cannot say whether it settled; this can.
    private var loadInFlightGeneration: UInt64?
    /// Test seam for the owed background decision on a platform without an app lifecycle.
    var owedBackgroundPolicyForTesting: (@MainActor (AetherEngine) async -> Void)?
    #if os(iOS)
    /// #127: pending grace-window teardown (sleep task + the background-task assertion holding it).
    private var backgroundGraceTask: Task<Void, Never>?
    private var backgroundGraceAssertion: UIBackgroundTaskIdentifier = .invalid
    #endif
    /// Armed by an audio-session interruption that paused an intent-to-play session; fires play()
    /// on interruption end (see the observer in setupLifecycleObservers). Disarmed by user pause()
    /// and stopInternal().
    private var resumeAfterInterruption = false
    /// True between an audio-session interruption's BEGAN and ENDED. See `AetherEngine+InterruptionGuard.swift`.
    var audioInterruptionActive = false
    /// A `play()` pressed while an interruption was active on a renderer path, held until it ends.
    var playDeferredByInterruption = false
    /// Bumped by every `pause()`: lets an await in the interruption-end path see that the user paused meanwhile.
    var userPauseCount = 0

    /// Wedge-safe keepalive decision: keep the video pipeline alive on background ONLY while the app stays
    /// genuinely running (PiP active, or actively playing for background audio), never across an idle
    /// suspension. Pure so the policy is unit-tested without the lifecycle. See setupLifecycleObservers.
    nonisolated static func shouldKeepVideoAlive(enabled: Bool, pipActive: Bool, state: PlaybackState) -> Bool {
        enabled && (pipActive || state == .playing)
    }

    /// tvOS keepalive: ONLY an active PiP window keeps the app genuinely running in the background (there
    /// is no tvOS background-audio case for video sessions); everything else keeps the wedge-safe
    /// unconditional teardown that protects mediaserverd across multi-hour suspensions.
    nonisolated static func shouldKeepVideoAliveTV(enabled: Bool, pipActive: Bool) -> Bool {
        enabled && pipActive
    }

    /// AE#158: a system PiP window closes the moment its source layer's player drops its item (the #93
    /// in-PiP recovery reload hit the same nil-item gap), so a native->native load while PiP is active
    /// keeps the old item attached through the load gap and swaps in place once the new master is ready.
    /// A host that mounts the engine's own `AVPlayerLayer` can be left with a black layer across the
    /// same gap on a foreground episode change, so it may request the handover explicitly
    /// (`hostRequested`). Neither applies unless the outgoing backend is native: there is no item to
    /// keep on the software path, and a native successor to a software session builds a fresh host.
    nonisolated static func shouldHandOverItemInPlace(
        pipActive: Bool,
        hostRequested: Bool = false,
        priorBackendWasNative: Bool
    ) -> Bool {
        priorBackendWasNative && (pipActive || hostRequested)
    }

    /// Whether `load()` hands its teardown a `NativeAVPlayerHost` to keep (issue #15).
    ///
    /// The question is whether a host is still THERE, not which backend is running. Reading the
    /// backend alone was wrong on exactly one path, and it is the one that most needs the host:
    /// `teardownVideoForBackground` preserves it deliberately, so AVKit's Now-Playing registration
    /// outlives the suspension, and then leaves `playbackBackend` at `.none`. The reload on the way
    /// back read that `.none`, answered "nothing native here", and threw away the instance the
    /// teardown had just kept. AVKit registers its MediaRemote client once per AVPlayer instance and
    /// never registers again against a swapped one ("Code=14 client callback"), so the viewer came
    /// back from the screensaver to a dead Control Center card and no remote transport until they
    /// left the player entirely (Sodalite#149).
    ///
    /// Keeping a host a load then has no use for is safe and already the contract: the software and
    /// audio-only dispatch branches each release a preserved-but-unused host before they build.
    /// AE#597: a media services reset outranks every reason above. After one, the platform has
    /// invalidated every audio and video object this process holds, so the host that would be
    /// preserved is precisely the object that can no longer work, and reusing it is how a session
    /// spends its whole recovery ladder reloading onto a dead AVPlayer.
    /// AE#597 defect 3: may the background teardown release the remote-HLS subtitle proxy?
    ///
    /// `Prepared` owns an `HLSLocalServer` bound on `0.0.0.0` with an accept thread and up to 32
    /// connection threads, plus an optional `HLSOriginRelay`. It is released in `load(source:)`'s
    /// prologue and in `stop()`, and `stopInternal` never mentions it, so the one teardown the
    /// background path runs is the one that leaves it standing. On tvOS it then rides the whole
    /// suspension.
    ///
    /// The release has to be conditional, and that is the difficulty of this defect rather than a
    /// nicety: it may only be dropped where the foreground return rebuilds it. A URL session
    /// returns through `reloadAtCurrentPosition()`'s URL branch into `load()`, whose prologue
    /// re-prepares the stand-in from the carryover registry. A custom source returns through
    /// `reloadWithAudioOverride` into `loadNative`/`loadSoftware`, neither of which ever reaches
    /// `loadRemoteHLS`, so dropping it there would take the injected renditions with it for the
    /// rest of the session. A socket held for an hour is the smaller cost than subtitles that
    /// never come back.
    nonisolated static func shouldReleaseSubtitleProxyForBackground(
        hasProxy: Bool, isCustomSource: Bool) -> Bool {
        hasProxy && !isCustomSource
    }

    nonisolated static func shouldPreserveNativeHostAcrossLoad(
        backend: PlaybackBackend,
        nativeHostSurvives: Bool,
        mediaServicesWereReset: Bool = false
    ) -> Bool {
        if mediaServicesWereReset { return false }
        return backend == .native || nativeHostSurvives
    }

    /// AE#597: raised by the platform's reset/lost notifications, lowered by the load that acts on
    /// it. A flag rather than an immediate teardown: a reset says the objects are dead, not that
    /// anyone stopped watching, and the host owns that second question.
    private var mediaServicesResetPending = false

    func noteMediaServicesReset(lost: Bool) {
        mediaServicesResetPending = true
        dropAtmosOutputActivator()
        EngineLog.emit(
            "[AetherEngine] #597 media services were \(lost ? "lost" : "reset"): every audio and "
            + "video object this process holds is invalid, so the next load builds fresh native and "
            + "audio-only players",
            category: .engine)
    }

    func consumeMediaServicesReset() -> Bool {
        let pending = mediaServicesResetPending
        mediaServicesResetPending = false
        return pending
    }

    /// Audit CORE-4: the audio-only AVPlayer host is kept across every `stopInternal` on purpose (its
    /// MPNowPlayingSession must persist between tracks), so after a reset nothing ever replaced it and
    /// the next track was handed to a dead AVPlayer. Any load consumes the reset, so it is dropped
    /// here whatever that load plays; the next audio load builds a fresh one with a fresh session.
    func dropAudioPlayerHostAfterMediaServicesReset() {
        guard let host = audioAVPlayerHost else { return }
        host.stop()
        audioAVPlayerHost = nil
        audioAVPlayerActive = false
        EngineLog.emit(
            "[AetherEngine] #597 audio-only AVPlayer dropped after the media services reset; the next "
            + "audio load builds a fresh one",
            category: .engine)
    }

    /// Consume the one-shot host request at the load boundary, folded with PiP's mandatory handover.
    /// Consumed here rather than where it is read so one episode transition cannot change the
    /// teardown of a later, unrelated load.
    func consumeInPlaceItemHandoverRequest(priorBackendWasNative: Bool) -> Bool {
        let hostRequested = nextLoadRequestsInPlaceItemHandover
        nextLoadRequestsInPlaceItemHandover = false
        return Self.shouldHandOverItemInPlace(
            pipActive: pictureInPictureActive,
            hostRequested: hostRequested,
            priorBackendWasNative: priorBackendWasNative
        )
    }

    /// SW-PiP: playable range for the sample-buffer PiP UI on the PTS axis of the enqueued frames
    /// (the source axis; sourceTime = currentTime + container start offset). Live or unknown
    /// duration reports indefinite so the window shows live UI instead of a bogus scrubber.
    nonisolated static func softwarePiPTimeRange(isLive: Bool, sourceTime: Double, currentTime: Double, duration: Double) -> CMTimeRange {
        guard !isLive, duration.isFinite, duration > 0 else {
            return CMTimeRange(start: .negativeInfinity, duration: .positiveInfinity)
        }
        let sourceStart = sourceTime - currentTime
        return CMTimeRange(
            start: CMTime(seconds: sourceStart, preferredTimescale: 600),
            duration: CMTime(seconds: duration, preferredTimescale: 600)
        )
    }

    /// What to do with the active video pipeline when the app enters the background. Pure so the lifecycle
    /// policy is unit-testable. Mirrors the spirit of the native keepalive onto the software path.
    enum BackgroundAction: Equatable {
        case doNothing               // audio backend, or native keepalive: leave the running session alone
        case enterSoftwareAudioOnly  // SW host kept alive: drop video in the demux loop, keep feeding audio
        case teardownVideo           // release the video pipeline before idle suspension
    }

    /// - keepVideoAlive: result of shouldKeepVideoAlive / shouldKeepVideoAliveTV.
    /// - pipActive: a live PiP window renders the SW layer's frames, so the SW host must keep
    ///   decoding video in background instead of dropping to audio-only (SW-PiP Phase A).
    /// - softwareHostHasAudio: AE#739, the SW host renders audio of its own. Audio-only mode paces the
    ///   demux loop on the audio renderer alone, so without audio nothing paces it: the loop dropped
    ///   the rest of the file within moments and parked the clock at end of media in the background.
    ///   Such a session has nothing to keep playing and is released like a paused one.
    nonisolated static func backgroundAction(
        isAudioBackend: Bool,
        hasSoftwareHost: Bool,
        softwareHostHasAudio: Bool,
        keepVideoAlive: Bool,
        pipActive: Bool,
        state: PlaybackState,
        retainPausedVideoPipeline: Bool = false
    ) -> BackgroundAction {
        if retainPausedVideoPipeline && state == .paused { return .doNothing }
        if isAudioBackend { return .doNothing }
        if keepVideoAlive {
            if hasSoftwareHost {
                if pipActive { return .doNothing }
                if softwareHostHasAudio { return .enterSoftwareAudioOnly }
            } else {
                return .doNothing
            }
        }
        guard state == .playing || state == .paused else { return .doNothing }
        return .teardownVideo
    }

    /// Audit CORE-2: a state in which `backgroundAction` cannot judge the pipeline yet, although one
    /// exists (a load has its loopback server and AVIO connection, a seek its whole session). The
    /// decision is owed until the state settles.
    nonisolated static func backgroundActionIsOwed(state: PlaybackState) -> Bool {
        state == .loading || state == .seeking
    }

    /// AE#870: `retainsVideoPipelineWhenBackgrounded` answers only for a paused session. One that
    /// resumes while still backgrounded gets the playing-session policy (teardown with background
    /// playback off, software audio-only), whichever transport owner started it. A seek or reload can
    /// carry a later play request, and remote-HLS autoplay has no paused readiness waypoint. Owe the
    /// decision when leaving the retained pause; `backgroundDecisionMustWait` defers it until the
    /// operation settles into its final transport state.
    nonisolated static func backgroundPolicyIsOwedOnResume(
        isBackgrounded: Bool, retainsPausedPipeline: Bool, from: PlaybackState, to: PlaybackState
    ) -> Bool {
        isBackgrounded && retainsPausedPipeline && from == .paused
            && (to == .playing || to == .seeking || to == .loading)
    }

    /// #127: how to execute a BackgroundAction. A PAUSED teardown on platforms with quick app switches
    /// (iOS) is deferred by a grace window held under a background-task assertion, so a 10-30 s app
    /// switch does not pay a full pipeline rebuild. Wedge-safety holds: the assertion keeps the app
    /// genuinely running for the whole window and the teardown fires at expiry, so the pipeline never
    /// crosses an idle suspension. A PLAYING teardown (background playback disabled) stays immediate,
    /// its audio would keep sounding through the window. tvOS passes supportsGraceWindow=false.
    enum BackgroundStep: Equatable {
        case perform(BackgroundAction)
        case deferTeardown(afterSeconds: Double)
    }

    nonisolated static func backgroundStep(
        action: BackgroundAction,
        state: PlaybackState,
        supportsGraceWindow: Bool,
        graceSeconds: Double
    ) -> BackgroundStep {
        guard action == .teardownVideo, state == .paused, supportsGraceWindow, graceSeconds > 0 else {
            return .perform(action)
        }
        return .deferTeardown(afterSeconds: graceSeconds)
    }

    /// #127: a host seek forwarded into a pre-ready AVPlayer item clamps to 0 against empty seekable
    /// ranges AND replaces load()'s own pending startPosition seek (AVPlayer holds one pending seek).
    /// Defer such seeks and replay the latest at readiness. Live rejoin/DVR paths own their timing
    /// (LiveReloadPolicy), SW/audio hosts resolve seeks synchronously; neither defers.
    nonisolated static func shouldDeferHostSeek(
        nativeSessionActive: Bool,
        isLive: Bool,
        nativeHostReady: Bool
    ) -> Bool {
        nativeSessionActive && !isLive && !nativeHostReady
    }

    /// #178: what to do with a seek stashed while `state == .loading` when `state` changes.
    /// Only transitions OUT of `.loading` resolve the stash; every other transition holds it
    /// (non-loading stashes belong to the #127 readiness sink). `.seeking` cannot follow
    /// `.loading` (the `.loading` guard stashes instead of seeking) but holds defensively.
    enum LoadingStashResolution { case replay, discard, hold }

    nonisolated static func loadingStashResolution(
        oldState: PlaybackState, newState: PlaybackState
    ) -> LoadingStashResolution {
        guard oldState == .loading else { return .hold }
        switch newState {
        case .playing, .paused: return .replay
        case .idle, .ended, .error: return .discard
        case .loading, .seeking: return .hold
        }
    }

    /// #178: `state` didSet hook. Replays the loading-window seek once the session settles into a
    /// playable state (covers autostart paths where readiness fires while `state` is still
    /// `.loading` and the #127 sink must not replay yet), discards it when the load dies.
    private func resolveLoadingStashedSeek(from oldState: PlaybackState) {
        guard let pending = pendingPreReadySeek else { return }
        switch Self.loadingStashResolution(oldState: oldState, newState: state) {
        case .hold:
            return
        case .discard:
            pendingPreReadySeek = nil
            // The load died under the stash; the seek never reaches a host (#38 follow-up).
            endDeferredSeek(.rejected(.noActiveSession))
        case .replay:
            pendingPreReadySeek = nil
            EngineLog.emit("[AetherEngine] replaying seek stashed during load to \(String(format: "%.2f", pending.seconds))s (#178)", category: .engine)
            Task { @MainActor in await self.seek(to: pending.seconds, origin: pending.origin, exact: pending.exact) }
        }
    }

    /// 1 Hz diagnostics sampler. Separate ObservableObject for the same reason as `clock`: per-sample
    /// objectWillChange would re-render every engine-observing view (AetherEngine#29 follow-up).
    /// Observe only in stats overlays.
    public let diagnostics = EngineDiagnostics()

    /// Forwarder; for push updates subscribe to `diagnostics.$liveTelemetry` (objectWillChange does NOT fire).
    public var liveTelemetry: LiveTelemetry? { diagnostics.liveTelemetry }

    /// Human-readable decoder label for stats UI (e.g. "VideoToolbox HEVC (HW)", "dav1d AV1 (SW)",
    /// "libavcodec VP9 (SW)"). nil while idle; cleared in stopInternal so sessions never inherit the previous label.
    @Published public internal(set) var activeVideoDecoder: String?

    /// Human-readable audio pipeline label (e.g. "Stream-copy (EAC3+JOC Atmos)", "TrueHD → FLAC bridge",
    /// "libavcodec <codec> -> CoreAudio"). nil when no audio or no session.
    @Published public internal(set) var activeAudioDecoder: String?

    /// Decoded cues for the active subtitle source (sidecar or embedded side-demuxer). When
    /// `LoadOptions.prepareNativeSubtitles` is set, cues also flow into NativeSubtitleCueStore for mov_text injection (#55).
    @Published public internal(set) var subtitleCues: [SubtitleCue] = []
    /// #100: per-channel holdback for PGS cues arriving behind the playhead (catch-up bursts after
    /// side-reader starvation). Reset wherever the cue arrays reset (track switch, seek re-anchor,
    /// clear, load/stop) so a hold can never leak across subtitle sessions.
    var pgsStaleArrivalGates: [SubtitleChannel: PGSStaleArrivalGate] = [:]

    /// #112 rework: per-channel embedded overlay targets served by the playhead-paced
    /// drainer (SubtitleOverlayDrainer) from the session's SubtitlePacketStore. Replaces
    /// the embedded side-demuxer reader for every host, VOD and live, text and bitmap.
    var subtitleDrainTargets: [SubtitleChannel: Int32] = [:]
    /// #921: channels whose drain target is a bitmap sidecar read into packets. Such a channel
    /// drains from the source's own store under `SidecarBitmapSource.streamKey`.
    var sidecarBitmapSources: [SubtitleChannel: SidecarBitmapSource] = [:]
    var subtitleDrainerTask: Task<Void, Never>?
    /// AE#628: the drain tick whose decode is running off the MainActor, nil while none is. At most
    /// one at a time, because a channel's decoder is one AVCodecContext and the tick in flight owns
    /// it; a tick asked for meanwhile sets `subtitleDrainTickRequested` and runs when it lands.
    var subtitleDrainTickInFlight: Task<Void, Never>?
    var subtitleDrainTickRequested = false
    /// AE#628: bumped by `stopSubtitleDrainer`, so a batch still decoding for a stopped drainer
    /// lands on a newer serial and is dropped instead of clearing a later tick's in-flight slot.
    var subtitleDrainTickSerial: UInt64 = 0
    #if DEBUG
    /// AE#973: runs on a software host that has loaded and not yet started its loops. A paused mount
    /// starts them for the first frame, so a hook installed after `load` returns can miss it.
    var softwareHostLoadedForTesting: (@MainActor (SoftwarePlaybackHost) -> Void)?
    /// AE#628: lets a test drive the drain tick with a real decoder but no playback session.
    var subtitleDrainDecoderFactoryForTesting: ((Int32) -> EmbeddedSubtitleDecoder?)?
    #endif
    /// SW-host sessions have no HLSVideoEngine; their tap fills this store instead.
    var softwareSubtitlePacketStore: SubtitlePacketStore?
    var subtitleDrainDecoders: [SubtitleChannel: EmbeddedSubtitleDecoder] = [:]
    var subtitleDrainCursors: [SubtitleChannel: SubtitleDrainCursor] = [:]
    /// #271: monotonic timestamp of the previous drain tick, so a tick that ran long is not read as
    /// a seek by the next one (`SubtitleOverlayDrainer.drainPlan`). Per tick, not per channel: both
    /// channels are planned in the same pass off the same playhead. nil before the first tick.
    var subtitleDrainLastTickUptime: Double?
    /// #271: the OCR worker's own tick timestamp; same rule, separate cadence.
    var subtitleOCRLastTickUptime: Double?
    /// #250: the frontier source of the last statement emitted per channel, so a change of source
    /// (the prefetcher dying, EOF landing) gets its own line instead of waiting for the 30 s
    /// cadence. nil before the first statement of a session.
    var subtitleResolutionLastFrontier: [SubtitleChannel: SubtitleResolutionStatement.Frontier] = [:]
    /// #318: channels whose current decoded run has already stated determination at the playhead,
    /// so the crossing is announced once and not on every tick after it. Cleared per channel by
    /// every reset, because a fresh run's coverage is a fresh question.
    var subtitleResolutionCoverageStated: Set<SubtitleChannel> = []
    /// #357: the delivery outcome of the last decoding tick per channel, so the line marks the
    /// moment a channel stopped (or resumed) publishing rather than repeating itself at 2 Hz. nil
    /// before a channel's first decoding tick.
    var subtitleDeliveryLastOutcome: [SubtitleChannel: SubtitleDeliveryStatement.Outcome] = [:]
    /// #151: subtitle-only forward side reader filling the session packet store up to
    /// playhead + subtitleDrainLeadSeconds independent of the producer's forward park, so the
    /// drainer's lead window holds cues for host-applied ADVANCE sync offsets (text and bitmap).
    /// nil while idle (subs off, live session, EOF reached).
    var subtitleForwardPrefetchTask: Task<Void, Never>?
    var subtitleForwardPrefetchDemuxer: Demuxer?
    /// #240: the running session's in-place anchor box, so a playhead jump moves its cursor instead
    /// of rebuilding the session. nil while no session is live.
    var subtitleForwardPrefetchReanchor: SubtitleForwardPrefetcher.SideReaderReanchor?
    /// #240: the lead the running session was started with. A changed lead (the OCR worker arming)
    /// is the one anchor change that still needs a rebuild, since the loop captures it at start.
    var subtitleForwardPrefetchActiveLead: Double?
    /// #496: why the last live prefetch session was cancelled. Set only when a task was actually
    /// running, so it names a real teardown rather than the many no-op cancels on the way through
    /// a selection. Mirrors the log line; kept as state so a test can assert the routing.
    var lastSubtitleDrainStopReason: SubtitleDrainStopReason?
    /// #240: link arbitration between the video path and the subtitle side readers. On Matroska a
    /// side reader is a second full copy of the stream, so on a link with little headroom the two
    /// starve each other; the video path has priority. See `SideReaderLinkPolicy`.
    nonisolated let sideReaderLinkGate = SideReaderLinkGate()
    /// #121: session-monotonic id source for cues entering the retained overlay stores
    /// (`subtitleCues` / `secondarySubtitleCues`). The overlay decoder is rebuilt on every seek
    /// (`.resetAndDecode`), restarting its own `nextCueID` at zero, so decoder-local ids cannot stay
    /// unique across the cues that survive the seek. Stamping at the insert funnel keeps the retained
    /// arrays collision-free (the `SubtitleCue: Equatable` / host `ForEach(id:)` contract). Never reset:
    /// monotonic for the engine's lifetime is collision-proof and needs no coordination with the many
    /// array-clear sites.
    var nextRetainedSubtitleCueID: Int = 0
    nonisolated static let subtitleDrainLeadSeconds: Double = 60
    /// #362: how far the forward prefetch (#151) parks BEYOND the drain window's forward edge.
    ///
    /// Without it the two lines coincide, and that is where a bitmap set loses its authored end: the
    /// last set inside the drain window publishes with FFmpeg's open placeholder, and the clear that
    /// closes it a few seconds later is past the edge, so it is neither decoded nor stored, and
    /// nothing can read it. The set is then closed by whatever composition the next landing decodes,
    /// tens or hundreds of seconds later. The margin costs no extra bytes over a session (the reader
    /// is sequential either way, the park only decides when), it just keeps the harvest one authored
    /// step ahead of the decode, which is what `SubtitlePacketStore.firstPTS(streamIndex:after:)`
    /// needs to answer at all.
    nonisolated static let subtitleForwardPrefetchLeadMarginSeconds: Double = 15
    /// #941: a hole is held for as long as its far side is at least this far ahead of the playhead.
    /// The far side, not the near one: a refill at about 1x keeps the playhead just behind the
    /// filling run, so it passes the last packet before the hole while the hole itself is still
    /// ahead of it, and releasing there decoded the island over the very sets the refill was about
    /// to harvest. Two seconds is four ticks, enough for the island to decode before it is due.
    /// Round 3: this is the hold's only bound. The tick budget it had besides ran on wall time and
    /// expired while a seek or a rebuffer kept the playhead still.
    nonisolated static let subtitleDrainHarvestGapReleaseLeadSeconds: Double = 2
    nonisolated static let subtitleDrainBackscanSeconds: Double = 15
    nonisolated static let subtitleDrainJumpThresholdSeconds: Double = 2.5
    nonisolated static let subtitleDrainTickNanoseconds: UInt64 = 500_000_000
    /// #271: per-tick decode cap for the overlay drainer, extended to the next PTS boundary
    /// (`SubtitleOverlayDrainer.batchEnd`). The drain window is bounded in seconds of content, so on
    /// a dense typeset track one window is thousands of packets and the loop holds the main actor
    /// for all of them. Generous on purpose: the backscan sits at the head of the window, so the
    /// cues around the playhead still land in the first batch and the rest of the 60 s lead fills
    /// over the following ticks.
    nonisolated static let subtitleDrainMaxPacketsPerTick: Int = 256
    /// Phase D: the OCR worker decodes bitmap compositions to playhead + this lead so AVKit's
    /// ~240 s forward .vtt prefetch burst at selection is served populated, never cached empty.
    nonisolated static let subtitleOCRLeadSeconds: Double = 240
    /// Phase D: forward-prefetch lead while the OCR worker is armed; exceeds
    /// subtitleOCRLeadSeconds so the packet store actually holds the worker's window.
    nonisolated static let subtitleOCRPrefetchLeadSeconds: Double = 270
    /// When a native select of an OCR rendition that is still waiting for the worker to cover
    /// `subtitleOCRLeadSeconds` reports what it is waiting on. The worker is armed on demand, so the
    /// wait is the prefetcher reading 270 s of the source at link rate plus the recognition.
    nonisolated static let subtitleOCRPrefillReportSeconds: Double = 60
    /// Phase D: per-tick decode cap; smooths the initial 240 s backfill over a few ticks
    /// instead of one long MainActor pass.
    nonisolated static let subtitleOCRMaxPacketsPerTick: Int = 48
    nonisolated static let subtitleForwardPrefetchParkPollNanoseconds: UInt64 = 500_000_000
    /// #231: a prefetch session that dies on a read error is restarted, bounded. Consecutive
    /// failures are what a dead link looks like; the total ceiling covers a source that fails in a
    /// loop after harvesting a packet each time.
    nonisolated static let subtitleForwardPrefetchMaxConsecutiveFailures: Int = 3
    nonisolated static let subtitleForwardPrefetchMaxRestarts: Int = 8
    /// Doubles per consecutive failure (1s, 2s, 4s), capped by the consecutive-failure ceiling.
    nonisolated static let subtitleForwardPrefetchRestartBackoffNanoseconds: UInt64 = 1_000_000_000

    @Published public internal(set) var isLoadingSubtitles: Bool = false
    @Published public internal(set) var isSubtitleActive: Bool = false
    /// Active primary embedded subtitle stream index (matches TrackInfo.id), or nil when subtitles are off or
    /// a sidecar (not an embedded track) is active. Mirrors `activeAudioTrackIndex` so a host picker reflects
    /// the track auto-selected by `LoadOptions.preferredSubtitleLanguages` (#73) as well as host `selectSubtitleTrack` calls.
    @Published public internal(set) var activeSubtitleTrackIndex: Int?

    /// ASS script header ([Script Info] + [V4+ Styles] + [Events] Format line) for the primary sidecar, or nil.
    /// Populated when `LoadOptions.preserveASSMarkup` is set and the file is ASS/SSA; `subtitleCues` then carry
    /// raw event lines. Hosts pair both to drive a whole-script renderer via ASSScriptBuilder (AetherEngine#48).
    /// Nil for SRT/VTT and when markup preservation is off.
    @Published public internal(set) var sidecarASSHeader: String? = nil

    /// ASS script header for the active secondary sidecar when preserveASSMarkup is enabled.
    /// Independent of the primary header; nil for other formats and after clearing or stopping.
    @Published public internal(set) var secondarySidecarASSHeader: String? = nil

    /// Cues for the secondary subtitle track (#47). Text and supported bitmap codecs; independent of primary.
    @Published public internal(set) var secondarySubtitleCues: [SubtitleCue] = []
    @Published public internal(set) var isLoadingSecondarySubtitles: Bool = false
    @Published public internal(set) var isSecondarySubtitleActive: Bool = false

    /// Selected secondary TrackInfo.id, embedded or registered external. nil when off or using
    /// the one-shot URL API; nil alone does not imply inactivity. A registered external publishes
    /// when its prepared replacement commits; the previous identity stays while it decodes or fails.
    @Published public private(set) var activeSecondarySubtitleTrackIndex: Int?
    private var publishingSecondarySubtitleIdentity = false

    /// One update path for the internal selection and its public projection. A synchronous
    /// @Published subscriber may select/clear again during willSet; drain that newer identity
    /// after the outer setter returns rather than leaving the projection on the old selection.
    func setSecondarySubtitleIdentity(embedded: Int32 = -1, external: Int? = nil) {
        activeSecondaryEmbeddedSubtitleStreamIndex = external == nil ? embedded : -1
        activeSecondaryExternalSubtitleTrackID = external
        guard !publishingSecondarySubtitleIdentity else { return }
        publishingSecondarySubtitleIdentity = true
        defer { publishingSecondarySubtitleIdentity = false }
        while true {
            let selected = secondarySubtitleSelectionIdentity
            guard activeSecondarySubtitleTrackIndex != selected else { return }
            activeSecondarySubtitleTrackIndex = selected
        }
    }

    /// The internal selection as a TrackInfo.id. Inside a reentrant willSet this is already the
    /// newer value while the published projection still holds the old one.
    var secondarySubtitleSelectionIdentity: Int? {
        activeSecondaryExternalSubtitleTrackID
            ?? (activeSecondaryEmbeddedSubtitleStreamIndex >= 0
                ? Int(activeSecondaryEmbeddedSubtitleStreamIndex) : nil)
    }

    /// True once the NativeSubtitleCueStore has at least one cue for the native mov_text track (#55).
    /// Use to gate the AVMediaSelection picker (PiP/AirPlay). Cleared by clearSubtitle and stopInternal.
    @Published public internal(set) var nativeSubtitleRenditionAvailable: Bool = false

    /// True when the SERVED playlist is the master, false when the media playlist is served. Mirrors the
    /// inner session's `servingMasterPlaylist` and goes false on a media fallback.
    ///
    /// A playlist property, nothing more. It once carried the reading "so the master's SUBTITLES
    /// renditions reach an external display", and a host gated its own external-subtitle window on that
    /// (Sodalite#98). Device evidence disproved it (Sodalite#34, 2026-08-09): across a wired HDMI adapter
    /// the master is served for SDR content on any panel and for HDR content on an HDR panel, and in all
    /// of those the subtitles stayed on the phone; they reached the external screen only in the one
    /// configuration serving media, where the host was allowed to take the screen and draw them itself.
    /// Whether a legible rendition is rendered on a wired external display is AVKit's business and is not
    /// observable from here, so do not derive that from this flag. Useful as a reload signal (a serving
    /// change means a rebuilt item) and for diagnostics.
    @Published public internal(set) var nativeSubtitleRenditionsServed: Bool = false

    /// Ordered native mov_text subtitle tracks for the session (#55). Populated from nativeSubtitleTrackTable
    /// when `LoadOptions.prepareNativeSubtitles` is set; empty otherwise. Cleared on stop/load.
    /// Hosts use this to populate a picker and call `setNativeSubtitleSelected(track:)`.
    @Published public internal(set) var nativeSubtitleTracks: [NativeSubtitleTrack] = []

    /// Ordinal of the native subtitle rendition marked DEFAULT=YES in the master, resolved from
    /// `LoadOptions.preferredSubtitleLanguages` (fallback 0). A programmatically-selected legible track only
    /// renders if it is the master's default (AVKit's AVSmartSubtitlesController hides a non-default selection
    /// as mute-only), so a host selecting a native track for PiP should select THIS ordinal (Sodalite#32).
    @Published public internal(set) var nativeSubtitleDefaultOrdinal: Int = 0

    /// True for a live session (`LoadOptions.isLive`). Cleared in stopInternal so it can't bleed into the next VOD load.
    @Published public internal(set) var isLive: Bool = false

    /// True while a VOD session is served as a sequential origin: the source can only be read front to
    /// back, either because `LoadOptions.sequentialOrigin` declared it or because the origin refused the
    /// range form at open (twice, AE#693) and served a plain GET. Such a session plays from the start,
    /// so a `startPosition` passed to `load()` is not honoured, and a seek lands only inside what the
    /// session has already read. A host that needs the position reopens the source itself, or tells the
    /// user. Set during `load()`, before `state` leaves `.loading`; cleared on stop.
    @Published public internal(set) var isSequentialOrigin: Bool = false

    /// What the session's live recording is doing (AE#560). `.idle` when nothing is recording.
    /// See `startRecording(to:)`.
    @Published public internal(set) var recordingState: RecordingState = .idle

    /// The running recording, if any. Retained here so a session teardown can end it.
    var activeRecording: LiveRecordingWriter?

    /// The route component feeding `activeRecording`, so the sink can be removed on stop. Weak: the
    /// producer or software host is owned by its session and may be torn down under us.
    weak var activeRecordingHost: AnyObject?

    /// Which recording a writer failure belongs to (audit CORE-5). Bumped once per writer.
    var recordingGeneration: UInt64 = 0

    /// The ended recording's drain and trailer, run off the main actor (audit REC-1).
    var recordingFinish: Task<Void, Never>?

    /// Bumped by every `stopRecording()`, so a `startRecording` that was waiting on `recordingFinish`
    /// can tell that a stop overtook it (audit FEA-106).
    var recordingStopSerial: UInt64 = 0

    /// Republishes `recordingState` progress at 1 Hz while a recording runs.
    var recordingProgressTimer: Timer?

    /// Forwarder; subscribe to `clock.$liveEdgeTime` for push (live-edge fields live on clock, not engine).
    public var liveEdgeTime: Double { clock.liveEdgeTime }
    /// Forwarder; see `clock.seekableLiveRange`.
    public var seekableLiveRange: ClosedRange<Double>? { clock.seekableLiveRange }
    /// Forwarder; see `clock.isAtLiveEdge`.
    public var isAtLiveEdge: Bool { clock.isAtLiveEdge }
    /// Forwarder; see `clock.behindLiveSeconds`.
    public var behindLiveSeconds: Double { clock.behindLiveSeconds }

    /// Fires when a live session cannot continue through its bounded in-engine source reopen.
    /// A verified replay first reopens a supported source while retaining its cache and packet
    /// history. When fresh negotiation is needed, production is parked and the host must call
    /// `load` with a fresh source under its bounded retune policy. Subscribe per session.
    public let liveSourceReset = PassthroughSubject<Void, Never>()

    /// Bounded recovery could not find new media after a verified replay. Cached DVR media
    /// remains readable, but automatic `load` would discard its history and permit the same
    /// broadcast to play again. The host can retry with `retryLiveSourceRecovery()` after
    /// its own backoff; this is not a codec failure. Fires only under
    /// `LoadOptions.hostRetriesExhaustedLiveReplay`; otherwise the exhaustion is a `liveSourceReset`.
    /// Subscribe per session.
    public let liveSourceReplayExhausted = PassthroughSubject<Void, Never>()

    /// Resume a parked live source without replacing the consumer item, DVR cache or replay
    /// evidence. Returns true when the retained session accepted the retry or has a retry in flight;
    /// false when this route cannot continue it. Calls coalesce; the host owns retry timing.
    @discardableResult
    public func retryLiveSourceRecovery() -> Bool {
        guard isLive, nativeVideoSession?.retryLiveSourceRecovery() == true else { return false }
        liveOutageSourceGivenUp = false
        // A timeshifted viewer can still be consuming cached runway. Restart the outage
        // watcher only if that item actually ended, never replace it merely because the
        // source connection is being renewed behind it.
        if nativeHost?.didReachEnd == true { handleLiveOutageWindowExhausted() }
        return true
    }

    /// AE#444 follow-up (Sodalite#104): fires when a resume found the playhead outside the DVR window
    /// and moved it forward.
    ///
    /// The clamp itself has been right since AE#444 and is the only sane thing to do: a session paused
    /// for longer than its own buffer depth has had the position it was parked on evicted by the
    /// sliding window, and there is nothing there to resume from. What it could not do is TELL anyone.
    /// Measured on the harness with a 30 s window, a session paused for 70 s: the playhead sat at
    /// 93881.2 while the window slid to 93890.0...93920.0 underneath it, and the resume landed at
    /// 93895.0 without a word. A viewer who paused a match and came back saw it continue somewhere
    /// else, and nothing on screen said why. No replay; subscribe per session.
    public let liveResumeClamped = PassthroughSubject<LiveResumeClamp, Never>()

    /// Fires when the SYSTEM turned captions on by itself, i.e. selected a legible option in the item that
    /// neither the host nor the user asked for. On iOS 26 that is Settings > Accessibility > Subtitles &
    /// Captioning > Automatic Subtitles (show when muted, on skip back, on a language mismatch); those
    /// toggles have no read API, so acting on the selection is the only way to honour them.
    ///
    /// The engine still deselects the option (its renditions exist for PiP, AirPlay and external screens,
    /// and rendering them in fullscreen draws a caption box over the host's own subtitles). A host that
    /// wants the behaviour renders the request itself: it knows which of the three triggers plausibly
    /// fired and which of its own tracks matches. No replay; subscribe per session.
    public let systemCaptionRequest = PassthroughSubject<SystemCaptionRequest, Never>()

    /// Fires when a native session AVPlayer refused on its merits is rebuilt on the software path
    /// (AE#561), carrying the failure the rebuild absorbed. Without it a host sees only `videoRoute`
    /// change, which a host re-planning failing titles itself cannot tell from a routing decision
    /// (AE#629). `LoadOptions.escalatesToSoftwarePath = false` declines the rebuild instead. No
    /// replay; subscribe per session.
    public let softwarePathEscalations = PassthroughSubject<SoftwarePathEscalationEvent, Never>()

    // MARK: - Scrub thumbnails

    /// LRU (cap 2) of FrameExtractor contexts for cache-backed scrub thumbnails (live and
    /// VOD; a session is one or the other). Reuses open demux/decode contexts across scrubs
    /// within the same segment; torn down in stopInternal.
    var scrubThumbnailExtractors: [(segmentIndex: Int, extractor: FrameExtractor)] = []

    // MARK: - Output

    /// Fill mode of the active AVPlayerLayer or SW displayLayer in the bound AetherPlayerView.
    public var videoGravity: AVLayerVideoGravity {
        get { _videoGravity }
        set {
            _videoGravity = newValue
            // Most tvOS hosts use AVPlayerViewController, which mounts its own AVPlayerLayer.
            // Still correct for hosts that use the engine's layer directly and for the SW displayLayer.
            nativeHost?.playerLayer.videoGravity = newValue
            softwareHost?.displayLayer.videoGravity = newValue
            #if DualLayerDolbyVision
            dualLayerOutputRoute?.setVideoGravity(newValue)
            #endif
            // The PiP fit depends on the gravity and no layout pass follows a change.
            if softwareHost != nil { boundView?.refreshHostedLayerFrame() }
        }
    }
    var _videoGravity: AVLayerVideoGravity = .resizeAspect

    // MARK: - Capabilities

    /// TEST-ONLY: forces every source through SoftwarePlaybackHost so the SW live+DVR path can be exercised
    /// against H.264 fixtures. Set only via `setForceSoftwarePathForTesting(_:)` from `aetherctl`.
    nonisolated(unsafe) static var forceSoftwarePathForTesting = false

    /// TEST-ONLY. Flip the SW-path override for the `aetherctl live --sw` harness; not for app use.
    public nonisolated static func setForceSoftwarePathForTesting(_ on: Bool) {
        forceSoftwarePathForTesting = on
    }

    /// TEST-ONLY: makes every audio pipeline fail to build, so the AE#462 video-only drop is
    /// reachable without a source whose codec this FFmpeg build has no decoder for. Honored by the
    /// loopback cascade and by `SoftwarePlaybackHost`'s decoder open. Set only via
    /// `setForceAudioPipelineFailureForTesting(_:)` from `aetherctl`.
    nonisolated(unsafe) static var forceAudioPipelineFailureForTesting = false

    /// TEST-ONLY. Flip the forced audio-pipeline failure for the `aetherctl play --drop-audio`
    /// harness; not for app use.
    public nonisolated static func setForceAudioPipelineFailureForTesting(_ on: Bool) {
        forceAudioPipelineFailureForTesting = on
    }

    /// TEST-ONLY: routes a loopback session behind its MASTER playlist regardless of codec, panel and
    /// subtitle state, so the harness can exercise the route a real host actually takes.
    ///
    /// A device reaches the master whenever the session has any subtitle track (hosts set
    /// `prepareNativeSubtitles` unconditionally) and, on tvOS, for every HEVC source. The harness
    /// reached it for none of them: every live leg ran `useMaster=false`, so a question about how a
    /// client treats what the manifest says had only ever been asked of the manifest the device
    /// usually does not read (AE#454).
    /// AE#459: this process has seen AVFoundation refuse an HDR master for the display.
    ///
    /// The one readout the platform will actually give. `UIScreen.currentEDRHeadroom` has been measured
    /// reading 1.00 on a panel whose own info display reported HDR, so an unproven panel is offered the
    /// master and refusal answers the question the display will not. Latched for the process because the
    /// answer costs a fallback to obtain and does not change while the output configuration does not.
    ///
    /// AE#849: tvOS only. A panel that engages HDR on demand (iOS, macOS) is never latched, see
    /// `MasterFallbackDecision.shouldLatchPanelRefusal`.
    ///
    /// Set ONLY by the two display-rejection codes. `-1002` also reaches the same fallback and means the
    /// manifest was filtered at parse time (#130), which is a statement about the playlist and not about
    /// the display; latching on it would teach the process a fact about the panel from an unrelated bug.
    ///
    /// AE#588: cleared on a real return from the background, because the answer is about an output
    /// CONFIGURATION and the user changes that in Settings, which they can only reach by leaving the app.
    /// Nothing reports the change itself, so the return is the one event guaranteed to follow it. See
    /// `clearPanelRefusalOnForegroundReturn`.
    nonisolated(unsafe) static var panelRefusedHDRMaster = false

    /// AE#588: forget a refusal on a real return from the background.
    ///
    /// The latch is true at the moment it is set and stale from the moment the output format changes.
    /// It was originally left to the process lifetime, on the reading that a stale refusal costs "the
    /// master route until the app restarts". Measured on a stuck box, it costs more than the route and
    /// all of it is visible: the label reads SDR for every title, a Profile 7 source builds its
    /// supplemental descriptor and then has no variant to carry it, and no master means no
    /// `TYPE=SUBTITLES` rendition, so bitmap subtitles vanish from PiP while the overlay keeps
    /// publishing cues to a window nobody can see. An Apple TV holds one app process for days, so that
    /// bill runs until a force-quit the user has no reason to suspect.
    ///
    /// What the clear costs when the panel really does refuse again: one in-place media fallback,
    /// measured at 223 ms with no visible black frame, at the next HDR load after a foregrounding
    /// rather than once per process. The latch keeps its whole job inside a viewing session, which is
    /// where the per-title repetition it was built to prevent would have happened.
    ///
    /// Deliberately not keyed to a fingerprint of the display configuration, which would be more
    /// precise: the latch is only set while `eligibleForHDRPlayback` reads true (enforced since AE#535,
    /// see `MasterFallbackDecision.shouldLatchPanelRefusal`), so the capability table at refusal time
    /// may be identical to the table afterwards, and a fingerprint built on that would hold the stale
    /// latch silently. The return needs no such assumption.
    nonisolated static func clearPanelRefusalOnForegroundReturn() {
        guard panelRefusedHDRMaster else { return }
        panelRefusedHDRMaster = false
        EngineLog.emit(
            "[DisplayCriteria] return from the background clears the panel's HDR-master refusal (#588); "
            + "the next HDR load asks the display again",
            category: .engine)
    }

    /// AE#887: a panel that reports HDR headroom during playback is presenting HDR, so a refusal latched
    /// earlier in the process was about the stream it was served, not about the panel. Measured on an
    /// Apple TV 4K (tvOS 27, output 4K HDR): a live PQ master refused with -11868, the latch set, and the
    /// playback probe read headroom 1.20 a tenth of a second later. Left standing, the latch routed every
    /// later HDR title in the process media-direct, without its subtitle renditions.
    nonisolated static func withdrawPanelRefusalOnHDRReading() {
        guard panelRefusedHDRMaster else { return }
        panelRefusedHDRMaster = false
        EngineLog.emit(
            "[DisplayCriteria] the panel reports HDR during playback, so the earlier HDR-master refusal was "
            + "not the panel's; withdrawn, the next HDR load offers the master again (#887)",
            category: .engine)
    }

    nonisolated(unsafe) static var forceMasterPlaylistForTesting = false

    /// TEST-ONLY. Flip the master-route override for the `aetherctl live --force-master` harness.
    public nonisolated static func setForceMasterPlaylistForTesting(_ on: Bool) {
        forceMasterPlaylistForTesting = on
    }

    /// TEST-ONLY. Drive the #93/#65 stage-2 recovery reload (item swapped in place under a session that
    /// stays whole) on demand, so `aetherctl live --force-recovery-reload-at` can measure where a live
    /// session comes back from it without having to starve a real consumer into item death first.
    /// Not for app use; the real trigger is the recovery ladder.
    public func forceStalledConsumerReloadForTesting() {
        reloadStalledConsumerItem(position: currentTime, allowPausedConsumer: true)
    }

    /// TEST-ONLY: throttle source IO to simulate a slow CDN/origin (kbit/s; 0 = unlimited). Read once by
    /// each `AVIOReader` at init, so set it before `load`/`start`. Used by `aetherctl --throttle-kbps` to
    /// starve the producer below real-time and provoke AVPlayer rebuffers (e.g. the #92 open-GOP repro).
    nonisolated(unsafe) static var sourceThrottleKbpsForTesting = 0

    /// TEST-ONLY. Set the source-IO throttle for the `aetherctl --throttle-kbps` harness; not for app use.
    public nonisolated static func setSourceThrottleKbpsForTesting(_ kbps: Int) {
        sourceThrottleKbpsForTesting = max(0, kbps)
    }

    /// Reads `AVPlayer.eligibleForHDRPlayback` and `AVPlayer.availableHDRModes` at call time.
    /// Eligibility is display-configuration aware on all platforms (its change notification fires
    /// on display connection/disconnection), so per-load reads pick up monitor changes; the value
    /// is device-wide, not per-window, so mixed HDR/SDR multi-display Macs read eligible (#98).
    ///
    /// `availableHDRModes` is deprecated in the 26 SDKs ("use eligibleForHDRPlayback instead"),
    /// but that Bool cannot express the per-mode split this engine routes on: a tvOS panel can be
    /// HDR10-capable yet not Dolby Vision, and a single-variant DV P5 master fails there with
    /// -11868. The 26 SDKs ship no public per-mode replacement (full header sweep, 2026-07), and
    /// deprecated is not obsoleted, so the read stays; no warning is emitted while the deployment
    /// targets sit below 26. If the symbol is ever removed: derive iOS modes from eligibility
    /// (built-in HDR panels present every flavor) and pessimistically route DV P5 media-direct on
    /// tvOS, accepting the DV-to-HDR10 downgrade for P8 on DV panels.
    public static var displayCapabilities: DisplayCapabilities {
        #if os(tvOS) || os(iOS)
        let hdrEligible = AVPlayer.eligibleForHDRPlayback
        let modes = AVPlayer.availableHDRModes
        // AE#459: the table may add a mode, it may no longer subtract one. It under-reports HLG over
        // HDMI against a panel whose EDID advertises it, so HDR10 and HLG take eligibility as their
        // floor and Dolby Vision stays on the table alone. Reasoning and the measurements behind it are
        // on `observedPerModeTable`.
        return DisplayCapabilities.observedPerModeTable(
            hdrEligible: hdrEligible,
            hdr10: modes.contains(.hdr10),
            hlg: modes.contains(.hlg),
            dolbyVision: modes.contains(.dolbyVision)
        )
        #elseif os(macOS)
        // AE#493: `availableHDRModes` is `API_UNAVAILABLE(macos)`, so there is no per-mode table to read
        // here. The old all-false stub was not a hedge, it was an assertion, and `effectiveVideoFormat`
        // clamped every PQ and HLG source to SDR against it. Eligibility answers the two that only need
        // EDR; Dolby Vision stays unclaimed. `NSScreen.maximumPotentialExtendedDynamicRangeColorComponentValue`
        // would be the other candidate and is not used: eligibility already reads true on the reported
        // display and false on an SDR-only Mac (#98), and NSScreen is main-actor isolated while this is
        // read per load off the main actor.
        return DisplayCapabilities.onDemandEDRDisplay(hdrEligible: AVPlayer.eligibleForHDRPlayback)
        #else
        return DisplayCapabilities(
            supportsHDR: AVPlayer.eligibleForHDRPlayback,
            supportsDolbyVision: false,
            supportsHDR10: false,
            supportsHLG: false
        )
        #endif
    }

    /// AE#515: whether this platform can be asked what the display presents, mode by mode.
    ///
    /// True exactly where `displayCapabilities` reads `AVPlayer.availableHDRModes`. Everywhere else the
    /// per-mode terms are not an observation: HDR10 and HLG are answered from eligibility, and Dolby
    /// Vision is left to a host assertion because nothing can observe it. `dolbyVisionLabelUpgrade` is
    /// the one rule that turns on the difference, so it is named rather than re-derived from `#if`s at
    /// the call site.
    nonisolated static let perModeDisplayCapabilitiesObservable: Bool = {
        #if os(tvOS) || os(iOS)
        return true
        #else
        return false
        #endif
    }()

    // MARK: - View binding

    /// Every surface bound and not yet unbound, in bind order. Weak: dropping the view reference must
    /// not leak the surface through the engine singleton, and a released view drops out on its own.
    ///
    /// One reference was not enough (AE#536). A host that remounts its surface by identity while
    /// keeping the engine gets the incoming view made and bound first, and SwiftUI then still updates
    /// the OUTGOING view on its way out, which rebinds to it (the #188 rebind), before dismantling it.
    /// With a single weak reference the engine ended up bound to a view that was about to go, then to
    /// nothing, and the next session's fresh layer attached nowhere: audio over a black picture. The
    /// list keeps the incoming view as the fallback that takes over when the outgoing one leaves.
    private var boundSurfaces: [BoundSurface] = []

    private struct BoundSurface {
        weak var view: AetherPlayerView?
    }

    /// The surface the layer is presented on: the most recently bound one that is still alive.
    var boundView: AetherPlayerView? {
        boundSurfaces.last { $0.view != nil }?.view
    }

    /// Bind a render surface. Attaches the active layer immediately; re-attaches on session swaps.
    /// Binding a different view detaches the old one, which stays the fallback until it is unbound or
    /// released. A view another engine held is taken over from that engine.
    public func bind(view: AetherPlayerView) {
        if let previousEngine = view.bindingEngine, previousEngine !== self {
            previousEngine.surfaceWasTakenOver(view)
        }
        view.bindingEngine = self
        if let existing = boundView, existing !== view {
            existing.detach()
        }
        boundSurfaces.removeAll { $0.view == nil || $0.view === view }
        boundSurfaces.append(BoundSurface(view: view))
        presentCurrentLayer()
    }

    /// Bind the surface the engine holds the picture on across the item swap of an audio-track switch,
    /// for a host that renders the native path through AVKit instead of `AetherPlayerView`. Without
    /// one the engine holds it on the bound `AetherPlayerView`, and with neither nothing is held.
    public func bindStillView(_ view: AetherStillView) {
        if let previous = boundStillView, previous !== view, heldPictureView === previous {
            releaseHeldPicture(reason: "still view replaced")
        }
        boundStillView = view
    }

    /// Unbind a still view. Idempotent; takes down a picture held on it.
    public func unbindStillView(_ view: AetherStillView) {
        guard boundStillView === view else { return }
        if heldPictureView === view { releaseHeldPicture(reason: "still view unbound") }
        boundStillView = nil
    }

    /// Unbind a view. Idempotent. Unbinding the surface the layer is on detaches it and presents the
    /// layer on the most recently bound surface that is still alive, if any.
    public func unbind(view: AetherPlayerView) {
        guard boundSurfaces.contains(where: { $0.view === view }) else { return }
        let wasPresenting = boundView === view
        boundSurfaces.removeAll { $0.view == nil || $0.view === view }
        if view.bindingEngine === self {
            view.bindingEngine = nil
        }
        guard wasPresenting else { return }
        view.detach()
        presentCurrentLayer()
    }

    /// Another engine bound `view` (#188's engine swap on a reused view). It is no longer ours to
    /// present on or to fall back to. Detached before our layer moves to a remaining surface: the view
    /// would otherwise still record the layer as its own, and the new engine's attach would pull it
    /// back out of the surface it just moved to. Both happen inside the new engine's bind, in one
    /// run-loop turn, so the view shows no gap.
    private func surfaceWasTakenOver(_ view: AetherPlayerView) {
        let wasPresenting = boundView === view
        boundSurfaces.removeAll { $0.view == nil || $0.view === view }
        guard wasPresenting else { return }
        view.detach()
        presentCurrentLayer()
    }

    /// While PiP is active the bound view shapes the software layer to the picture so the window does
    /// not inherit the view's aspect; otherwise it fills the view.
    func updatePictureFit() {
        boundView?.setPictureFit(pictureInPictureActive && softwareHost != nil ? softwareDisplaySize : nil)
        #if os(macOS)
        boundView?.setPictureArea(pictureInPictureActive && softwareHost != nil ? pictureInPictureArea : nil)
        #endif
    }

    #if os(macOS)
    /// The picture's size arrived or changed: let the window tracker match against its aspect.
    func updatePictureInPictureAspect() {
        guard pictureInPictureActive, softwareHost != nil,
              let size = softwareDisplaySize, size.width > 0, size.height > 0 else { return }
        pictureInPictureAreaTracker?.updateAspect(size.width / size.height)
    }

    /// macOS: follow the system PiP window while a software session is in it, see
    /// `PictureInPictureAreaTracker`. Stopped (and the area cleared) when PiP ends.
    func updatePictureInPictureTracking() {
        if pictureInPictureActive && softwareHost != nil {
            if pictureInPictureAreaTracker == nil {
                pictureInPictureAreaTracker = PictureInPictureAreaTracker { [weak self] in self?.pictureInPictureArea = $0 }
            }
            let aspect = softwareDisplaySize.flatMap { $0.width > 0 && $0.height > 0 ? $0.width / $0.height : nil }
            pictureInPictureAreaTracker?.start(known: softwarePiPSource?.windowsBeforeController ?? .weakObjects(),
                                               host: boundView?.window, aspect: aspect)
        } else {
            pictureInPictureAreaTracker?.stop()
        }
    }
    #endif

    /// Attaches nativeHost.playerLayer or softwareHost.displayLayer to the bound view. No-op when no host.
    func presentCurrentLayer() {
        guard let view = boundView else { return }
        defer { updatePictureFit() }
        if let host = nativeHost {
            view.attach(host.playerLayer)
            view.attachOverlay(dualLayerOutputLayer)
        } else if let host = softwareHost {
            view.attachOverlay(nil)
            view.attach(host.displayLayer)
        }
    }

    // MARK: - Display + native state

    /// Programs AVDisplayManager.preferredDisplayCriteria from probed format + frame rate. No-op on iOS/macOS.
    let displayCriteria = DisplayCriteriaController()

    /// Loopback HLS-fMP4 engine. Non-nil between load and stop.
    var nativeVideoSession: HLSVideoEngine? {
        didSet {
            oldValue?.setResidentRangesObserver(nil)
            guard let session = nativeVideoSession else {
                residentPlaylistRanges = []
                residentRanges = []
                return
            }
            session.setResidentRangesObserver { [weak self, weak session] ranges in
                Task { @MainActor in
                    guard let self, let session, self.nativeVideoSession === session else { return }
                    self.residentPlaylistRanges = ranges
                    self.republishResidentRanges()
                }
            }
            residentPlaylistRanges = []
            residentRanges = []
            // Ask for the first snapshot instead of reading it here: this didSet runs on the main actor
            // right after `start()`, so a synchronous read would take the session's restart lock and the
            // cache's condition on main while the producer is already storing into both (AE#422).
            session.noteResidentSetChanged()
        }
    }

    /// Fold the cache's playlist-axis spans onto the published display axis, the same way
    /// `onSeekStateChanged` folds a scrub target (#38). The two axes differ by
    /// `playlistShiftSeconds - sourcePresentationOrigin`, which is not zero on the very path this
    /// feature serves: AE#270 anchors the origin on the container's start while the shift also carries
    /// the producer's drift, and that drift grows with each restart. Publishing plan seconds raw would
    /// hand a host a band that sits beside its own scrubber.
    func republishResidentRanges() {
        residentRanges = residentPlaylistRanges.compactMap { range in
            let lower = displaySeconds(forPlaylistSeconds: range.lowerBound)
            let upper = displaySeconds(forPlaylistSeconds: range.upperBound)
            return lower <= upper ? lower...upper : nil
        }
    }

    /// A playlist-axis second on the published display axis. Live loopback uses the shift latched
    /// at join; VOD follows its producer seams.
    func displaySeconds(forPlaylistSeconds seconds: Double) -> Double {
        if isLive && videoRoute == .loopback {
            return seconds + liveSessionShiftSeconds
        }
        let shift = presentationAxis.shiftSeconds(atItemSeconds: seconds) ?? playlistShiftSeconds
        return PresentationAxis.display(sourcePTS: seconds + shift,
                                        origin: displayOrigin(forShift: shift))
    }

    /// AE#446 round 2: polls for the source coming back after a window was closed with ENDLIST.
    /// Cancelled on stop; see `handleLiveOutageWindowExhausted`.
    var liveOutageResumeWatcher: Task<Void, Never>?
    /// AE#446 round 3: the source read behind that poll has been given up, so the poll cannot come
    /// true. Set when the engine hands the session to the host; cleared with the session.
    var liveOutageSourceGivenUp = false
    /// Thread-safe starvation inputs for session-coupled FrameExtractor yield closures
    /// (#93 startup); written on load/stop and by the 1 Hz telemetry tick.
    let extractorYieldState = ExtractorYieldState()

    /// #65: thread-safe mirror of AVPlayer's rendered (playlist-axis) position, updated on the main actor by
    /// the $renderedTime sink. Read off-main by the producer when it re-anchors on a backpressure wedge.
    let renderedPositionMirror = AtomicDouble(0)

    /// AE#520 round 2: thread-safe mirror of how long the consumer can keep playing out of what it
    /// already holds (the loaded range the playhead is inside), written by `LiveTelemetrySampler` at
    /// 1 Hz off the main actor. Read on the playlist-build thread by the outage close, which spends a
    /// depth and until this existed could only see the half of it the consumer had not fetched yet.
    /// nil while there is no native item to read one off (software path, between item swaps).
    let consumerContiguousBufferMirror = AtomicOptionalDouble(nil)

    /// #65: thread-safe mirror of AVPlayer's play intent (`timeControlStatus != .paused`), updated on the main
    /// actor by the $timeControlStatus sink. Read off-main by the producer to suspend its backpressure wedge
    /// detector while the consumer is paused (a paused player issues no forward fetch, so its frozen fetch
    /// target is not a wedge, pause false-positive). Starts true: VOD autostarts and the sink corrects it.
    let playIntentMirror = AtomicBool(true)

    /// #35/#93 startup: thread-safe mirror of "AVPlayer has presented a frame this item" (its
    /// `timeControlStatus` reached `.playing` at least once), set on the main actor by the
    /// $timeControlStatus sink and reset per new load(). Read off-main by the producer to keep the VOD
    /// backpressure wedge detector suspended through cold pre-roll: a flat rendered clock before the first
    /// frame is not a wedge, and re-anchoring there livelocks a slow high-bitrate DV-master start.
    let hasRenderedFirstFrameMirror = AtomicBool(false)

    /// #65: how long a native VOD seek may stay pending before the engine checks for a wedge. A normal
    /// loopback seek lands in ~1-2s and slow-but-buffering seeks refill within it; only a starved seek
    /// (no forward buffer after the budget) is reconciled.
    static let nativeSeekReconcileBudgetSeconds: Double = 8.0

    /// DV/SMB forward-seek revert fix: when the first budget expires but the producer is demonstrably
    /// serving the target region (buffer at the seek target is above the floor and still growing), the
    /// seek is slow, not wedged, and the recovery (clock revert + producer re-anchor) would destroy
    /// in-flight download progress and park the session. Grant a bounded number of shorter extension
    /// windows so a slow SMB / Dolby-Vision source can land, before falling back to recovery.
    static let nativeSeekMaxDeadlineExtensions: Int = 4
    /// Per-extension budget, shorter than the initial budget so a landing is detected promptly.
    ///
    /// This also bounds how long `await seek(to:)` can stay suspended. Worst case is
    /// `8s initial + 4×4s extensions + 4s re-issued seek + 4×4s post-re-anchor waits ≈ 44s`, reached only
    /// on a source that keeps making measurable progress and then never lands. The loop cannot exceed it:
    /// both counters are monotone and never reset, so it runs at most 10 iterations before the terminal
    /// give-up, which reports `.rebuffering`/`.stalled` rather than staying `.seeking`.
    static let nativeSeekExtensionBudgetSeconds: Double = 4.0
    /// This much media buffered AT the seek target proves the producer is serving it: extend rather than
    /// recover. `bufferedEnd`/`seekIsWedged` are blind to it (they only span the pinned pre-seek
    /// playhead); `NativeAVPlayerHost.bufferedSecondsAtTarget(_:)` measures it directly against the
    /// target, needing no playhead reference. Presence alone is not enough, see
    /// `shouldExtendSeekDeadlineForProgress`, which also requires the figure to be growing.
    static let nativeSeekProgressIslandFloorSeconds: Double = 1.0

    /// Native AVPlayer + AVPlayerLayer host. Non-nil between load and stop.
    var nativeHost: NativeAVPlayerHost?

    /// Controlled host I/O boundary for integration witnesses. Production reads only the
    /// existing KVO mirror, never AVPlayerItem's synchronous seekableTimeRanges getter.
    var nativeSeekableEndReading: (() -> Double)?
    var nativeItemSeekableEnd: Double { nativeSeekableEndReading?() ?? nativeHost?.seekableEnd ?? 0 }

    /// Combine subscriptions mirroring nativeHost's @Published into the engine. Cancelled in stopInternal.
    var nativeCancellables: Set<AnyCancellable> = []

    /// SW decode host (dav1d/libavcodec) for codecs AVPlayer can't handle (AV1 on tvOS, VP9, MPEG-2, VC-1).
    /// Non-nil between load and stop when the source routed SW.
    var softwareHost: SoftwarePlaybackHost?

    /// Combine subscriptions mirroring softwareHost's @Published. Cancelled in stopInternal.
    var softwareCancellables: Set<AnyCancellable> = []
    /// Now-Playing card and remote commands for the software host, which has no AVPlayer to supply them.
    var softwareNowPlaying: SoftwareNowPlayingController?
    /// Where the software host's Now-Playing goes; replaced by tests so they never touch the shared centers.
    var makeSoftwareNowPlayingSink: @MainActor () -> SoftwareNowPlayingSink = { SystemNowPlayingSink() }

    /// FFmpeg audio-only host (music). Mutually exclusive with nativeHost/softwareHost; stopInternal tears all down.
    var audioHost: AudioPlaybackHost?

    /// Combine subscriptions mirroring audioHost's @Published. Cleared in stopInternal.
    var audioCancellables = Set<AnyCancellable>()

    /// AVPlayer audio host. Kept alive for the engine's lifetime and reused across tracks via replaceCurrentItem:
    /// its MPNowPlayingSession must persist for stable system Now-Playing across a playlist. `audioAVPlayerActive`
    /// gates whether this is the active backend.
    var audioAVPlayerHost: AudioAVPlayerHost?
    var audioAVPlayerActive = false
    var audioNativeCancellables = Set<AnyCancellable>()

    /// Periodic memory diagnostic (30 s). Emits grep-friendly lines:
    ///   [AetherEngine] memprobe t=210s rss=412MB cache=27 subCues=0
    /// Started when state reaches .playing; cancelled in stopInternal.
    var memoryProbeTask: Task<Void, Never>?

    /// Live native reload watchdog. Armed only on live native reloads; nil for initial loads, VOD, and SW path.
    /// Cancelled in stopInternal so it can never outlive its session.
    var liveReloadWatchdogTask: Task<Void, Never>?

    /// AE#418 round 3: bounded read of the item's loaded ranges after a VOD axis seam, which is where
    /// AVPlayer says it holds the bytes that seam describes. One at a time, newest wins, cancelled in
    /// stopInternal: it exists only to check the axis just published, so an older check is stale.
    var placementVerificationTask: Task<Void, Never>?
    /// AE#481: the sampler reading what the run holding a seek landing carries. One at a time, and the
    /// newest seek owns it: an older landing describes a position the playhead has left.
    var landingAxisTask: Task<Void, Never>?

    /// 1 Hz live-telemetry sampler. Lifecycle mirrors memoryProbeTask. Holds a weak engine reference
    /// so the retained task can't keep self alive past teardown.
    var liveTelemetrySampler: LiveTelemetrySampler?

    /// DVR/live window tracker. Non-nil for any live session. `windowSeconds` nil means DVR disabled.
    /// Updated by `publishLiveWindow` from both the native time tick and SW host edge callback.
    var liveWindow: LiveWindow?

    /// AE#442: `behindLiveSeconds` from the last publish where the picture actually moved, and the
    /// playhead that publish saw. A stall inflates the live value by its own duration, so at the moment
    /// a recovery has to decide where to rejoin, only a sample taken while the clock was advancing can
    /// still say whether the viewer was parked in the DVR window or sitting at the edge.
    var liveBehindWhenLastAdvancing: Double = 0
    var lastPublishedLivePlayhead: Double? = nil
    /// Sodalite#104 round 2: playhead at the last cadence sample, which rate-limits the samples to one
    /// every half second of media. See `LiveWindow.trackingCadenceSeconds`.
    var lastLiveCadenceSamplePlayhead: Double? = nil
    /// AE#524: when the live runway was last checked, so the check stays at 1 Hz whatever rate the
    /// clock publishes at, and whether it has already been reported as thin (one line per episode,
    /// not one per second).
    var lastLiveCushionLogAt: Date? = nil
    var liveThinRunwayNoted = false
    /// AE#524 round 2: the item generation whose runway has been seen at or above the floor. A thin
    /// reading on any other item is a mount that has not fetched yet, not a session running out.
    var liveRunwayHealthyGeneration: Int? = nil

    /// Current session URL. Used by reloadAtCurrentPosition and AetherEngine+FrameExtractor.
    var loadedURL: URL?

    /// True for a custom IOReader source. loadedURL is a synthetic placeholder; URL-based reopens must no-op.
    /// Read by AetherEngine+FrameExtractor.
    private(set) var isCustomSource = false

    /// Retained custom IOReader. Reused on internal reloads; closed in stopInternal; nil for URL sources.
    private(set) var customReader: IOReader?

    /// Format hint for the active custom source; reused on reload and when opening clones.
    private(set) var customFormatHint: String?

    /// False for forward-only custom sources; reload features (audio switch, background reload) no-op for them.
    private(set) var customSourceIsSeekable = false

    /// Seconds the producer subtracted from source PTS so AVPlayer's raw clock sits at
    /// `source_pts - playlistShiftSeconds`. Source time folds this back for cue alignment; live
    /// loopback currentTime uses `liveDisplayShiftSeconds` so PTS rollbacks cannot move its DVR axis.
    /// Updated by HLSVideoEngine.onPlaylistShiftChanged
    /// on every producer init/restart (Matroska seek imprecision means the shift can differ per restart).
    /// 0 on SW/audio paths (no shift). See `nativeClockSeconds` for the pre-fold raw value.
    @Published public internal(set) var playlistShiftSeconds: Double = 0

    /// Live loopback segments keep increasing their item timestamps across a source PTS rollback.
    /// Keep the first shift as the session's display axis; later shifts still describe the source
    /// PTS of rendered frames, but must never move the DVR rail or its seek targets.
    var liveDisplayShiftSeconds: Double?

    var liveSessionShiftSeconds: Double {
        isLive && videoRoute == .loopback ? (liveDisplayShiftSeconds ?? playlistShiftSeconds)
            : playlistShiftSeconds
    }

    var liveSessionSeekAxis: PresentationAxisMap {
        isLive && videoRoute == .loopback
            ? .anchored(shiftSeconds: liveSessionShiftSeconds) : presentationAxis
    }

    /// Raw AVPlayer clock (source_pts - playlistShiftSeconds) before shift fold. Held so
    /// onPlaylistShiftChanged can re-derive currentTime immediately on shift change. Unused on SW/audio (shift 0).
    var nativeClockSeconds: Double = 0

    /// Source PTS that maps to display-time 0 for the SELECTED source. 0 for normal files and live (their
    /// public seconds axis already coincides with source PTS). For a disc title it equals the (constant) VOD
    /// `playlistShiftSeconds` = clip 0's STC base, because a disc title publishes its `duration` from the
    /// MPLS/IFO playlist on a 0-based axis while the raw source PTS starts at that base (599s / 4199s on the
    /// TRON multi-clip titles, AE#105). Subtracted from the published `currentTime`/`seekTarget` and added back
    /// to the `seek` input so the scrubber position, total, seek and resume all live on the same 0-based axis
    /// the producer already anchors `startPosition` on (`segmentIndexForPlaylistTime`), while `sourceTime`
    /// stays true source PTS for subtitle-cue alignment. Reset to 0 on load/stop; set in onPlaylistShiftChanged.
    var sourcePresentationOrigin: Double = 0

    /// AE#270: the origin this session settled on, nil before the first publish. A non-disc VOD source
    /// keeps its first one: later publishes fold producer drift into the shift, and re-reading them would
    /// move the display axis under a picture that has not moved.
    var latchedPresentationOrigin: Double?

    /// #368: this session publishes the ITEM axis, i.e. the display origin is whatever shift a value was
    /// folded with rather than the latched `sourcePresentationOrigin`. Set for a sequential origin, where
    /// the source axis is not an axis: every archive chunk restarts near PTS 0 and libavformat's 33-bit
    /// wrap correction turns each seam into a +2^33 fiction, which the producer's chunk-seam rebase
    /// absorbs into the shift. With a latched origin that whole delta reached the scrubber (device:
    /// playhead 250 s -> 63378 s on an hour-long archive). The item axis starts at 0 by construction (the
    /// producer is pinned to byte 0) and is what `declaredDurationSeconds` measures, so it IS the 0-based
    /// axis AE#270 requires. Latched with the native session, cleared on teardown.
    var displayAxisIsItemAxis: Bool = false

    /// Source PTS that maps to display-0 for a value folded with `shift`. Identity to
    /// `sourcePresentationOrigin` for every source whose timestamps are a real axis; on a sequential
    /// origin (#368) it is the shift itself, so the published value is the item-axis position.
    func displayOrigin(forShift shift: Double) -> Double {
        displayAxisIsItemAxis ? shift : sourcePresentationOrigin
    }

    /// Diagnostics only. Reads HLSVideoEngine's videoShiftPts synchronously, bypassing the async
    /// onPlaylistShiftChanged relay. A persistent gap vs `playlistShiftSeconds` means the clock is folding
    /// with a stale shift (AetherEngine#49 divergence). Poll alongside `frameAhead` when tracing divergence.
    /// 0 on SW/audio. Not for production playback logic.
    public var activeProducerShiftSeconds: Double {
        nativeVideoSession?.playlistShiftSeconds ?? 0
    }

    /// `activeProducerShiftSeconds - playlistShiftSeconds`. Positive = decoded frame ahead of currentTime.
    /// Growing value with seek count indicates AetherEngine#49 accumulation. Diagnostics only.
    public var frameAhead: Double {
        activeProducerShiftSeconds - playlistShiftSeconds
    }

    /// Seek target ahead of the rendered position, on the same display axis. Source PTS can roll
    /// backward on live loopback while the item axis continues, so compare item time on that route.
    public var clockLeadSeconds: Double {
        if isLive && videoRoute == .loopback {
            return clock.currentTime - (renderedPositionMirror.get() + liveSessionShiftSeconds
                                        + liveItemAxisOffsetSeconds)
        }
        return clock.currentTime - clock.sourceTime
    }

    /// Monotonic load/stop generation. Bumped by every stopInternal; captured after teardown; re-checked at
    /// every suspension point. Without it, a load suspended at the probe/criteria/session-start could resume
    /// after a newer load, orphan the successor's producer+loopback server, and resurrect playback after
    /// dismissal. A superseded load throws CancellationError at the first checkpoint.
    var loadGeneration: UInt64 = 0

    /// Separates cache lifecycle callbacks from superseding sessions.
    var sessionCacheStatusToken: UInt64 = 0
    /// Bumped by every host subtitle selection or clear on either channel (#829): a
    /// `PreparedExternalSubtitle` from an older value is stale.
    var externalSubtitleIntentGeneration: UInt64 = 0

    /// Distinct across engine instances and refreshed whenever teardown invalidates preview work.
    public private(set) var scrubPreviewSourceGeneration = UUID()

    /// #361: generation of the startup the user is currently waiting through. Deliberately NOT
    /// `loadGeneration`, which counts teardowns: an engine-initiated reroute (an HLS playlist found
    /// on the loopback path, a carriage case rerouted onto ingest) tears down and calls `load()`
    /// again underneath one uninterrupted wait, and counting that as a new startup would drop a
    /// host's bar back to zero halfway through a load nobody restarted.
    private(set) var startupGeneration: UInt64 = 0

    /// Set immediately before an engine-initiated reroute re-enters `load()`, consumed by that
    /// load's prologue. The one thing that distinguishes a reroute from a fresh request, since by
    /// the time `load()` runs they look identical.
    private var startupContinuesAcrossReroute = false

    /// AE#629: generations of the `load()` calls a caller is still awaiting. The software-path
    /// rebuild reads it to tell a startup it is taking over from a session that already returned.
    var waitingLoadGenerations: Set<UInt64> = []

    /// Open a startup sequence for the load now beginning, and return its generation for the call
    /// sites that have to record checkpoints from detached work. A reroute continues the sequence
    /// already in flight instead of opening a new one.
    func beginStartupProgress() -> UInt64 {
        if startupContinuesAcrossReroute {
            startupContinuesAcrossReroute = false
            return startupGeneration
        }
        startupGeneration &+= 1
        startupProgress = StartupProgress(generation: startupGeneration, checkpoint: .dispatched)
        EngineLog.emit(
            "[AetherEngine] #361 startup 0/\(StartupCheckpoint.total) dispatched "
            + "(gen \(startupGeneration))",
            category: .engine
        )
        return startupGeneration
    }

    /// Mark the next `load()` as the continuation of the startup already running (see
    /// `startupContinuesAcrossReroute`).
    func continueStartupAcrossReroute() {
        startupContinuesAcrossReroute = true
    }

    /// Withdraw a continuation that no `load()` consumed, because the reroute was refused before it
    /// reached one. Left set, it would fold the host's NEXT load into a startup that already ended.
    func abandonStartupContinuation() {
        startupContinuesAcrossReroute = false
    }

    /// Record a checkpoint against a startup generation. `generation` defaults to the running one,
    /// which is what every main-actor call site wants; detached work and Combine sinks that can
    /// outlive their load pass the generation they captured, so a straggler cannot write into a
    /// successor's sequence. Ordering, dedupe and supersession all live in `StartupProgress`.
    func recordStartupCheckpoint(_ checkpoint: StartupCheckpoint, generation: UInt64? = nil) {
        guard let next = StartupProgress.advanced(
            from: startupProgress,
            to: checkpoint,
            generation: generation ?? startupGeneration
        ) else { return }
        startupProgress = next
        // One line per real step (the guard above has already dropped repeats), so the ladder can be
        // read off a device trace or an aetherctl run without a host to render it.
        EngineLog.emit(
            "[AetherEngine] #361 startup \(next.completed)/\(next.total) "
            + "\(next.checkpoint) (gen \(next.generation))",
            category: .engine
        )
    }

    /// Throws CancellationError when the captured generation is stale. Callers must clean up local resources
    /// before calling; shared state belongs to the successor.
    func checkLoadCurrent(_ gen: UInt64) throws {
        guard loadGeneration == gen else {
            EngineLog.emit(
                "[AetherEngine] load superseded (gen \(gen) -> \(loadGeneration)); unwinding",
                category: .engine
            )
            throw CancellationError()
        }
    }

    /// Audit LIF-103, Vcore-101: a session callback's hop onto the main actor, dropped when the session
    /// that raised it has ended by the time it lands. Only `stopInternal` bumps `loadGeneration` and it
    /// always ends the session, so the generation is the session's identity on every path, the software
    /// one included, which has no session object to compare.
    nonisolated func hop(for generation: UInt64, _ body: @escaping @Sendable @MainActor () async -> Void) {
        Task { @MainActor [weak self] in
            guard let self, self.loadGeneration == generation else { return }
            await body()
        }
    }

    /// Shift seam history on the item axis. The producer rebases immediately (live program boundary) or starts a
    /// fresh epoch (VOD restart); AVPlayer renders that content ~buffer+holdback later. The currentTime sink
    /// resolves the active shift by looking up the newest seam at or before the raw clock (a history, not a
    /// queue: backward DVR seeks must fold pre-seam content with pre-seam shift). Cleared on load/stop.
    ///
    /// Write only through `setPresentationAxis`, which keeps the off-main mirror in step.
    private(set) var presentationAxis = PresentationAxisMap()

    /// Off-main mirror of `presentationAxis`. Read by hosts converting between axes on their own thread
    /// (subtitle rasterisation, #260); the map itself is main-actor state.
    let presentationAxisMirror = AtomicPresentationAxisMap()

    /// Conversion between the source-PTS axis (subtitle cues, chapters, `sourceTime`) and the item axis
    /// (`AVPlayerItem.currentTime()`, its timebase, `NativeVideoFrameTime.item`) for the native path.
    /// Readable off the main actor. Empty on the SW and audio paths, which have no producer shift (#260).
    public nonisolated var presentationAxisMap: PresentationAxisMap {
        presentationAxisMirror.get()
    }

    /// Host observer for per-frame presentation times (#260). Held here so it survives across loads and is
    /// re-installed on each new native session; see `setNativeVideoFrameTimeObserver`.
    var nativeVideoFrameTimeObserver: NativeVideoFrameTimeObserver?
    /// Set by the load's route decision when a Profile 7 FEL source takes `DualLayerRoute.avPlayerOutput`:
    /// the stream's frame rate (known and positive; the decision refuses the route otherwise). `loadNative`
    /// starts the route for the session it builds.
    var outputRouteFrameRate: Double?
    #if DualLayerDolbyVision
    var dualLayerOutputRoute: DualLayerOutputRoute?
    #endif

    /// The software path's equivalent (#311), held for the same reason: a `load()` builds a fresh
    /// host, and the observer has to survive it. See `setSoftwareVideoFrameTimeObserver`.
    var softwareVideoFrameTimeObserver: SoftwareVideoFrameTimeObserver?

    func setPresentationAxis(_ map: PresentationAxisMap) {
        presentationAxis = map
        presentationAxisMirror.set(map)
    }

    /// 1 Hz live-window updater, independent of the periodic time observer (which only fires while playing).
    /// Without this, liveEdgeTime/behindLiveSeconds/isAtLiveEdge/seekableLiveRange all freeze on pause:
    /// the UI shows "at live edge" while drifting, and DVR scrubs seek against a stale edge.
    var liveWindowTimerTask: Task<Void, Never>?

    /// Source PTS of the rendered frame. Equals currentTime in steady state; holds the on-screen frame while a
    /// seek is in flight or the loopback rebuffers (issue #49). Use for subtitle overlay and side-demuxer re-arm.
    /// On SW it is the raw synchronizer clock in the source axis: equal to currentTime for zero-based sources,
    /// offset by the session zero on live / mid-stream-joined sources (#107). Forwarder; subscribe to `clock.$sourceTime`.
    public var sourceTime: Double { clock.sourceTime }

    /// Whether `sourceTime` is known to follow the displayed frame (AE#616). Forwarder; subscribe to
    /// `clock.$sourceTimeFollowsPicture`.
    public var sourceTimeFollowsPicture: Bool { clock.sourceTimeFollowsPicture }

    /// Source-axis buffer frontier ahead of the playhead (AetherEngine#54). Forwarder; subscribe to `clock.$bufferedPosition`.
    public var bufferedPosition: Double { clock.bufferedPosition }

    /// LoadOptions from the current session. Replayed on every internal source reopen (audio-track switch,
    /// subtitle side-demuxer, background reload) so auth, matchContentEnabled, and dvh1 tag survive pipeline
    /// rebuilds. Without replay, audio-switch was silently reverting matchContentEnabled=true to false, causing
    /// HDR HEVC to route via the master playlist on a non-DV panel and surface "Öffnen fehlgeschlagen".
    /// Read by AetherEngine+FrameExtractor. Every internal reroute (#154, #168, #199, #246, #268) reaches
    /// the published route through this property, so its writes feed `recomputeVideoRoute` (#321).
    private(set) var loadedOptions: LoadOptions = .init() {
        didSet { recomputeVideoRoute(); recomputeAudioDelivery() }
    }

    /// #364: the one narrow write into `loadedOptions` outside a load, so a mid-session teletext page
    /// change survives the internal reopens that replay these options (audio switch, background
    /// reload). Without it the page would silently revert to the load-time value on the next reopen,
    /// which is the same defect `matchContentEnabled` had before the replay existed.
    func setLoadedTeletextPage(_ page: Int?) { loadedOptions.teletextPage = page }

    /// AE#464: the third narrow write into `loadedOptions`, same reason as the teletext page. The
    /// value has to live where the session's own rebuilds replay it from, or a lip-sync correction
    /// would be lost at the next audio-track switch or background return.
    func setLoadedAudioDelay(_ seconds: Double) { loadedOptions.audioDelaySeconds = seconds }

    /// AE#923: the narrow write for `setAudioShaping`, for the same reason as the delay above.
    func setLoadedAudioShaping(_ shaping: AudioShaping) { loadedOptions.audioShaping = shaping }

    /// AE#464 round 2: the fourth narrow write, and the one that makes a session-preserving reload
    /// preserve the session's transport. `autoplay` describes a MOUNT, and a rebuild is not a mount;
    /// writing the session's own transport state here is what both reload branches then replay,
    /// without either of them having to learn about it (the URL branch copies this struct into
    /// `load`, the custom-source branch reads these fields one by one). See `rebuildResumesPlaying`.
    func setLoadedAutoplay(_ autoplay: Bool) { loadedOptions.autoplay = autoplay }

    /// AE#792: the fifth narrow write, for the same reason as the teletext page. A rotated credential
    /// has to live where the session's own rebuilds replay it from, or the next audio switch, background
    /// return or revive would reopen with the header the origin already refused.
    func setLoadedHTTPHeaders(_ headers: [String: String]) { loadedOptions.httpHeaders = headers }

    /// AE#792: the session's live request headers. One store per load, created from
    /// `LoadOptions.httpHeaders`, handed to every reader the session opens on its source, and
    /// replaced in place by `updateRequestHeaders(_:)`.
    var sessionRequestHeaders = RequestHeaderStore([:])

    /// AE#792: the audio-only session is an `AVPlayer` item, whose request headers AVFoundation fixed
    /// at asset creation. Reset by every load.
    var audioSessionRequestsOwnedByAVFoundation = false

    /// AE#460: the second narrow write into `loadedOptions` outside a load, for a host correction
    /// that a session-preserving reload is about to rebuild on. Installed before the rebuild rather
    /// than carried through it, because only the URL branch passes a struct into `load`: the
    /// custom-source branch reaches `reloadWithAudioOverride`, which reads these fields one by one.
    /// Callers go through `reloadAtCurrentPosition(applying:)`, which refuses the load-identity
    /// fields first; this setter does not re-check them.
    func applySessionOptionCorrection(_ options: LoadOptions) { loadedOptions = options }

    #if DEBUG
    /// Test-only: install LoadOptions without a load (#88 unit tests exercise selection gating).
    func setLoadedOptionsForTesting(_ options: LoadOptions) { loadedOptions = options }
    #endif

    /// In-flight sidecar decode task. Cancelled on clear/track-switch to prevent stale cue overwrites.
    var sidecarTask: Task<Void, Never>?

    /// Active embedded subtitle stream index, or -1. Used by seek to decide whether to re-arm the side demuxer.
    var activeEmbeddedSubtitleStreamIndex: Int32 = -1


    /// #95 audio tap lifecycle owner; nil when no tap installed. Torn down by stopInternal.
    var audioTapController: AudioTapController?

    /// #77: in-band CEA-608 tap state. The tap owns the cue buffer and publishes snapshots; `ccCueSnapshot`
    /// is the latest, mirrored into `subtitleCues` while the CC track is active.
    var closedCaptionTap: ClosedCaptionTap?
    var ccCueSnapshot: [SubtitleCue] = []
    var ccLastSnapshotSeq: Int = 0

    /// AE#359: SUBTITLES renditions the live master declared, ordinal-aligned with the track ids
    /// published from `liveSubtitleRenditionTrackIDBase`. The fetch task exists only while such a
    /// track is selected; `liveSubtitleCueID` keeps cue ids unique across the session.
    var liveSubtitleRenditions: [LiveSubtitleRenditionInfo] = []
    var liveSubtitleFetchTask: Task<Void, Never>?
    var liveSubtitleCueID: Int = 0

    /// Secondary subtitle reader state mirrors (#47). Driven only through SubtitleChannel.secondary.
    var secondarySidecarTask: Task<Void, Never>?
    #if DEBUG
    /// Per-engine failure injection; never changes another session's decoder factory.
    var secondarySidecarDecoderFactoryForTesting: (@Sendable (SidecarBitmapSource) -> EmbeddedSubtitleDecoder?)?
    #endif
    private(set) var activeSecondaryEmbeddedSubtitleStreamIndex: Int32 = -1

    /// Source video dimensions from the probe. Used as a bitmap-subtitle canvas fallback before the first PCS
    /// is parsed. 0 before load or when source has no video (AetherEngine#28). Also available in SourceProbe.
    /// On the probe-free native HLS bypass they are the delivered stream's, read back from AVPlayer's item
    /// track once it resolves, so a capped transcode reports the resolution it is actually playing.
    @Published public private(set) var sourceVideoWidth: Int32 = 0
    @Published public private(set) var sourceVideoHeight: Int32 = 0

    /// The remote-HLS bypass's stand-in for the probe: what AVPlayer parsed of the delivered video.
    func publishRemoteHLSVideoDescription(_ video: RemoteHLSStreamDescription.Video) {
        if video.width > 0, video.height > 0 {
            sourceVideoWidth = video.width
            sourceVideoHeight = video.height
        }
        if let codec = video.codecName { sourceVideoCodecName = codec }
        sourceVideoStreamFormat = video.format
    }
    /// Display-width multiplier for non-square source pixels: `sourceVideoWidth * this` is the width
    /// the picture presents at. 1 before load, on square-pixel sources, and whenever the declared
    /// ratio is one the engine refuses to believe (#290), so it is never a number the picture
    /// contradicts. Resolved once through `PixelAspectPolicy`, which is also the ratio the decoders
    /// attach and the `pasp` the loopback fMP4 carries.
    public private(set) var sourceVideoPixelAspectRatio: Double = 1

    /// MKV font attachments from the probe. Hosts write these to disk for ASS renderer font config (AetherEngine#30).
    /// Not @Published and not in SourceProbe: payloads are 10-30 MB and only playback hosts need them.
    public private(set) var fontAttachments: [FontAttachment] = []

    /// Latched at load; reused by audio-track-switch reload to re-derive activeVideoDecoder without re-probing.
    /// Reset to AV_CODEC_ID_NONE in stopInternal.
    var lastDetectedVideoCodec: AVCodecID = AV_CODEC_ID_NONE
    /// Preserved through same-source reloads; cleared when the session stops.
    var lastRequiresDeinterlaceWarmup = false

    /// In-flight probe demuxer. Registered before the detached open so stopInternal can markClosed() it:
    /// without this, player dismissal/channel zapping left the probe reconnecting through subsequent sessions.
    private var inFlightProbeDemuxer: Demuxer?

    /// One entry per native mov_text track in muxer-declaration order (#55). Built at load from the merged
    /// subtitleTracks (probed non-bitmap streams + load-declared external tracks, #88). sourceStreamIndex is
    /// nil for external entries, whose synthetic id lives in externalID; language is ISO 639-2. Ordinal =
    /// position in array. Empty means native subs disabled. Cleared on stop/load.
    struct NativeSubtitleTrackEntry: Sendable {
        let sourceStreamIndex: Int?
        var externalID: Int? = nil
        let language: String?
        /// Container FORCED disposition; declared as FORCED=YES on the WebVTT rendition so
        /// AVFoundation distinguishes same-language forced/full pairs.
        var isForced: Bool = false
        /// Phase D: bitmap (PGS/DVB/DVD) entry whose store is filled by the OCR worker /
        /// sidecar OCR fill, not by the pump tap or the side readers.
        var needsOCR: Bool = false
    }
    var nativeSubtitleTrackTable: [NativeSubtitleTrackEntry] = []

    /// #266: one pass over one container, filling every native store whose external track points at
    /// it. Tracks that share a URL and headers collapse into a single job, so a container holding
    /// several subtitle streams is fetched once rather than once per registered track.
    struct ExternalSubtitleFillJob: Sendable {
        struct Target: Sendable {
            /// Absolute AVStream index in this container, nil for its first subtitle stream.
            let streamIndex: Int32?
            let store: NativeSubtitleCueStore
        }
        let url: URL
        let headers: [String: String]
        let targets: [Target]
        /// AE#984: the host's format hint, so an extensionless text URL still takes the whole-body fetch.
        var formatHint: String? = nil

        /// AE#984: set before the fill task is scheduled, so a `.vtt` request that lands first is
        /// answered "not yet" rather than held.
        func markPending() { targets.forEach { $0.store.markExternalFillPending() } }
    }

    /// Native WebVTT rendition store for the in-band CEA-608 track (#98). The CC tap feeds it (via
    /// `updateClosedCaptionCues`) so 608 captions ride a native AVKit-selectable rendition and
    /// survive PiP / AirPlay, not just the overlay. Nil when there is no 608 track or native
    /// subtitles are off. Set in the load path, cleared with the tap.
    var ccNativeStore: NativeSubtitleCueStore?

    /// Last ordinal the host requested via setNativeSubtitleSelected (nil after a deselect).
    /// The #93 stage-2 recovery reload swaps AVPlayerItems and legible selection is per-item,
    /// so the reload re-applies this to keep an active rendition (PiP) rendering. Cleared with
    /// the track table on load/stop so a new session never inherits a stale selection.
    var nativeSubtitleReapplyOrdinal: Int?

    /// Whole-file decode tasks filling native stores for load-declared external tracks (#88).
    var externalNativeStoreFillTask: Task<Void, Never>? = nil

    /// Phase D: OCR worker state. Armed while the active subtitle is a needsOCR table entry;
    /// cursors/pending persist across deselect/reselect (no re-recognition of covered regions)
    /// and reset only on load/stop.
    var subtitleOCRArmedOrdinal: Int?
    var subtitleOCRWorkerTask: Task<Void, Never>?
    var subtitleOCRBatchInFlight = false
    var subtitleOCRSidecarFillTask: Task<Void, Never>?
    var subtitleOCRDecoder: EmbeddedSubtitleDecoder?
    var subtitleOCRCursors: [Int: SubtitleDrainCursor] = [:]
    var subtitleOCRPendingStates: [Int: SubtitleOCRPendingState] = [:]

    /// #214 follow-up: `LoadOptions.confirmAtmos` state. The ledger is the session's authority on which
    /// stream indices carry JOC, because a mid-session audio switch republishes `audioTracks` and would
    /// otherwise drop a confirmed flag. It is keyed to the source it was gathered from, so it invalidates
    /// itself on a new item and survives a session-preserving reload of the same one.
    var atmosConfirmationTask: Task<Void, Never>?
    var atmosConfirmationDemuxer: Demuxer?
    var confirmedAtmosStreamIndices: Set<Int32> = []
    var confirmedAtmosSource: URL?

    /// #744 follow-up: the stream indices the DTS:X decoder confirmed as DTS:X while they played, keyed to their
    /// source like the Atmos ledger above and republished through `applyConfirmedTrackFlags()`.
    var confirmedDTSXStreamIndices: Set<Int32> = []
    var confirmedDTSXSource: URL?

    /// AE#154: publishes the remote-HLS bypass item's legible options as `subtitleTracks`.
    /// Session-scoped; cancelled on load()/stop() alongside the other subtitle tasks.
    var remoteHLSSubtitleDiscoveryTask: Task<Void, Never>? = nil

    /// AE#458: reads back what AVFoundation resolved from the audio the load served. Diagnostic only, and
    /// session-scoped; cancelled on load()/stop() alongside the subtitle tasks.
    var audibleReadbackTask: Task<Void, Never>? = nil

    /// Sodalite#38 / #65: the pin that keeps the native legible rendition deselected while the host
    /// draws subtitles itself. The task is the load-time burst, the observer holds the deselect for
    /// the rest of the item's life against iOS 26's automatic captions, and the burst budget stops
    /// the pin from spinning if the system re-selects after every deselect. Session-scoped, all four
    /// dropped together by `cancelNativeLegibleDeselectPin()`.
    var nativeLegibleDeselectPinTask: Task<Void, Never>? = nil
    var nativeLegibleDeselectPinObserver: NSObjectProtocol? = nil
    var nativeLegibleDeselectPinItem: AVPlayerItem? = nil
    var nativeLegibleDeselectPinGroup: AVMediaSelectionGroup? = nil
    var nativeLegibleDeselectPinBurst = NativeLegibleDeselectPin()

    /// #316: the loopback origin standing in front of a remote HLS master to carry the host's declared
    /// sidecars as legible renditions. Nil whenever the bypass plays the origin URL directly, which is
    /// every live source, every source without declared sidecars, and every refused rewrite.
    var remoteHLSSubtitleProxy: RemoteHLSSubtitleProxy.Prepared?

    /// AE#616: measures how far AVPlayer's item time leads the presented frame on the bypass, off the
    /// injected renditions. Nil whenever `remoteHLSSubtitleProxy` serves none.
    var remoteHLSCueClock: RemoteHLSCueClockObserver?

    /// AE#616: the last offset `remoteHLSCueClock` measured, subtracted from item time to publish
    /// `sourceTime`. Zero on every other path and until the first injected line is presented.
    var remoteHLSItemOffset: Double = 0

    /// #316: external track id -> the NAME its injected rendition carries in the served master. Selecting
    /// one of these must drive AVMediaSelection, not the sidecar overlay, or the two draw on top of
    /// each other. Empty when no proxy is standing.
    var injectedSubtitleRenditionNames: [Int: String] = [:]

    /// Deferred lazy-reader start while a producer restart is in flight (#93 residual): the
    /// readers' side demuxer competed with the restart for the starved link. Cancelled by
    /// cancelNativeSubtitleReaders (deselect / clear / stop / load).
    var nativeSubtitleReaderDeferralTask: Task<Void, Never>? = nil

    /// #93 residual spurious-pause window: after a playbackStalled notification (or a consumer
    /// re-engage nudge), AVPlayer can drop to `.paused` with rate 0 and no wait reason WITHOUT any
    /// user action (device: stall, -15628 errorLog, fetches stop, then the pause). Latching that as
    /// a user pause kills both recovery paths (producer wedge breaker suspends, re-engage nudge
    /// aborts on play intent). Within this bounded window a `.paused` transition is re-asserted
    /// with play() instead of latched; a user pause outside recovery keeps the normal latch, and
    /// the re-assert cap lets a determined in-window user pause win after two presses.
    var stallRecoveryWindowUntil: Date = .distantPast
    var stallRecoveryReasserts = 0
    nonisolated static let stallRecoveryWindowSeconds: TimeInterval = 30
    nonisolated static let maxStallRecoveryReasserts = 3

    /// Stall-triggered re-engage watchdog (#93 residual): the producer-wedge chain needs ~60 s
    /// (park build-up + 24 s break threshold + grace) before its nudge fires; a dead consumer
    /// pipeline (-15628 signature: stall, then ZERO media fetches) is detectable within seconds
    /// of the playbackStalled notification. Cancelled on load reset; superseded by newer stalls.
    var stallReengageTask: Task<Void, Never>? = nil
    nonisolated static let stallReengageGraceSeconds: TimeInterval = 6.0
    /// #65 level re-watch: fetch activity inside the grace window used to disarm the watchdog
    /// PERMANENTLY (single instantaneous check), which parked a player that drained its tail
    /// segments and then waited forever on a frozen playlist: playbackStalled never re-fires
    /// while the buffer is non-empty, so nothing re-armed. The loop re-baselines instead, capped
    /// so trickling fetches on a merely slow session hand back to the producer-side arms.
    nonisolated static let maxStallWatchPasses = 10

    /// #65 level re-watch verdict, one grace window at a time: silence escalates into the
    /// nudge/reload ladder, fetch activity re-arms the watch (bounded by `cap`), a recovered,
    /// paused, or failed player disarms it (recovery has other owners for those states).
    enum StallWatchVerdict: Equatable {
        case escalate
        case rewatch
        case disarm
    }

    nonisolated static func stallWatchVerdict(
        fetchesNow: UInt64,
        baseline: UInt64,
        isWaitingToPlay: Bool,
        itemFailed: Bool,
        passesSoFar: Int,
        cap: Int
    ) -> StallWatchVerdict {
        guard isWaitingToPlay, !itemFailed else { return .disarm }
        if fetchesNow == baseline { return .escalate }
        return passesSoFar + 1 < cap ? .rewatch : .disarm
    }

    /// #65 final rung: a stage-2 reload against a FROZEN live playlist refills nothing, AVPlayer
    /// re-buffers the same tail and parks again, and no notification ever re-fires. If the rendered
    /// clock has not ADVANCED a post-reload window later and the player still waits, the local
    /// session is unrecoverable consumer-side and only the host can retune (liveSourceReset).
    ///
    /// Not advanced, not unchanged: the stage-2 reload is an in-place swap, so a swap that half
    /// took can park the fresh item at a DIFFERENT clock (its own timeline, or zero before it is
    /// ready) while being just as dead. An equality test reads that as recovery and the rung never
    /// fires in the shape it exists for. `progressEpsilon` is the same 0.5 s the item-death gate
    /// and the deferred-failure check use for "the clock did not move".
    ///
    /// The false-positive guard is `isWaitingToPlay`, not the clock: a consumer that recovered is
    /// `.playing`, and nothing gets here without a stall plus two silent grace windows plus a
    /// stage-2 reload before it.
    nonisolated static func shouldPublishLiveSourceReset(
        isLive: Bool,
        clockAtReload: Double,
        clockNow: Double,
        isWaitingToPlay: Bool,
        progressEpsilon: Double = 0.5
    ) -> Bool {
        isLive && clockNow <= clockAtReload + progressEpsilon && isWaitingToPlay
    }

    /// #405: whether stage 2 has anything to fix. Replacing the consumer's item helps a consumer
    /// that died under a HEALTHY producer; against a producer starved by its origin it refills the
    /// same frozen tail, parks again, and the retune the host actually needs waits out two more
    /// grace windows (field trace: 12 s and eleven replayed seconds on a one-slot Xtream host).
    /// Consumer fetches cannot tell the two apart, they are zero in both. The finalized-segment
    /// count can: it is the producer answering.
    ///
    /// `nil` on either side means there is no local producer to ask (a remote HLS session AVPlayer
    /// fetches itself), and absence is not starvation: stage 2 keeps its old behaviour there.
    nonisolated static func liveProducerIsStarved(
        isLive: Bool,
        segmentsAtStall: Int?,
        segmentsNow: Int?
    ) -> Bool {
        guard isLive, let atStall = segmentsAtStall, let now = segmentsNow else { return false }
        return now <= atStall
    }

    /// #93 round 3: item death (failedToPlayToEndTime after -12889 strikes) escalation.
    /// Deferred-confirm task (a transient that resumes within the window self-clears) plus the
    /// bounded reload budget. Cancelled on load reset; superseded by newer deaths.
    var itemDeathConfirmTask: Task<Void, Never>? = nil
    var itemDeathReviveGate = ItemDeathReviveGate(maxAttempts: 3)
    /// AE#561: the one rebuild onto the software path this session may spend when AVPlayer refuses
    /// the media. Replaced (not reset) on teardown, so a closure held by a dead host cannot spend
    /// the next session's.
    var softwarePathEscalationBudget = SoftwarePathEscalation.Budget()

    /// AE#629: the engine's own rebuild in flight or finished, kept so a `load()` whose startup it
    /// superseded can wait for it instead of throwing. Matched by generation, so a stale one is inert.
    var softwarePathTakeover: SoftwarePathEscalation.Takeover?
    /// The engine's own rebuild most recently started, and the generation it is armed to take over
    /// until its teardown claims it (see `claimSoftwarePathTakeover`).
    var softwarePathRebuild: Task<Void, Error>?
    var softwarePathTakeoverArm: UInt64?
    /// AE#641: the live audio streams whose bridge decoded nothing in this session. They outlive the
    /// session's own rebuilds, which is what keeps them video-only, and a host load clears them. A set,
    /// not a slot (audit FEA-103): a channel with two undecodable tracks would otherwise re-hang on the
    /// second one, after the viewer's pick, with nothing surfaced.
    var undecodableLiveAudioStreamIndices: Set<Int32> = []
    /// #65 final rung, storm shape: on a frozen live playlist each stage-2 reload replays the tail,
    /// re-stalls within seconds, and the fresh stall SUPERSEDES the ladder task before its
    /// post-reload rung can run, so the reload cycle alone would loop forever. This gate persists
    /// across stall events: stage-2 reloads at the same frozen position exhaust it (then the ladder
    /// publishes liveSourceReset instead of reloading again); real progress restores the budget.
    var stallReloadReviveGate = ItemDeathReviveGate(maxAttempts: 2)

    /// #199: masters whose #168 carriage verdict fired; consulted at the top of `load(source:)` to
    /// route known cases straight onto the live-ingest loopback. Engine-lifetime by design: it must
    /// survive stop()/load() seams (zap away and back) or the discovery tax returns per retune.
    var rerouteVerdictMemory = RerouteVerdictMemory()
    nonisolated static let itemDeathConfirmSeconds: TimeInterval = 3.0

    /// Single-shot latch for the reactive master->media fallback (#98): fall back at most once per
    /// session so a media reload that also fails cannot loop. Reset in loadSession and in
    /// stopInternal, so a session-preserving rebuild gets its own (#849).
    var masterFallbackUsed = false

    /// AE#849: this session's fallback answered a display refusal of an HDR master, which an audio
    /// switch does not change. Per session like `masterFallbackUsed`, and reset with it.
    var masterRefusedByDisplay = false

    /// #93 PiP skips: AVKit-side seeks (PiP +-15s buttons) bypass the engine seek API, so a far
    /// playhead jump is detected on $renderedTime and, once settled, the native subtitle readers
    /// re-anchor and the remembered rendition selection replays (its deselect/reselect busts
    /// AVKit's cached empty .vtt windows). Cancelled on load reset / stop; newer jumps supersede.
    var nativeSubtitleReanchorTask: Task<Void, Never>? = nil
    /// seekTo anchor of the currently running native subtitle readers; nil = no readers running.
    var nativeSubtitleReaderCoverageStart: Double?
    nonisolated static let subtitleReanchorJumpSeconds: Double = 60
    nonisolated static let subtitleReanchorSettleNanos: UInt64 = 2_500_000_000
    nonisolated static let subtitleReanchorBackwardSlack: Double = 5
    nonisolated static let subtitleReanchorForwardSlack: Double = 90

    /// #93 retest: a user seek that wedges never lands, so the frozen clock still reports the
    /// PRE-seek position (#37) and a recovery anchored there silently loses the seek. The
    /// unlanded seek target (AVPlayer/item clock axis) survives the wedge as recovery intent:
    /// nudge and stage-2 reload aim at it. Cleared on real landing, on rendered output reaching
    /// the target's neighbourhood, on organic playback progress elsewhere (stale: AVPlayer
    /// abandoned the seek), and on load reset / stop.
    var pendingRecoverySeekClockTarget: Double? = nil
    /// The rendered-time sink owns clock/subtitle finalization only after the bounded seek wait
    /// expires. Ordinary in-flight seeks remain owned by their normal continuation.
    var pendingRecoverySeekDeadlineExpired = false
    /// True when a starved deadline already reset subtitle discontinuity state before the pending
    /// seek landed. Healthy late landings perform that reset in the rendered-time sink instead.
    var pendingRecoverySeekSubtitlesReanchored = false
    /// Rendered frame parked on screen when the current native seek began. Distinguishes a genuine
    /// late landing from a short seek whose unchanged old frame is already within the 5 s window.
    var pendingSeekInitialRenderedPosition: Double = 0
    /// Off-main mirror of `pendingRecoverySeekClockTarget` so the session's wedge re-anchor can aim
    /// the producer at the pending target (#93 retest). Kept in sync via `setPendingRecoverySeekTarget`.
    let recoverySeekTargetMirror = AtomicOptionalDouble()
    var pendingSeekProgressAccum: Double = 0
    var lastRenderedForPendingSeek: Double = 0

    /// Single write path for the recovery seek intent: the MainActor field and its off-main mirror
    /// must never diverge (a stale mirror would teleport a wedge re-anchor to a retired target).
    func setPendingRecoverySeekTarget(_ target: Double?) {
        pendingRecoverySeekDeadlineExpired = false
        pendingRecoverySeekSubtitlesReanchored = false
        pendingRecoverySeekClockTarget = target
        if target == nil {
            pendingSeekInitialRenderedPosition = 0
        }
        recoverySeekTargetMirror.set(target)
    }
    nonisolated static let pendingSeekLandedEpsilon: Double = 5.0
    nonisolated static let pendingSeekStaleProgressSeconds: Double = 3.0

    /// Pure decision: where does a stall recovery anchor? The requested-but-unlanded seek target
    /// wins over the frozen clock position. Without one, the anchor can never sit below the
    /// current rendered frame (#115): on VOD the consumer keeps draining buffered segments
    /// through the re-engage grace window, so a pre-grace capture lands the zero-tolerance
    /// nudge behind the on-screen frame, a visible backward replay.
    nonisolated static func recoveryAnchorPosition(
        frozenPosition: Double, pendingSeekTarget: Double?, currentRendered: Double
    ) -> Double {
        pendingSeekTarget ?? max(frozenPosition, currentRendered)
    }

    /// Log suffix explaining why a recovery anchor diverged from the captured position.
    nonisolated static func recoveryAnchorLogSuffix(
        anchor: Double, position: Double, pendingSeekTarget: Double?
    ) -> String {
        guard anchor != position else { return "" }
        let capture = String(format: "%.2f", position)
        return pendingSeekTarget != nil
            ? " (requested seek target; frozen clock \(capture)s)"
            : " (rendered frame; stale capture \(capture)s)"
    }

    /// Pure decision: rendered output near the target means the seek effectively landed.
    nonisolated static func pendingSeekLanded(rendered: Double, target: Double) -> Bool {
        abs(rendered - target) < pendingSeekLandedEpsilon
    }

    nonisolated static func pendingSeekHasRenderedLandingEvidence(
        rendered: Double,
        target: Double,
        initialRendered: Double,
        completionRenderedTimePublished: Bool
    ) -> Bool {
        guard pendingSeekLanded(rendered: rendered, target: target) else { return false }
        if completionRenderedTimePublished { return true }

        let initialDistance = abs(initialRendered - target)
        let currentDistance = abs(rendered - target)
        guard abs(rendered - initialRendered) > 0.1 else { return false }
        if initialDistance < pendingSeekLandedEpsilon {
            return currentDistance <= 0.5
        }
        return true
    }

    nonisolated static func shouldReanchorSubtitlesOnLateSeekLanding(
        alreadyReanchored: Bool
    ) -> Bool {
        !alreadyReanchored
    }

    /// Pure decision: organic playback progress far from the target means AVPlayer abandoned the
    /// seek; keep no stale intent a later unrelated stall could teleport to.
    nonisolated static func isPendingSeekStale(progressWhilePending: Double) -> Bool {
        progressWhilePending >= pendingSeekStaleProgressSeconds
    }

    /// Nudge a consumer that stopped requesting: a zero-tolerance seek to its own position
    /// rebuilds AVFoundation's loading pipeline (the effect a manual back-out had), play()
    /// re-asserts intent. Opens the spurious-pause window, since the nudge can bounce transport.
    func reengageStalledConsumer(position: Double, trigger: String) {
        guard let host = nativeHost, let player = currentAVPlayer,
              let item = player.currentItem else { return }
        guard player.timeControlStatus != .paused else { return }
        // AE#422: the rendered position comes from the mirror, not from `player.currentTime()`.
        // Two reasons, and either one is enough. It is the right VALUE: this parameter exists to keep
        // the anchor from sitting below the frame on screen (#115), and `currentTime()` is the clock,
        // which diverges from the rendered frame during exactly the landing this runs in (#123).
        // And it is the right THREAD: `currentTime()` is a sync XPC round trip to mediaserverd, and
        // this line runs on the main actor in the one state where that server is not answering. The
        // reporter measured 13.3 s of fully blocked app on such a read, returning 30 ms after the
        // watchdog fired. The mirror is written by the periodic observer and costs a lock.
        let anchor = Self.recoveryAnchorPosition(
            frozenPosition: position, pendingSeekTarget: pendingRecoverySeekClockTarget,
            currentRendered: renderedPositionMirror.get())
        stallRecoveryWindowUntil = Date().addingTimeInterval(Self.stallRecoveryWindowSeconds)
        EngineLog.emit(
            "[AetherEngine] #65 re-engaging stalled AVPlayer (\(trigger)): nudge seek to "
            + "\(String(format: "%.2f", anchor))s"
            + Self.recoveryAnchorLogSuffix(
                anchor: anchor, position: position,
                pendingSeekTarget: pendingRecoverySeekClockTarget),
            category: .engine
        )
        item.cancelPendingSeeks()
        player.seek(to: CMTime(seconds: anchor, preferredTimescale: 600),
                    toleranceBefore: .zero, toleranceAfter: .zero) { _ in }
        host.play()
    }

    /// Last-resort consumer revival (#93 residual): device-proven that after a -15628 errorLog
    /// the nudge seek reaches AVPlayer (rate re-asserts) yet its media loader stays dead, zero
    /// GETs follow. Only a fresh AVPlayerItem resets the loader, the same effect as the user's
    /// manual back-out. Same URL + same host (the #15 reuse path keeps AVKit/Control Center and
    /// the AVPlayer instance alive); segments are in retention so the reload serves instantly.
    /// Native subtitle rendition selection is per-item, so the host's last request is replayed
    /// onto the fresh item below (an active PiP rendition otherwise silently disappeared).
    /// React to AVPlayer rejecting the served master (#98, #130): if eligible, reload the media
    /// playlist in place (single-variant); otherwise surface the failure normally.
    @MainActor
    func fallBackToMediaPlaylist(_ rejection: DisplayRejection, expectedGeneration: UInt64) {
        // Audit LIF-103: a rejection of an ended session's item is not the running session's to act on.
        guard loadGeneration == expectedGeneration else { return }
        guard let host = nativeHost, let session = nativeVideoSession else {
            publishError(PlaybackErrorInfo(kind: .masterPlaylistRejected, message: rejection.message, underlyingDomain: rejection.domain, underlyingCode: rejection.code))
            return
        }
        guard MasterFallbackDecision.shouldFallBackToMediaPlaylist(
            errorCode: rejection.code,
            servingMasterPlaylist: session.servingMasterPlaylist,
            alreadyFellBack: masterFallbackUsed),
              let mediaURL = session.mediaPlaylistURL else {
            publishError(PlaybackErrorInfo(kind: .masterPlaylistRejected, message: rejection.message, underlyingDomain: rejection.domain, underlyingCode: rejection.code))
            return
        }
        masterFallbackUsed = true
        masterRefusedByDisplay = MasterFallbackDecision.isDisplayRejectionCode(rejection.code)
            && session.servedSourceIsHDR
        // AE#459: the display answered. Display-rejection codes only, never the -1002 parse failure.
        // AE#535: and only for an HDR master on an HDR-eligible display, or the answer is about the window.
        if MasterFallbackDecision.isDisplayRejectionCode(rejection.code), !Self.panelRefusedHDRMaster {
            let eligibleNow = AVPlayer.eligibleForHDRPlayback
            let switching = displayCriteria.displayModeSwitchInProgress
            if !session.servedSourceIsHDR {
                EngineLog.emit(
                    "[DisplayCriteria] SDR master refused (code=\(rejection.code)); this item falls back, "
                    + "an SDR refusal does not latch the HDR route (#535)",
                    category: .engine)
            } else if MasterFallbackDecision.shouldLatchPanelRefusal(
                code: rejection.code, servedMasterIsHDR: true, displayEligibleForHDRNow: eligibleNow,
                displaySwitchInProgress: switching,
                panelEngagesHDROnDemand: HLSVideoEngine.builtInPanelEngagesOnDemand,
                hostAssertsPanelHDR: loadedOptions.panelIsInHDRMode) {
                Self.panelRefusedHDRMaster = true
                // A display that refused an HDR master no longer vouches for the HDR proof either. Cleared
                // here, before the fallback below reloads, so that session cannot read the proof.
                DisplayCriteriaController.forgetPanelProof("a refused HDR master")
                EngineLog.emit(
                    "[DisplayCriteria] panel refused an HDR master (code=\(rejection.code)); this process "
                    + "routes HDR sources media-direct until it returns from the background (#588)",
                    category: .engine)
            } else if loadedOptions.panelIsInHDRMode {
                EngineLog.emit(
                    "[DisplayCriteria] HDR master refused (code=\(rejection.code)) while the host asserts the "
                    + "panel presents HDR; this item falls back, the process does not latch the refusal (#887)",
                    category: .engine)
            } else if HLSVideoEngine.builtInPanelEngagesOnDemand {
                EngineLog.emit(
                    "[DisplayCriteria] HDR master refused (code=\(rejection.code)) on a panel that engages HDR "
                    + "on demand; this item falls back, later titles still offer the master (#849)",
                    category: .engine)
            } else {
                EngineLog.emit(
                    "[DisplayCriteria] HDR master refused (code=\(rejection.code)) while the display reads "
                    + "hdrEligible=\(eligibleNow ? "yes" : "no") switching=\(switching ? "yes" : "no") "
                    + "(#535, #667); this item falls back, the process does not latch the refusal",
                    category: .engine)
            }
        }
        session.markServingMediaAfterFallback()
        nativeSubtitleRenditionsServed = false
        // #227: while AirPlaying, the item under the rejection is the LAN-IP URL; `mediaPlaylistURL` is the
        // 127.0.0.1 loopback the receiver cannot reach, so the fallback has to be rewritten too or the
        // recovery loads nothing. Media playlist already, so there is no master to keep.
        let fallbackURL = airPlayActive ? (airPlayPlaybackURL(base: mediaURL) ?? mediaURL) : mediaURL
        // #130: a live fallback is a REJOIN of the running ingest (the window may have slid since
        // the failed master attempt); a stale explicit position can wedge AVPlayer against the
        // backlog, so skip the initial seek and let it pick edge-minus-holdback (LiveReloadPolicy).
        // VOD reloads where the rejected item was placed. That is not always where the session
        // started: the #93/#65 stage-2 recovery swaps a fresh item in at the position it held, and a
        // rejection of THAT item has to come back there, not rewind to the first mount.
        let position = host.mountedStartPosition ?? 0
        EngineLog.emit(
            "[AetherEngine] AVPlayer rejected the master (code=\(rejection.code)); falling back to "
            + "media playlist (no CC/subtitle renditions) at "
            + (isLive ? "the live edge" : "\(String(format: "%.2f", position))s"),
            category: .session)
        host.swapItem(url: fallbackURL,
                      startPosition: isLive ? nil : position,
                      skipInitialSeek: LiveReloadPolicy.skipInitialSeek(isLive: isLive, isRejoin: true))
        // Resume only a viewer who was playing; the host's intent (#122) survives the in-place swap.
        // A paused title refused behind the tvOS screensaver used to start itself and wake it.
        if host.transportIntentIsPlaying { host.play() }
    }

    /// #35 readiness-gate settle windows. Generous enough that a slow-but-healthy cold start reads as
    /// ready (early-out on presentationSize / first play), tight enough that two failed master attempts
    /// plus a media fallback stay within ~8.5s worst case. Tunable from device logs.
    static let startupGateInitialSeconds: Double = 3.0
    static let startupGateReloadSeconds: Double = 3.0
    static let startupGateMediaSeconds: Double = 2.5

    /// First settle window on a wireless AirPlay hop (#227 follow-up). The receiver fetches across the LAN
    /// and runs its own decode handshake before anything is playable, which the local 3 s window can miss.
    static let airPlayGateInitialSeconds: Double = 6.0

    /// #124: whether a completed load runs its terminal autostart, the single decision every load
    /// path routes through: the native/software/audio `host.play()` + `state = .playing`, and the
    /// native VOD cold-start readiness gate (which plays to poll readiness). `false` is an honest
    /// paused mount: skip all of it, leave `playIntent` false, and let the wired `host.$isReady`
    /// waypoint settle `.loading -> .paused`. Pure so the gate stays greppable and a new autostart
    /// site cannot silently bypass the flag.
    nonisolated static func loadPerformsAutostart(_ options: LoadOptions) -> Bool {
        options.autoplay
    }

    /// AE#464 round 2: whether a session-preserving rebuild comes back PLAYING.
    ///
    /// `reloadAtCurrentPosition` replayed `LoadOptions.autoplay` verbatim, and that flag describes the
    /// FIRST mount, not the session. A host that owns transport itself and mounts with
    /// `autoplay = false` therefore got a frozen picture and no error out of every rebuild the engine
    /// makes on its own (the AirPlay LAN swap, a #460 correction, the #464 nudge): the rebuilt host
    /// settled `paused`, the producer parked on a consumer that would never ask for a segment, and
    /// nothing was left to call `play()` because the load was the engine's, not the host's. The rate a
    /// host set already survives these rebuilds (#436); the play/pause did not.
    ///
    /// `nativeTransportIntent` is the native host's durable #122 intent, which is what the session is
    /// DOING rather than what its player momentarily reads: it survives a scrub, so a rebuild raised
    /// mid-seek comes back playing instead of paused. nil where there is no native host to ask (the
    /// software and audio routes have no competing transport owner, so `state` is authoritative there,
    /// which is the same split `togglePlayPause` makes).
    ///
    /// Round 3: a rebuild STACKED behind one still in flight has no transport to read either, and
    /// both readings above then say "paused" about a session that is playing: `state` is `.loading`
    /// for the load in flight, and the native host whose intent would be asked is the one that load
    /// is replacing. So the surviving generation mounted paused and nothing was left to call
    /// `play()`, which is round 2's own defect re-entered through the door round 2 did not close.
    /// Measured on the CLI: three stepper presses in one runloop turn left the session stopped at
    /// 14.58 s for the rest of the run, and the harness still ended `VERDICT: OK`. The intent the
    /// load in flight was handed is the honest answer for exactly that window, the same shape and
    /// the same window as `rebuildPosition`.
    nonisolated static func rebuildResumesPlaying(
        state: PlaybackState, nativeTransportIntent: Bool?, underReconstruction: Bool?
    ) -> Bool {
        if state == .loading, let parked = underReconstruction { return parked }
        if let nativeTransportIntent { return nativeTransportIntent }
        switch state {
        case .playing, .seeking: return true
        case .idle, .loading, .paused, .ended, .error: return false
        }
    }

    /// AE#464 round 2: the playhead a session-preserving rebuild has to come back to.
    ///
    /// `load()` zeroes the clock at its start, before the session it is building has anything to put
    /// there, so a reload raised while another load is still in flight snapshotted that zero and
    /// rebuilt the session at its head. Measured by the reporter: three stepper presses inside one
    /// runloop turn stacked three reloads, two were superseded by generation, and the one that
    /// survived cut `seg0+` on a title 15 s in. While a load is in flight the position that describes
    /// the session is the one THAT load was handed, which it received before the clock was cleared.
    ///
    /// Round 5 (cmcpherson274, E8-F4): `.loading` was NOT the whole window. The autostart at the tail
    /// of `load()` writes `.playing` before the new host has published a position, so for the next
    /// ~50 ms the clock still reads the zero `load()` wrote, and a correction raised the moment a
    /// rebuild returned rebuilt at the head. `setAudioDelay`'s own catch-up pass sits exactly there,
    /// and so did a second stepper press 50-90 ms after the first on `.loopback` (measured on the CLI:
    /// `#3 mount seek: item axis 0.00s`, `cutting seg0+`). A playable session whose clock reads exactly
    /// the reset zero has not published yet, and the parked value is what it is mounted at. A seek
    /// retires the parked value (`seek(to:origin:)`), so a genuine seek to 0 is never overridden.
    nonisolated static func rebuildPosition(state: PlaybackState, clock: Double, underReconstruction: Double?,
                                            pendingSeek: Double? = nil) -> Double {
        if let pendingSeek, pendingSeek.isFinite, pendingSeek >= 0 { return pendingSeek }
        guard let parked = underReconstruction else { return clock }
        switch state {
        case .loading: return parked
        case .playing, .paused: return clock == 0 ? parked : clock
        case .idle, .seeking, .ended, .error: return clock
        }
    }

    /// #227 round 2: whether a finishing session-preserving rebuild is the one that owns the held
    /// external-playback edge, and so the one that reconciles it against the live route.
    ///
    /// Only the outermost does. Every rebuild raises the hold, because every rebuild tears down the
    /// item the KVO watches and so produces a false edge that describes the teardown rather than the
    /// route; but a nested one that reconciled would start a reload inside the teardown of the
    /// rebuild still running. That is the same loop #227 exists to prevent, reached from the inside
    /// rather than from the KVO, and it is why the flag is restored on exit instead of cleared.
    nonisolated static func rebuildOwnsHeldExternalPlaybackEdge(wasAlreadyRebuilding: Bool) -> Bool {
        !wasAlreadyRebuilding
    }

    /// #35 cold-DV-master startup-readiness gate. A DV master (P7->P8.1, or any HDR master)
    /// instantiated while the HDMI DV/HDCP decode path is still warming right after an SDR->HDR switch
    /// resolves 0 tracks (silent park) or fails -11819 "Cannot Complete Action"; neither is a
    /// -11868/-11848 rejection, so the reactive #98 path never fires and startup surfaces "Playback
    /// stopped". A second launch just works because the failed attempt warmed the link. This gate
    /// replays that recovery in-session: play, poll readiness, and on a cold failure reload the SAME
    /// master with a fresh asset (bounded) before falling back to the media playlist (HDR10 base, no
    /// DV upgrade). Bounded at every stage, so a cold resume can never hang forever on 0 tracks.
    ///
    /// #227: the same escalation is what a wireless AirPlay hop needs. The master kept for an SDR source
    /// carries the subtitle renditions but assumes the receiver can take that variant, which the sender
    /// cannot check (a receiver without 4K HEVC would reject it). The gate covers the rejection and the
    /// silent park, and its reloads are rewritten onto the LAN IP so the receiver can reach them at all.
    @MainActor
    private func runStartupReadinessGate(
        session: HLSVideoEngine, position: Double, gen: UInt64
    ) async throws {
        guard let host = nativeHost else { return }
        host.startupReadinessGateActive = true
        defer { host.startupReadinessGateActive = false }

        // A receiver's first fetch crosses the LAN and its own decode handshake, so the local 3 s settle
        // window would judge a healthy AirPlay start too early and reload a master that was on its way.
        let initialSettle = airPlayActive
            ? Self.airPlayGateInitialSeconds
            : Self.startupGateInitialSeconds
        var attempt = 1
        var dataWaitRounds = 0
        while true {
            // Attempt 1 plays the item the load path already created; later attempts replay it fresh.
            host.play()
            let timeout = attempt == 1
                ? initialSettle
                : Self.startupGateReloadSeconds
            let outcome = await host.awaitStartupReadiness(timeoutSeconds: timeout)
            try checkLoadCurrent(gen)

            // AE#169 round 3: the data-wait exists for a first segment still being produced. A pump
            // that already exited with nothing served (tail resume onto an unproducible final
            // segment) can never satisfy it; consult liveness so the gate fails over immediately
            // instead of riding 24 s of false hope. A restart in flight reads as still-producing.
            let productionFinished = session.currentProducerFinished && !session.restartInFlight
            if outcome == .awaitingData, productionFinished {
                EngineLog.emit(
                    "[AetherEngine] #169 readiness gate: production already finished with no data "
                    + "served; skipping the data-wait (not a slow link)",
                    category: .session)
            }

            switch StartupReadinessGate.nextAction(
                outcome: outcome,
                attempt: attempt,
                masterAlreadyFellBack: masterFallbackUsed,
                hasMediaFallbackURL: session.mediaPlaylistURL != nil,
                dataWaitRounds: dataWaitRounds,
                productionFinished: productionFinished
            ) {
            case .proceed:
                return

            case .keepAwaitingData:
                // #169: the master's first segment (a tail resume anchors it on the final segment) has
                // not been served yet because it is still being produced over a slow link. That is not a
                // cold DV/HDCP decode failure; keep the DV master and re-await the SAME item rather than
                // reloading and falling back to the media playlist (which would needlessly drop DV).
                dataWaitRounds += 1
                EngineLog.emit(
                    "[AetherEngine] #35/#169 readiness gate: master's first segment not served yet "
                    + "(still producing over a slow link); keeping the DV master and waiting "
                    + "(data-wait \(dataWaitRounds)/\(StartupReadinessGate.maxDataWaitRounds)) at "
                    + "\(String(format: "%.2f", position))s",
                    category: .session)
                continue

            case .reloadMaster:
                guard let masterURL = session.masterPlaylistURL else {
                    // Master URL unavailable (should not happen while serving the master): force the
                    // fallback path on the next loop rather than reloading a URL we don't have.
                    attempt = StartupReadinessGate.masterAttempts
                    continue
                }
                EngineLog.emit(
                    "[AetherEngine] #35 readiness gate: master did not start (\(outcome)) after a "
                    + "panel switch; reloading the master (attempt \(attempt + 1)/"
                    + "\(StartupReadinessGate.masterAttempts), link may still be warming) at "
                    + "\(String(format: "%.2f", position))s",
                    category: .session)
                host.swapItem(url: airPlayHostSwapped(masterURL), startPosition: position)
                attempt += 1

            case .fallBackToMedia:
                // #98: before the bare (subtitle-less) media playlist, try the HDR-preserving reduced
                // master. It keeps HDR10 + subtitle renditions and, being plain hvc1 without DV signaling,
                // may start where the cold DV handshake did not. This case is terminal (returns/throws),
                // so it runs at most once per gate; no guard needed.
                if let reducedURL = session.reducedHDRMasterPlaylistURL {
                    EngineLog.emit(
                        "[AetherEngine] #35 readiness gate: master never produced tracks; trying the "
                        + "HDR-preserving reduced master (subtitles preserved, DV dropped) at "
                        + "\(String(format: "%.2f", position))s",
                        category: .session)
                    host.swapItem(url: airPlayHostSwapped(reducedURL), startPosition: position)
                    host.play()
                    let reducedOutcome = await host.awaitStartupReadiness(
                        timeoutSeconds: Self.startupGateReloadSeconds)
                    try checkLoadCurrent(gen)
                    if reducedOutcome == .ready {
                        EngineLog.emit(
                            "[AetherEngine] #35 readiness gate: reduced master started; HDR10 base and "
                            + "subtitles preserved (DV upgrade dropped this session)",
                            category: .session)
                        return
                    }
                }
                guard let mediaURL = session.mediaPlaylistURL else {
                    throw StartupGateFailure(message: startupGateFailureMessage(host))
                }
                masterFallbackUsed = true
                session.markServingMediaAfterFallback()
                nativeSubtitleRenditionsServed = false
                EngineLog.emit(
                    "[AetherEngine] #35 readiness gate: master never produced tracks after "
                    + "\(StartupReadinessGate.masterAttempts) attempts; falling back to the media "
                    + "playlist at \(String(format: "%.2f", position))s (HDR10 base, DV upgrade "
                    + "dropped this session)",
                    category: .session)
                host.swapItem(url: airPlayHostSwapped(mediaURL), startPosition: position)
                host.play()
                // Best-effort readiness confirm; the media playlist is the universal-compatible route.
                // Clearing the gate (defer) lets a genuine residual media failure surface normally via
                // the host's startup path -- no false-negative terminal error, still bounded.
                _ = await host.awaitStartupReadiness(timeoutSeconds: Self.startupGateMediaSeconds)
                try checkLoadCurrent(gen)
                return

            case .giveUp:
                throw StartupGateFailure(message: startupGateFailureMessage(host))
            }
        }
    }

    /// The message for a terminal gate failure: prefer the real startup error the gate suppressed
    /// while it held the item; fall back to a generic line for a silent 0-track park (no `.failed`).
    @MainActor
    private func startupGateFailureMessage(_ host: NativeAVPlayerHost) -> String {
        host.lastSuppressedStartupFailure
            ?? "The video could not start (no playable tracks after the display handshake)."
    }

    /// AE#446 round 2: the viewer has played out a window that was closed with ENDLIST because its
    /// source stopped delivering. Two ways forward and neither of them is `.ended`.
    ///
    /// If the source has cut again, the window is live once more, and the way to tell an item that has
    /// seen an ENDLIST is a swap: it never reloads its playlist again. That swap is the same one #442
    /// fixed, so it rejoins at the place the viewer held rather than at the edge.
    ///
    /// If the source is still down, the honest state is the one the viewer is already in, waiting, with
    /// the picture on the last frame it had. A poll every few seconds is what turns the source coming
    /// back into a resumed session; it stops with the session, and it is the only thing running,
    /// because an item under an ENDLIST generates no events of its own.
    ///
    /// - Returns: true when this was such a session, i.e. the caller must not publish `.ended`.
    @MainActor
    @discardableResult
    func handleLiveOutageWindowExhausted() -> Bool {
        guard isLive, let session = nativeVideoSession, session.liveOutageEndlistActive else {
            return false
        }
        // AE#446 round 3: nothing to swap into once the source read is gone, and the last thing a
        // dying source does is cut a partial segment on its way out (the no-cut exit flushes one in
        // the same millisecond as its abort). That flush refreshes the finalize timestamp, so
        // `liveOutageProductionResumed`, which asks whether the source is late, reads "delivering
        // again" for one cadence and swaps the item into a window whose source is dead. Measured on
        // the harness with a 150 s outage: the swap fired 10 ms after the retune request.
        guard !liveOutageSourceGivenUp else {
            liveOutageResumeWatcher?.cancel()
            liveOutageResumeWatcher = nil
            EngineLog.emit(
                "[AetherEngine] #446 the window ran out and the source read is already given up; "
                + "holding the last frame, and the session is the host's to retune",
                category: .engine)
            return true
        }
        if session.liveOutageProductionResumed {
            // The place to come back to, decided BEFORE the swap. It cannot be left to
            // `LiveReloadPolicy.recoveryRejoinPosition`, which reads how far behind live the item was:
            // a window closed with ENDLIST is a finite asset whose seekable end IS the playhead, so that
            // distance reads zero and the rejoin aims at the edge. Measured doing exactly that, and it
            // discards the rewind the viewer just spent the whole outage keeping.
            let heldPosition = currentTime
            EngineLog.emit(
                "[AetherEngine] #446 the window ran out and the source is delivering again; swapping "
                + "the item so the session is live once more, at \(String(format: "%.2f", heldPosition))s, "
                + "the place it held",
                category: .engine)
            session.clearLiveOutageEndlist()
            liveRejoinAuditUntil = Date().addingTimeInterval(20)
            liveRejoinAuditLastEmit = nil
            reloadStalledConsumerItem(position: heldPosition, allowPausedConsumer: true,
                                      liveRejoinOverride: heldPosition > 0 ? heldPosition : nil)
            return true
        }
        guard liveOutageResumeWatcher == nil else { return true }
        EngineLog.emit(
            "[AetherEngine] #446 the window ran out with the source still down; holding the session "
            + "live and watching for the source to cut again, for as long as the source read lasts "
            + "(this is not an end)",
            category: .engine)
        liveOutageResumeWatcher = Task { @MainActor [weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: UInt64(Self.liveOutageResumePollSeconds * 1_000_000_000))
                guard let self, let session = self.nativeVideoSession,
                      session.liveOutageEndlistActive else { return }
                if session.liveOutageProductionResumed {
                    self.liveOutageResumeWatcher = nil
                    self.handleLiveOutageWindowExhausted()
                    return
                }
            }
        }
        return true
    }

    /// AE#446 round 3: the outage hold's wait ends when the source read does.
    ///
    /// The hold parks the session on its last frame and polls the provider for the source cutting
    /// again. That poll can only come true while something is still reading the source, so when the
    /// read is given up (the no-cut watchdog's starvation exit, a replayed source, an exhausted reopen
    /// budget) the watcher is watching nothing. Measured on the harness before the read was taught to
    /// survive a runway: the session held one frame for the rest of the run and the source delivering
    /// again 41 s later was never seen. The host is handed the session in the same breath
    /// (`liveSourceReset`); what has to stop here is the claim.
    @MainActor
    func noteLiveSourceGivenUp() {
        liveOutageSourceGivenUp = true
        guard liveOutageResumeWatcher != nil else { return }
        liveOutageResumeWatcher?.cancel()
        liveOutageResumeWatcher = nil
        EngineLog.emit(
            "[AetherEngine] #446 the outage wait ends here: the source read was given up, so nothing "
            + "can observe the source cutting again; the session is the host's to retune",
            category: .engine)
    }

    /// AE#446 round 2: how often the outage watcher above asks whether the source is back. A source
    /// that returns is not urgent to the frame, and the item is parked either way.
    nonisolated static let liveOutageResumePollSeconds: Double = 3.0

    /// - Parameter liveRejoinOverride: AE#446: where to rejoin when the caller knows the position and
    ///   `LiveReloadPolicy.recoveryRejoinPosition` cannot. A window closed with ENDLIST is a finite asset
    ///   whose seekable end IS the playhead, so the distance-behind-live that policy reads is zero and it
    ///   would aim at the edge, discarding the rewind the viewer kept through the whole outage.
    func reloadStalledConsumerItem(position: Double, allowPausedConsumer: Bool = false,
                                   liveRejoinOverride: Double? = nil,
                                   preserveLivePosition: Double? = nil, replacementURL: URL? = nil) {
        guard let host = nativeHost, let player = currentAVPlayer,
              let url = replacementURL ?? (player.currentItem?.asset as? AVURLAsset)?.url else { return }
        // Item death parks tcs at .paused; only that trigger may bypass the user-pause guard.
        guard Self.stalledConsumerRecoveryAllowed(
            consumerIsPaused: player.timeControlStatus == .paused,
            allowPausedConsumer: allowPausedConsumer) else { return }
        // AE#422: mirror, not `currentTime()`. See `reengageStalledConsumer`; this path runs one
        // grace window deeper into the same stall.
        let anchor = Self.recoveryAnchorPosition(
            frozenPosition: position, pendingSeekTarget: pendingRecoverySeekClockTarget,
            currentRendered: renderedPositionMirror.get())
        stallRecoveryWindowUntil = Date().addingTimeInterval(Self.stallRecoveryWindowSeconds)
        // AE#442: this reload swaps the item under a session that stays whole, so a playhead parked
        // in the DVR window is still resident content. Decided BEFORE the load, while the window and
        // the pre-reload playhead still describe the item being replaced.
        let policyRejoin = LiveReloadPolicy.recoveryRejoinPosition(
            isLive: isLive,
            playhead: currentTime,
            behindWhenLastAdvancing: liveBehindWhenLastAdvancing,
            residentRange: liveWindow?.seekableRange,
            targetDurationSeconds: liveTargetDurationSeconds)
        let rejoinPosition = preserveLivePosition
            ?? (replacementURL == nil ? (policyRejoin ?? liveRejoinOverride) : liveRejoinOverride)
        // AE#446 round 3: name which of the two decided, because they mean different things and the
        // difference is exactly what a reader of this line is trying to establish. The policy reads
        // how far behind live the item was; a window closed with ENDLIST is a finite asset whose
        // seekable end IS the playhead, so that distance reads zero there and printing it next to a
        // carried position says nothing true about a timeshifted viewer.
        let liveTarget: String = rejoinPosition.map { position in
            let provenance = preserveLivePosition != nil
                ? "(video presentation repair at the current playhead)"
                : replacementURL != nil
                ? "(preserving the current position across playlist renewal)"
                : policyRejoin != nil
                ? "(\(String(format: "%.1f", liveBehindWhenLastAdvancing))s behind live when the "
                  + "picture last moved, still resident)"
                : "(carried across the swap: the window it played out under was closed, so its own "
                  + "distance behind live reads zero)"
            return "\(String(format: "%.2f", position))s, the place it held \(provenance)"
        } ?? "the live edge (rejoin)"
        EngineLog.emit(
            (replacementURL == nil
                ? "[AetherEngine] #65 nudge did not revive the consumer; reloading item at "
                : "[AetherEngine] live playlist timing changed; replacing item at ")
            + (isLive ? liveTarget : "\(String(format: "%.2f", anchor))s")
            + Self.recoveryAnchorLogSuffix(
                anchor: anchor, position: position,
                pendingSeekTarget: pendingRecoverySeekClockTarget)
            + (replacementURL == nil ? " (same URL, same host)" : " (new playlist URL, same source and cache)"),
            category: .engine
        )
        // AE#454: the placement, expressed in the playlist the fresh item is about to load. A rejoin
        // is two operations, attaching an item and placing it, and only the first was ever stated to
        // AVPlayer at the swap: the item then joined where a live playlist tells any client to join,
        // its own edge, started playing there, and was corrected ~150 ms later by the stashed seek
        // below. Measured on the harness at 50.27s above the place it held, and in the field at 4 to
        // 37s for 140 to 220ms, thirteen swaps out of thirteen. Armed before the swap so the item's
        // FIRST manifest carries it; the stashed seek stays as the fallback for a client that ignores
        // the tag, and it is the same seek it always was.
        var didArmPlacement = false
        if isLive, let rejoinPosition, let session = nativeVideoSession {
            let outputSeconds = liveSessionSeekAxis.itemSeconds(forSourceSeconds: rejoinPosition)
                ?? (rejoinPosition - liveSessionShiftSeconds)
            if let armed = session.armLiveRejoinStart(atOutputSeconds: outputSeconds) {
                didArmPlacement = true
                EngineLog.emit(
                    "[AetherEngine] #454 placing the fresh item at "
                    + "\(String(format: "%.2f", rejoinPosition))s in its own playlist: segment "
                    + "\(armed.segmentIndex) + \(String(format: "%.2f", armed.secondsIntoSegment))s "
                    + "(output \(String(format: "%.2f", outputSeconds))s), so it never joins the edge "
                    + "to be corrected off it",
                    category: .engine)
            } else {
                if preserveLivePosition != nil {
                    EngineLog.emit("[AetherEngine] video presentation repair deferred: current position is not resident; preserving playback", category: .engine)
                    return
                }
                EngineLog.emit(
                    "[AetherEngine] #454 the place it held is not in a segment the producer still "
                    + "holds, so the fresh item joins as before and the stashed seek decides",
                    category: .engine)
            }
        }
        // Live reload = live REJOIN: no stale-clock resume, no explicit start seek — the
        // zero-tolerance seek into a possibly-slid window wedges the fresh item in waitingToPlay.
        // Same contract as the #98 media fallback above; see LiveReloadPolicy.
        host.swapItem(url: url,
                      startPosition: isLive ? nil : anchor,
                      skipInitialSeek: LiveReloadPolicy.skipInitialSeek(isLive: isLive, isRejoin: true))
        // AE#454 round 2: the item that is about to load is the one the placement was armed for, and
        // the only one whose axis the playlist will state.
        if didArmPlacement { liveRejoinPlacementGeneration = host.itemGeneration }
        // Item death parks AVPlayer at .paused whatever the viewer wanted, which is why this reload may
        // run for a paused consumer at all; resuming is still the viewer's call, read from the host's
        // intent (#122), which the in-place swap keeps. Playing a paused title here woke the tvOS
        // screensaver its item had died behind.
        if host.transportIntentIsPlaying { host.play() }
        if let rejoinPosition {
            // Stashed rather than seeked: the pre-readiness seek IS the wedge LiveReloadPolicy exists
            // to avoid, and a live seek does not defer itself (`shouldDeferHostSeek` excludes live), so
            // issuing one here would convert against a `seekableEnd` the fresh item has reset to 0 and
            // land on 0. The #127 slot replays it once the item is ready, and the live seek expresses
            // its target as a distance behind the edge, so it lands on the same content whatever axis
            // the fresh item came up on.
            pendingPreReadySeek = PendingPreReadySeek(seconds: rejoinPosition, origin: .liveRejoin)
        }
        if let ordinal = nativeSubtitleReapplyOrdinal {
            EngineLog.emit(
                "[AetherEngine] #65 re-applying native subtitle ordinal=\(ordinal) after item reload",
                category: .engine
            )
            // The select path's own stall-recovery retries (#32) cover the fresh item's
            // not-ready window; the stores are already filled, so the pre-fill returns fast.
            setNativeSubtitleSelected(track: ordinal)
        }
    }

    /// Pure decision (#93 PiP skips): does a rendered-time transition qualify as a seek-like jump?
    nonisolated static func isSubtitleReanchorJump(from: Double, to: Double) -> Bool {
        abs(to - from) >= subtitleReanchorJumpSeconds
    }

    /// Pure decision (#93 PiP skips): do the running readers cover `position`? Slightly ahead of
    /// readMax is covered (the parked reader catches up on its own); far ahead or anywhere behind
    /// the read anchor is not.
    nonisolated static func nativeSubtitleReadersCover(
        position: Double, coverageStart: Double?, readMax: Double
    ) -> Bool {
        guard let start = coverageStart else { return false }
        return position >= start - subtitleReanchorBackwardSlack
            && position <= readMax + subtitleReanchorForwardSlack
    }

    /// Pure decision for the tcs sink (#93 residual): re-assert play() instead of latching a pause?
    nonisolated static func shouldReassertPlayDuringRecovery(
        statusIsPaused: Bool, engineStateIsPlaying: Bool,
        now: Date, windowUntil: Date, reasserts: Int
    ) -> Bool {
        statusIsPaused && engineStateIsPlaying && now < windowUntil
            && reasserts < maxStallRecoveryReasserts
    }

    /// Reconcile native seek completion while the regular time-control sink was gated by `.seeking`.
    /// Live AVPlayer status captures an external play that superseded older engine pause intent; a
    /// live pause wins unless the bounded stall-recovery policy deliberately reasserts playback.
    nonisolated static func seekRecoveredState(
        transportIntentIsPlaying: Bool,
        statusIsPaused: Bool,
        shouldReassertPausedStatus: Bool
    ) -> PlaybackState {
        if statusIsPaused {
            guard transportIntentIsPlaying, shouldReassertPausedStatus else {
                return .paused
            }
        }
        return .playing
    }

    /// Apply the same transport reconciliation after a normal native seek landing and after a
    /// deadline recovery. A starved deadline opens the bounded reassert window; a stable pause on a
    /// healthy path is treated as an external AVKit / MediaRemote command. When recovery overrides a
    /// spurious pause, replay play() because the paused KVO was consumed while state was `.seeking`.
    private func reconcileNativeSeekTransport(
        host: NativeAVPlayerHost,
        isStarved: Bool
    ) {
        let now = Date()
        if isStarved, now >= stallRecoveryWindowUntil {
            stallRecoveryWindowUntil = now.addingTimeInterval(Self.stallRecoveryWindowSeconds)
            stallRecoveryReasserts = 0
        }
        let liveStatus = host.liveTimeControlStatus
        let statusIsPaused = liveStatus == .paused
        let transportIntentIsPlaying = host.transportIntentIsPlaying
        let shouldReassertPausedStatus = Self.shouldReassertPlayDuringRecovery(
            statusIsPaused: statusIsPaused,
            engineStateIsPlaying: transportIntentIsPlaying,
            now: now,
            windowUntil: stallRecoveryWindowUntil,
            reasserts: stallRecoveryReasserts
        )
        let recoveredState = Self.seekRecoveredState(
            transportIntentIsPlaying: transportIntentIsPlaying,
            statusIsPaused: statusIsPaused,
            shouldReassertPausedStatus: shouldReassertPausedStatus
        )
        state = recoveredState
        isBuffering = recoveredState == .playing
            && liveStatus == .waitingToPlayAtSpecifiedRate
        if shouldReassertPausedStatus {
            stallRecoveryReasserts += 1
            playIntentMirror.set(true)
            host.play()
        }
    }

    /// #123: whether a seek landing (host completion + engine finalize) may settle `sourceTime` /
    /// `renderedTime` onto the seek target. `sourceTime` is the on-screen frame (#49), not the scrub
    /// target. When the landed frame is presented (the player is playing or paused at the position)
    /// the target IS the on-screen frame, so settle onto it. While the player is still buffering
    /// toward the target (`waitingToPlayAtSpecifiedRate`, a queued-burst chase on heavy 4K) the
    /// picture is frozen behind the target: settling would park `sourceTime` up to tens of seconds
    /// ahead of the frame for the whole chase, because the 100 ms periodic observer is silent while
    /// buffering and cannot walk it back, so any host pacing cues off `sourceTime` renders them over a
    /// stale frame (rrgomes' report). Hold instead; the observer settles `sourceTime` onto the target
    /// when playback resumes and the frame is delivered. This also keeps `abs(currentTime - sourceTime)`
    /// honest as a "converging" gap hosts can gate cue rendering on, instead of collapsing it at every
    /// landing while the picture is still behind.
    nonisolated static func seekLandingSettlesToTarget(bufferingTowardTarget: Bool) -> Bool {
        !bufferingTowardTarget
    }

    /// Tolerance for "the playhead has reached the end of a VOD" (AetherEngine#164). Absorbs the
    /// frame-granular gap between a scrub-to-end target and the exact declared duration, plus the
    /// loopback playlist-shift float error, without tripping on a deliberate pause a second or two
    /// before the credits.
    nonisolated static let endOfMediaEpsilonSeconds: Double = 0.5

    /// True when a non-live source's playhead sits at (or past) its final frame (AetherEngine#164).
    /// Live sources have no fixed end, and an unknown (zero) duration cannot be "reached".
    nonisolated static func isAtEndOfMedia(currentTime: Double, duration: Double, isLive: Bool) -> Bool {
        guard !isLive, duration > 0 else { return false }
        return currentTime >= duration - endOfMediaEpsilonSeconds
    }

    /// True when a native VOD tick shows the tail-park signature of AetherEngine#169: the final segment
    /// is loaded to (approximately) the advertised end, yet the playhead sits a hair short of `duration`
    /// waiting to minimize stalls. The final segment's advertised EXTINF is derived from the container
    /// duration (`sourceDurationSeconds`), which overshoots the last real video sample whenever the audio
    /// track runs a few frames longer or the container duration is rounded up; the video renderer then
    /// has no frame for the last fraction of a second, AVPlayer parks in WaitingToMinimizeStalls, never
    /// fires didPlayToEndTime, and after ~43 s dies with CoreMediaErrorDomain -12889.
    ///
    /// The `loadedEnd` guard is the discriminator against a still-downloading final segment: a playhead
    /// within the end epsilon but with the media loaded well short of `duration` is a recoverable network
    /// stall, NOT exhausted video, and must be left to the stall/reload recovery. A live source, an
    /// actually-playing item, a deliberate pause (not waiting-to-play), and a mid-stream position all fail
    /// the guards above.
    nonisolated static func endOfMediaParkTickQualifies(
        isLive: Bool,
        duration: Double,
        playhead: Double,
        loadedEnd: Double,
        waitingToPlay: Bool,
        minimizingStalls: Bool
    ) -> Bool {
        guard !isLive, duration > 0 else { return false }
        guard waitingToPlay, minimizingStalls else { return false }
        guard isAtEndOfMedia(currentTime: playhead, duration: duration, isLive: isLive) else { return false }
        return loadedEnd >= duration - endOfMediaEpsilonSeconds
    }

    /// Rolling count of consecutive 1 Hz native ticks whose tail-park conditions held with a frozen
    /// playhead. Resets to zero the instant a tick stops qualifying or the playhead advances, so a
    /// momentary near-end buffering blip that then resumes never accumulates toward completion.
    nonisolated static func endOfMediaParkFrozenTicks(
        previous: Int,
        tickQualifies: Bool,
        playheadFrozen: Bool
    ) -> Int {
        (tickQualifies && playheadFrozen) ? previous + 1 : 0
    }

    /// Grace before synthesizing end-of-media from a tail park (AetherEngine#169): the park must persist
    /// this many consecutive 1 Hz ticks so a transient near-end stall that self-recovers is never cut
    /// short. Three ticks (~3 s) still finishes far faster than the ~43 s AVPlayer takes to surface -12889.
    nonisolated static let endOfMediaParkGraceTicks: Int = 3

    /// Synthesize organic end-of-media once the tail park has persisted past the grace window.
    nonisolated static func shouldSynthesizeEndOfMediaFromPark(frozenTicks: Int) -> Bool {
        frozenTicks >= endOfMediaParkGraceTicks
    }

    /// How far short of `duration` an end-of-item event must land before it counts as premature
    /// (AetherEngine#287). Deliberately above `endOfMediaEpsilonSeconds` so the #169 tail park owns the
    /// last half second and the two can never contend for the same event.
    nonisolated static let prematureEndShortfallSeconds: Double = 1.0

    /// How far past the playhead AVPlayer's own seekable range must reach before its end-of-item event
    /// counts as self-contradicted (AetherEngine#287).
    nonisolated static let prematureEndSeekableLeadSeconds: Double = 1.0

    /// Cap on premature-end recoveries per item (AetherEngine#287). A source whose video track has
    /// several holes gets a recovery at each of them; a pathological one cannot spin.
    nonisolated static let prematureEndRecoveryMaxAttempts: Int = 3

    /// A recovery must have moved the playhead by at least this much before another one is allowed
    /// (AetherEngine#287). Re-seeking a position that already failed to resume would loop forever.
    nonisolated static let prematureEndRecoveryMinProgressSeconds: Double = 0.5

    /// True when AVPlayer's `didPlayToEndTime` is contradicted by AVPlayer's own seekable range, i.e. it
    /// ended the item tens of seconds inside a presentation it still reports as seekable
    /// (AetherEngine#287).
    ///
    /// A VOD whose selected audio track outruns its video track (the reporter's dual-audio BDRip: video
    /// ends 1431.971 s, the selected English AAC 1484.935 s, container 1484.936 s) makes AVPlayer end the
    /// item the moment the video renderer runs dry, ~53 s short of the advertised duration. Reproduced
    /// on a synthesized 60 s-video / 113 s-audio MKV: the end fires at 60.03 s of a 113.02 s
    /// presentation whose final segment had already been fetched whole, and identically for a 2 s, an
    /// 8 s and a 53 s tail, so the trigger is the video exhaustion rather than the length of the tail.
    /// The playlist is not the culprit either: its EXTINF sum equals the container duration to the
    /// millisecond (measured 14 x 4.004 + 56.967 = 113.023).
    ///
    /// The engine cannot talk AVPlayer out of that call, but it must not forward it as an organic
    /// finish. `.ended` is terminal (#63/#164), so seek and play become no-ops and the tail is
    /// unreachable for the rest of the session; the host sees a hard stop tens of seconds early. Seeking
    /// back to the SAME position and resuming re-arms the renderers and plays the tail out to an organic
    /// end at the real duration with no audio dropped (measured; `play()` without the seek leaves the
    /// clock frozen at the boundary indefinitely).
    ///
    /// The witness is the SEEKABLE range, not the loaded one that carries #169. Measured at the instant
    /// the premature end fires: `loadedTimeRanges` has already been trimmed back to the exhaustion point
    /// ([22.34, 60.01] with the playhead at 60.03), so the loaded range agrees with AVPlayer's mistake
    /// and cannot refute it, while `seekableTimeRanges` still reports the whole presentation
    /// ([0, 113.02]). A live session fails this guard on its own, its seekable end being the live edge.
    ///
    /// A real serve failure does not reach here: a segment that never arrives fails the item with
    /// `failedToPlayToEndTime` / -12889, a different notification with its own recovery. And a recovery
    /// that cannot work costs one re-seek before the same end is accepted, so the worst case is today's
    /// behaviour one seek later.
    nonisolated static func prematureEndRecoveryQualifies(
        isLive: Bool,
        duration: Double,
        playhead: Double,
        seekableEnd: Double?,
        attemptsUsed: Int,
        lastAttemptPlayhead: Double?
    ) -> Bool {
        guard !isLive, duration > 0, playhead.isFinite else { return false }
        guard attemptsUsed < prematureEndRecoveryMaxAttempts else { return false }
        guard duration - playhead > prematureEndShortfallSeconds else { return false }
        guard let seekableEnd, seekableEnd.isFinite,
              seekableEnd - playhead >= prematureEndSeekableLeadSeconds else { return false }
        if let lastAttemptPlayhead,
           playhead - lastAttemptPlayhead < prematureEndRecoveryMinProgressSeconds { return false }
        return true
    }

    /// How long the #287 in-place re-seek may take before the end is accepted (AE#962). The seek
    /// targets a position whose segments are resident, so it lands in well under a second when it can
    /// land at all; the reporter's session waited on one for over two minutes behind a black picture.
    nonisolated static let prematureEndRecoverySeekDeadlineSeconds: Double = 20

    enum PrematureEndRecoveryOutcome: Equatable {
        /// The re-seek landed: resume playback into the tail.
        case resume
        /// A newer seek replaced it: that seek owns the transport, and the item has not ended.
        case yield
        /// It timed out or did not reach the target: the end stands, one bounded seek later.
        case acceptEnd
    }

    nonisolated static func prematureEndRecoveryOutcome(landed: Bool, superseded: Bool) -> PrematureEndRecoveryOutcome {
        if superseded { return .yield }
        return landed ? .resume : .acceptEnd
    }

    /// How recently the published clock must have reached its peak for `prematureEndPlayhead` to
    /// trust it over AVPlayer's reading (AE#962). The snap-back it guards against lands two observer
    /// ticks (0.2 s) before the end notification.
    nonisolated static let prematureEndPeakMaxAgeSeconds: Double = 1.0

    /// The playhead a `didPlayToEndTime` is judged at (AE#962). A session that joined inside an
    /// audio-only tail never loaded a video sample, and at the REAL end AVPlayer publishes its clock
    /// back at the end of the video track (measured: 126.9 s, then 60.000 and 60.008 at rate 1.0, then
    /// the notification), so the item, the player and the observer all read a position a whole tail
    /// short of the end. `peak` is the highest clock published since the last seek: reached moments
    /// ago, it is where playback actually was. A peak from before an external backward scrub is old
    /// by the time the item ends, and is ignored.
    nonisolated static func prematureEndPlayhead(read: Double, peak: Double?, peakAgeSeconds: Double?) -> Double {
        guard let peak, let peakAgeSeconds, peak.isFinite, peak > read,
              peakAgeSeconds <= prematureEndPeakMaxAgeSeconds else { return read }
        return peak
    }

    /// Complete a native VOD that parked a hair short of its advertised duration because the final
    /// segment's video is exhausted (AetherEngine#169): the final segment's EXTINF, derived from the
    /// container duration, overshoots the last real video sample, so AVPlayer sits in
    /// WaitingToMinimizeStalls a few frames from the end, never fires didPlayToEndTime, and after ~43 s
    /// dies with -12889. Fires organic end-of-media through the host's `didReachEnd` so the session
    /// finishes cleanly (`.ended` -> mark-watched / autoplay-next / dismiss) instead of hanging then
    /// erroring. The tail numbers are logged so a field trace confirms the mechanism (video ends short
    /// of the container duration the final EXTINF was built from). Driven from the 1 Hz native tick.
    @MainActor
    func synthesizeEndOfMediaFromTailPark(playhead: Double, loadedEnd: Double) {
        EngineLog.emit(
            "[AetherEngine] #169 tail park: playhead=\(String(format: "%.3f", playhead))s "
            + "duration=\(String(format: "%.3f", duration))s loadedEnd=\(String(format: "%.3f", loadedEnd))s; "
            + "final-segment video exhausted within \(String(format: "%.2f", Self.endOfMediaEpsilonSeconds))s "
            + "of duration, synthesizing end-of-media",
            category: .engine)
        nativeHost?.markEndOfMediaReached()
    }

    /// A VOD seek whose target lands at end-of-media parks at the final frame (AetherEngine#164): it is
    /// not playing, but it is NOT the terminal `.ended` state either. `.ended` (organic completion, #63)
    /// fires the host's end-of-playback handling (mark-watched / autoplay-next / dismiss) and is reserved
    /// for playback finishing on its own; forcing it on a manual scrub would misfire those side effects
    /// and, being terminal, would strand the playhead with no way to scrub back. Settle to `.paused`
    /// instead so the scrubber stays live and the park replays via `play()`. Returns nil to keep the
    /// normal seek-landing reconcile for a mid-stream target.
    nonisolated static func seekEndParkState(target: Double, duration: Double, isLive: Bool) -> PlaybackState? {
        isAtEndOfMedia(currentTime: target, duration: duration, isLive: isLive) ? .paused : nil
    }

    /// Whether `play()` / `togglePlayPause()` must rewind to the start before resuming (AetherEngine#164).
    /// A VOD parked at its final frame (scrubbed to the end, or paused there) cannot advance;
    /// `AVPlayer.play()` at end-of-media is a no-op, freezing the button. `.ended` is deliberately
    /// excluded: it is terminal (#63), the host revives it by reloading, and a play press racing the end
    /// card must not silently restart the finished session.
    nonisolated static func shouldRewindBeforePlay(
        state: PlaybackState, currentTime: Double, duration: Double, isLive: Bool
    ) -> Bool {
        guard state != .ended else { return false }
        return isAtEndOfMedia(currentTime: currentTime, duration: duration, isLive: isLive)
    }

    #if DEBUG
    /// Test-only override for the session's restart-in-flight signal (#93 residual deferral tests).
    var testHookRestartInFlightOverride: Bool? = nil
    #endif

    #if DEBUG
    /// Test-only store override for the external instant-backfill path (#88); production reads the
    /// live session's stores.
    var testHookNativeStores: [NativeSubtitleCueStore]? = nil
    func testHookInstallNativeStores(_ stores: [NativeSubtitleCueStore]) { testHookNativeStores = stores }
    #endif

    /// External subtitle registrations by synthetic TrackInfo id (AetherEngine#88). Cleared on
    /// load()/stop() alongside subtitleTracks.
    var externalSubtitleRegistry: [Int: ExternalSubtitleTrack] = [:]
    var nextExternalSubtitleOrdinal = 0
    /// True once the host made an explicit subtitle choice this session (select / sidecar / clear).
    /// Gates the preferred-language re-run after a late external add, so a user who turned
    /// subtitles off does not get them re-enabled (#88).
    var hostExplicitSubtitleAction = false
    /// Synthetic id of the external track active on the secondary channel, nil when the secondary
    /// is off or embedded (#88).
    private(set) var activeSecondaryExternalSubtitleTrackID: Int? = nil
    /// Selection intent is separate from the still-visible active track while preparation runs.
    var pendingSecondaryExternalSubtitleTrackID: Int? = nil
    /// Base for synthetic external-subtitle TrackInfo ids; far above any real AVStream index.
    public static let externalSubtitleTrackIDBase = 100_000
    /// #170: true while `reloadAtCurrentPosition` runs a session-preserving reload. Host
    /// `setNativeSubtitleRendering` calls landing in this window are latched into
    /// `pendingNativeRenderingRequest` (the mid-reload active track is transiently nil and would
    /// misread as deselect) and applied by `restoreSubtitleSelection`.
    var sessionPreservingReloadInFlight = false
    var pendingNativeRenderingRequest: Bool? = nil

    /// Sodalite#156: the host's standing "the picture is not on my layer" request, from
    /// `setNativeSubtitleRendering`. While it holds, the native rendition IS the display, so a
    /// subtitle pick has to reach it and a subtitles-off has to take it down. Both directions were
    /// missing, and they hid each other: nothing deselected, so a pick made against a standing
    /// selection looked like it had been followed.
    var nativeSubtitleRenderingRequested = false
    /// AE#955: the standing request above was raised by the engine for a wireless AirPlay receiver,
    /// not by the host. Only such a request is withdrawn when the receiver lets go; any host call to
    /// `setNativeSubtitleRendering` clears this and owns the request from then on.
    var nativeRenderingImpliedByAirPlay = false

    /// AE#464 round 2: the position the load currently in flight was handed, parked across the window
    /// in which `load` has already zeroed the clock but the rebuilt session has not reached it yet.
    /// Written at the two sites that raise `state = .loading` for a load, retired by an accepted seek;
    /// read only through `positionForSessionRebuild`, which is what makes a reload stacked behind
    /// another one, or raised the moment one returned (round 5), rebuild at the playhead instead of at
    /// the head.
    var positionUnderReconstruction: Double?

    /// AE#464 round 3: the transport intent the load in flight was handed, parked across the same
    /// window as `positionUnderReconstruction` and for the same reason. Read only through
    /// `sessionRebuildResumesPlaying`. See `rebuildResumesPlaying`.
    var transportIntentUnderReconstruction: Bool?
    private(set) var audioSelectionTask: Task<Void, Never>?
    /// AE#711 follow-up: the picture held over an in-place item swap. See `holdPictureAcrossItemSwap`.
    var heldPictureRelease: AnyCancellable?
    weak var heldPictureView: (any HeldStillSurface)?
    weak var boundStillView: AetherStillView?
    /// Why the last hold showed nothing, for the log and the tests that pin it.
    var heldPictureLastSkip: String?
    var heldPictureToken = 0
    var heldPictureShownAt: ContinuousClock.Instant?
    /// What took the last held picture down, for the log line and the tests that pin it.
    var heldPictureLastRelease: String?
    /// A hold over a software rebuild waits for `loadSoftware` to install the host it comes down on.
    var heldPictureAwaitsSoftwareHost = false
    /// Which route the last held picture came from, for the log line and the tests that pin it.
    var heldPictureLastRoute: String?
    private var pendingAudioSelection: Int?
    private var audioSelectionEpoch = UUID()

    private func cancelPendingAudioSelection() {
        audioSelectionEpoch = UUID()
        audioSelectionTask?.cancel()
        audioSelectionTask = nil
        pendingAudioSelection = nil
    }

    /// AE#464 round 3: true while a re-anchor raised by `setAudioDelay` is running, so the presses
    /// that arrive during it are folded into it instead of stacking re-anchors of their own. The
    /// value does not ride the call (every press writes `loadedOptions.audioDelaySeconds` first), so
    /// the rebuild already in flight delivers the newest one. See `reanchorForAudioDelay`.
    var audioDelayReanchorInFlight = false

    /// AE#923: the same latch for `setAudioShaping`'s rebuilds.
    var audioShapingReanchorInFlight = false

    /// The playhead a rebuild of this session has to come back to (#464 round 2).
    var positionForSessionRebuild: Double {
        let pending = !isLive && nativeHost != nil
            ? pendingRecoverySeekClockTarget.map { displaySeconds(forPlaylistSeconds: $0) } : nil
        return Self.rebuildPosition(state: state, clock: currentTime,
            underReconstruction: positionUnderReconstruction, pendingSeek: pending)
    }

    /// The transport state a rebuild of this session has to come back in (#464 round 2). Asks the
    /// native host for its durable intent where there is one to ask, exactly as `togglePlayPause`
    /// does, and falls back to `state` on the routes that have no competing transport owner.
    /// AE#711 follow-up: a play/pause that arrives while a session-preserving rebuild runs is the
    /// transport that rebuild has to come back in. Recorded on the flag both rebuild routes raise
    /// rather than on `.loading`, because `play()` itself moves `.loading` to `.playing` and a pause
    /// after it would otherwise go unrecorded. Read back where each rebuild settles its transport.
    func recordTransportDuringRebuild(playing: Bool) {
        guard sessionPreservingReloadInFlight else { return }
        transportIntentUnderReconstruction = playing
    }

    var sessionRebuildResumesPlaying: Bool {
        let nativeIntent = (nativeHost != nil && !audioAVPlayerActive && audioHost == nil && softwareHost == nil)
            ? nativeHost?.transportIntentIsPlaying
            : nil
        return Self.rebuildResumesPlaying(state: state, nativeTransportIntent: nativeIntent,
                                          underReconstruction: transportIntentUnderReconstruction)
    }
    /// #357: selection parked by a background teardown for the foreground reload, because on that
    /// path the two are minutes apart and `stopInternal` has wiped the state the reload snapshots
    /// itself. Claimed by `consumeReloadSelection`, dropped by any other `load()` and by `stop()`.
    var backgroundTeardownSelection: BackgroundTeardownSelection?

    /// The background policy released the video item while retaining the source, playhead,
    /// selection and native host. A foreground host must rebuild before sending play().
    public var needsForegroundVideoRestore: Bool { backgroundTeardownSelection != nil }

    /// Detached reader that decodes ALL embedded text subtitle streams in one side-demuxer pass into their
    /// ordinal's NativeSubtitleCueStore (#55, all-tracks). Parallel to the packet-store drainer (which drives
    /// subtitleCues for the active track with full styling). Cancelled on stop/clear/load.
    var nativeSubtitleReadersTask: Task<Void, Never>?

    /// Abort handle for the native multi-decode side demuxer. markClosed unblocks AVIO reconnect loops
    /// (mirrors the old primary side-demuxer teardown).
    var nativeSubtitleReadersDemuxer: Demuxer?

    /// Lazy-start params for the native subtitle readers (#15): captured at load when prepareNativeSubtitles
    /// declared the mov_text track, but the readers only start on the first setNativeSubtitleSelected (PiP),
    /// so a session that never selects a native track pays no standing side-demuxer cost. Cleared on stop/clear.
    var nativeSubtitleReaderParams: (url: URL, stores: [NativeSubtitleCueStore])?

    /// True while the running native readers were started in read-to-EOF (eager) mode (Sodalite#32).
    /// Deselect must NOT cancel such a reader (it is building whole-session coverage for the next PiP
    /// entry), and select must not replace it with a playhead-anchored parking reader.
    var nativeSubtitleReadersRunToEOF = false

    /// #357: budget for the per-cue `[applySubtitleEvent #N]` line, refilled per seek generation.
    /// Was a per-load counter, which went blind after 20 events and left every later seek landing
    /// unobservable; see `SubtitleDeliveryStatement.EventBudget`.
    var subtitleCueDiagnosticBudget = SubtitleDeliveryStatement.EventBudget()

    /// Trailing retention window for subtitleCues (seconds). Evicted cues come back when a backward
    /// seek re-decodes its window from the packet store. Bitmap cues are bounded by bytes as well,
    /// see `subtitleCueBitmapByteBudget`.
    let subtitleCueRetentionSeconds: Double = 300

    /// AE#879: ceiling on the decoded RGBA bytes of retained bitmap cues (PGS/DVB/DVD), enforced only
    /// on cues that ended further behind the playhead than `bitmapCueFloorSeconds(offsetReach:)`.
    nonisolated static let subtitleCueBitmapByteBudget = 64 * 1024 * 1024
    /// AE#879: the default of `maximumSubtitleOffsetSeconds`, so the history the byte budget never
    /// evicts for a host that declares nothing: a host-side offset still finds its cue without a seek.
    nonisolated static let subtitleCueBitmapFloorSeconds: Double = 60
    /// AE#929: the least a bitmap channel keeps decoded on either side of the playhead, whatever the
    /// host declares. Behind, a backward nudge under `subtitleDrainJumpThresholdSeconds` does not
    /// re-decode, so the cues it lands on have to still be there; ahead, it keeps the next sets
    /// decoded well before they are due. Equal to the backscan a seek re-decodes.
    nonisolated static let subtitleBitmapMinimumReachSeconds: Double = 15

    /// AE#929: the largest subtitle offset, of either sign, the host applies to its overlay against
    /// `clock.sourceTime`. Bitmap cues (PGS/DVB/DVD) are retained as decoded RGBA, so this sets how
    /// much of them the engine keeps: the history the byte budget never evicts and how far ahead the
    /// drain decodes, each never less than `subtitleBitmapMinimumReachSeconds`, and the lead never
    /// more than `subtitleDrainLeadSeconds`. A host without an offset control should set 0; the
    /// default keeps the behavior from before this property existed. Text tracks are unaffected.
    /// Negative and non-finite values are ignored. Takes effect on the next drain tick.
    public var maximumSubtitleOffsetSeconds: Double = AetherEngine.subtitleCueBitmapFloorSeconds {
        didSet {
            if !maximumSubtitleOffsetSeconds.isFinite || maximumSubtitleOffsetSeconds < 0 {
                maximumSubtitleOffsetSeconds = oldValue
            }
        }
    }

    /// AE#929: the reach the bitmap windows are sized from. The software PiP compositor applies
    /// `softwareSubtitleDelaySeconds` itself, so that offset is covered even when the host
    /// declared less.
    var bitmapSubtitleOffsetReach: Double {
        max(maximumSubtitleOffsetSeconds, abs(softwareSubtitleDelaySeconds))
    }

    /// AE#929: history behind the playhead the bitmap byte budget never evicts.
    nonisolated static func bitmapCueFloorSeconds(offsetReach: Double) -> Double {
        max(offsetReach, subtitleBitmapMinimumReachSeconds)
    }

    /// AE#929: the drain's decode lead for a channel. A bitmap lead holds decoded images, so it
    /// follows the host's offset reach; a text lead is cheap and stays at `subtitleDrainLeadSeconds`.
    nonisolated static func subtitleDrainLead(isBitmap: Bool, offsetReach: Double) -> Double {
        guard isBitmap else { return subtitleDrainLeadSeconds }
        return min(max(offsetReach, subtitleBitmapMinimumReachSeconds), subtitleDrainLeadSeconds)
    }

    /// AE#929: whether a drain channel decodes bitmap cues. A sidecar channel only ever carries a
    /// bitmap source (#921); an embedded one is read off the track list.
    func subtitleDrainChannelIsBitmap(_ channel: SubtitleChannel, streamIndex: Int32) -> Bool {
        if sidecarBitmapSources[channel] != nil { return true }
        guard let codec = subtitleTracks.first(where: { $0.id == Int(streamIndex) })?.codec else { return false }
        return Self.isBitmapSubtitleCodec(codec)
    }

    func subtitleDrainLead(for channel: SubtitleChannel, streamIndex: Int32) -> Double {
        Self.subtitleDrainLead(isBitmap: subtitleDrainChannelIsBitmap(channel, streamIndex: streamIndex),
                               offsetReach: bitmapSubtitleOffsetReach)
    }

    /// #357: shortest window that can only be FFmpeg's open-ended placeholder, not an authored
    /// duration. A PGS composition carries no end of its own, so the decoder stamps it with
    /// `end_display_time = UINT32_MAX` (~49.7 days) and the successor composition's `pgsTrimAt`
    /// closes it. An hour is far past any authored subtitle window and far short of the placeholder,
    /// so the test never has to know which decoder produced the cue.
    nonisolated static let subtitleOpenEndedWindowSeconds: Double = 3600

    /// #15: native WebVTT readers must stay ahead of AVPlayer's subtitle prefetch (~240s burst at PiP start),
    /// otherwise far segments are fetched empty and cached empty for the VOD rendition. Larger than the inline
    /// reader's 90s lead; only runs while a native rendition is selected (PiP), so the extra read is bounded.
    nonisolated static let nativeSubtitleReadAheadSeconds: Double = 300

    /// Source-time flush window for ASS cue batching (#56). Previously each event triggered a MainActor.run hop;
    /// on packet-dense tracks (hundreds of events in a few seconds) those hops serialised the demux loop against
    /// the on-MainActor renderer, causing published cues to fall far behind the playhead. Coalescing within this
    /// window decouples demux speed from MainActor pressure. Small enough that sparse tracks still flush per event,
    /// and well under the 2 s seek pre-roll so the first cue lands before the playhead.
    nonisolated static let embeddedSubtitleFlushWindowSeconds: Double = 0.5

    /// Per-flush event count cap. Handles same-timestamp bursts (span stays 0, so the window rule never trips)
    /// and NOPTS packets with no demux clock. The #56 sample had 1534 ASS events on a single pts (5.207s);
    /// at this cap that cluster publishes in ~12 hops. Sized large because same-pts bursts are far ahead of the
    /// playhead, so a bigger batch costs no display latency.
    nonisolated static let embeddedSubtitleFlushCountCap = 128

    /// Flush predicate for the embedded ASS cue batch. Pure so SubtitleBatchFlushTests can unit-test it.
    ///
    /// - `batchSpanSeconds`: demux position minus the first event's source time, or nil (NOPTS).
    ///
    /// Flushes when the batch spans >= windowSeconds (common case) or reaches countCap (same-timestamp/NOPTS).
    /// An empty batch never flushes.
    nonisolated static func shouldFlushSubtitleBatch(
        pendingCount: Int,
        batchSpanSeconds: Double?,
        windowSeconds: Double = AetherEngine.embeddedSubtitleFlushWindowSeconds,
        countCap: Int = AetherEngine.embeddedSubtitleFlushCountCap
    ) -> Bool {
        guard pendingCount > 0 else { return false }
        if pendingCount >= countCap { return true }
        if let span = batchSpanSeconds, span >= windowSeconds { return true }
        return false
    }

    // MARK: - Init

    /// Block-based observers are NOT auto-removed on dealloc; the bag removes them in its own deinit.
    /// A MainActor deinit can't touch non-Sendable stored state under Swift 6, hence the helper class.
    private let lifecycleObservers = LifecycleObserverBag()
    /// For lifecycle observers installed from extension files.
    func retainLifecycleObserver(_ observer: NSObjectProtocol) { lifecycleObservers.append(observer) }

    private final class LifecycleObserverBag: @unchecked Sendable {
        private let lock = NSLock()
        private var tokens: [Any] = []
        func append(_ token: Any) {
            lock.lock(); tokens.append(token); lock.unlock()
        }
        deinit {
            for token in tokens {
                NotificationCenter.default.removeObserver(token)
            }
        }
    }

    #if os(iOS) || os(tvOS)
    /// Pending off-main deactivation (#215). See `scheduleAudioSessionDeactivation()`.
    private var audioSessionDeactivationTask: Task<Void, Never>?
    #endif

    /// Run a session activation or release off the main actor, after every one asked for before it.
    ///
    /// Since AE#538 both halves are detached tasks, and two detached tasks carry no order between them.
    /// While the renderer activation still ran synchronously on the main actor a `stop()` could not land
    /// inside it, so the #215 release always followed it; without the queue a stop during a software or
    /// audio-only load's activation can send `setActive(false)` first and leave the session active after a
    /// final teardown. Each transition awaits its predecessor, including a cancelled one, which then drops
    /// on its own guard. Not platform-gated, so the order is testable where the session does not exist.
    /// Since Sodalite#175 the queue is the process-wide one in `SharedOutputCoordinator`.
    func enqueueAudioSessionTransition(_ body: @escaping @Sendable () async -> Void) -> Task<Void, Never> {
        SharedOutputCoordinator.shared.enqueueTransition(body)
    }

    #if os(iOS) || os(tvOS)
    /// Route-sharing policy the engine declares with the session category. Platform-split (#116):
    /// tvOS keeps `.longFormAudio` for HDMI route negotiation (#24); on iOS that policy marks the
    /// process as a long-form audio client, which pins AVKit's
    /// `AVPictureInPictureController.isPictureInPicturePossible` to false for any host-built PiP
    /// controller around the engine's player layer, so iOS declares `.default`.
    #if os(tvOS)
    nonisolated static let audioSessionRouteSharingPolicy: AVAudioSession.RouteSharingPolicy = .longFormAudio
    #else
    nonisolated static let audioSessionRouteSharingPolicy: AVAudioSession.RouteSharingPolicy = .default
    #endif
    #endif

    public init() throws {
        // Route av_log into EngineLog before any libav* entry point so probe/load diagnostics are captured.
        FFmpegLogBridge.install()
        // Which FFmpeg answers is decided by the host's link, not by the package graph (AE#396).
        FFmpegRuntimeCheck.logOnce()

        // The category is declared off-main at the first load, once per process (#114), and the session
        // is never activated here: AVKit owns native playback activation (#24).

        setupLifecycleObservers()
    }

    /// Declare the process-wide category before a load can activate the session (#114, off-main).
    /// Concurrent loads share one operation, and once it has succeeded no later load touches the
    /// category again: a host that switches the mode afterwards (music playback setting `.default`)
    /// keeps it, as it did when the declaration ran once at init. A failed attempt is retried.
    func awaitAudioSessionCategoryConfigured() async {
        #if os(iOS) || os(tvOS)
        await SharedOutputCoordinator.shared.configureAudioSessionCategory {
            Self.configureAudioSessionCategory()
        }
        #endif
    }

    #if os(iOS) || os(tvOS)
    /// A host that already declared `.playback` before the first load owns mode and policy; only a
    /// session still on the system default gets the engine's declaration.
    nonisolated private static func configureAudioSessionCategory() -> Bool {
        let session = AVAudioSession.sharedInstance()
        do {
            if session.category != .playback {
                try session.setCategory(.playback, mode: .moviePlayback, policy: audioSessionRouteSharingPolicy)
            }
            if !session.supportsMultichannelContent {
                try session.setSupportsMultichannelContent(true)
            }
            EngineLog.emit("[AetherEngine] AVAudioSession: category set off-main, not activated (AVKit drives activation) category=\(session.category.rawValue) mode=\(session.mode.rawValue) policy=\(session.routeSharingPolicy.rawValue) maxChannels=\(session.maximumOutputNumberOfChannels) output=\(session.outputNumberOfChannels)", category: .engine)
            return true
        } catch {
            EngineLog.emit("[AetherEngine] AVAudioSession setup error: \(error)", category: .engine)
            return false
        }
    }
    #endif

    // MARK: - Public load

    /// Load a media file or stream URL. Replaces any current playback.
    ///
    /// Behavior:
    /// 1. Tears down the previous session.
    /// 2. Briefly opens the demuxer to detect format + frame rate.
    /// 3. Programs `AVDisplayCriteria` from the detected metadata
    ///    (DV → `dvh1`, others → `hvc1`; refresh rate snapped to a
    ///    standard rate; honors Match Content + Match Frame Rate).
    /// 4. Waits for the panel mode-switch to settle.
    /// 5. Spins up `HLSVideoEngine` + `NativeAVPlayerHost`.
    ///
    /// VP9 / AV1 sources gate on a runtime VideoToolbox capability
    /// probe; on hardware that can't decode them, the engine throws
    /// `HLSVideoEngine.HLSVideoEngineError.unsupportedCodec` and the
    /// host should surface that to the user. Dolby Vision Profile 7
    /// (dual-layer) and Profile 8.2 (SDR base) similarly throw.
    ///
    /// - Parameters:
    ///   - url: Media source (http/https/file).
    ///   - startPosition: Seconds into the stream to start at (resume).
    ///   - options: Engine-internal toggles. See `LoadOptions`.
    ///   - audioSourceStreamIndex: Optional container stream index for
    ///     the audio track to mux into the output. When non-nil, this is
    ///     used instead of `av_find_best_stream`'s automatic pick. Lets
    ///     the host honor a saved language preference on the very first
    ///     frame without bouncing through a separate
    ///     `selectAudioTrack` reload (which would cost a second of
    ///     "default-language audio plus black frame" at session start).
    ///     Validated against the container; an invalid index falls back
    ///     to the auto pick.
    /// Load media from a URL. Convenience wrapper over `load(source:)`.
    @discardableResult
    public func load(
        url: URL,
        startPosition: Double? = nil,
        options: LoadOptions = .init(),
        audioSourceStreamIndex: Int32? = nil,
        discTitleID: Int? = nil
    ) async throws -> SourceProbe? {
        try await load(
            source: .url(url),
            startPosition: startPosition,
            options: options,
            audioSourceStreamIndex: audioSourceStreamIndex,
            discTitleID: discTitleID
        )
    }

    /// Load media from a URL or a custom `IOReader`. See `MediaSource`.
    ///
    /// Custom sources: seekable readers play on both the native and
    /// software paths; forward-only readers (`seek` returns negative for
    /// SEEK_SET/CUR/END) play on the software path only. A custom source
    /// whose initial probe fails throws, since it cannot be reopened by URL.
    ///
    /// Capability for custom sources. Seekable readers support audio-track
    /// switching and background-return reload (the pipeline rebuilds on the
    /// retained reader). Embedded-subtitle selection and FrameExtractor scrub
    /// previews work when the reader implements `makeIndependentReader()` (they
    /// run a second demuxer concurrently and need an independent cursor); they
    /// no-op when it returns nil. Forward-only readers (seek returns negative)
    /// cannot rewind or, typically, clone, so those features no-op for them.
    /// Plain playback and sidecar subtitles always work.
    ///
    /// Returns the `SourceProbe` assembled from the internal probe
    /// stage (video size, codec, tracks, metadata) so hosts get the
    /// source facts without a second probe round-trip
    /// (AetherEngine#28). nil on the `nativeRemoteHLS` bypass (no
    /// probe runs there) and when the probe failed but playback
    /// proceeds anyway (URL sources can be reopened internally).
    enum HLSVODIngestReroute {
        /// No content evidence for unsupported carriage; the caller keeps its existing route.
        case notTaken
        /// The load was restarted on the ingest; the caller must return this result.
        case taken(SourceProbe?)
    }

    /// AE#268: content-gated reroute of a finite HLS VOD onto the seekable TS -> fMP4 ingest.
    ///
    /// AVFoundation builds no video track for HEVC in MPEG-TS (the HLS Authoring Spec sanctions HEVC
    /// only in fMP4), so the AE#154 bypass would hand this source to AVPlayer for an audio-only,
    /// black session. The #168 watchdog cannot catch it either: it is live-only and needs master
    /// variant evidence, which a direct media playlist has none of. The decision therefore comes from
    /// the playlist and the first segment's PMT, never from the `.m3u8` suffix or an AVPlayer error,
    /// and only positive evidence reroutes: unknown, fMP4, live, encrypted, demuxed-audio and
    /// H.264 shapes stay on the native path.
    ///
    /// AE#990: a session that decodes in software takes the ingest for any finite MPEG-TS. AVPlayer
    /// decodes nothing the engine owns, so on the bypass `preferredDecodePath = .software` had nothing
    /// to act on, and the AE#561 escalation of a refused native mount had nowhere to go.
    private func rerouteOntoMPEGTSIngest(
        playlistURL: URL,
        options: LoadOptions,
        startPosition: Double?,
        audioSourceStreamIndex: Int32?,
        discTitleID: Int?,
        generation: UInt64,
        evidence: String
    ) async throws -> HLSVODIngestReroute {
        guard !options.isLive else { return .notTaken }
        let acceptance: HLSVODIngestReader.Acceptance =
            options.preferredDecodePath == .software ? .anyMPEGTS : .hevcInMPEGTS
        guard let reader = try await HLSVODIngestReader.makeIfMPEGTS(
            playlistURL: playlistURL,
            httpHeaders: options.httpHeaders,
            persistentHTTP1: options.heldSourceConnection,
            accepting: acceptance,
            diagnosticContext: options.sourceDiagnosticsContext
        ) else { return .notTaken }
        try checkLoadCurrent(generation)
        EngineLog.emit(
            acceptance == .anyMPEGTS
                ? "[AetherEngine] AE#990: finite MPEG-TS HLS with preferredDecodePath=.software; routing "
                    + "through the seekable TS ingest so the engine decodes it"
                : "[AetherEngine] AE#268: \(evidence); routing through the seekable TS -> fMP4 ingest",
            category: .engine
        )
        var remuxOptions = options
        remuxOptions.nativeRemoteHLS = false
        // #361: the user asked for one thing and is still waiting for it; this reroute is the engine
        // changing its mind about how to serve it, not a second startup.
        continueStartupAcrossReroute()
        return .taken(try await load(
            source: .custom(reader, formatHint: "mpegts"),
            startPosition: startPosition,
            options: remuxOptions,
            audioSourceStreamIndex: audioSourceStreamIndex,
            discTitleID: discTitleID
        ))
    }

    @discardableResult
    /// - Parameter discTitleID: For a disc image (Blu-ray / DVD ISO), the title to open (id from
    ///   `discTitles`). nil opens the main title. Threaded into the probe so the chosen title is honored
    ///   on the first frame; an out-of-range id clamps to the main title. `selectTitle(id:)` and
    ///   background-resume route through here to (re)open at the right title (#67).
    public func load(
        source: MediaSource,
        startPosition: Double? = nil,
        options: LoadOptions = .init(),
        audioSourceStreamIndex: Int32? = nil,
        discTitleID: Int? = nil
    ) async throws -> SourceProbe? {
        // Sodalite#173: a task cancelled before the load began has nothing to end; the running session stays.
        // A reroute's #361 continuation armed for this load is withdrawn with it.
        if Task.isCancelled {
            abandonStartupContinuation()
            throw CancellationError()
        }
        let attempt = LoadAttempt()
        defer { if let gen = attempt.generation { waitingLoadGenerations.remove(gen) } }
        do {
            let probe = try await withTaskCancellationHandler {
                try await SourceNetworkDiagnostics.$context.withValue(options.sourceDiagnosticsContext) {
                    try await loadSession(
                        source: source, startPosition: startPosition, options: options,
                        audioSourceStreamIndex: audioSourceStreamIndex, discTitleID: discTitleID,
                        attempt: attempt)
                }
            } onCancel: {
                Task { @MainActor [weak self] in self?.abandonCancelledLoad(attempt) }
            }
            if Task.isCancelled, abandonCancelledLoad(attempt) { throw CancellationError() }
            return probe
        } catch is CancellationError {
            // AE#629: the engine took this startup over itself (the AE#561 / AE#641 rebuild), so the caller is
            // still waiting for the same thing and gets it, the way a #361 reroute keeps its wait. A
            // load the HOST superseded matches no takeover and unwinds as before.
            guard let generation = attempt.generation,
                  let takeover = softwarePathTakeover,
                  takeover.supersededGeneration == generation else {
                if Task.isCancelled { abandonCancelledLoad(attempt) }
                throw CancellationError()
            }
            EngineLog.emit(
                "[AetherEngine] #629 load (gen \(generation)) follows the engine's own rebuild "
                + "instead of unwinding", category: .engine)
            // Sodalite#173: a cancelled follower cancels the rebuild's Task, which ends a load() rebuild and
            // any reroute nested in it through their own handlers, and ends the rebuild's generation, which
            // the retained-reader branch observes only at its checkpoints. Both are generation-guarded.
            do {
                try await withTaskCancellationHandler {
                    try await takeover.rebuild.value
                } onCancel: {
                    takeover.rebuild.cancel()
                    Task { @MainActor [weak self] in self?.abandonFollowedRebuild(takeover, follower: attempt) }
                }
            } catch {
                if Task.isCancelled { throw CancellationError() }
                throw error
            }
            if Task.isCancelled {
                abandonFollowedRebuild(takeover, follower: attempt)
                throw CancellationError()
            }
            return attempt.probe
        } catch {
            guard Task.isCancelled else { throw error }
            abandonCancelledLoad(attempt)
            throw CancellationError()
        }
    }

    /// What `loadSession` tells the public `load` about itself: the generation it ran under and the
    /// probe it assembled, which a load followed across a takeover still returns (AE#629).
    @MainActor
    final class LoadAttempt {
        var generation: UInt64?
        var probe: SourceProbe?
    }

    /// Sodalite#173: the caller cancelled the task awaiting this load. Ends it only while it is still the
    /// load in flight: a newer load, or a session this one already returned, is not its to end.
    @discardableResult
    func abandonCancelledLoad(_ attempt: LoadAttempt) -> Bool {
        guard let gen = attempt.generation, loadGeneration == gen,
              waitingLoadGenerations.contains(gen) else { return false }
        endCancelledGeneration(gen)
        return true
    }

    /// Sodalite#173: the same for a load following an AE#629 rebuild, whose generation is the one the
    /// rebuild's teardown opened. Only while the follower still waits and nothing newer took over.
    func abandonFollowedRebuild(_ takeover: SoftwarePathEscalation.Takeover, follower: LoadAttempt) {
        guard let followed = follower.generation, waitingLoadGenerations.contains(followed),
              loadGeneration == takeover.rebuildGeneration else { return }
        endCancelledGeneration(takeover.rebuildGeneration)
    }

    /// Leaves the engine the way the next `load()`'s teardown would: the generation moves on, every
    /// blocking open is aborted and the custom reader closed, while the native host (#15) and an AE#158
    /// handover item are kept for that load and the panel keeps its mode. `state` reads `.idle`; a host
    /// that is leaving playback calls `stop()` to release the rest.
    private func endCancelledGeneration(_ gen: UInt64) {
        EngineLog.emit(
            "[AetherEngine] Sodalite#173: load (gen \(gen)) cancelled by its caller; ending it",
            category: .engine)
        let keepNativeHost = Self.shouldPreserveNativeHostAcrossLoad(
            backend: playbackBackend, nativeHostSurvives: nativeHost != nil,
            mediaServicesWereReset: mediaServicesResetPending)
        stopInternal(resetDisplayCriteria: false, keepNativeHost: keepNativeHost,
                     keepCurrentItem: keepNativeHost && pendingInPlaceItemHandover)
        pendingInPlaceItemHandover = false
        state = .idle
        startupProgress = nil
        clock.currentTime = 0
        clock.bufferedPosition = 0
        clock.progress = 0
        loadedURL = nil
        isCustomSource = false
    }

    private func loadSession(
        source: MediaSource,
        startPosition: Double?,
        options: LoadOptions,
        audioSourceStreamIndex: Int32?,
        discTitleID: Int?,
        attempt: LoadAttempt
    ) async throws -> SourceProbe? {
        var source = source
        var startPosition = startPosition
        var options = options
        options = Self.applyingSharedOutputRole(options)
        SharedOutputCoordinator.shared.join(ObjectIdentifier(self), role: options.sharedOutputRole, tag: logTag, owner: self)
        // AE#950: the panel's cadence before the criteria write, so the play gate can tell a rate the panel
        // already ran from one it had to switch to. Runs across the probe, `apply()` reads and stops it.
        let preWriteCadenceToken = options.engineWritesDisplayCriteria
            ? displayCriteria.beginPreWriteCadence() : nil
        defer { if let preWriteCadenceToken { displayCriteria.endPreWriteCadence(token: preWriteCadenceToken) } }
        // #436: a speed the host set belongs to the item it was set on. The rebuilds a session makes
        // on its own (reload at position, audio-track switch, AirPlay LAN swap, background return)
        // reopen the same source and keep it; a different item starts at 1.0, so a host whose speed
        // control resets per item cannot end up showing 1.0 over a session still running at 1.5.
        if !Self.rateSurvivesLoad(of: source, loadedURL: loadedURL) { desiredRate = nil }
        // #199: a live master whose #168 carriage verdict already fired routes straight onto the
        // live-ingest loopback. Remounting the native bypass would burn readyToPlay plus the watchdog
        // grace on a deterministic no-video-track outcome; after an ingest death that discovery tax
        // used to run once per host retune (the reporter's ~13s reroute cycle).
        if case .url(let candidate) = source,
           options.nativeRemoteHLS,
           RemoteHLSIngestFallback.shouldRouteDirectlyToIngest(
               isLive: options.isLive,
               fallbackEnabled: options.nativeRemoteHLSIngestFallback,
               verdictRemembered: rerouteVerdictMemory.remembers(candidate, now: Date())) {
            EngineLog.emit(
                "[AetherEngine] #199: master is a remembered no-video-track carriage case; "
                + "routing directly onto the live-ingest loopback path",
                category: .engine
            )
            options.nativeRemoteHLS = false
            source = .custom(
                HLSLiveIngestReader(playlistURL: candidate, httpHeaders: options.httpHeaders,
                                    diagnosticContext: options.sourceDiagnosticsContext),
                formatHint: "mpegts"
            )
        }
        // Preserve the NativeAVPlayerHost across native->native reloads so AVKit's system Now-Playing
        // registration survives the seam (issue #15). Captured before stopInternal resets playbackBackend;
        // the SW dispatch branch releases it if this source routes software.
        let priorBackendWasNative = (playbackBackend == .native)
        let mediaServicesWereReset = consumeMediaServicesReset()
        let preserveNativeHost = Self.shouldPreserveNativeHostAcrossLoad(
            backend: playbackBackend, nativeHostSurvives: nativeHost != nil,
            mediaServicesWereReset: mediaServicesWereReset)
        // AE#158: while a PiP window is live, or when the host asked for it, the running item must
        // survive this load's teardown; the loopback host.load callsite finishes the handover
        // (inPlaceSwap). The host request is consumed here so it can affect only this load. The
        // RUNNING session is the right question here, unlike the host above: a background teardown
        // has already unloaded the item, so there is nothing left to hand over in place.
        let handOverInPlace = consumeInPlaceItemHandoverRequest(priorBackendWasNative: priorBackendWasNative)
        cancelPendingAudioSelection()
        releaseHeldPicture(reason: "new load")
        pendingInPlaceItemHandover = handOverInPlace
        // #128 follow-up: preserve the previous session's display criteria across the load seam. Nil-ing it
        // here bounces the panel through SDR before apply() re-negotiates the same mode on video->video
        // reloads. Sessions that never reach apply() clear a stale criteria via loadDisplayCriteriaAction
        // (audio-only fast path, suppressed hosts); a load() that throws before routing leaves it for stop().
        claimSoftwarePathTakeover()   // AE#629
        stopInternal(resetDisplayCriteria: false, keepNativeHost: preserveNativeHost, keepCurrentItem: handOverInPlace)
        sessionCacheStatusToken &+= 1
        diagnostics.sessionCacheStatus = .inactive
        if mediaServicesWereReset { dropAudioPlayerHostAfterMediaServicesReset() }
        // #35/#93: a genuinely new item has not rendered yet; re-arm the cold-startup wedge suspension.
        // Scrub/seek/producer-restart never route through load(), so mid-stream #93 detection stays armed.
        hasRenderedFirstFrameMirror.set(false)
        // The public #315 counterpart is un-latched by the stopInternal() above, which every load()
        // runs. The seams that reuse the running host call host.load() directly, reach neither, and
        // keep the latch through their few tens of ms without a picture.
        // Drop disc recognition memoized for the previous media. Track-switch reopens (audio / subtitle
        // side demuxer) deliberately keep it so a remote ISO is parsed once per session (#76); only a
        // genuinely new load clears it, which also keeps custom sources (shared placeholder URL) from
        // bleeding one disc's structure into the next.
        DiscReader.clearCache()
        // Capture generation; every suspension point re-checks for supersession.
        let gen = loadGeneration
        attempt.generation = gen
        waitingLoadGenerations.insert(gen)
        // Audit LIF-101: an owed background decision is settled from here, not from a waypoint.
        beginLoadInFlight(gen)
        defer { endLoadInFlight(gen) }
        // #361: open the host-visible startup sequence. A reroute re-entering load() continues the
        // one already running rather than starting a second.
        let startupGen = beginStartupProgress()
        // For custom sources this is a synthetic placeholder; all I/O runs against the preopened probe demuxer.
        let url: URL
        switch source {
        case .url(let u):
            url = u
            isCustomSource = false
            customReader = nil
            customFormatHint = nil
        case .custom(let reader, let hint):
            url = URL(string: "aether-custom://source")!
            isCustomSource = true
            customReader = reader
            customFormatHint = hint
        }
        loadedURL = url
        loadedOptions = options
        // AE#792: a fresh store per load, so a header rotated on the previous session can never reach
        // this one through a reader that outlived it.
        sessionRequestHeaders = RequestHeaderStore(options.httpHeaders)
        relayCredentialRefusals(of: sessionRequestHeaders)
        audioSessionRequestsOwnedByAVFoundation = false
        // #377: register the host's concurrency ceiling for this origin before anything fetches
        // from it. Keyed on the origin rather than the load, so the subtitle side reader and any
        // later reopen of the same source are bound by it too.
        if !isCustomSource {
            OriginRequestBudget.shared.setHostLimit(options.maxConcurrentSourceRequests, for: url)
        } else if let ingest = customReader as? HLSLiveIngestReader {
            // AE#678: the ingest fetches from the playlist's origin, not from `aether-custom://`.
            OriginRequestBudget.shared.setHostLimit(
                options.maxConcurrentSourceRequests, for: ingest.budgetOriginURL)
            if options.isLive {
                ingest.setJoinCushion(LiveEdgePolicy.edgeCushion(options.liveEdgeCushionSeconds))
            }
        }
        // #170: the carryover is consumed by THIS load only (registration site below, or never on
        // the branches that return before it); it must not persist into loadedOptions where a later
        // host-initiated reload would resurrect a stale session snapshot.
        loadedOptions.subtitleSessionCarryover = nil
        isLive = options.isLive
        isSequentialOrigin = !options.isLive && options.sequentialOrigin
        // nativeRemoteHLS: DVR window is unbounded (AVPlayer clamps seeks to its real seekable range);
        // an over-wide published bound only affects range width, not seek landing.
        liveWindow = options.isLive
            ? LiveWindow(windowSeconds: options.nativeRemoteHLS ? .greatestFiniteMagnitude : options.dvrWindowSeconds)
            : nil
        state = .loading
        // AE#464 round 2: park the position THIS load is rebuilding toward before the clock that held
        // it is cleared below, so a reload raised while this one is still in flight has something
        // truer than the zero to snapshot. See `rebuildPosition`.
        positionUnderReconstruction = startPosition ?? 0
        // Round 3: and the transport it is rebuilding toward, for the same window and the same
        // reason. The host this load replaces is the one a stacked rebuild would ask.
        transportIntentUnderReconstruction = options.autoplay
        isBuffering = false
        residentPlaylistRanges = []
        residentRanges = []
        readerStall = .flowing
        clock.currentTime = 0
        clock.bufferedPosition = 0
        nativeClockSeconds = 0
        duration = 0
        clock.progress = 0
        audioTracks = []
        subtitleTracks = []
        teardownLiveSubtitleRenditions()   // AE#359
        externalSubtitleRegistry = [:]
        nextExternalSubtitleOrdinal = 0
        hostExplicitSubtitleAction = false
        setSecondarySubtitleIdentity()
        // #357: any load that is not the reload claiming it (which consumed it before calling here)
        // is a different session; a parked selection must not follow it.
        backgroundTeardownSelection = nil
        // #170: a stale latched rendering request from a superseded session-preserving reload
        // must not leak into this session; requests for the in-flight reload can only land at
        // suspension points after this prologue, so they survive.
        pendingNativeRenderingRequest = nil
        externalNativeStoreFillTask?.cancel()
        externalNativeStoreFillTask = nil
        resetSubtitleOCRState()   // Phase D: new session, new axis
        remoteHLSSubtitleDiscoveryTask?.cancel()
        remoteHLSSubtitleDiscoveryTask = nil
        audibleReadbackTask?.cancel()
        audibleReadbackTask = nil
        cancelNativeLegibleDeselectPin()   // Sodalite#65: the pin belongs to the item being replaced
        remoteHLSSubtitleProxy?.tearDown()   // #316
        remoteHLSSubtitleProxy = nil
        injectedSubtitleRenditionNames = [:]
        detachRemoteHLSCueClock()   // AE#616
        stallRecoveryWindowUntil = .distantPast
        stallRecoveryReasserts = 0
        stallReengageTask?.cancel()
        stallReengageTask = nil
        itemDeathConfirmTask?.cancel()
        itemDeathConfirmTask = nil
        itemDeathReviveGate = ItemDeathReviveGate(maxAttempts: 3)
        stallReloadReviveGate = ItemDeathReviveGate(maxAttempts: 2)
        softwarePathEscalationBudget = SoftwarePathEscalation.Budget()
        undecodableLiveAudioStreamIndices = Self.undecodableAudioStreamIndicesAcrossLoad(
            undecodableLiveAudioStreamIndices, sessionPreservingReload: sessionPreservingReloadInFlight)
        masterFallbackUsed = false
        nativeSubtitleReanchorTask?.cancel()
        nativeSubtitleReanchorTask = nil
        setPendingRecoverySeekTarget(nil)
        nativeSubtitleTrackTable = []
        nativeSubtitleReapplyOrdinal = nil
        nativeSubtitleTracks = []
        nativeSubtitleReaderParams = nil
        metadata = nil
        fontAttachments = []
        discTitles = []
        selectedDiscTitle = nil
        discChapters = []
        containerChapterSource = nil
        softwareClockSessionZero = nil
        mediaChapters = []
        subtitleCueDiagnosticBudget = .init()
        // Reset format/dimension state so paths that skip the probe (nativeRemoteHLS) or find no video
        // don't keep publishing the predecessor's values (e.g. Live TV after an HDR10 film kept reporting .hdr10).
        videoFormat = .sdr
        sourceDVBLCompatID = nil
        sourceDolbyVisionBaseLayerPresentable = false
        sourceVideoFormat = .sdr
        sourceDVProfile = nil
        dolbyVisionConversion = nil
        sourceCarriesHDR10PlusMetadata = false
        sourceElType = nil
        outputRouteFrameRate = nil
        sourceUpscalePlan = nil
        sourceUpscaleDisabled = nil
        sourceSoftwareOnlyForUpscale = false
        sourceUpscaleFrameRate = nil
        sourceDolbyVisionRPUProfile = nil
        sessionPanelHDRReadout = nil
        sessionObservedDisplayCaps = nil
        sourceVideoFrameRate = nil
        sourceVideoScan = .unknown
        sourceVideoBitrate = 0
        sourceVideoStreamFormat = nil
        decodedVideoFormat = nil
        sourceVideoCodecName = nil
        sourceContainerFormat = nil
        sourceVideoWidth = 0
        sourceVideoHeight = 0
        sourceVideoPixelAspectRatio = 1

        // #114: guarantee the AVAudioSession category is declared off-main before any branch
        // below can activate the session: AVKit on the native/remote-HLS paths, activateRendererAudioSession()
        // on the SW and audio paths. Only the first load in the process does any work here.
        await awaitAudioSessionCategoryConfigured()
        // Audit CORE-6: the first suspension point. Two loads issued back to back right after init
        // both wait on the same category task, and the older one must not resume as the current one.
        try checkLoadCurrent(gen)

        // nativeRemoteHLS: skip probe + loopback; play HLS URL directly with AVPlayer (Jellyfin already serves HLS).
        // Routed before the probe because we never demux the m3u8.
        if options.nativeRemoteHLS {
            // AE#990: a finite MPEG-TS playlist the session is to decode in software moves onto the
            // seekable ingest, which is also where the AE#561 escalation of a refused mount lands.
            if options.preferredDecodePath == .software, case .url(let playlistURL) = source,
               case .taken(let probe) = try await rerouteOntoMPEGTSIngest(
                   playlistURL: playlistURL,
                   options: options,
                   startPosition: startPosition,
                   audioSourceStreamIndex: audioSourceStreamIndex,
                   discTitleID: discTitleID,
                   generation: gen,
                   evidence: "finite MPEG-TS HLS") {
                return probe
            }
            // AE#461: the bypass demuxes nothing and builds no decoder of its own (AVPlayer plays the
            // remote playlist), so a decode-path preference has nothing to act on here. Say so rather
            // than let it look like it was applied.
            if options.preferredDecodePath == .software {
                EngineLog.emit(
                    "[AetherEngine] #461: preferredDecodePath=.software ignored on the nativeRemoteHLS "
                    + "bypass; AVPlayer plays the remote playlist and the engine decodes nothing. Only "
                    + "a finite, unencrypted MPEG-TS playlist reaches a decode path the engine owns.",
                    category: .engine
                )
            }
            // #316: this bypass returns before the probe path's registration, so a host that declared
            // sidecars at load time used to get nothing at all, silently. Seat them here instead.
            registerDeclaredExternalSubtitles(options)
            // #361: the bypass demuxes nothing and runs no panel handshake of its own, so those
            // checkpoints are credited here rather than left for a probe that never runs.
            recordStartupCheckpoint(.routed, generation: startupGen)
            do {
                // AE#246: a VOD playlist honors the resume anchor here the same way the AE#154 reroute
                // does; without it a rerouted (or directly requested) VOD bypass always restarted at 0.
                // Live keeps the no-initial-seek contract every live caller relies on, so its anchor
                // stays nil even when the host passes one.
                try await loadRemoteHLS(url: url, options: options,
                                        startPosition: options.isLive ? nil : startPosition,
                                        generation: gen)
            } catch is CancellationError {
                throw CancellationError()
            } catch {
                // A failure that lands after a successor took over is not this session's to publish.
                if loadGeneration != gen { throw CancellationError() }
                // Without this catch, a throwing loadRemoteHLS would strand state at .loading forever.
                publishError(.sourceOpenFailed, "Failed to load: \(error.localizedDescription)", underlying: error)
                throw error
            }
            // No probe ran on this bypass; there is nothing to report.
            return nil
        }

        // 1. Probe: detect format, frame rate, and track metadata.
        //    HLSVideoEngine re-opens internally; the double-open keeps the failure-mode matrix small.
        var detectedFormat: VideoFormat = .sdr
        var effectiveFormat: VideoFormat = .sdr
        var detectedDVProfileNum: Int? = nil
        var detectedDVBLCompatIDNum: Int? = nil
        var detectedRate: Double? = nil
        var detectedVideoBitrate: Int64 = 0
        var detectedVideoStreamFormat: VideoStreamFormat? = nil
        var detectedDVProfile: Bool = false
        // `dolbyVisionHandling = .baseLayerOnly` resolved against this source: the two halves the
        // format clamp, the criteria request and the software-path guard below all read.
        var detectedDVBaseLayerPresentable = false
        var presentsDolbyVisionBaseLayer = false
        // AE#532: what this source's own RPU says, and the profile the route should believe instead of
        // the record. Both stay nil for every source but a Profile 5 record over a BT.2020 YCbCr HDR VUI.
        var detectedDVRPUProfile: Int? = nil
        var correctedDVProfile: Int? = nil
        var detectedCodecID: AVCodecID = AV_CODEC_ID_NONE
        var detectedFieldOrder: AVFieldOrder = AV_FIELD_UNKNOWN
        var probedAudioTracks: [TrackInfo] = []
        var probedSubtitleTracks: [TrackInfo] = []
        var probedDefaultAudioIndex: Int32 = -1
        // Audit LIF-107: published only after the post-probe generation check below. The AE#532 audit
        // is a second read `stopInternal` cannot abort, so a superseded load can return from it after
        // its successor's prologue and would write this source's geometry over the reset.
        var probedGeometry: (width: Int32, height: Int32, pixelAspect: Double?)?
        // AE#493: what this session takes the display to be. The observed table is what the platform
        // could answer; the session table adds what the host asserted, because Dolby Vision has no
        // public capability API on macOS and eligibility deliberately does not claim it. Composed once,
        // so the format clamp below and the served DV route cannot disagree about the same display.
        let observedDisplayCaps = Self.displayCapabilities
        let sessionDisplayCaps = observedDisplayCaps.assertingDolbyVision(options.panelPresentsDolbyVision)
        // What the clamp below and the served route are about to read, stated once per load. Every question
        // this table decides (why a source resolved to SDR, why a panel was asked for one format and not
        // another, why a route went media-direct) was previously answered by inference from the outcome,
        // and a per-mode false is an assertion the platform made, not an absence of information (AE#493).
        EngineLog.emit(
            "[DisplayCapabilities] observed: hdr=\(observedDisplayCaps.supportsHDR) "
            + "hdr10=\(observedDisplayCaps.supportsHDR10) hlg=\(observedDisplayCaps.supportsHLG) "
            + "dv=\(observedDisplayCaps.supportsDolbyVision)"
            + (options.panelPresentsDolbyVision ? " (session dv asserted true)" : ""),
            category: .session
        )
        if options.isLive, !options.nativeRemoteHLS, case .url(let livePlaylistURL) = source,
           RemoteHLSMediaSelection.isKnownLivePlaylist(livePlaylistURL) {
            EngineLog.emit(
                "[AetherEngine] AE#678: known HLS playlist URL on the live path; straight onto the "
                + "live-ingest reader, no raw probe",
                category: .engine
            )
            continueStartupAcrossReroute()
            return try await load(
                source: .custom(
                    HLSLiveIngestReader(playlistURL: livePlaylistURL,
                                        httpHeaders: loadedOptions.httpHeaders,
                                        diagnosticContext: loadedOptions.sourceDiagnosticsContext),
                    formatHint: "mpegts"
                ),
                startPosition: startPosition,
                options: loadedOptions,
                audioSourceStreamIndex: audioSourceStreamIndex,
                discTitleID: discTitleID
            )
        }
        let probe = Demuxer()
        // Register so stopInternal can markClosed(): avformat_open_input/find_stream_info can block for the
        // full AVIOReader reconnect budget (device repro: a 500-looping channel kept reconnecting across three
        // subsequent sessions until the budget ran out).
        inFlightProbeDemuxer = probe
        // Identity-guarded: a superseding load() has already registered its own probe; unconditioned nil here
        // would strip the successor's abort handle.
        defer { if inFlightProbeDemuxer === probe { inFlightProbeDemuxer = nil } }
        // #361: the open runs detached and is the longest unobservable stretch of a slow load. Its
        // stages hop back onto the actor carrying the generation they started under, so an open that
        // is still unwinding when a newer load has taken over cannot move that load's bar.
        probe.onOpenProgress = { [weak self] stage in
            Task { @MainActor in
                self?.recordStartupCheckpoint(StartupCheckpoint(openStage: stage), generation: startupGen)
            }
        }
        var probeOpened = false
        var probeFailure: Error?
        do {
            // Detach avformat_open_input + find_stream_info off @MainActor (~6 s on a slow CDN).
            // AetherEngine#10: a @MainActor async body without a suspension point blocks the main thread
            // despite the async signature; a detached task's value introduces a real background hop,
            // and BlockingWork keeps that hop off the cooperative pool while the open blocks.
            try await BlockingWork.detached(priority: .userInitiated) { [probe, source, options, requestHeaders = sessionRequestHeaders] in
                // Caller-bounded find_stream_info budget (#68); nil keeps the .playback default. This probe
                // demuxer is reused as the session demuxer, so the cap lands on the open that actually pays it.
                let probeProfile = DemuxerOpenProfile.playback.withProbeBudget(
                    probesize: options.probesize, maxAnalyzeDuration: options.maxAnalyzeDuration)
                    .withSequentialOrigin(options.sequentialOrigin,
                                          declaredDuration: options.declaredDurationSeconds)
                    .withHeldSourceConnection(options.heldSourceConnection)
                    .skippingAttachments(options.skipsContainerAttachments)
                    .withSourceOpenPolicy(options.sourceOpenPolicy)
                    .withDiagnosticContext(options.sourceDiagnosticsContext)
                    .withRequestHeaders(requestHeaders)
                switch source {
                case .url(let u):
                    // isLive configures the AVIOReader for endless-feed mode; must be set at open time because
                    // the probe demuxer is reused as the session demuxer (avformat_open_input runs only once).
                    try probe.open(url: u, extraHeaders: options.httpHeaders, profile: probeProfile, isLive: options.isLive, selectTitleID: discTitleID)
                case .custom(let reader, let formatHint):
                    // isLive suppresses SEEK_END duration estimate on forward-only live readers; same open-time requirement.
                    try probe.open(reader: reader, formatHint: formatHint, profile: probeProfile, isLive: options.isLive, selectTitleID: discTitleID)
                }
            }.value
            probeOpened = true
            let videoIdx = probe.videoStreamIndex
            if videoIdx >= 0, let stream = probe.stream(at: videoIdx) {
                detectedFormat = Self.detectVideoFormat(stream: stream)
                let detectedDVConfig = Self.dvConfig(stream: stream)
                detectedDVProfileNum = detectedDVConfig?.profile
                detectedDVBLCompatIDNum = detectedDVConfig?.blCompatID
                detectedCodecID = stream.pointee.codecpar.pointee.codec_id
                // `.baseLayerOnly`: the clamp reads a table with Dolby Vision left unclaimed, so the
                // source resolves to the HDR10 / HLG its base layer is, the criteria ask for hvc1, and
                // the served route (same predicate, `CodecRoutePolicy`) agrees. A source with no base
                // layer to present (a genuine Profile 5) keeps everything as it was.
                detectedDVBaseLayerPresentable = VideoRoutingPolicy.dolbyVisionBaseLayerIsPresentable(
                    codecID: detectedCodecID,
                    dvProfile: detectedDVProfileNum,
                    dvBlCompatID: detectedDVBLCompatIDNum,
                    colorTransfer: stream.pointee.codecpar.pointee.color_trc,
                    colorMatrix: stream.pointee.codecpar.pointee.color_space)
                presentsDolbyVisionBaseLayer = options.dolbyVisionHandling == .baseLayerOnly
                    && detectedDVBaseLayerPresentable
                // AE#532: a Profile 5 record over a VUI that contradicts it is the one claim in a
                // container worth checking against the bitstream, because a Profile 5 RPU cannot carry a
                // residual or an NLQ and the RPU is therefore proof rather than a guess. Gated on that
                // pairing, so no other source reads a packet here. `.url` only: a custom reader has no
                // second open to give, and live is not a class this was reported on.
                if case .url(let auditURL) = source, !options.isLive,
                   DolbyVisionRecordAudit.recordIsContradicted(
                       codecID: detectedCodecID, dvProfile: detectedDVProfileNum,
                       colorTransfer: stream.pointee.codecpar.pointee.color_trc,
                       colorMatrix: stream.pointee.codecpar.pointee.color_space) {
                    let auditHeaders = options.httpHeaders
                    detectedDVRPUProfile = await BlockingWork.detached(priority: .userInitiated) {
                        DolbyVisionRecordAudit.rpuProfileOfSource(url: auditURL, extraHeaders: auditHeaders)
                    }.value
                    correctedDVProfile = DolbyVisionRecordAudit.correctedProfile(
                        record: detectedDVProfileNum, rpu: detectedDVRPUProfile)
                    EngineLog.emit(
                        correctedDVProfile.map {
                            "[AetherEngine] AE#532: DV Profile 5 record contradicted by its own RPU "
                            + "(RPU reads profile \($0)); this session routes it as Profile \($0)"
                        } ?? ("[AetherEngine] AE#532: DV Profile 5 record over a BT.2020 YCbCr VUI, but the "
                              + "RPU "
                              + (detectedDVRPUProfile.map { "reads profile \($0)" } ?? "could not be read")
                              + "; the record stands"),
                        category: .engine)
                }
                if options.dolbyVisionHandling == .baseLayerOnly, detectedFormat == .dolbyVision {
                    EngineLog.emit(
                        presentsDolbyVisionBaseLayer
                            ? "[AetherEngine] dolbyVisionHandling=baseLayerOnly: DV Profile "
                              + "\(detectedDVProfileNum ?? 0) presents its base layer; the format clamp and the "
                              + "criteria request leave Dolby Vision unclaimed"
                            : "[AetherEngine] dolbyVisionHandling=baseLayerOnly ignored: DV Profile "
                              + "\(detectedDVProfileNum ?? 0) compat=\(detectedDVBLCompatIDNum ?? 0) has no base "
                              + "layer to present (IPT-PQ-c2, VUI unspecified); keeping the Dolby Vision route",
                        category: .engine)
                }
                effectiveFormat = Self.effectiveVideoFormat(
                    detected: detectedFormat, stream: stream,
                    capabilities: presentsDolbyVisionBaseLayer
                        ? sessionDisplayCaps.withoutDolbyVision() : sessionDisplayCaps)
                detectedRate = Self.detectFrameRate(stream: stream)
                // DrHurt #4 (2026-05-26): use source-detected DV, not effective-format, so codecTag=dvh1
                // asks AVDisplayManager for DV mode on every DV source. AVPlayer's HLS tone-mapper downgrades
                // DV->HDR10 when the panel can't host it; we don't pre-strip engine-side. Pairs with
                // always-emit-SUPPLEMENTAL + no-strip in HLSVideoEngine's profile81/profile84 emission.
                // The base-layer route is the one exception: it serves hvc1 and asks for hvc1.
                detectedDVProfile = (detectedFormat == .dolbyVision) && !presentsDolbyVisionBaseLayer
                detectedFieldOrder = stream.pointee.codecpar.pointee.field_order
                let width = stream.pointee.codecpar.pointee.width
                let height = stream.pointee.codecpar.pointee.height
                let sar = PixelAspectPolicy.declaredPixelAspect(
                    bitstream: stream.pointee.codecpar.pointee.sample_aspect_ratio,
                    container: stream.pointee.sample_aspect_ratio,
                    width: width,
                    height: height
                )
                probedGeometry = (width, height, sar.map { Double($0.num) / Double($0.den) })
                detectedVideoBitrate = probe.declaredBitrate(stream: stream)
                detectedVideoStreamFormat = VideoStreamFormat(codecpar: stream.pointee.codecpar)
            }
            probedAudioTracks = probe.audioTrackInfos()
            probedSubtitleTracks = probe.subtitleTrackInfos()
            probedDefaultAudioIndex = probe.audioStreamIndex
            // Ownership transfers to loadNative/loadSoftware, which adopt the probe for reuse
            // or open fresh if the probe failed.
        } catch {
            probeFailure = error
            EngineLog.emit("[AetherEngine] probe failed (\(error)); proceeding without criteria", category: .engine)
        }

        // Superseded during probe: close the local probe (detached, can block) and unwind.
        if loadGeneration != gen {
            probe.markClosed()
            if probeOpened {
                BlockingWork.detached { [probe] in probe.close() }
            }
            try checkLoadCurrent(gen)
        }
        if let probedGeometry {
            sourceVideoWidth = probedGeometry.width
            sourceVideoHeight = probedGeometry.height
            if let pixelAspect = probedGeometry.pixelAspect { sourceVideoPixelAspectRatio = pixelAspect }
            lastDetectedVideoCodec = detectedCodecID
        }

        // Custom sources have no URL to reopen from: a failed probe is fatal.
        if case .custom(let reader, _) = source, !probeOpened {
            // The engine's own live HLS ingest knows why it handed the probe nothing: its playlist
            // was refused or could not be reached. That is the source's answer, typed as an HTTP
            // reader's is (`publishLoadFailure`), not a stream the probe could not read: a host that
            // takes a custom probe failure to mean the format moves the channel to another route for
            // good, over a 509 an IPTV panel gives while another device holds the account's last slot.
            if let ingest = reader as? HLSLiveIngestReader, let failure = ingest.terminalFailure {
                publishLoadFailure(failure, isLiveStart: true)
                throw failure
            }
            publishError(.customSourceProbeFailed, "Failed to load: custom source probe failed", underlying: probeFailure)
            throw probeFailure ?? DemuxerError.openFailed(code: -1)
        }

        // The reader already spent the configured initial and recovery budgets. Reopening
        // the same source in HLSVideoEngine would silently repeat that entire wait.
        if !options.isLive, let failure = probeFailure as? AVIOReaderError,
           failure == .requestTimeout || failure == .noResponse {
            let transport = URLError(failure == .requestTimeout ? .timedOut : .cannotConnectToHost)
            publishError(.sourceOpenFailed, "Source did not respond within the opening budget", underlying: transport)
            throw failure
        }

        // AE#363: an HLS playlist URL on the raw-byte live path, which AE#140 detects at the byte source
        // (#EXTM3U where a container's first byte belongs) instead of looping its endless-feed reconnect.
        // That detection stays; its destination changes. AE#140 handed the host a typed rejection naming
        // HLSLiveIngestReader, and the engine can build that reader itself: it is the only live path that
        // puts LoadOptions.httpHeaders on the playlist, on every segment and on every AES key, which is
        // exactly what a tokenized IPTV origin enforces. Telling a host to go and wire the one path that
        // would have worked is not an answer the engine has to give. The VOD side of the same misroute
        // has rerouted itself since AE#154.
        if RemoteHLSMediaSelection.shouldRouteLiveOntoIngest(
            failure: probeFailure, isCustomSource: isCustomSource),
           case .url(let livePlaylistURL) = source {
            EngineLog.emit(
                "[AetherEngine] AE#363: HLS playlist on the raw live path; routing through the "
                + "live-ingest reader (headers ride every fetch)",
                category: .engine
            )
            RemoteHLSMediaSelection.noteLivePlaylist(livePlaylistURL)
            // #361: the host is still waiting for the load it asked for, so this is the same startup
            // taking a different route, not a second one.
            continueStartupAcrossReroute()
            return try await load(
                source: .custom(
                    HLSLiveIngestReader(playlistURL: livePlaylistURL,
                                        httpHeaders: loadedOptions.httpHeaders,
                                        diagnosticContext: loadedOptions.sourceDiagnosticsContext),
                    formatHint: "mpegts"
                ),
                startPosition: startPosition,
                options: loadedOptions,
                audioSourceStreamIndex: audioSourceStreamIndex,
                discTitleID: discTitleID
            )
        }

        // A custom source carries the same misroute with no playlist URL to ingest from, so it keeps the
        // AE#140 typed rejection: the host built that reader and only the host can re-point it.
        if let readerError = probeFailure as? AVIOReaderError, case .hlsPlaylistOnRawLivePath = readerError {
            publishError(.hlsPlaylistOnRawLivePath, "HLS playlist supplied to the raw live path. Use LoadOptions.nativeRemoteHLS or HLSLiveIngestReader for m3u8 sources.")
            throw AetherEngineError.hlsPlaylistOnRawLivePath
        }

        // AE#154: a non-live HLS playlist on the loopback path. FFmpeg (--disable-network) can never
        // demux it (see AVIOReaderError.hlsPlaylistOnVODPath); remote HLS is AVPlayer's native
        // domain, so reroute this load onto the nativeRemoteHLS bypass instead of surfacing the
        // former bare AVERROR_INVALIDDATA. loadedOptions flips so every downstream consumer
        // (audio-tap reader selection, seek paths) sees a genuine remote-HLS session.
        if RemoteHLSMediaSelection.shouldReroute(failure: probeFailure, isCustomSource: isCustomSource),
           case .url(let hlsURL) = source {
            if case .taken(let probe) = try await rerouteOntoMPEGTSIngest(
                playlistURL: hlsURL,
                options: loadedOptions,
                startPosition: startPosition,
                audioSourceStreamIndex: audioSourceStreamIndex,
                discTitleID: discTitleID,
                generation: gen,
                evidence: "finite HEVC-in-MPEG-TS HLS"
            ) {
                return probe
            }
            EngineLog.emit("[AetherEngine] AE#154: HLS playlist on the VOD loopback path; rerouting to the native remote-HLS bypass", category: .engine)
            loadedOptions.nativeRemoteHLS = true
            // #316: the reroute returns before the registration below, same as the direct bypass.
            registerDeclaredExternalSubtitles(loadedOptions)
            recordStartupCheckpoint(.routed, generation: startupGen)   // #361
            do {
                try await loadRemoteHLS(url: hlsURL, options: loadedOptions, startPosition: startPosition,
                                        generation: gen)
            } catch is CancellationError {
                throw CancellationError()
            } catch {
                if loadGeneration != gen { throw CancellationError() }
                publishError(.sourceOpenFailed, "Failed to load: \(error.localizedDescription)", underlying: error)
                throw error
            }
            return nil
        }

        // Live fail-fast: a failed probe means the AVIOReader burned its full reconnect budget.
        // Proceeding would dispatch on codec NONE and grind another ~30 s before erroring.
        if options.isLive, !probeOpened {
            // #796: a live open the origin answered with a status fails with that answer, as the VOD
            // path's does (`publishLoadFailure` types it as sourceRefused / sourceRateLimited and the
            // reader's httpStatus is thrown). A live open that reaches nothing keeps
            // liveSourceUnavailable: the reader rode its transport failures out on the reconnect
            // ladder, and the URL error its last connection ended with is the cause it gives up with.
            let failure = probeFailure ?? DemuxerError.openFailed(code: -5)
            publishLoadFailure(failure, isLiveStart: true, transportFailureCode: probe.openTransportFailureCode)
            throw failure
        }

        // Forward-only custom sources cannot rewind; audio-switch and background-reload stay no-op for them.
        customSourceIsSeekable = isCustomSource ? probe.isSourceSeekable : false
        isSourceSeekable = probeOpened ? probe.isSourceSeekable : nil
        if !options.isLive, isSourceSeekable == false {
            // The byte source and AVPlayer must mount at the same place. A container duration
            // does not make a saved position reachable on a forward-only source.
            startPosition = nil
            positionUnderReconstruction = nil
            clock.currentTime = 0
        }

        // sourceVideoFormat = what's in the file; videoFormat = what the panel shows (published after
        // the criteria handshake; see panelHDRAfterHandshake below).
        // The capability pair is assigned before its publishing peers so their sinks read it current.
        sourceDVBLCompatID = detectedDVBLCompatIDNum
        sourceDolbyVisionBaseLayerPresentable = detectedDVBaseLayerPresentable
        sourceVideoFormat = detectedFormat
        sourceDVProfile = detectedDVProfileNum
        sourceDolbyVisionRPUProfile = detectedDVRPUProfile
        sourceVideoFrameRate = detectedRate
        sourceVideoBitrate = detectedVideoBitrate
        sourceVideoStreamFormat = detectedVideoStreamFormat
        sourceVideoCodecName = detectedCodecID == AV_CODEC_ID_NONE
            ? nil
            : avcodec_get_name(detectedCodecID).map { String(cString: $0) }
        sourceContainerFormat = probeOpened ? probe.containerFormatName : nil
        audioTracks = probedAudioTracks
        applyConfirmedTrackFlags()
        subtitleTracks = probedSubtitleTracks
        // #88: load-declared external tracks join the list now, BEFORE preferred-language selection
        // and the native rendition table are built from it.
        // #170: a session-preserving reload seeds the previous session's registry verbatim
        // instead: mid-session adds survive with their ids (and, registered pre-table, become
        // rendition-eligible on the reloaded item); mid-session removals stay removed; the host's
        // subtitle authority carries over so the load-end auto-selection cannot override it.
        registerDeclaredExternalSubtitles(options)
        metadata = probeOpened ? probe.mediaMetadata() : nil
        fontAttachments = probeOpened ? probe.fontAttachmentInfos() : []
        // Disc titles/chapters off the probe demuxer (post-detach, on MainActor) so the host can populate
        // a title picker. selectedDiscTitleID reflects what DiscReader.wrap actually selected (discTitleID
        // clamped to an in-range id); non-disc sources report empty/nil (#67).
        discTitles = probeOpened ? probe.discTitleInfos() : []
        discChapters = probeOpened ? probe.discChapterInfos() : []
        containerChapterSource = (probeOpened && discTitles.isEmpty) ? probe.containerChapterSource() : nil
        republishMediaChapters()
        activeDiscTitleID = probeOpened ? probe.selectedDiscTitleID : nil
        selectedDiscTitle = activeDiscTitleID.flatMap { id in discTitles.first { $0.id == id } }
        // Source start PTS for the software-path chapter-seek base (see sourceStartSeconds): the same
        // resolved origin the software host predicts its session zero from, so engine and host agree even
        // when the container states no start and only the video stream carries one.
        sourceStartSeconds = probeOpened ? probe.resolvedSourceStartOrigin : 0
        // Assemble SourceProbe now while the demuxer is open; ownership transfers to loadNative/loadSoftware
        // after which streams are gone (AetherEngine#28).
        let sourceProbe: SourceProbe? = probeOpened
            ? Self.makeSourceProbe(demuxer: probe, displayURL: url)
            : nil
        attempt.probe = sourceProbe
        // Resolve the initial audio track: an explicit host override wins, else the ordered language
        // preference (#72) resolved from this single probe. selectedAudio is nil when neither applies,
        // so the session keeps its own default pick (empty preferences + no override is a behavioural
        // no-op). Passing selectedAudio into session start lets the host honor a saved language on the
        // first frame without a separate pre-probe or a selectAudioTrack reload.
        // On probe failure (probedAudioTracks empty) the override can't be validated, so honor it
        // verbatim and let the reopened session re-validate it: an explicit audioSourceStreamIndex
        // still wins (the contract), matching pre-#72 behavior where the raw override was passed through.
        let selectedAudio = Self.selectAudioIndex(
            tracks: probedAudioTracks,
            override: audioSourceStreamIndex,
            preferredLanguages: options.preferredAudioLanguages,
            // Only where the spatial bridge can run: a VOD video session on an OS with the APAC encoder,
            // on the loopback route or on the software host (which renders TrueHD Atmos and DTS:X as
            // APAC too). Live, audio-only and older systems would decode TrueHD or DTS for its 7.1 bed
            // and no heights, so the default track keeps its place there.
            prefersObjectAudio: options.objectAudioRendering != .off && ObjectAudioRendering.isAvailable
                && !options.isLive && !options.audioOnly,
            defaultIndex: probedDefaultAudioIndex
        ) ?? (probeOpened ? nil : audioSourceStreamIndex)
        let resolvedInitialAudio = selectedAudio ?? probedDefaultAudioIndex
        activeAudioTrackIndex = resolvedInitialAudio >= 0 ? Int(resolvedInitialAudio) : nil
        let snappedRate = FrameRateSnap.snap(detectedRate ?? 0)
        EngineLog.emit("[AetherEngine] load url=\(url.absoluteString) source-format=\(detectedFormat) effective-format=\(effectiveFormat) rate=\(snappedRate.map { String(format: "%.3f", $0) } ?? "n/a")", category: .engine)

        // 1.5 Audio-only fast path: no display-criteria handshake, no video dispatch.
        //     Native sub-branch closes the probe and reopens via AVPlayer; FFmpeg sub-branch reuses the probe
        //     (required for custom sources).
        let hasVideoStream = probeOpened && probe.videoStreamIndex >= 0
        if Self.shouldUseAudioOnlyPath(audioOnlyRequested: options.audioOnly, probeOpened: probeOpened, hasVideoStream: hasVideoStream) {
            // #361: this path is decided before the panel handshake and never runs one, so the route
            // checkpoint credits both.
            recordStartupCheckpoint(.routed, generation: startupGen)
            // The load seam preserves display criteria (#128 follow-up); an audio-only session never calls
            // apply(), so clear a criteria the previous video session left applied. The engine is a
            // process-wide singleton; without this, music playback keeps the panel in DV/HDR.
            if Self.loadDisplayCriteriaAction(engineWritesCriteria: options.engineWritesDisplayCriteria, audioOnlyPath: true) == .clearStale {
                resetDisplayCriteriaRespectingOthers()
            }
            // Read codec before closing the probe; custom sources always use FFmpeg (AVPlayer can't consume a custom demuxer).
            let audioCodecID: AVCodecID = (probeOpened && resolvedInitialAudio >= 0)
                ? (probe.stream(at: resolvedInitialAudio)?.pointee.codecpar.pointee.codec_id ?? AV_CODEC_ID_NONE)
                : AV_CODEC_ID_NONE
            // AE#764: AVPlayer reads the source's own STREAMINFO here, so a FLAC with blocks under
            // CoreMedia's floor goes to libavcodec rather than failing to open.
            let flacBlocksTooSmall = probeOpened && resolvedInitialAudio >= 0
                && (probe.stream(at: resolvedInitialAudio).map {
                    FLACStreamInfo.coreMediaRejectsSource(UnsafePointer($0.pointee.codecpar))
                } ?? false)
            let flacSeeksMisplaced = Self.coreMediaMisplacesSeeks(
                codecID: audioCodecID, containerFormatName: probeOpened ? probe.containerFormatName : nil)
            // AE#946: AVPlayer times every fixed-blocksize FLAC frame by STREAMINFO's max_blocksize, so a
            // stream whose frames are smaller runs its clock past the real length or fails. Peeked only
            // when AVPlayer would otherwise get the stream.
            let flacFrameBlockSize: UInt16? = audioCodecID == AV_CODEC_ID_FLAC
                && Self.audioOnlyUsesAVPlayer(
                    codecID: audioCodecID, isCustomSource: isCustomSource,
                    flacBlocksTooSmall: flacBlocksTooSmall, flacFramesMistimed: false,
                    flacSeeksMisplaced: flacSeeksMisplaced, preferred: options.preferredDecodePath)
                ? Self.firstFLACFrameBlockSize(demuxer: probe, streamIndex: resolvedInitialAudio)
                : nil
            let flacDeclaredMax = probe.stream(at: resolvedInitialAudio)
                .flatMap { FLACStreamInfo.blockSizes(UnsafePointer($0.pointee.codecpar))?.max }
            let flacFramesMistimed = flacFrameBlockSize.map { size in
                probe.stream(at: resolvedInitialAudio).map {
                    FLACStreamInfo.coreMediaMistimesFrames(UnsafePointer($0.pointee.codecpar), frameBlockSize: size)
                } ?? false
            } ?? false
            let useNativeAudio = Self.audioOnlyUsesAVPlayer(
                codecID: audioCodecID, isCustomSource: isCustomSource,
                flacBlocksTooSmall: flacBlocksTooSmall, flacFramesMistimed: flacFramesMistimed,
                flacSeeksMisplaced: flacSeeksMisplaced, preferred: options.preferredDecodePath)
            // Named only when it decided the route (AVPlayer otherwise), so a host can tell its
            // preference arrived.
            let hostAskedSoftware = !useNativeAudio && Self.audioOnlyUsesAVPlayer(
                codecID: audioCodecID, isCustomSource: isCustomSource,
                flacBlocksTooSmall: flacBlocksTooSmall, flacFramesMistimed: flacFramesMistimed,
                flacSeeksMisplaced: flacSeeksMisplaced, preferred: .automatic)
            let mistimedNote = flacFramesMistimed
                ? " (FLAC frames carry \(flacFrameBlockSize ?? 0) samples, STREAMINFO declares \(flacDeclaredMax ?? 0), AE#946)"
                : ""
            EngineLog.emit("[AetherEngine] audio dispatch: codec=\(audioCodecID.rawValue) -> \(useNativeAudio ? "AVPlayer" : "FFmpeg")\(flacBlocksTooSmall ? " (FLAC min_blocksize below CoreMedia's floor)" : "")\(mistimedNote)\(flacSeeksMisplaced ? " (raw FLAC, CoreMedia misplaces its seeks, AE#946)" : "")\(hostAskedSoftware ? " (host asked for the software path, #461)" : "")", category: .engine)
            // A preserved video NativeAVPlayerHost from a native->native reload must be released before an audio
            // session; otherwise the old AVPlayer stays alive in currentAVPlayer and the volume setter writes into it.
            if nativeHost != nil {
                nativeHost?.tearDown()
                nativeHost = nil
                currentAVPlayer = nil
            }
            do {
                if useNativeAudio {
                    if probeOpened { probe.close() }
                    try await loadAudioNative(url: url, startPosition: startPosition, httpHeaders: options.httpHeaders, generation: gen)
                    try checkLoadCurrent(gen)
                    audioSessionRequestsOwnedByAVFoundation = true
                    playbackBackend = .audio
                    activeVideoDecoder = nil
                    activeAudioDecoder = "AVPlayer"
                    videoFormat = .sdr
                    // #124: a paused mount skips autostart; loadAudioNative's host.$isReady settles .paused.
                    if Self.loadPerformsAutostart(options) {
                        audioAVPlayerHost?.play()
                        state = .playing
                    }
                    startMemoryProbe()
                } else {
                    try await loadAudio(
                        url: url,
                        sourceHTTPHeaders: options.httpHeaders,
                        startPosition: startPosition,
                        audioSourceStreamIndex: resolvedInitialAudio >= 0 ? resolvedInitialAudio : nil,
                        preopenedDemuxer: probeOpened ? probe : nil,
                        generation: gen
                    )
                    try checkLoadCurrent(gen)
                    playbackBackend = .audio
                    activeVideoDecoder = nil
                    activeAudioDecoder = Self.softwareAudioDecoderLabel(
                        audioTracks: probedAudioTracks,
                        activeIndex: resolvedInitialAudio
                    )
                    videoFormat = .sdr
                    // #124: a paused mount skips autostart; loadAudio's host.$isReady settles .paused.
                    if Self.loadPerformsAutostart(options) {
                        audioHost?.play()
                        state = .playing
                    }
                    startMemoryProbe()
                }
            } catch is CancellationError {
                // Superseded: successor owns state.
                throw CancellationError()
            } catch {
                if loadGeneration != gen { throw CancellationError() }
                publishLoadFailure(error)
                throw error
            }
            startAtmosConfirmation()
            return sourceProbe
        }

        // Reaching here with a failed probe means a non-audioOnly URL source whose open-time probe lost to a
        // transient origin error (custom + live already fail-fast above). Don't degrade to audio-only (#78):
        // dispatch native on codec NONE (the default switch arm) with a nil preopenedDemuxer so HLSVideoEngine
        // reopens and discovers the real stream. Format/codec stay at their .sdr/NONE defaults; AVKit fires the
        // criteria from the AVPlayerItem formatDescription once the reopened stream lands.
        if !probeOpened {
            EngineLog.emit("[AetherEngine] probe failed; falling through to the native video path (HLSVideoEngine will reopen and discover the stream) rather than degrading to audio-only", category: .engine)
        }

        // 2. Display-criteria handshake. Use effective format so a non-DV panel isn't asked to switch to dvh1.
        // #35: remember whether an actual SDR->HDR panel switch happened this load. The cold-DV-master
        // startup-readiness gate only arms on a real switch, when the DV/HDCP decode path is still
        // warming and the served master resolves 0 tracks / fails -11819; a warm start (no switch) keeps
        // the unchanged immediate-play path.
        var didSwitchPanel = false
        // #133: when apply() reports the criteria are already active (same-format zap), the panel never
        // starts a switch, so the post-load play-gate waitForSwitch() below has nothing to settle and would
        // otherwise burn its full ~3s cap on unobservable-DV panels. Skip it in exactly that case.
        var criteriaUnchanged = false
        // AE#348: the pre-flight gate of a VOD load, running beside the load instead of in front of it.
        var preflightGate: Task<Void, Never>?
        defer { preflightGate?.cancel() }
        switch Self.loadDisplayCriteriaAction(engineWritesCriteria: options.engineWritesDisplayCriteria, audioOnlyPath: false) {
        case .applyFresh:
            let codecTag: FourCharCode? = detectedDVProfile ? 0x64766831 : nil
            switch displayCriteria.apply(
                format: effectiveFormat,
                frameRate: snappedRate,
                codecTag: codecTag,
                omitColorExtensions: options.omitCriteriaColorExtensions
            ) {
            case .willSwitch:
                didSwitchPanel = true
                // #339: consumesRecord: false, the play gate after loadNative is entitled to the same
                // start/end timestamps; spending them here made it pay Stage 1's grace for a settled switch.
                // AE#348: started here, at the write, so it releases exactly when it always did, but only
                // the routing read waits for it (`settlePanelRouting`), not the segment production.
                if Self.preflightGateRunsBesideLoad(isLive: options.isLive) {
                    preflightGate = Task { [displayCriteria] in
                        await displayCriteria.waitForSwitch(consumesRecord: false,
                                                            isCurrent: { self.loadGeneration == gen })
                    }
                    break
                }
                await displayCriteria.waitForSwitch(consumesRecord: false,
                                                    isCurrent: { self.loadGeneration == gen })
                // Superseded during panel handshake: close local probe and unwind.
                if loadGeneration != gen {
                    probe.markClosed()
                    if probeOpened {
                        BlockingWork.detached { [probe] in probe.close() }
                    }
                    try checkLoadCurrent(gen)
                }
            case .applied:
                break
            case .unchanged:
                criteriaUnchanged = true
            }
        case .clearStale:
            // Suppressed host: the load seam preserved the criteria (#128 follow-up), and AVKit writes its
            // own from the AVPlayerItem formatDescription later. Clear a leftover engine criteria now
            // (didApply-gated no-op for hosts that always suppress) so the two writers can't fight.
            resetDisplayCriteriaRespectingOthers()
            // #339: AVKit's write lands inside loadNative, so the observation has to be armed before the
            // load rather than when the play gate opens. After reset(), so a switch back to the default
            // mode is not recorded as this session's. Audio-only loads reach clearStale too and have no
            // panel handshake to observe.
            if !options.engineWritesDisplayCriteria { displayCriteria.armSwitchObservation() }
        }

        // 2.5. Post-handshake panel-mode snapshot.
        //      tvOS exposes only one combined isDisplayCriteriaMatchingEnabled toggle; no API distinguishes
        //      Match Dynamic Range from Match Frame Rate. A user with rate-only matching reports the flag true,
        //      host passes matchContentEnabled=true, but the panel stays SDR. The old supportsHDR gate routed
        //      via the master playlist with VIDEO-RANGE=PQ and AVPlayer rejected -11848/-11868.
        //
        //      Reading currentEDRHeadroom after waitForSwitch is the only authoritative check: headroom > 1.0
        //      means the panel accepted HDR (range matching on); == 1.0 means refused. Pass to both videoFormat
        //      and HLSVideoEngine master-vs-media routing so they stay in step.
        //
        //      Suppressed-criteria hosts fall back to the caller's pre-load panelIsInHDRMode snapshot
        //      (AVKit fires criteria later from the AVPlayerItem formatDescription).
        //      AE#459: the host's assertion is an OR term over that readout on every platform, not just
        //      where criteria are suppressed. The readout answers only around a dynamic-range transition,
        //      so a panel parked in HDR never proves itself and one tvOS 27 box stopped answering at all;
        //      a host that knows better says so, and a wrong claim costs the -11848 fallback, not the item.
        var criteriaPanelReadout: Bool?
        var panelHDRAfterHandshake = false
        var routingPanelHDR = false
        var panelRoutingSettled = false
        // AE#348: everything from here to `.displayPrepared` reads the settled panel. With the pre-flight
        // gate running beside the load it runs where the route is chosen, after the session has started
        // producing segments; otherwise right here, as before. `ownsProbe` is false once the probe has
        // been handed to the native session, which then closes it.
        func settlePanelRouting(ownsProbe: Bool) async throws {
            panelRoutingSettled = true
            if let gate = preflightGate {
                preflightGate = nil
                await gate.value
                if loadGeneration != gen {
                    if ownsProbe {
                        probe.markClosed()
                        if probeOpened {
                            BlockingWork.detached { [probe] in probe.close() }
                        }
                    }
                    try checkLoadCurrent(gen)
                }
            }
            criteriaPanelReadout =
                options.awaitsInboundCriteriaWrite ? nil : displayCriteria.currentPanelIsHDR()
            panelHDRAfterHandshake = Self.sessionPanelPresentsHDR(
                hostAsserts: options.panelIsInHDRMode, criteriaReadout: criteriaPanelReadout)
            // AE#459: the ROUTE may assume more than the LABEL may claim. `panelHDRAfterHandshake` stays the
            // label's answer, conservative by design; the route additionally offers an unproven but
            // HDR-eligible display the master and lets AVFoundation's acceptance be the readout `UIScreen`
            // has been measured getting wrong on a panel that was demonstrably presenting HDR. Live attempts
            // too: a refusal lands before the first frame, so the fallback's rejoin at the edge is where the
            // session was joining anyway (#130), and without the attempt a live session has no proof at all (#887).
            routingPanelHDR = Self.sessionRoutesAsHDRPanel(
                panelPresentsHDR: panelHDRAfterHandshake,
                attemptWhenUnproven: options.attemptsHDRMasterOnUnprovenPanel,
                displayEligibleForHDR: observedDisplayCaps.supportsHDR,
                panelRefusedHDRMaster: Self.panelRefusedHDRMaster)
            // AE#667: that acceptance only answers once the panel has arrived. See `unprovenMasterAwaitsSwitchEnd`.
            if Self.unprovenMasterAwaitsSwitchEnd(
                routesAsHDR: routingPanelHDR,
                panelPresentsHDR: panelHDRAfterHandshake,
                switchRunning: displayCriteria.observedSwitchIsRunning()) {
                EngineLog.emit(
                    "[DisplayCriteria] unproven HDR master waits for the running switch to end before it is "
                    + "served (#667)",
                    category: .session)
                await displayCriteria.waitForSwitch(consumesRecord: false, settleCap: .awaitObservedEnd,
                                                    isCurrent: { self.loadGeneration == gen })
                if loadGeneration != gen {
                    if ownsProbe {
                        probe.markClosed()
                        if probeOpened {
                            BlockingWork.detached { [probe] in probe.close() }
                        }
                    }
                    try checkLoadCurrent(gen)
                }
                criteriaPanelReadout = options.awaitsInboundCriteriaWrite ? nil : displayCriteria.currentPanelIsHDR()
                panelHDRAfterHandshake = Self.sessionPanelPresentsHDR(
                    hostAsserts: options.panelIsInHDRMode, criteriaReadout: criteriaPanelReadout)
                routingPanelHDR = Self.sessionRoutesAsHDRPanel(
                    panelPresentsHDR: panelHDRAfterHandshake,
                    attemptWhenUnproven: options.attemptsHDRMasterOnUnprovenPanel,
                    displayEligibleForHDR: observedDisplayCaps.supportsHDR,
                    panelRefusedHDRMaster: Self.panelRefusedHDRMaster)
            }
            sessionPanelHDRReadout = criteriaPanelReadout
            sessionObservedDisplayCaps = observedDisplayCaps
            if routingPanelHDR != panelHDRAfterHandshake {
                EngineLog.emit(
                    "[DisplayCriteria] panel unproven but HDR-eligible: serving the master and letting "
                    + "AVPlayer answer (refusal costs one in-place media fallback)",
                    category: .session)
            }

            // Only when an assertion actually claims something: a line that fires on every load stops being
            // read, and this one has to be legible next to the rejection a wrong claim can produce.
            if options.panelIsInHDRMode || options.panelPresentsDolbyVision {
                EngineLog.emit(
                    "[DisplayCriteria] host assertion in force: panelIsInHDRMode="
                    + "\(options.panelIsInHDRMode) panelPresentsDolbyVision=\(options.panelPresentsDolbyVision)"
                    + " (observed: panelReadout="
                    + (criteriaPanelReadout.map { "\($0)" } ?? "suppressed")
                    + " supportsDolbyVision=\(observedDisplayCaps.supportsDolbyVision))",
                    category: .session)
            }
            #if os(iOS) || os(macOS)
            // The iPhone built-in display has no HDMI Match-Content handshake; it renders HDR/DV natively
            // whenever the system reports it eligible. effectiveFormat is already clamped to displayCapabilities
            // (the same signal that drives the served DV/HDR stream), so publish it directly. Gating on
            // panelHDRAfterHandshake (false on iOS, kept for media-playlist routing) wrongly relabelled every
            // HDR/DV title as SDR in Stats for Nerds.
            //
            // AE#493: macOS belongs on this branch for the same reason and was on the tvOS one. It composites
            // EDR per window with no display mode switch, so there is no handshake to read and
            // `currentPanelIsHDR()` is a hard `false` off tvOS, which labelled every HDR title on an XDR
            // display SDR. `panelIsInHDRMode` is not the fix there: the panel-mode question is the tvOS
            // question, and asking it of a window is the wrong question.
            videoFormat = effectiveFormat
            #else
            videoFormat = Self.presentedVideoFormat(
                effectiveFormat: effectiveFormat,
                panelPresentsHDR: panelHDRAfterHandshake,
                sourceCarriesHDR10Plus: sourceCarriesHDR10PlusMetadata)
            #endif
            // #361: the handshake above is the second stretch a host cannot see, and on a real SDR->HDR
            // switch it is seconds long. Recorded on every branch, including the ones with nothing to
            // wait for, so a suppressed-criteria host advances here too.
            recordStartupCheckpoint(.displayPrepared, generation: startupGen)
        }
        if preflightGate == nil {
            try await settlePanelRouting(ownsProbe: true)
        }

        // 3. Dispatch by codec.
        //    Native: HEVC/H.264 (unconditional) and AV1 on platforms with HW decode (iOS 17+/macOS 14+).
        //    That list is exactly what HLSVideoEngine accepts; everything else it refuses with
        //    unsupportedCodec, so every other video codec belongs on the software path by default
        //    (FFmpegBuild#1: qtrle reached loadNative and died there instead of decoding).
        //    SW (SoftwarePlaybackHost / dav1d / libavcodec):
        //    - AV1 on tvOS: no Apple-shipped dav1d, no HW AV1 on any Apple TV chip.
        //    - VP9/VP8: AVPlayer's HLS manifest parser rejects vp09/vp8 CODECS attributes even when VT can
        //      HW-decode VP9 (verified via aetherctl: item.status never leaves .unknown).
        //    - MPEG-4 Part 2, MPEG-2, VC-1: not in the HLS Authoring Spec CODECS list; libavcodec handles all.
        //    - qtrle and the rest of the QuickTime long tail: same reason, whatever libavcodec was
        //      built with decodes them.
        // #107: interlaced H.264 joins MPEG-2/VC-1 on the software path so DeinterlaceFilter (bwdif)
        // can deinterlace it; tvOS AVPlayer does not. Decision is pure and unit-tested in
        // VideoRoutingPolicyTests. deint=interlaced passes progressive frames through untouched, so a
        // mis-signalled progressive stream only pays an unnecessary SW decode, never a wrong deinterlace.
        // #150: some live TS channels are interlaced at the SPS level (frame_mbs_only_flag=0) but the
        // demuxer's field_order probe stays UNKNOWN, silently defeating the #107 rule; consult the SPS
        // from codecpar extradata as the tie-breaker.
        var spsIndicatesInterlaced = false
        if detectedCodecID == AV_CODEC_ID_H264, detectedFieldOrder == AV_FIELD_UNKNOWN,
           probeOpened,
           let vStream = probe.stream(at: probe.videoStreamIndex),
           let codecpar = vStream.pointee.codecpar {
            spsIndicatesInterlaced = VideoRoutingPolicy.spsIndicatesInterlaced(codecParameters: codecpar)
            if spsIndicatesInterlaced {
                EngineLog.emit(
                    "[AetherEngine] fieldOrder=UNKNOWN but SPS frame_mbs_only_flag=0; "
                    + "treating as interlaced for routing (#150)",
                    category: .engine
                )
            }
        }
        // #435: a 3D Blu-ray MVC remux muxes both eyes into one H.264 track (Matroska StereoMode
        // block_lr / block_rl, which libavformat reports as stream-level AV_STEREO3D_FRAMESEQUENCE).
        // VideoToolbox is handed samples carrying both views and renders nothing; libavcodec skips the
        // dependent view's NALs and decodes the base view, which is the left eye. Read here so the
        // decision stays in the pure policy.
        var containerStereoType: AVStereo3DType?
        if probeOpened, let vStream = probe.stream(at: probe.videoStreamIndex) {
            containerStereoType = Self.stereo3DType(stream: vStream)
        }
        let multiviewCarriage = VideoRoutingPolicy.routesSoftwareForMultiviewCarriage(
            codecID: detectedCodecID, stereo3DType: containerStereoType)
        if multiviewCarriage {
            EngineLog.emit(
                "[AetherEngine] H.264 carries both stereo views in one track "
                + "(container stereo3d=frame sequence, MVC 3D remux); VideoToolbox has no base-view-only "
                + "mode, routing to the software path so the left eye plays as 2D (#435)",
                category: .engine
            )
        }
        // A split Dolby Vision source (enhancement layer on its own PID or track) joins the layers into single-track
        // units when the dual-layer route is wanted, so the checks below see the stream the decoder would read. The
        // join is undone after the decision when the route is not taken.
        if probeOpened, !options.isLive, probe.canJoinDolbyVisionEnhancementLayer,
           VideoRoutingPolicy.dualLayerRouteIsWanted(
               codecID: detectedCodecID,
               dvProfile: detectedDVProfileNum,
               dolbyVisionHandling: options.dolbyVisionHandling,
               preferDualLayerDolbyVision: options.preferDualLayerDolbyVision,
               canHardwareDecode: nil) {
            probe.enableDolbyVisionEnhancementLayerJoin()
        }
        // A Profile 7 source with in-band parameter sets (`hev1` with an empty hvcC) is unclassifiable
        // to the strict verdict below and would stay native for that reason alone. When the dual-layer
        // route is wanted, complete the probe's record from the head of the stream first; the session
        // reuses this demuxer, so the software host and its decoders see the completed record too.
        // AE#348: the dual-layer probes below open a VideoToolbox session, which is decode work the serial
        // order never ran mid-switch. A source that may take that route settles the panel first.
        if !panelRoutingSettled, VideoRoutingPolicy.dualLayerRouteIsWanted(
               codecID: detectedCodecID,
               dvProfile: detectedDVProfileNum,
               dolbyVisionHandling: options.dolbyVisionHandling,
               preferDualLayerDolbyVision: options.preferDualLayerDolbyVision,
               canHardwareDecode: nil) {
            try await settlePanelRouting(ownsProbe: true)
        }
        if probeOpened, probe.videoStreamIndex >= 0, !options.isLive, probe.isSourceSeekable,
           VideoRoutingPolicy.dualLayerRouteIsWanted(
               codecID: detectedCodecID,
               dvProfile: detectedDVProfileNum,
               dolbyVisionHandling: options.dolbyVisionHandling,
               preferDualLayerDolbyVision: options.preferDualLayerDolbyVision,
               canHardwareDecode: nil) {
            let vIdx = probe.videoStreamIndex
            await BlockingWork.detached(priority: .userInitiated) { [probe] in
                _ = VideoConfigRecord.completeHEVCRecordFromInBandParameterSets(demuxer: probe, streamIndex: vIdx)
            }.value
            if loadGeneration != gen {
                probe.markClosed()
                BlockingWork.detached { [probe] in probe.close() }
                try checkLoadCurrent(gen)
            }
        }
        // Strict verdict: SoftwarePlaybackHost only opens HardwareVideoDecoder for a proven hardware
        // session. An unclassifiable config record stays native, because the host would hand it to
        // libavcodec, which cannot compose the dual layers. Shared by the el_type probe's gate and the
        // routing decision below, so the two cannot disagree.
        let opensHardwareHEVC: () -> Bool = {
            if let vStream = probe.stream(at: probe.videoStreamIndex),
               let cp = vStream.pointee.codecpar {
                return VTCapabilityProbe.opensHardwareDecoder(codecpar: cp)
            }
            return false
        }
        // Dual-layer decision for a Profile 7 source: FEL only, behind a capability gate (hardware HEVC
        // decode, and a pixel rate the box can decode twice in real time), logged once. The el_type
        // probe reads up to 256 packets and seeks back, so it runs only when nothing in
        // `blockingReasonBeforeProbe` (preference, handling, live/seekable, hardware) rules the route
        // out. The geometry and the budget are NOT in that list: they run after the probe, in
        // `decide`, because a MEL or unclassified el_type outranks them in the log line, so a stream
        // that its size alone would refuse still pays the probe.
        var elType: String? = nil
        var dualLayerGeometry = DualLayerRouteDecision.Geometry(width: 0, height: 0, frameRate: nil)
        // The output route splits the enhancement layer off hvcC-framed (length-prefixed) packets.
        var dualLayerPacketsAreHVCCFramed = false
        if probeOpened, let vStream = probe.stream(at: probe.videoStreamIndex),
           let cp = vStream.pointee.codecpar {
            dualLayerPacketsAreHVCCFramed = cp.pointee.extradata_size > 23 && cp.pointee.extradata?[0] == 1
            dualLayerGeometry = DualLayerRouteDecision.Geometry(
                width: Int(cp.pointee.width), height: Int(cp.pointee.height),
                frameRate: Self.detectFrameRate(stream: vStream))
        }
        let dualLayerSeekable = probeOpened && probe.videoStreamIndex >= 0 && probe.isSourceSeekable
        // Read once: the route can change between the pre-probe check and the decision, and the two must agree.
        let wirelessAirPlayRoute = Self.isWirelessAirPlayRoute()
        let airPlayVideoReceiver = Self.airPlayVideoReceiverHoldsRoute(
            wirelessAirPlayRoute: wirelessAirPlayRoute, receiverShowsVideo: airPlayReceiverShowsVideo)
        if DualLayerRouteDecision.blockingReasonBeforeProbe(
            codecID: detectedCodecID,
            dvProfile: detectedDVProfileNum,
            dolbyVisionHandling: options.dolbyVisionHandling,
            preferDualLayerDolbyVision: options.preferDualLayerDolbyVision,
            isLive: options.isLive,
            isSourceSeekable: dualLayerSeekable,
            canHardwareDecode: opensHardwareHEVC,
            enhancementLayerInPackets: !probe.foldsBluRayDolbyVisionLayers || probe.joinsDolbyVisionEnhancementLayer,
            airPlayVideoReceiver: airPlayVideoReceiver) == nil {
            let vIdx = probe.videoStreamIndex
            elType = await BlockingWork.detached(priority: .userInitiated) { [probe] in
                let result = DolbyVisionRecordAudit.probeEnhancementLayerType(demuxer: probe, streamIndex: vIdx)
                // The session reuses this demuxer, so a type read from a position that cannot be
                // restored is worth nothing: a seek that stalls leaves the type unknown, and the
                // route is not taken.
                guard probe.seekBounded(to: 0, timeout: Self.probeRewindSeekTimeout) else {
                    EngineLog.emit(
                        "[AetherEngine] el_type probe could not rewind the source within "
                        + "\(Int(Self.probeRewindSeekTimeout)) s; enhancement layer type unknown",
                        category: .engine)
                    return nil
                }
                return result
            }.value
            if loadGeneration != gen {
                probe.markClosed()
                BlockingWork.detached { [probe] in probe.close() }
                try checkLoadCurrent(gen)
            }
        }
        let dualLayerDecision = DualLayerRouteDecision.decide(
            codecID: detectedCodecID,
            dvProfile: detectedDVProfileNum,
            dolbyVisionHandling: options.dolbyVisionHandling,
            preferDualLayerDolbyVision: options.preferDualLayerDolbyVision,
            isLive: options.isLive,
            isSourceSeekable: dualLayerSeekable,
            canHardwareDecode: opensHardwareHEVC,
            elType: elType,
            geometry: dualLayerGeometry,
            enhancementLayerInPackets: !probe.foldsBluRayDolbyVisionLayers || probe.joinsDolbyVisionEnhancementLayer,
            airPlayVideoReceiver: airPlayVideoReceiver)
        if let line = dualLayerDecision.logLine {
            EngineLog.emit(line, category: .engine)
        }
        // A route that was not taken leaves no el_type behind, so neither the routing below nor a
        // software host the session reaches for another reason composes the dual layers.
        if !dualLayerDecision.isTaken { elType = nil }
        if !dualLayerDecision.isTaken, probe.joinsDolbyVisionEnhancementLayer {
            probe.disableDolbyVisionEnhancementLayerJoin()
        }
        sourceElType = elType
        // The AVPlayer-output route keeps the native route: AVPlayer plays the base layer, the enhancement
        // layer is composed onto its frames. Everything that routes a Profile 7 FEL source to the software
        // host reads `elType`, so the route hides it from the policy and keeps it in `sourceElType` for
        // the fallback to the software host.
        let runsOnAVPlayerOutput = DualLayerRouteDecision.runsOnAVPlayerOutput(
            dualLayerDecision, route: options.dualLayerRoute, packetsAreHVCCFramed: dualLayerPacketsAreHVCCFramed,
            frameRate: dualLayerGeometry.frameRate)
        if options.dualLayerRoute == .avPlayerOutput, dualLayerDecision.isTaken, !runsOnAVPlayerOutput {
            EngineLog.emit(
                "[AetherEngine] DV P7 dual-layer: the AVPlayer-output route is not available here "
                + "(it needs the DualLayerDolbyVision trait, hvcC-framed packets and a known frame rate); "
                + "taking the software host",
                category: .engine)
        }
        outputRouteFrameRate = runsOnAVPlayerOutput ? dualLayerGeometry.frameRate : nil
        var useSoftwarePath = VideoRoutingPolicy.requiresSoftwarePath(
            codecID: detectedCodecID,
            fieldOrder: detectedFieldOrder,
            av1Available: VTCapabilityProbe.av1Available,
            spsIndicatesInterlaced: spsIndicatesInterlaced,
            stereo3DType: containerStereoType,
            dvProfile: detectedDVProfileNum,
            dolbyVisionHandling: options.dolbyVisionHandling,
            preferDualLayerDolbyVision: options.preferDualLayerDolbyVision,
            canHardwareDecode: opensHardwareHEVC,
            elType: runsOnAVPlayerOutput ? nil : elType
        )
        var requiresDeinterlaceWarmup = VideoRoutingPolicy.requiresDeinterlaceWarmup(
            codecID: detectedCodecID, fieldOrder: detectedFieldOrder,
            spsIndicatesInterlaced: spsIndicatesInterlaced)
        var frameSampleRefutesInterlace = false
        // #232: a declared interlaced field order is not evidence that any frame IS interlaced.
        // European 25 fps Blu-ray masters ship as 1080i25 (there is no 1080p25): interlaced carriage,
        // progressive pictures, and FFmpeg's parser reports TT for them off SEI pic_struct alone while
        // its decoder leaves AV_FRAME_FLAG_INTERLACED clear on the very same picture. Those streams took
        // the software detour and then never deinterlaced, because SoftwareVideoDecoder engages the
        // filter on that flag and on nothing else. So decode a sample and ask the runtime's own
        // question: would the deinterlacer ever engage. Only a clean answer overrules the declaration;
        // inconclusive keeps today's routing. VOD + seekable only: the sample moves the read position of
        // the demuxer the session reuses, and live 1080i broadcast (the case the rule exists for) is
        // neither seekable nor mis-declared.
        if useSoftwarePath, probeOpened, !options.isLive, probe.isSourceSeekable,
           probe.videoStreamIndex >= 0, !multiviewCarriage,
           VideoRoutingPolicy.routesSoftwareForDeclaredInterlace(
               codecID: detectedCodecID,
               fieldOrder: detectedFieldOrder,
               spsIndicatesInterlaced: spsIndicatesInterlaced) {
            let videoIdx = probe.videoStreamIndex
            let verdict = await BlockingWork.detached(priority: .userInitiated) { [probe] in
                let verdict = InterlaceProbe.run(demuxer: probe, streamIndex: videoIdx)
                // The sample consumed packets and the session reuses this demuxer. A rewind that
                // stalls leaves the declaration standing: the sample says nothing about the title.
                guard probe.seekBounded(to: 0, timeout: Self.probeRewindSeekTimeout) else {
                    return InterlaceProbe.Verdict.inconclusive(reason: "source did not rewind")
                }
                return verdict
            }.value
            if loadGeneration != gen {
                probe.markClosed()
                BlockingWork.detached { [probe] in probe.close() }
                try checkLoadCurrent(gen)
            }
            if InterlaceProbe.refutesDeclaredInterlace(verdict) {
                useSoftwarePath = false
                requiresDeinterlaceWarmup = false
                frameSampleRefutesInterlace = true
                EngineLog.emit(
                    "[AetherEngine] declared interlaced (fieldOrder=\(detectedFieldOrder.rawValue)) but "
                    + "\(verdict); the deinterlacer would never engage, routing native for HW decode (#232)",
                    category: .engine
                )
            } else {
                EngineLog.emit(
                    "[AetherEngine] declared interlaced and the frame sample agrees (\(verdict)); "
                    + "keeping the software deinterlace path (#232)",
                    category: .engine
                )
            }
        }
        sourceVideoScan = VideoScan.resolve(
            codecID: detectedCodecID, fieldOrder: detectedFieldOrder,
            spsIndicatesInterlaced: spsIndicatesInterlaced,
            frameSampleRefutesInterlace: frameSampleRefutesInterlace)
        // #2: an H.264 / HEVC format AVPlayer accepts at the HLS CODECS level but VideoToolbox can't
        // hardware-decode (H.264 High 4:2:2/4:4:4/High-10, HEVC Rext on Intel Macs / older Apple TV) reaches
        // readyToPlay then renders nothing on the native path. QuickTime plays it via its own software decoder;
        // there is no analogous fallback on the native route, so route it to the SoftwarePlaybackHost
        // (libavcodec), which decodes these profiles. VOD only for H.264 / HEVC: forced-native live keeps its
        // verified path, and broadcast H.264 / HEVC is HW-decodable. AV1 is judged on live too (audit HLS-5).
        // Apple Silicon HW-decodes these, so the probe keeps them native.
        // #176: DV Profile 5 is exempt inside the policy; the raw-hvcC probe misjudges the dvh1 route and the
        // software path decodes IPT-PQ-c2 with a green/purple cast, so P5 must stay native unconditionally.
        if !useSoftwarePath, probeOpened,
           VideoRoutingPolicy.consultsUndecodableFormatGate(codecID: detectedCodecID, isLive: options.isLive),
           let vStream = probe.stream(at: probe.videoStreamIndex),
           let codecpar = vStream.pointee.codecpar {
            let dvProfile = Self.dvProfile(stream: vStream)
            // A Profile 5 record served as its base layer plays as plain HEVC, which is what
            // the raw-hvcC probe judges; the exemption is for the dvh1 route it is not on.
            // AE#532: a record the RPU corrected is not on that route either, and its base layer
            // is standard Main10, so the gate judges it the way it judges any Profile 7 / 8.
            let gateDVProfile = presentsDolbyVisionBaseLayer ? nil : (correctedDVProfile ?? dvProfile)
            // AE#883: called in place rather than through a stored closure. Swift 6.2 infers a stored local
            // closure main-actor and rejects it capturing `codecpar` ("sending risks causing data races");
            // a non-escaping argument is not sent.
            var routesSoftware = VideoRoutingPolicy.forcesSoftwareForUndecodableFormat(
                codecID: detectedCodecID, dvProfile: gateDVProfile,
                canHardwareDecode: { VTCapabilityProbe.canHardwareDecode(codecpar: codecpar) })
            // AE#348: with the pre-flight gate beside the load, this probe's throwaway session can open while
            // the panel switches, which the serial order never did. Only a refusal changes the route, so a
            // refusal taken then is asked again once the panel has settled, where the serial order asked it.
            if routesSoftware, !panelRoutingSettled {
                try await settlePanelRouting(ownsProbe: true)
                routesSoftware = VideoRoutingPolicy.forcesSoftwareForUndecodableFormat(
                    codecID: detectedCodecID, dvProfile: gateDVProfile,
                    canHardwareDecode: { VTCapabilityProbe.canHardwareDecode(codecpar: codecpar) })
            }
            if routesSoftware {
                useSoftwarePath = true
                EngineLog.emit(
                    "[AetherEngine] codec=\(detectedCodecID.rawValue) not hardware-decodable by "
                    + "VideoToolbox; routing to the software path so it plays instead of a black screen (#2)",
                    category: .engine
                )
            } else if detectedCodecID == AV_CODEC_ID_HEVC, dvProfile == 5 {
                EngineLog.emit(
                    "[AetherEngine] DV Profile 5: VT probe skipped, native dvh1 path is the only "
                    + "correct decode (#176)",
                    category: .engine
                )
            }
        }
        // Forward-only sources can't serve the native path's seeks (cue prewarm, segment seeks).
        // Covers custom readers AND URL sources whose AVIOReader resolved no size and degraded to
        // the forward-only streaming reader (#126: unknown-length HTTP MP4 produced zero segments).
        // Live sources are exempt: the live producer never seeks backward, scrub previews come from
        // the DVR segment cache, and audio-switch is already no-op for forward-only sources.
        // An explicit sequential-origin declaration is exempt for the same reasons a live session
        // is: the producer reads the archive linearly from byte 0, the duration is caller-declared
        // (no tail estimate), the segment plan is the uniform-stride fallback, restarts/revives are
        // gated off, and the cue prewarm fails fast on the non-seekable pb. Forcing those archives
        // onto the software path traded AVPlayer's buffering and hardware decode for nothing
        // (device trace: a 720p50 timeshift archive played clean on the native path and visibly
        // stuttered on the software one). Declared-interlaced archives still route software via
        // the field-order policy above - the #232 refute probe cannot run without a rewind.
        if probeOpened, VideoRoutingPolicy.promotesForwardOnlySourceToSequential(
            isSourceSeekable: probe.isSourceSeekable,
            isLive: options.isLive,
            declaredSequential: options.sequentialOrigin,
            isCustomSource: isCustomSource,
            routedSoftware: useSoftwarePath,
            preferred: options.preferredDecodePath,
            containerDurationSeconds: probe.duration
        ) {
            // Written into loadedOptions as well, so every rebuild of this session (AirPlay LAN swap,
            // audio switch, background return) reopens it as the sequential origin it turned out to be.
            options.sequentialOrigin = true
            options.declaredDurationSeconds = probe.duration
            loadedOptions.sequentialOrigin = true
            loadedOptions.declaredDurationSeconds = probe.duration
            isSequentialOrigin = true
            EngineLog.emit(
                "[AetherEngine] forward-only source with a container duration of "
                + "\(String(format: "%.1f", probe.duration))s: serving it as a sequential origin",
                category: .engine
            )
        }
        if !probe.isSourceSeekable && !options.isLive {
            if options.sequentialOrigin {
                if !useSoftwarePath {
                    EngineLog.emit(
                        "[AetherEngine] sequential origin keeps the native path (linear read, "
                        + "declared duration, seeks only inside the resident tail)",
                        category: .engine
                    )
                }
            } else {
                useSoftwarePath = true
                EngineLog.emit("[AetherEngine] source is forward-only, forcing software path", category: .engine)
            }
        }
        // AE#461: the host's own routing override, scoped to this session. Placed last among the
        // routing decisions and before the guards below, because it is an override: it wins over
        // what the engine concluded, and it does not get to suspend what the software path cannot
        // represent. The two levers that existed before this were both wrong for the job: the test
        // hook below is process-global (on a shared engine it drags every concurrent session with
        // it), and the only per-session route onto the software host was presenting a reader that
        // fails its seek, which costs the source its seeks, its audio switch, its title switch and
        // `reloadAtCurrentPosition` itself. Unlike the #2 capability gate this is NOT VOD-only: a
        // live load never reaches that gate at all, and a live session is exactly where a host has
        // no second engine left to hand a struggling stream to.
        if options.preferredDecodePath == .software {
            // Stating the no-op matters here for the same reason it does for #364's teletext page:
            // a host that asked for software and saw software cannot otherwise tell "the engine had
            // already routed there" from "the request did not arrive".
            EngineLog.emit(
                useSoftwarePath
                    ? "[AetherEngine] #461: host asked for the software path; the routing had already chosen it"
                    : "[AetherEngine] #461: host asked for the software path, overriding the native route",
                category: .engine
            )
        }
        useSoftwarePath = VideoRoutingPolicy.usesSoftwarePath(
            routedSoftware: useSoftwarePath, preferred: options.preferredDecodePath)
        // #846: after every other routing decision, because this one only ever adds the software path and
        // the interlace refute probe above can take that path away again.
        let upscaleDecision = !options.upscalesLowResolutionVideo
            ? UpscaleRouteDecision.notTaken(.preferenceOff)
            : upscaleRouteDecision(
                options: options,
                videoStream: probeOpened ? probe.stream(at: probe.videoStreamIndex) : nil,
                dvProfile: detectedDVProfileNum,
                wirelessAirPlayRoute: wirelessAirPlayRoute,
                demuxedAudioLive: SessionOptionCorrection.isDemuxedAudioLive(
                    isLive: options.isLive,
                    hasCompanionAudioReader: (customReader as? LiveIngestSourceInfo)?.companionAudioReader != nil))
        if let line = upscaleDecision.logLine {
            EngineLog.emit(line, category: .engine)
        }
        sourceUpscalePlan = upscaleDecision.plan
        sourceSoftwareOnlyForUpscale = sourceUpscalePlan != nil && !useSoftwarePath
        if sourceUpscalePlan != nil { useSoftwarePath = true }
        // TEST-ONLY: forces SW path for aetherctl live --sw; unset in shipping builds.
        if Self.forceSoftwarePathForTesting {
            useSoftwarePath = true
            EngineLog.emit("[AetherEngine] TEST override: forcing software path", category: .engine)
        }
        EngineLog.emit("[AetherEngine] dispatch: codec=\(detectedCodecID.rawValue) → \(useSoftwarePath ? "software" : "native")", category: .engine)
        // #361: routing is settled here and not at the first `useSoftwarePath` assignment; the
        // interlace refute probe and the VideoToolbox capability probe above can both overturn it,
        // and the refute probe decodes a real sample, which is work worth showing.
        recordStartupCheckpoint(.routed, generation: startupGen)

        // #176 follow-up: IPT-only DV (HEVC P5, AV1 P10.0) must never start on the software path; the
        // decoded IPT-PQ-c2 signal renders as YCbCr (green/purple cast). AV1 P10.0 without HW AV1 decode
        // has no native fallback (AVPlayer HLS requires HW AV1), and HEVC P5 reaches here only off
        // forward-only sources the native path cannot serve. Fail fast instead of playing wrong color.
        if useSoftwarePath, probeOpened,
           let vStream = probe.stream(at: probe.videoStreamIndex),
           let dvConfig = Self.dvConfig(stream: vStream),
           VideoRoutingPolicy.softwarePathCannotRepresent(
               codecID: detectedCodecID,
               // AE#532: the refusal is about IPT-PQ-c2, which a record the RPU contradicts does not
               // carry. Its base layer is plain HEVC and decodes correctly.
               dvProfile: correctedDVProfile ?? dvConfig.profile,
               dvBlCompatID: dvConfig.blCompatID,
               presentsDolbyVisionBaseLayer: presentsDolbyVisionBaseLayer) {
            probe.markClosed()
            BlockingWork.detached { [probe] in probe.close() }
            let profileLabel = detectedCodecID == AV_CODEC_ID_AV1 ? "10.0" : "5"
            EngineLog.emit(
                "[AetherEngine] DV Profile \(profileLabel) routed to the software path; IPT-PQ-c2 has "
                + "no compatible base layer and would render green/purple, failing fast (#176)",
                category: .engine
            )
            publishError(.dolbyVisionRequiresHardware, "Dolby Vision Profile \(profileLabel) requires a hardware playback path on this device")
            throw AetherEngineError.dolbyVisionUnplayableOnSoftwarePath(profile: profileLabel)
        }

        // Demuxed-audio live ingest is native-path-only (side-demuxer merge lives in HLSSegmentProducer).
        // A demuxed-audio source routed SW would play silent; fail fast so the host falls back to server-muxed.
        if useSoftwarePath, options.isLive,
           (customReader as? LiveIngestSourceInfo)?.companionAudioReader != nil,
           probe.audioStreamIndex < 0 {
            probe.markClosed()
            BlockingWork.detached { [probe] in probe.close() }
            EngineLog.emit(
                "[AetherEngine] demuxed-audio live source routed to the software path "
                + "(codec=\(detectedCodecID.rawValue)); side-audio merge is native-only, failing fast",
                category: .engine
            )
            publishError(.demuxedAudioLiveUnsupported, "Demuxed-audio live source not supported on this codec path")
            throw HLSIngestError.demuxedAudioNotSupported
        }

        do {
            if useSoftwarePath {
                if !panelRoutingSettled {
                    try await settlePanelRouting(ownsProbe: true)
                }
                // SW path reuses the probe demuxer (single AVFormatContext open); do not close here.
                // Release a preserved NativeAVPlayerHost from a native->native reload: the SW pipeline
                // renders into its own layer and currentAVPlayer must publish nil to drop AVKit's stale player.
                if nativeHost != nil {
                    nativeHost?.tearDown()
                    nativeHost = nil
                    currentAVPlayer = nil
                }
                try await loadSoftware(
                    url: url,
                    sourceHTTPHeaders: options.httpHeaders,
                    startPosition: startPosition,
                    audioSourceStreamIndex: selectedAudio,
                    isLive: options.isLive,
                    dvrWindowSeconds: options.dvrWindowSeconds,
                    preopenedDemuxer: probeOpened ? probe : nil,
                    requiresDeinterlaceWarmup: requiresDeinterlaceWarmup,
                    generation: gen,
                    elType: elType
                )
                playbackBackend = .software
                lastRequiresDeinterlaceWarmup = requiresDeinterlaceWarmup
                // AE#550: the one thing a viewer on a receiver needs said out loud. This backend's
                // picture cannot leave the device, so a wireless route carries the sound alone, and
                // the report that opened this was someone hearing a film they could not see.
                if Self.isWirelessAirPlayRoute() {
                    EngineLog.emit(
                        "[AetherEngine] AE#550: software path with a wireless receiver on the audio route; "
                        + "the sound goes to the receiver and the picture stays on this device "
                        + "(screen mirroring is what carries it)",
                        category: .engine
                    )
                }
                activeVideoDecoder = Self.videoDecoderLabel(
                    codecID: detectedCodecID,
                    isSoftware: !(softwareHost?.usesHardwareVideoDecoder ?? false)
                )
                // AE#462: the host's own resolved index, not the engine's pick. The pick says which
                // track was ASKED for; only the host knows whether a decoder opened for it, and this
                // label claimed one for a session that had dropped its audio and gone video-only.
                activeAudioDecoder = Self.softwareAudioDecoderLabel(
                    audioTracks: probedAudioTracks,
                    activeIndex: softwareHost?.audioStreamIndex ?? -1,
                    route: softwareHost?.audioRoute ?? .pcm
                )
                presentCurrentLayer()
                // The play gate the native branch below also runs. The pre-flight above gives up on an HDR
                // switch at its cap while the panel is still switching and never waits for a rate-only one,
                // so without this the host starts playing into a dark panel. There is no AVPlayerItem here
                // for AVKit to read criteria from, so a host that leaves the write to AVKit expects no
                // inbound write.
                await displayCriteria.waitForSwitch(
                    startGrace: Self.playGateGrace(
                        criteriaUnchanged: criteriaUnchanged,
                        criteriaWrittenBeforeLoad: !options.awaitsInboundCriteriaWrite,
                        formatKnown: probeOpened,
                        effectiveFormat: effectiveFormat,
                        noWriterExpected: options.sharedOutputRole == .secondary
                            || options.awaitsInboundCriteriaWrite
                    ),
                    settleCap: options.isLive ? .standard : .awaitObservedEnd,
                    isCurrent: { self.loadGeneration == gen })
                try checkLoadCurrent(gen)
                // #124: a paused mount skips autostart; loadSoftware's host.$isReady settles .paused.
                if Self.loadPerformsAutostart(options) {
                    softwareHost?.play()
                    state = .playing
                } else {
                    // AE#973: the loops only ran on play(), so a paused mount (and every rebuild of a
                    // paused session, which mounts paused) never decoded the frame at the playhead.
                    softwareHost?.pause()
                }
                startMemoryProbe()
                startLiveTelemetrySampler()
                armDisplayModeDiagnostic(gen: gen, backend: "software",
                                         contentRate: detectedRate, requestedRate: snappedRate)
                armPlaybackPanelProbe(gen: gen, effectiveFormat: effectiveFormat,
                                      panelPresentedHDRAtLoad: panelHDRAfterHandshake,
                                      sessionIsPlaying: Self.loadPerformsAutostart(options))
            } else {
                // Native path: pass the probe Demuxer to loadNative so HLSVideoEngine.start() skips
                // avformat_open_input + find_stream_info (~1-3 s saved on slow CDN). The cue prewarm
                // seek inside start() invalidates any stale read position. Pass nil if probe failed.
                try await loadNative(
                    url: url,
                    sourceHTTPHeaders: options.httpHeaders,
                    startPosition: startPosition,
                    audioSourceStreamIndex: selectedAudio,
                    keepDvh1TagWithoutDV: options.keepDvh1TagWithoutDV,
                    forceDolbyVisionOnNonDVDisplay: options.forceDolbyVisionOnNonDVDisplay,
                    dolbyVisionHandling: options.dolbyVisionHandling,
                    dolbyVisionRPUProfile: detectedDVRPUProfile,
                    matchContentEnabled: options.matchContentEnabled,
                    panelIsInHDRMode: routingPanelHDR,
                    // AE#535: the table composed at the top of this load, not a second read of it.
                    sessionDisplayCaps: sessionDisplayCaps,
                    audioBridgeMode: options.audioBridgeMode,
                    isLive: options.isLive,
                    dvrWindowSeconds: options.dvrWindowSeconds,
                    // Set only by reloadAtCurrentPosition's live reopen:
                    // the host must skip its initial seek so AVPlayer
                    // joins the rebuilt (possibly backlog-bearing)
                    // playlist at its own live edge. Hosts cannot set
                    // this; fresh joins keep the verified seek-to-0.
                    liveRejoin: options.isLiveRejoin,
                    preopenedDemuxer: probeOpened ? probe : nil,
                    generation: gen,
                    resolvePanelRouting: panelRoutingSettled ? nil : {
                        try await settlePanelRouting(ownsProbe: false)
                        return routingPanelHDR
                    }
                )
                playbackBackend = .native
                // Preserve source evidence for a later native-to-software recovery.
                lastRequiresDeinterlaceWarmup = requiresDeinterlaceWarmup
                activeVideoDecoder = Self.videoDecoderLabel(
                    codecID: detectedCodecID, isSoftware: false
                )
                // Audio label comes from HLSVideoEngine's stream-copy/FLAC-bridge cascade.
                activeAudioDecoder = nativeVideoSession?.audioPipelineDescription
                // Reconcile published audioTracks with the session's real pick (side-demuxer tracks for
                // demuxed-audio sources). Without this a post-load language check would reload the track already playing.
                syncPublishedAudioStateFromNativeSession()
                presentCurrentLayer()
                // Gate play() on panel handshake. With appliesPreferredDisplayCriteriaAutomatically=true,
                // AVKit drives the criteria write from the live AVPlayerItem's formatDescription (reads dvcC
                // via private CoreMedia hooks). waitForSwitch Stage 1 gives AVKit time to fire that write;
                // Stage 2 waits for the panel to settle so the first frame doesn't hit a mid-transition panel.
                // Critical for DV P5 (no HDR10 base, requires immediate DV mode).
                // #133: unchanged criteria (same-format zap) mean the panel is already in the target mode and
                // neither the engine nor AVKit will switch it, so there is nothing to settle here. Skipping
                // avoids Stage 1's blind 1s (and, on unobservable-DV panels, the full ~3s cap) on every zap.
                // #274: the 1000ms Stage 1 budget is the DV-cold-start bet on a sole-writer host's inbound
                // write. Sessions no dynamic-range switch can reach (engine-writer, or SDR content) take the
                // 200ms budget instead of paying it on every load.
                await displayCriteria.waitForSwitch(
                    startGrace: Self.playGateGrace(
                        criteriaUnchanged: criteriaUnchanged,
                        criteriaWrittenBeforeLoad: !options.awaitsInboundCriteriaWrite,
                        formatKnown: probeOpened,
                        effectiveFormat: effectiveFormat,
                        noWriterExpected: options.sharedOutputRole == .secondary
                    ),
                    // Sodalite#49: this gate runs after the item is ready, so waiting out an observed switch
                    // blocks nothing else, and the panel is dark until it ends either way. Live keeps the
                    // standard cap: a zap must not sit behind a panel handshake.
                    settleCap: options.isLive ? .standard : .awaitObservedEnd,
                    isCurrent: { self.loadGeneration == gen })
                try checkLoadCurrent(gen)
                // automaticallyWaitsToMinimizeStalling=true (default) handles play-before-ready.
                // #35: on a real SDR->HDR switch while serving a VOD master, drive the bounded
                // cold-start readiness gate (play -> poll -> reload master -> media fallback) instead
                // of an unconditional play(); the gate calls play() itself. Warm/live/media paths keep
                // the immediate play().
                // #124: a paused mount skips the terminal play() AND the cold-start readiness gate
                // (an autostart-path recovery: it plays to poll readiness). loadNative wired
                // host.$isReady, which settles .loading -> .paused; the host resumes later with play().
                // #227 follow-up: a master handed to a wireless AirPlay receiver arms the same gate. The
                // receiver's HDR mode is unreadable from the sender, so an offered HDR/DV master can be
                // rejected or park silently, and the escalation (reload master -> reduced HDR master ->
                // media, all on the LAN IP) is exactly the recovery that hop needs.
                if Self.loadPerformsAutostart(options) {
                    if didSwitchPanel || airPlayServedMasterToReceiver, let session = nativeVideoSession,
                       session.servingMasterPlaylist, !options.isLive {
                        try await runStartupReadinessGate(
                            session: session, position: startPosition ?? 0, gen: gen)
                    } else {
                        nativeHost?.play()
                    }
                    state = .playing
                    // #227: a receiver that refuses the playlist it was handed neither fails the item nor
                    // reports a rejection, so the gate above cannot see it. Watch the clock instead.
                    armAirPlayProgressWatchdog(gen: gen, position: startPosition ?? 0)
                }
                startMemoryProbe()
                startLiveTelemetrySampler()
                armDisplayModeDiagnostic(gen: gen, backend: "native",
                                         contentRate: detectedRate, requestedRate: snappedRate)
                armPlaybackPanelProbe(gen: gen, effectiveFormat: effectiveFormat,
                                      panelPresentedHDRAtLoad: panelHDRAfterHandshake,
                                      sessionIsPlaying: Self.loadPerformsAutostart(options))
            }
        } catch is CancellationError {
            // Superseded.
            throw CancellationError()
        } catch {
            // A host or open that failed because stop()/load() tore it down mid-flight throws its own
            // error before the post-load generation check; the successor owns the state (audit CORE-1).
            if loadGeneration != gen { throw CancellationError() }
            // AE#246: the load-time probe failed for a reason that was not the HLS classification, so the
            // AE#154 check above saw an inconclusive failure and this load fell through to the loopback
            // path with no preopened demuxer. The session's own open is then the first one to read the
            // body, and it has now classified the source as remote HLS after all. Take the same reroute
            // rather than surfacing a terminal failure for a source AVPlayer can play. A full load()
            // restart (the #168 reroute's shape) is what clears the half-built loopback session; the
            // bypass runs no probe, so this cannot bounce back here a second time.
            if RemoteHLSMediaSelection.shouldReroute(failure: error, isCustomSource: isCustomSource),
               case .url(let hlsURL) = source,
               loadGeneration == gen {
                if case .taken(let probe) = try await rerouteOntoMPEGTSIngest(
                    playlistURL: hlsURL,
                    options: loadedOptions,
                    startPosition: startPosition,
                    audioSourceStreamIndex: audioSourceStreamIndex,
                    discTitleID: discTitleID,
                    generation: gen,
                    evidence: "second open confirmed finite HEVC-in-MPEG-TS HLS"
                ) {
                    return probe
                }
                EngineLog.emit(
                    "[AetherEngine] AE#246: the loopback session's own open classified the source as HLS; "
                    + "taking the AE#154 reroute onto the native remote-HLS bypass",
                    category: .engine
                )
                var rerouted = loadedOptions
                rerouted.nativeRemoteHLS = true
                continueStartupAcrossReroute()   // #361, same wait, different route
                _ = try await load(source: .url(hlsURL), startPosition: startPosition, options: rerouted)
                return nil
            }
            publishLoadFailure(error)
            throw error
        }
        // Honor a saved subtitle-language preference on the first frame (#73). Runs only on the successful
        // video path (the audio-only branch returns earlier and renders no subtitles); a no-op when the
        // preference list is empty, no track matches, or the host already activated one.
        applyPreferredSubtitleSelection(startAnchor: startPosition, sourceDuration: sourceProbe?.durationSeconds)
        // #214 follow-up: opt-in JOC confirmation runs behind the session, never in front of the first frame.
        startAtmosConfirmation()
        return sourceProbe
    }

    // MARK: - Transport

    /// Current transport owner. Priority: audio-AVPlayer -> FFmpeg audio -> software -> native.
    /// Centralised so priority can't drift across call sites.
    private var activeTransportHost: (any TransportControllable)? {
        if audioAVPlayerActive, let host = audioAVPlayerHost { return host }
        if let host = audioHost { return host }
        if let host = softwareHost { return host }
        return nativeHost
    }

    public func play() {
        recordTransportDuringRebuild(playing: true)
        if deferPlayForInterruption() { return }
        // AetherEngine#164: a VOD parked at its final frame (scrubbed to the end, or paused there)
        // cannot advance; AVPlayer.play() would no-op and leave the button frozen. Rewind to the start
        // first, then resume. `.ended` is excluded (see shouldRewindBeforePlay): it stays terminal so a
        // play press racing the host end card does not silently revive a finished session (#63).
        if Self.shouldRewindBeforePlay(
            state: state, currentTime: currentTime, duration: duration, isLive: isLive
        ) {
            Task { @MainActor in
                await self.seek(to: 0)
                self.play()
            }
            return
        }
        activeTransportHost?.play()
        if state == .paused || state == .loading {
            state = .playing
        }
        // #882: the software pumps keep their rebuffer hold across a pause, and pause() cleared the level,
        // so a play into a hold carries no edge. Re-read it, or the phase reads `.playing` until the hold ends.
        if let softwareHost {
            isBuffering = state == .playing && softwareHost.isRebuffering
        }
        // A resume that leaves `state` at `.playing` (the end of an audio interruption) restarts the
        // renderer without a state change; the Atmos output activator follows the renderer, so tell it.
        atmosOutputActivator?.refresh()
        clampLiveResumeIfBehindWindow()
    }

    public func pause() {
        recordTransportDuringRebuild(playing: false)
        resumeAfterInterruption = false
        playDeferredByInterruption = false
        userPauseCount &+= 1
        activeTransportHost?.pause()
        isBuffering = false
        if state == .playing {
            state = .paused
        }
        #if os(iOS)
        // Paused while backgrounded with no PiP: the app will idle-suspend, so release the video pipeline
        // (wedge-safe, mirrors the unconditional background teardown). Audio backends are already spared.
        // #127: same grace window as the didEnterBackground path, so pause-after-background quick switches
        // also skip the rebuild.
        if isBackgrounded && !retainsVideoPipelineWhenBackgrounded && !pictureInPictureActive && !audioAVPlayerActive && audioHost == nil && softwareHost == nil {
            switch Self.backgroundStep(
                action: .teardownVideo,
                state: state,
                supportsGraceWindow: true,
                graceSeconds: backgroundTeardownGraceSeconds
            ) {
            case .deferTeardown(let seconds):
                scheduleBackgroundGraceTeardown(afterSeconds: seconds)
            default:
                Task { @MainActor in await self.teardownVideoForBackground() }
            }
        }
        #endif
    }

    public func togglePlayPause() {
        // Only togglable from steady states + .loading ("start"). Ignore in .seeking/.error/.idle.
        switch state {
        case .playing, .paused, .loading: break
        default: return
        }
        // Read the LIVE AVPlayer state, not the published `state`. AVKit/Control Center/hardware button can
        // toggle AVPlayer directly; the $timeControlStatus reconciliation is async, so a fast press on a stale
        // value would no-op. SW/audio hosts have no competing transport owner so `state` is authoritative there.
        let isPlaying: Bool
        if let nativeHost, !audioAVPlayerActive && audioHost == nil && softwareHost == nil {
            isPlaying = nativeHost.isEffectivelyPlaying
        } else {
            isPlaying = (state == .playing)
        }
        if isPlaying { pause() } else { play() }
    }

    /// Tear down and reload from the current position. Call after background return; tvOS invalidates
    /// AVIO connections and VT sessions on suspension.
    public func reloadAtCurrentPosition() async throws {
        // AE#560: a reload re-opens the source, which can come back with different codecs or a
        // different program, so the recording ends as a source reset rather than as a session end.
        // stopInternal's own call further down is then a no-op.
        endRecordingIfRunning(reason: .sourceReset)
        // #357: a background teardown already ran stopInternal and parked the selection, because on
        // that path the live state every snapshot below reads is wiped long before this call. When
        // nothing was parked this is exactly the pre-#357 live read.
        let resumesTornDownSession = backgroundTeardownSelection != nil
        let selection = consumeReloadSelection()
        // AE#464 round 2: come back in the transport state the session is IN, not the one its first
        // mount was given. Written before the branch because only the URL branch below carries a
        // struct into `load`; the custom-source branch reads `loadedOptions` field by field.
        // A torn-down session (#357 background teardown) has no transport left to read and its
        // resume is the host's call, so that path keeps replaying the mount flag exactly as before.
        if !resumesTornDownSession { setLoadedAutoplay(sessionRebuildResumesPlaying) }
        if isCustomSource {
            // Rebuild on retained reader (seekable only); no URL to reopen.
            //
            // AE#526: a refusal, said out loud. This used to return silently, and a host cannot tell
            // that from a reload that worked: measured on a device, a live session torn down by the
            // paused-background window (#127) came back to a player that had called this, believed it
            // had rebuilt, and sat on a spinner for twenty minutes. A forward-only origin cannot be
            // reopened at a position, and the vocabulary for saying so already existed
            // (`sessionReloadRefusal`); only this path did not use it.
            guard customSourceIsSeekable, let placeholderURL = loadedURL else {
                let refusal: SessionReloadRefusal =
                    loadedURL == nil ? .noActiveSession : .customSourceNotSeekable
                EngineLog.emit(
                    "[AetherEngine] #526 reload at current position refused: \(refusal). A session "
                    + "on a forward-only custom source has no position to reopen at; a live host's "
                    + "answer to this is to tune again, not to wait for a rebuild that cannot come",
                    category: .session
                )
                throw AetherEngineError.sessionNotReloadable(refusal)
            }
            // Sodalite#173: the rebuild's own teardown moves the generation by one; anything further is a
            // stop() or load() that superseded it, which a returned nil does not say.
            let reloadGeneration = loadGeneration &+ 1
            // Audit LIF-102: the value written above, or the mount flag after a background teardown.
            let failure = await reloadWithAudioOverride(
                url: placeholderURL,
                audioStreamIndex: selection.audioTrackIndex.map { Int32($0) },
                expectedGeneration: loadGeneration,
                discTitleIDOverride: selection.discTitleID,
                resumePlaying: loadedOptions.autoplay,
                restoredDeinterlaceWarmupDecision: selection.requiresDeinterlaceWarmup
            )
            // AE#460 follow-up: a rebuild that died leaves the session in `.error`, and this branch
            // used to return as if it had come back, so `reloadAtCurrentPosition(applying:)`
            // reported a correction it had not made. The URL branch below has always thrown what
            // its load threw; both branches now answer the same way. Measured on a live custom
            // source whose reader read `cancel()` as terminal: the rebuild failed on stream info
            // and the call still returned success.
            if let failure { throw failure }
            if loadGeneration != reloadGeneration { throw CancellationError() }
            // The reload restores from its own pre-stopInternal snapshot, which a torn-down session
            // no longer had anything in; replay the parked subtitle pick on top of it.
            if resumesTornDownSession {
                restoreSubtitleSelection(from: selection.subtitles, resumeAnchor: nil)
            }
            return
        }
        guard let url = loadedURL else { return }
        // AE#464 round 2: not `currentTime`. A reload stacked behind one still in flight reads a clock
        // that load already zeroed, and rebuilds the session at its head. See `rebuildPosition`.
        let pos = positionForSessionRebuild
        // Snapshot the disc title before load()'s stopInternal wipes it, so a background-resumed disc image
        // keeps the title the user selected instead of reverting to the main title (#67).
        let titleID = selection.discTitleID
        // #170: session state the from-scratch load() would wipe and re-derive by auto-selection
        // (AirPlay LAN-swap reload, background-return reopen). The explicit audio pick rides the
        // load's own override contract (matching the custom-source branch above); the subtitle
        // session state is seeded into the load and the selection restored after it.
        let audioToRestore = selection.audioTrackIndex
        let carryover = selection.subtitles
        let wasPreservingSession = sessionPreservingReloadInFlight
        sessionPreservingReloadInFlight = true
        // #227: the reconcile has to run on every exit, including a thrown/superseded load, or an edge held
        // during the reload is lost and the session stays on the wrong URL for the current route.
        // Round 2: restored rather than cleared, and only the outermost rebuild reconciles. This used
        // to clear the flag outright, so a rebuild nested inside another one ended the outer hold
        // early and reconciled on its behalf, mid-teardown.
        defer {
            sessionPreservingReloadInFlight = wasPreservingSession
            if AetherEngine.rebuildOwnsHeldExternalPlaybackEdge(wasAlreadyRebuilding: wasPreservingSession) {
                reconcileExternalPlaybackAfterReload()
            }
        }
        // Live: rejoin at the live edge; pre-suspend playhead is stale and may have slid out of the window.
        let resume: Double? = LiveReloadPolicy.resumePosition(
            isLive: loadedOptions.isLive, currentTime: pos)
        // isLiveRejoin tells loadNative to skip the initial seek: the rebuilt playlist can have a multi-segment
        // backlog where the fresh-join contract (seg0 == live edge) no longer holds.
        var options = loadedOptions
        options.isLiveRejoin = options.isLive
        options.subtitleSessionCarryover = carryover
        try await load(url: url, startPosition: resume, options: options,
                       audioSourceStreamIndex: audioToRestore.map { Int32($0) }, discTitleID: titleID)
        // AE#711 follow-up: `load` autostarts from the flag it was handed; a play/pause that arrived
        // while it ran is the newer word.
        if let intent = transportIntentUnderReconstruction, intent != options.autoplay {
            if intent { play() } else { pause() }
        }
        restoreSubtitleSelection(from: carryover, resumeAnchor: resume)
        // Arm the watchdog so a live reopen whose AVPlayer never becomes ready fails visibly instead of freezing.
        if options.isLive, !options.nativeRemoteHLS, playbackBackend == .native {
            armLiveReloadWatchdog(generation: loadGeneration)
        }
    }

    public func seek(to seconds: Double) async {
        await seek(to: seconds, exact: false)
    }

    /// `exact: true` lands on `seconds` even where the route would otherwise land on a nearby
    /// keyframe (the software host's AV1 through dav1d, `SWKeyframeSnap`): a chapter mark or the end of
    /// an intro, where a landing a few seconds early or late is wrong. It costs that route the decode
    /// from the keyframe before the target up to it. Every other route is exact either way.
    public func seek(to seconds: Double, exact: Bool) async {
        // Audit DMX-113: the `.loading` branch below would otherwise publish a NaN or infinite
        // position into the clock, and the hosts' seeks hand it to the Demuxer as ticks.
        guard seconds.isFinite else {
            EngineLog.emit("[AetherEngine] seek(to:\(seconds)) ignored: not a finite position", category: .engine)
            return
        }
        await seek(to: seconds, origin: .host, exact: exact)
    }

    /// AE#446 round 4: the same seek, with who asked for it. `.liveRejoin` is the engine coming back
    /// to a position it decided itself out of content the session served; it is not a scrub, so the
    /// live-only refusal below does not apply to it and its landing is measured against what the item
    /// holds rather than against what the session advertises.
    /// AE#958: a loopback session on a sequential origin can seek inside the resident span that reaches the
    /// producer's frontier. The cache keeps everything from the consumer's target up to the highest stored
    /// segment, so every fetch from there on is served or produced next, never a restart (which the origin
    /// cannot honour). An earlier, detached span would run into a segment that no longer exists.
    nonisolated static func sequentialSeekStaysResident(
        target: Double,
        sequentialOrigin: Bool,
        loopbackSession: Bool,
        residentRanges: [ClosedRange<Double>]
    ) -> Bool {
        guard sequentialOrigin, loopbackSession, target.isFinite,
              let frontier = residentRanges.max(by: { $0.upperBound < $1.upperBound }) else { return false }
        return frontier.contains(target)
    }

    func seek(to seconds: Double, origin: SeekOrigin, exact: Bool = false) async {
        // Guard: a host scrub racing stop() must not flip an idle/error engine to .seeking -> .playing.
        // .ended is terminal too: after end-of-media the host reloads to replay, it does not scrub a parked session.
        switch state {
        case .idle, .ended, .error:
            EngineLog.emit("[AetherEngine] seek(to:\(seconds)) ignored: no active session (state=\(state))", category: .engine)
            emitSeekRejected(.noActiveSession, target: seconds)
            return
        case .loading:
            // #178: don't drop a seek raced against load(). No hosts exist yet (forwarding would
            // no-op and flip state early, dropping the host's spinner), so stash the latest target
            // in the #127 slot and resolve it on the transition out of .loading (state didSet):
            // replay into a playable state, discard into a terminal one. Clamp/live guards re-run
            // at replay when the session is actually known; duration may still be unprobed here.
            pendingPreReadySeek = PendingPreReadySeek(seconds: seconds, origin: origin, exact: exact)
            clock.currentTime = duration > 0 ? max(0, min(seconds, duration)) : max(0, seconds)
            EngineLog.emit("[AetherEngine] seek(to:\(String(format: "%.2f", seconds))) stashed during load; will replay when the session settles (#178)", category: .engine)
            beginDeferredSeek(target: clock.currentTime)
            return
        default:
            break
        }
        // Live-only (no DVR): no rewind range; AVPlayer would stall or land on an unmaterialised segment.
        // Hosts should hide the scrubber when seekableLiveRange == nil; this guard is defence-in-depth.
        //
        // AE#446 round 4: it is the HOST's contract, and the engine's own rejoin was never party to it.
        // A client that keeps its rewind outside the engine loads with `dvrWindowSeconds` nil, and the
        // outage swap's carried position was refused here, on a session whose producer was still
        // holding the segment that position names.
        if isLive {
            guard let w = liveWindow else {
                EngineLog.emit("[AetherEngine] seek(to:\(seconds)) ignored: live, DVR disabled", category: .engine)
                emitSeekRejected(.liveWithoutDVR, target: seconds)
                return
            }
            if Self.liveSeekRefusedWithoutDVR(origin: origin, windowSeconds: w.windowSeconds) {
                EngineLog.emit("[AetherEngine] seek(to:\(seconds)) ignored: live, DVR disabled", category: .engine)
                emitSeekRejected(.liveWithoutDVR, target: seconds)
                return
            }
        }
        if !isLive, loadedOptions.sequentialOrigin || isSourceSeekable == false,
           !Self.sequentialSeekStaysResident(
               target: seconds,
               sequentialOrigin: loadedOptions.sequentialOrigin,
               loopbackSession: nativeVideoSession != nil && softwareHost == nil,
               residentRanges: residentRanges
           ) {
            EngineLog.emit("[AetherEngine] seek(to:\(seconds)) rejected: source is forward-only", category: .engine)
            // A seek stashed during load must relinquish its optimistic clock as well.
            let wasDeferred = deferredSeekInFlight
            endDeferredSeek(.superseded)
            if wasDeferred {
                clock.currentTime = nativeHost.map { displaySeconds(forPlaylistSeconds: $0.currentTime) }
                    ?? PresentationAxis.display(sourcePTS: clock.sourceTime, origin: sourcePresentationOrigin)
            }
            emitSeekRejected(.sourceNotSeekable, target: seconds)
            return
        }
        // #127: pre-ready native item (background-teardown reload, cold start): forwarding the seek now
        // would clamp to 0 against empty seekable ranges and replace load()'s pending startPosition seek.
        // Stash the latest target (publishing it optimistically so scrub UI follows) and replay at readiness.
        if Self.shouldDeferHostSeek(
            nativeSessionActive: nativeHost != nil && softwareHost == nil && audioHost == nil && !audioAVPlayerActive,
            isLive: isLive,
            nativeHostReady: nativeHost?.isReady ?? true
        ) {
            pendingPreReadySeek = PendingPreReadySeek(seconds: seconds, origin: origin, exact: exact)
            clock.currentTime = max(0, min(seconds, duration))
            EngineLog.emit("[AetherEngine] seek(to:\(String(format: "%.2f", seconds))) deferred until item ready (#127)", category: .engine)
            beginDeferredSeek(target: clock.currentTime)
            return
        }
        // VOD: clamp to [0, duration] in source PTS. Live/DVR: clamp to the window's
        // session-relative seekable range, and to the edge the ITEM is showing rather than the
        // running maximum the window keeps across ticks (AE#446 round 3, see `liveSeekLanding`).
        let liveLanding: (sessionTarget: Double, clockTarget: Double)? = isLive
            ? liveWindow.map {
                Self.liveSeekLanding(requested: seconds, window: $0,
                                     itemEnd: nativeItemSeekableEnd,
                                     shift: liveSessionShiftSeconds,
                                     axis: liveSessionSeekAxis,
                                     origin: origin,
                                     residentRange: origin == .liveRejoin || videoRoute == .loopback
                                        ? residentLiveRangeSessionSeconds() : nil,
                                     itemAxisOffset: liveItemAxisOffsetSeconds,
                                     // The effective allowance after a lease renewal or expiry (#714).
                                     nativePlayedTime: videoRoute == .loopback
                                        && $0.windowSeconds != nil
                                            ? currentTime : nil)
              }
            : nil
        var target: Double = isLive
            ? (liveLanding?.sessionTarget ?? seconds)
            : max(0, min(seconds, duration))
        if isLive, softwareHost != nil, nativeHost == nil, let window = liveWindow {
            let landing = Self.softwareLiveLanding(
                requested: target, window: window,
                holdbackSeconds: softwareHost?.liveHoldback.landingHoldbackSeconds
                    ?? AudioLookaheadPolicy.rebufferResumeLeadSeconds)
            if landing < target {
                EngineLog.emit(
                    "[AetherEngine] #104 SW live landing held \(String(format: "%.2f", target - landing))s "
                    + "back: requested=\(String(format: "%.2f", target))s "
                    + "landing=\(String(format: "%.2f", landing))s "
                    + "edge=\(String(format: "%.2f", window.edgeTime))s, "
                    + "so the ring holds the rebuffer lead instead of the clock waiting for it",
                    category: .engine)
            }
            target = landing
        }
        // AE#446 round 4: a rejoin on a session that advertises no rewind is the one landing measured
        // against something other than what `seekableLiveRange` states, so it says so. Whether the
        // place survived is the whole question the reader of this line has, so the line answers it.
        if isLive, origin == .liveRejoin {
            let resident = residentLiveRangeSessionSeconds()
            let held = abs(target - seconds) < 0.5
            let itemRange = nativeHost.map {
                "\(String(format: "%.2f", $0.seekableStart + liveSessionShiftSeconds + liveItemAxisOffsetSeconds))..\(String(format: "%.2f", $0.seekableEnd + liveSessionShiftSeconds + liveItemAxisOffsetSeconds))s"
            } ?? "no range"
            EngineLog.emit(
                "[AetherEngine] #446 rejoin to \(String(format: "%.2f", seconds))s"
                + (liveWindow?.windowSeconds == nil ? " on a session that advertises no rewind" : "")
                + "; the producer holds "
                + (resident.map { "\(String(format: "%.2f", $0.lowerBound))..\(String(format: "%.2f", $0.upperBound))s" }
                   ?? "a range it cannot state")
                + " and the item reports \(itemRange)"
                + ", landing at \(String(format: "%.2f", target))s"
                + (held ? ", the place it held" : ", which is as close to it as the cache still reaches"),
                category: .engine)
        }
        // AE#464 round 5: from here the seek target describes the session, not the load before it,
        // so a landing at exactly 0 is never read as a clock that has not published yet.
        positionUnderReconstruction = nil
        state = .seeking
        // Span isSeeking across the real landing, not just the optimistic .playing flip (#38).
        // Generation guard at each finalize point prevents a superseded seek from clearing it.
        let seekGen = advanceSeekGeneration()
        // A stash resolving into this seek hands its window over without a gap in `isSeeking`: the
        // deferred flag clears in the same recompute that sets the programmatic one.
        closeSeekTicket(&deferredSeekTicket, with: .superseded)
        deferredSeekInFlight = false
        deferredSeekTarget = nil
        // Whatever was in flight lost; its ticket closes here rather than at the generation guards, which
        // are spread over every exit of the deadline loop.
        closeSeekTicket(&programmaticSeekTicket, with: .superseded)
        programmaticSeekTicket = beginSeekTicket(origin: .programmatic, target: target)
        setProgrammaticSeek(inFlight: true, target: target)
        // Capture loadGeneration so the live finalize can detect a concurrent stop()/load()/zap
        // (which bumps loadGeneration in stopInternal but leaves seekGeneration untouched), matching
        // the VOD guard below. Without it a superseded live seek writes clock/state onto a torn-down session.
        let loadGen = loadGeneration
        if isLive {
            // Live/DVR native: translate session-time target into AVPlayer live clock via behind-delta
            // (robust if the edge advances between publish tick and seek; collapses to clockTarget = target - shift).
            // Live SW: drive the host's ring-backed DVR reseed directly; no AVPlayer-clock translation applies.
            if let host = softwareHost, nativeHost == nil {
                EngineLog.emit("[AetherEngine] SW live seek target=\(target)", category: .engine)
                // #416, and #107 round 2 for the axis: the ledger's notes and the overlay drainer's
                // playhead are both source-axis, so the anchor is stated there too.
                let targetSource = host.sourceSeconds(forSession: target)
                softwareSubtitlePacketStore?.noteHarvestAnchor(.pump, at: targetSource)
                await host.seek(to: target)
                guard loadGeneration == loadGen, seekGeneration == seekGen else { return }
                clock.currentTime = target
                // #107 round 2: `sourceTime` rides the RAW synchronizer clock everywhere else on
                // this path (see the `$sourceClockSeconds` sink), and the drainer reads it as its
                // playhead. Published session-relative here, a mid-stream-joined live source saw
                // one drain tick at a position its packet store has nothing at, and `drainPlan`
                // read the gap as an unannounced reposition and reset the cursor for it.
                clock.sourceTime = targetSource
                // Sodalite#104 round 2: the transport this publishes is the HOST's, the same way the
                // VOD landing below reads it off the host it just drove (#122, #292). The live branch
                // returns early and never got that rule, so a rewind issued while paused published
                // `.playing` over a host that `seekLiveDVR` had just anchored at rate 0: measured on
                // the harness, five ticks of `state=playing` over a clock that did not move, and the
                // next press then spent on a pause the host had already applied ("press Play, nothing;
                // press it again, it plays").
                state = (softwareHost?.isPlaying ?? true) ? .playing : .paused
                setProgrammaticSeek(inFlight: false, target: nil)
                closeSeekTicket(&programmaticSeekTicket, with: .landed(renderedTime: target))
                return
            }
            // Convert the sampled session target to the item clock. Live loopback uses its stable
            // session axis so a source PTS rollback cannot name a future, nonexistent item time.
            let clockTarget = liveLanding?.clockTarget ?? max(0, target - liveSessionShiftSeconds)
            EngineLog.emit("[AetherEngine] live seek target=\(target) clockTarget=\(clockTarget) "
                           + "seekableEnd=\(nativeItemSeekableEnd) sessionShift=\(liveSessionShiftSeconds) "
                           + "sourceShift=\(playlistShiftSeconds) "
                           + "publishedEdge=\(liveWindow?.edgeTime ?? 0)", category: .engine)
            // Publish target up front to hold the scrub clock while the host suppresses stale pre-seek reads.
            // Only currentTime takes the optimistic target; sourceTime stays on the rendered frame (#49).
            nativeClockSeconds = clockTarget
            clock.currentTime = target
            await nativeHost?.seek(to: clockTarget)
            guard loadGeneration == loadGen, seekGeneration == seekGen else { return }
            nativeClockSeconds = clockTarget
            clock.currentTime = target
            // publishLiveWindow on the next tick recomputes behindLiveSeconds.
            if let nativeHost {
                reconcileNativeSeekTransport(host: nativeHost, isStarved: false)
            } else {
                state = .playing
            }
            setProgrammaticSeek(inFlight: false, target: nil)
            closeSeekTicket(&programmaticSeekTicket, with: .landed(renderedTime: target))
            return
        }
        // #178: this seek supersedes any recovery re-anchor still holding the restart coalescer's
        // authoritative slot (it was computed for the seek being superseded). Released before the
        // host seek below so the new target's segment-driven restart cannot be dropped against a
        // locked slot. Live never reaches here (returned above); LiveReopen's anchors are safe.
        nativeVideoSession?.releaseSupersededAuthoritativeRestart()
        // Convert the (display-axis) target to AVPlayer's HLS clock. The origin re-adds a disc title's clip-0
        // STC base so `target` (0-based, matching duration) lands on the source-PTS shift the producer subtracts,
        // i.e. clockTarget == the 0-based playlist time (AE#105). Origin 0 off disc, so this stays
        // `target - playlistShiftSeconds` for normal VOD; SW/audio hosts run on source time (shift 0), no-op.
        var clockTarget = PresentationAxis.source(displayTime: target, origin: sourcePresentationOrigin) - playlistShiftSeconds
        // AE#418 round 2: AVPlayer throws a sub-second axis offset away at a seek and snaps back to
        // the playlist; a larger one it carries through unchanged (measured with `play
        // --picture-probe`: -0.500 and -0.875 read `axisErr=0.000` after a seek, -1.000 through
        // -11.000 all survive one). The target above is deliberately computed on the axis AVPlayer
        // still had when the seek was issued; from the landing forward the clock describes the axis
        // it will have instead.
        // AE#534: whether AVPlayer already HOLDS the landing, which is what decides if this seek
        // rebuilds its timeline and therefore whether it throws the axis away at all. Measured at
        // exactly this point before it went in: 0.10 ms median and 0.70 ms worst of 215 seeks, on an
        // idle and on a loaded box, including seeks issued on top of unsettled ones. That is the size
        // of `prepareSeekLanding` below, an off-main hop this path already takes unconditionally, so
        // this adds a second hop of a size already accepted here rather than a first one.
        //
        // An item that answers nothing reads as not placed, which is the behaviour this rule had
        // before, so a failed read costs the axis and never the session.
        let landingIsPlaced = nativeVideoSession != nil && nativeHost != nil
            ? await avPlayerLoadedRanges().contains { clockTarget >= $0.0 && clockTarget <= $0.1 }
            : false
        guard loadGeneration == loadGen, seekGeneration == seekGen else { return }
        nativeVideoSession?.snapAxisAfterSeek(
            landingItemSeconds: clockTarget, landingIsPlaced: landingIsPlaced)
        // AE#481: and what the landing's run carries is a READING, not the composition it inherits. A
        // seek that opens a new run at a segment written on its planned position lands on a source-true
        // stretch, which nothing else in the session ever looks at: measured on the #418 chain with the
        // re-anchoring seek last, the clock stayed 9 s over the picture from the landing to the end of
        // the session. Armed here rather than at the landing because the sampler waits for a run to
        // hold the target anyway, and a superseded seek cancels it.
        if let session = nativeVideoSession, nativeHost != nil {
            verifyAxisAtSeekLanding(session: session, landingItemSeconds: clockTarget)
        }
        // AE#412: inside a keyframe drought, audio opened plan boundaries the keyframe-gated cutter
        // folded, so the landing segment can carry no random-access point at all. AVPlayer reaches
        // back a fixed few seconds on a cold seek and does not look for one, so the picture would
        // start at the next sync sample ABOVE the target and the seek would silently skip content
        // (measured: a seek to 50.0 s landed at 55.0 s on a 12 s drought). This re-cuts that segment
        // from its covering random-access point so it covers the target before the seek goes out.
        // The target itself is unchanged: AVPlayer places the re-cut segment at its own tfdt inside
        // the timeline it is already building. Off the main actor: it parks on the pump.
        clockTarget = await Self.prepareSeekLanding(
            session: nativeVideoSession, itemSeconds: clockTarget)
        guard loadGeneration == loadGen, seekGeneration == seekGen else { return }
        let gen = loadGeneration
        // Publish the native-path seek target up front so the scrub clock snaps immediately (#37); the host
        // suppresses periodic-observer reads until landing. SW/audio hosts resolve synchronously and write
        // the clock only at finalize.
        let nativeOnly = !audioAVPlayerActive && audioHost == nil && softwareHost == nil && nativeHost != nil
        if nativeOnly {
            // Optimistic scrub clock; sourceTime holds the rendered frame via $renderedTime sink until landing (#49).
            nativeClockSeconds = clockTarget
            clock.currentTime = target
        }
        // #254: the SW/audio hosts reposition their demuxer under a read deadline, off the main actor.
        // A reposition that spends its budget leaves the read position undefined and nothing re-issues
        // it, unlike the native recovery path whose ticket stays open for a late landing, so that case
        // closes this ticket terminally as `.stalled` instead of claiming a landing it cannot back up.
        // PR #943: AV1 through dav1d lands on a keyframe unless the host asked for the exact position.
        // Decided here, so the harvest anchor below and the finalize describe where the pump restarts.
        if !exact, let host = softwareHost, let landing = host.keyframeLanding(forSession: clockTarget) {
            target += landing - clockTarget
            clockTarget = landing
        }
        var hostReposition: Demuxer.RepositionOutcome = .landed
        if audioAVPlayerActive, let host = audioAVPlayerHost {
            await host.seek(to: clockTarget)
        } else if let host = audioHost {
            hostReposition = await host.seek(to: clockTarget)
        } else if let host = softwareHost {
            // #416: the software pump is this path's subtitle harvest, and it reads forwards from
            // wherever this reposition puts it. Everything between where it had got to and here is
            // ground nobody read; the drain must not read an empty store there as an authored
            // silence. Stated before the seek: the demuxer lands at or before the target.
            //
            // #107 round 2: on the SOURCE axis, like every other note this ledger takes. The pump
            // reports its progress from `sourceTime` (`subtitleDrainTick`), so an anchor left on
            // the session axis opens a run below every note that follows it, and `noteReach` has
            // no unannounced-advance guard to catch the gap. On a mid-stream-joined source that
            // silently extends one run over the whole offset, which is exactly the claim
            // `SubtitleHarvestCoverage` exists to refuse.
            softwareSubtitlePacketStore?.noteHarvestAnchor(
                .pump, at: host.sourceSeconds(forSession: clockTarget))
            hostReposition = await host.seek(to: clockTarget)
        } else {
            // #93 retest: remember the target as recovery intent BEFORE awaiting; a wedged seek
            // never lands and the recovery chain must aim here, not at the frozen clock.
            setPendingRecoverySeekTarget(clockTarget)
            refreshNativeBufferedPosition()
            pendingSeekProgressAccum = 0
            let renderedAtSeekStart = nativeHost?.renderedTime ?? 0
            pendingSeekInitialRenderedPosition = renderedAtSeekStart
            lastRenderedForPendingSeek = renderedAtSeekStart
            // Direction of travel for landing detection: a forward seek's playhead climbs from the old
            // position toward (and, once playing, PAST) the target; a backward seek's descends to it.
            let seekIsForward = clockTarget >= renderedAtSeekStart
            // Await real AVPlayer landing so isSeeking spans it (#37/#38), but bound the wait (#65): a seek
            // AVPlayer can never land (producer-wedge starvation) must not leave the optimistic clock latched
            // forever. A normal/slow-but-buffering seek lands or keeps buffering well within the budget.
            var deadlineExtensionsUsed = 0
            // Last observed buffer AT the target, so an extension can require the island to be GROWING
            // rather than merely present: a producer that served 4 s and then died reads identically to
            // one still filling, and presence alone would buy it the whole extension budget.
            var lastTargetIslandSeconds: Double?
            // Recovery fallthrough state (backward-into-unbuffered / true wedge / budget exhausted):
            // once the producer is re-anchored at the target we hold the clock there and wait on the
            // re-issued seek for a bounded number of windows rather than reverting to the old position.
            var reanchored = false
            var postReanchorWaits = 0
            var landed = await nativeHost?.seek(to: clockTarget,
                                                deadlineSeconds: Self.nativeSeekReconcileBudgetSeconds) ?? true
            deadlineLoop: while !landed {
                // Deadline expired. Only the surviving (winning) generation reconciles; a superseded seek
                // returns at the guard below and lets the newer seek own the final state.
                guard loadGeneration == gen, seekGeneration == seekGen else { return }
                guard let host = nativeHost else {
                    EngineLog.emit(
                        "[AetherEngine] seek deadline expired after native host teardown",
                        category: .engine
                    )
                    return
                }
                // The `$renderedTime` sink can finalize this very seek underneath the loop, and its
                // landing predicate is deliberately looser than the loop's: `pendingSeekLanded` accepts
                // any rendered position within ±5 s of the target (symmetric), while `seekLandedAtTarget`
                // wants ±0.75 s on the near side. A landing 3 s short of the target therefore settles the
                // clock and runs `finalizeLateRecoverySeekLanding` (clearing the seek gate, reconciling the
                // transport) while this loop still reads "not landed" and would go on to re-anchor the
                // producer and re-issue a backward seek on an item that is already playing, the exact
                // yank the overshoot rule above exists to prevent. `programmaticSeekInFlight` is the
                // authoritative "this seek is still ours" latch: it is set before the first host seek and
                // cleared only by a finalize (here, in the sink, or at the give-up) or `stopInternal`.
                guard programmaticSeekInFlight else {
                    EngineLog.emit(
                        "[AetherEngine] seek finalized elsewhere while the deadline loop waited "
                        + "(late landing settled through the rendered-time sink); leaving recovery to it",
                        category: .engine
                    )
                    return
                }
                // Cancellation of the calling task must not be spent running the recovery at full speed.
                // `awaitPendingSeekLanding` sleeps on the caller's task, so a cancelled `Task.sleep` throws
                // instantly and every remaining window returns `false` in microseconds: the loop would burn
                // its whole budget in one runloop turn and still restart the producer on the way through.
                // (`host.seek(to:deadlineSeconds:)` runs its deadline on a detached task and is unaffected,
                // which is why this could not happen before the wait windows existed.) Terminate on the
                // give-up contract instead: clock held at the target, gate cleared, honest phase reported.
                guard !Task.isCancelled else {
                    setProgrammaticSeek(inFlight: false, target: nil)
                    reportSeekStalled()
                    reconcileNativeSeekTransport(host: host, isStarved: true)
                    EngineLog.emit(
                        "[AetherEngine] seek deadline recovery cancelled; holding clock at target "
                        + "\(String(format: "%.2f", target))s without re-anchoring",
                        category: .engine
                    )
                    return
                }
                pendingRecoverySeekDeadlineExpired = true
                let avpReal = host.renderedTime
                // The deadline continuation and AVPlayer completion are both MainActor jobs. If the
                // completion published renderedTime first, its sink still saw deadlineExpired=false.
                // Catch that ordering now; otherwise the later publication will settle through the sink.
                if Self.shouldCatchUpDeadlineLanding(
                    renderedTimePublished: host.latestSeekRenderedTimePublished
                ),
                   settleRecoveryClockIfRenderedTargetLanded(
                       rendered: avpReal,
                       shift: playlistShiftSeconds,
                       completionRenderedTimePublished: true
                   ) {
                    nativeClockSeconds = avpReal
                    clock.sourceTime = avpReal + playlistShiftSeconds
                    setProgrammaticSeek(inFlight: false, target: nil)
                    closeSeekTicket(&programmaticSeekTicket,
                                    with: .landed(renderedTime: PresentationAxis.display(
                                        sourcePTS: avpReal + playlistShiftSeconds,
                                        origin: sourcePresentationOrigin)))
                    reconcileNativeSeekTransport(host: host, isStarved: false)
                    EngineLog.emit(
                        "[AetherEngine] seek landed while deadline ownership transferred; "
                        + "reconciled from rendered \(String(format: "%.2f", avpReal))s",
                        category: .engine
                    )
                    return
                }
                // Overshoot landing: a zero-tolerance seek lands AT the target, then a *playing* item keeps
                // moving in the seek direction while the deadline continuation settles, so a forward seek can
                // render a GOP PAST the target (device: rendered=1289.70 vs target=1288.14, contiguous buffer,
                // timeControlStatus=playing). The old tolerance treated that overshoot as "not landed" and the
                // fallthrough re-seeked backward to the exact target, dragging a playing playhead back ~1.5s and
                // re-stalling it (Brandon: "loading even though it had already started playing, then reverted
                // back a second or 2"). Accept a landing at/past the target in the seek direction and finalize;
                // NEVER issue a backward correction for a forward overshoot (overshoot is strictly better for
                // the user than a re-stall + yank). The opposite bound stays tight so the pinned pre-seek
                // playhead (forward: far below target; backward: far above) is never mistaken for a landing.
                if Self.seekLandedAtTarget(
                    rendered: avpReal, target: clockTarget, forward: seekIsForward) {
                    EngineLog.emit(
                        "[AetherEngine] seek landed at deadline "
                        + "(rendered=\(String(format: "%.2f", avpReal))s "
                        + "target=\(String(format: "%.2f", clockTarget))s "
                        + "\(seekIsForward ? "fwd" : "back")); finalizing without re-seek",
                        category: .engine
                    )
                    landed = true
                    break deadlineLoop
                }
                // AE#141: a progressing producer is only worth preserving when its march can actually
                // deliver the pending target. A far-forward target beyond coverage (640 s target, march at
                // ~316 s) rides 3x30 s serve timeouts into item death if left to "land late", and the
                // old-position buffer health cannot see that. Computed BEFORE the extend branch so it can
                // veto an extension too -- granting 16 s of "land late" to an unreachable target is exactly
                // what AE#141 forbids.
                //
                // Uses the immutable local `clockTarget`, not the published `pendingRecoverySeekClockTarget`:
                // the $renderedTime sink can retire that field mid-flight (organic progress far from the
                // target reads as "seek abandoned"), and a nil there would both weaken this gate and make
                // `recoveryAnchorPosition` fall back to the frozen OLD position -- re-anchoring the producer
                // at the very spot the user is leaving while the clock is held at, and the seek re-issued
                // to, the target.
                let targetBeyondCoverage: Bool = {
                    guard let session = nativeVideoSession else { return false }
                    return !session.producerCoversPlaylistTime(clockTarget)
                }()
                // DV/SMB forward-seek revert fix: `seekIsWedged`/`bufferedEnd` only measure the buffer
                // contiguous with AVPlayer's pre-seek playhead, which stays pinned during a pending
                // zero-tolerance forward seek, so a slow-but-working forward seek (the producer IS
                // serving the target) reads identically to a true wedge. Reconciling here (clock revert +
                // producer re-anchor) would discard the in-flight download and park the session flapping on
                // a slow SMB source. Measure what the producer has actually served AT the target instead,
                // and extend only while that is above the floor AND still growing.
                // A backward seek excludes the abandoned playhead's own buffer explicitly: the measurement
                // window is only wide enough to keep a FAR backward target clear of it, and a near one
                // (less than the window back) would otherwise read the old, full buffer as progress at the
                // target and earn an extension the producer never served.
                // AE#422: one off-main reading for both figures. This loop runs while a seek is not
                // landing, so every synchronous read here is taken in the state where the media
                // server is least likely to answer, and it was doing four of them per pass.
                let bufferSnapshot = await host.seekBufferSnapshot(
                    target: clockTarget, excludeAtOrAbove: seekIsForward ? nil : avpReal)
                let targetIsland = bufferSnapshot.targetIsland
                if Self.shouldExtendSeekDeadlineForProgress(
                    targetIslandSeconds: targetIsland,
                    previousIslandSeconds: lastTargetIslandSeconds,
                    extensionsUsed: deadlineExtensionsUsed,
                    maxExtensions: Self.nativeSeekMaxDeadlineExtensions,
                    islandFloor: Self.nativeSeekProgressIslandFloorSeconds,
                    targetBeyondProducerCoverage: targetBeyondCoverage
                ) {
                    deadlineExtensionsUsed += 1
                    lastTargetIslandSeconds = targetIsland
                    // Re-assert the optimistic scrub clock at the target: the host cleared seekInFlight at
                    // the deadline, un-gating the periodic observer, which could otherwise stick the clock
                    // at the old playhead while the island fills. `awaitPendingSeekLanding` re-gates it and
                    // waits on the SAME in-flight seek (no new avPlayer.seek, so the loaded target island is
                    // not flushed); the producer is deliberately NOT restarted, and together that preserves the
                    // in-flight target download that the old re-anchor discarded (the ~40s device stall).
                    nativeClockSeconds = clockTarget
                    clock.currentTime = target
                    EngineLog.emit(
                        "[AetherEngine] seek slow but producer serving target "
                        + "(island=\(String(format: "%.2f", targetIsland))s at target, "
                        + "rendered=\(String(format: "%.2f", avpReal))s "
                        + "buffered=\(String(format: "%.2f", bufferSnapshot.bufferedEnd))s); extending budget "
                        + "\(deadlineExtensionsUsed)/\(Self.nativeSeekMaxDeadlineExtensions)",
                        category: .engine
                    )
                    landed = await host.awaitPendingSeekLanding(
                        target: clockTarget,
                        deadlineSeconds: Self.nativeSeekExtensionBudgetSeconds,
                        forward: seekIsForward)
                    continue deadlineLoop
                }
                lastTargetIslandSeconds = targetIsland
                // No forward island (or extend budget exhausted). This is a true wedge, a
                // backward-into-unbuffered seek (the target sits BEHIND the frozen playhead, so
                // `avPlayerBufferAheadSeconds` never counts it -> island is structurally 0), or a
                // forward seek that spent its whole extension budget. The old recovery reverted the
                // clock to the frozen rendered position and reconciled the transport, which on a slow
                // DV/SMB source is exactly the device-reported failure: the scrubber visibly jumps back
                // to the pre-seek spot and the session flaps paused<->playing for ~40s while the old
                // segment drains. Instead HOLD the clock at the target (same UX contract as the extend
                // branch: scrubber parked at target + buffering spinner), re-anchor the producer to the
                // target once, re-issue the seek so AVPlayer abandons the old-position buffer and targets
                // the re-anchored region, and wait for it to land -- reconciling FORWARD to the target,
                // never back to the rendered position.
                let wasStarved = seekIsWedged(
                    renderedTime: avpReal, bufferedEnd: bufferSnapshot.bufferedEnd)
                // `targetBeyondCoverage` (AE#141) was computed above, before the extend branch, so it
                // gates both the extension and this re-anchor decision.
                let reason = wasStarved
                    ? "starved"
                    : (targetBeyondCoverage
                        ? "old position still buffered, target beyond producer coverage"
                        : "old position still buffered")
                // Hold the optimistic clock at the target; pendingRecoverySeekClockTarget stays set so
                // applyNativeHostClockTick keeps it there between ticks (no revert to the old playhead).
                nativeClockSeconds = clockTarget
                clock.currentTime = target
                if !reanchored {
                    reanchored = true
                    postReanchorWaits = 0
                    let recoveryAnchor = Self.recoveryAnchorPosition(
                        frozenPosition: avpReal, pendingSeekTarget: clockTarget,
                        currentRendered: avpReal)
                    let didReanchor = Self.shouldReanchorProducerAfterSeekDeadline(
                        isStarved: wasStarved, targetBeyondProducerCoverage: targetBeyondCoverage)
                    if didReanchor {
                        reanchorProducerToPlaylistTime(recoveryAnchor)
                        // The playhead will jump when the restarted producer lets the pending seek land.
                        reanchorSubtitleOverlays()
                        pendingRecoverySeekSubtitlesReanchored = true
                    }
                    EngineLog.emit(
                        "[AetherEngine] seek did not land within budget "
                        + "(\(deadlineExtensionsUsed) extension\(deadlineExtensionsUsed == 1 ? "" : "s"); "
                        + "\(reason), "
                        + "island=\(String(format: "%.2f", targetIsland))s at target, "
                        + "rendered=\(String(format: "%.2f", avpReal))s "
                        + "buffered=\(String(format: "%.2f", bufferSnapshot.bufferedEnd))s); holding clock at target "
                        + "\(String(format: "%.2f", target))s"
                        + (didReanchor
                            ? " and re-anchored producer at \(String(format: "%.2f", recoveryAnchor))s, re-seeking"
                            : ", re-seeking without restarting the progressing producer"),
                        category: .engine
                    )
                    // Re-issue the seek toward the (re-anchored) target. A deadline does not cancel the
                    // prior seek, but this fresh zero-tolerance seek supersedes it and points AVPlayer at
                    // the re-anchored region so it stops waiting on the abandoned old-position segments.
                    landed = await host.seek(to: clockTarget,
                                             deadlineSeconds: Self.nativeSeekExtensionBudgetSeconds)
                    continue deadlineLoop
                }
                // Already re-anchored + re-seeked. Keep holding the clock at the target and wait on the
                // re-issued seek for a bounded number of windows; the re-anchored producer is serving the
                // target so it should land within a couple of GOP fetches on any workable source.
                if postReanchorWaits < Self.nativeSeekMaxDeadlineExtensions {
                    postReanchorWaits += 1
                    EngineLog.emit(
                        "[AetherEngine] holding clock at target \(String(format: "%.2f", target))s while "
                        + "re-anchored producer serves it (wait \(postReanchorWaits)/"
                        + "\(Self.nativeSeekMaxDeadlineExtensions))",
                        category: .engine
                    )
                    landed = await host.awaitPendingSeekLanding(
                        target: clockTarget,
                        deadlineSeconds: Self.nativeSeekExtensionBudgetSeconds,
                        forward: seekIsForward)
                    continue deadlineLoop
                }
                // Budget fully spent and still buffering after the re-anchor. Keep the clock held at the
                // target (no revert, no scrubber jump-back -- the whole point of this path), but do NOT
                // stay `.seeking`: `programmaticSeekInFlight`/`isSeeking` are cleared only by
                // setProgrammaticSeek, finalizeLateRecoverySeekLanding, or stopInternal, and none of those
                // is on a timer. Both $renderedTime exits require host.renderedTime to be PUBLISHED again,
                // which the periodic observer does not do while waitingToPlayAtSpecifiedRate and the seek
                // completion withholds while buffering (#123). On a source that never serves the target --
                // an SMB share dropped mid-seek, a dead producer, the #65 wedge signature of "stall with no
                // surfaced failure" -- nothing would ever fire and the engine would park in `.seeking`
                // forever. That is the permanent-spinner class this whole change exists to remove, so
                // relocating it to the give-up is not acceptable.
                //
                // Report the honest phase instead: clear the programmatic-seek gate and reconcile the
                // transport as starved, which surfaces `.rebuffering`/`.stalled` rather than an
                // indistinguishable infinite spinner. `pendingRecoverySeekClockTarget` deliberately stays
                // set so the clock keeps holding at the target and the producer keeps aiming there; a late
                // landing still settles through the sink, where finalizeLateRecoverySeekLanding is then a
                // harmless no-op.
                setProgrammaticSeek(inFlight: false, target: nil)
                reportSeekStalled()
                reconcileNativeSeekTransport(host: host, isStarved: true)
                EngineLog.emit(
                    "[AetherEngine] seek still buffering after re-anchor + full budget "
                    + "(\(Self.nativeSeekMaxDeadlineExtensions) waits); holding clock at target "
                    + "\(String(format: "%.2f", target))s (no revert), reported as stalled",
                    category: .engine
                )
                return
            }
        }
        // Guard: stop/load during the await tore the session down; writing clock state would publish a phantom.
        // A superseding seek owns the final state.
        guard loadGeneration == gen, seekGeneration == seekGen else { return }
        setPendingRecoverySeekTarget(nil)
        if softwareHost != nil, hostReposition != .landed {
            setProgrammaticSeek(inFlight: false, target: nil)
            closeSeekTicket(&programmaticSeekTicket,
                            with: hostReposition == .superseded ? .superseded : .stalled)
            // Host failure sinks may already have published .error. Never overwrite it with
            // .playing/.paused or publish the requested position as though it was reached.
            if hostReposition == .stalled {
                if case .error = state {} else {
                    publishError(.softwarePipelineFailed, "Playback source could not reposition.")
                }
            }
            return
        }
        // Publish the measured native landing, not the optimistic request. The two can differ
        // slightly even after a successful callback; subtitle anchors and SeekEvent must agree.
        let landedClock = nativeOnly ? (nativeHost?.currentTime ?? clockTarget) : clockTarget
        let landedDisplay = nativeOnly ? displaySeconds(forPlaylistSeconds: landedClock) : target
        nativeClockSeconds = landedClock
        clock.currentTime = landedDisplay
        let landedSourcePTS = PresentationAxis.source(displayTime: landedDisplay, origin: sourcePresentationOrigin)
        // #123: only settle sourceTime onto the target when the landed frame is actually presented (see
        // applySeekFinalizeSourceTime); while buffering toward it the picture is frozen behind the target,
        // so hold sourceTime on the rendered frame and let the $renderedTime sink settle it when the frame
        // is delivered.
        applySeekFinalizeSourceTime(target: landedSourcePTS,
                                    bufferingTowardTarget: nativeHost?.isBufferingTowardSeekTarget ?? false)

        // #100 + #96: the playhead jumped; re-anchor the overlay subtitle readers at the landed source-PTS.
        reanchorSubtitleOverlays()

        // Seek has physically landed. #122: preserve the transport intent in effect when the seek
        // was issued: a scrub started while paused lands paused, so the engine never reports playing
        // after a paused scrub and the #93 recovery reassert can't misread the paused landing as a
        // spurious pause and call host.play().
        // #292: the SW/audio hosts carry that intent through their seek window now, so read it off
        // them instead of defaulting to `.playing`. Reporting playing over a host that landed paused
        // is half of what the #292 report describes. AVPlayer-backed audio keeps the default.
        if let nativeHost {
            reconcileNativeSeekTransport(host: nativeHost, isStarved: false)
        } else if !audioAVPlayerActive, let hostIsPlaying = softwareHost?.isPlaying ?? audioHost?.isPlaying {
            state = hostIsPlaying ? .playing : .paused
        } else {
            state = .playing
        }
        // AetherEngine#164: a VOD scrubbed to its final frame is parked, not playing. Override the
        // reconcile's `.playing` with an honest `.paused` (non-terminal, so the scrubber stays live and
        // `play()` can rewind + replay). `.ended` stays reserved for organic completion (#63).
        if let parked = Self.seekEndParkState(target: target, duration: duration, isLive: isLive) {
            state = parked
        }
        // #394 follow-up: the audio host writes the buffering level only on its own rebuffer edges, and a
        // starve that began inside the seek window carries no edge across the landing (on the way in the
        // `.seeking` gate suppressed the level). Re-read it against the state this finalize just settled,
        // or a seek into an unbuffered span lands as a frozen `.playing`, the very shape the axis exists
        // to end. The native path already reconciles its own level in reconcileNativeSeekTransport.
        if audioAVPlayerActive, let host = audioAVPlayerHost {
            isBuffering = state == .playing && host.isRebuffering
        }
        setProgrammaticSeek(inFlight: false, target: nil)
        // `sourceTime` is the on-screen frame (#49/#123): the honest landing position, which keyframe
        // granularity or a still-draining chase can put a little off the target. Folded onto the display
        // axis because that is the axis the ticket's `target` is on (AE#270; identity off disc and off a
        // PTS-origin source).
        closeSeekTicket(&programmaticSeekTicket,
                        with: Self.seekTicketOutcome(
                            hostReposition: hostReposition,
                            renderedTime: PresentationAxis.display(sourcePTS: clock.sourceTime,
                                                                   origin: sourcePresentationOrigin)))
    }

    /// #254: how a SW/audio-host reposition maps onto this seek's ticket. A reposition that spent its
    /// read-deadline budget left the read position undefined, and nothing on that path re-issues it:
    /// the native recovery loop can leave its ticket open because AVPlayer keeps aiming at the target
    /// and a late `.landed` still arrives, while here no one does. So it closes terminally as
    /// `.stalled` rather than claiming a landing it cannot back up.
    nonisolated static func seekTicketOutcome(
        hostReposition: Demuxer.RepositionOutcome, renderedTime: Double
    ) -> SeekEvent.Outcome {
        hostReposition == .stalled ? .stalled : .landed(renderedTime: renderedTime)
    }

    /// #112 rework: the playhead jumped (seek landing or wedge reconcile). Reset the PGS
    /// stale-arrival gates (#100: a held stale arrival belongs to the old position) and reset the
    /// CC tap at the discontinuity. Drained overlay channels keep their retained cues: a backward
    /// in-window seek re-displays instantly (the old retained-coverage semantics), and the drainer's
    /// jump detection rebuilds its decoder and re-decodes the window around the new position on the
    /// next tick.
    func reanchorSubtitleOverlays() {
        pgsStaleArrivalGates = [:]
        if activeEmbeddedSubtitleStreamIndex >= 0,
           activeSubtitleStreamIsClosedCaption(activeEmbeddedSubtitleStreamIndex) {
            subtitleCues = []
            ccCueSnapshot = []
            closedCaptionTap?.requestReset()
        }
    }

    /// Re-base the loopback producer onto the recovery position after a seek deadline, so the
    /// segments AVPlayer is waiting for get produced. requestRestart does blocking teardown
    /// (old.stop + waitForFinish up to 5s) and is designed to run off-main, so dispatch it detached.
    private func reanchorProducerToPlaylistTime(_ seconds: Double) {
        guard let session = nativeVideoSession else { return }
        BlockingWork.detached {
            let idx = session.segmentIndexForPlaylistTime(seconds)
            // Authoritative re-anchor: deadline recovery must win the coalescer over any stale
            // in-flight scrub target.
            session.requestRestart(at: idx, authoritative: true)
        }
    }

    /// #129 kept a progressing producer at the seek deadline (restarting discards useful fill);
    /// AE#141 narrows that: preservation only pays when the march can reach the pending target.
    nonisolated static func shouldReanchorProducerAfterSeekDeadline(
        isStarved: Bool, targetBeyondProducerCoverage: Bool
    ) -> Bool {
        isStarved || targetBeyondProducerCoverage
    }

    /// Pure decision: on a seek-deadline expiry, should the engine grant another (shorter) extension
    /// window instead of reverting the clock + re-anchoring the producer?
    ///
    /// Yes only while the producer is *demonstrably* serving the target. Three conditions:
    ///
    /// - `targetIslandSeconds >= islandFloor`: enough media is buffered AT the target to call it served.
    /// - The island is still **growing** (`targetIslandSeconds > previousIslandSeconds + growthEpsilon`),
    ///   except for the first extension, which has no earlier sample to compare against. Presence alone is
    ///   a single observation and cannot distinguish a producer that is still filling from one that
    ///   buffered a few seconds and then died, and the latter would otherwise buy the full 16 s of extensions
    ///   while nothing happens.
    /// - `targetBeyondProducerCoverage == false`: AE#141: a target the producer's march cannot reach
    ///   rides serve timeouts into item death if left to "land late", so it must never be granted an
    ///   extension no matter how healthy the buffer looks.
    ///
    /// Plus the budget check. This keeps a slow-but-working forward seek (DV/SMB) from being converted
    /// into a permanent wedge by a recovery that would discard the in-flight download, without letting a
    /// dead or unreachable one sit for the whole budget.
    nonisolated static func shouldExtendSeekDeadlineForProgress(
        targetIslandSeconds: Double,
        previousIslandSeconds: Double?,
        extensionsUsed: Int,
        maxExtensions: Int,
        islandFloor: Double,
        targetBeyondProducerCoverage: Bool,
        growthEpsilon: Double = 0.25
    ) -> Bool {
        guard extensionsUsed < maxExtensions else { return false }
        guard !targetBeyondProducerCoverage else { return false }
        guard targetIslandSeconds >= islandFloor else { return false }
        guard let previous = previousIslandSeconds else { return true }
        return targetIslandSeconds > previous + growthEpsilon
    }

    nonisolated static func shouldCatchUpDeadlineLanding(
        renderedTimePublished: Bool
    ) -> Bool {
        renderedTimePublished
    }

    /// Pure decision: has a zero-tolerance seek physically landed at the target by the deadline, allowing
    /// for a directional overshoot? A zero-tolerance `avPlayer.seek` lands AT the target, but a *playing*
    /// item keeps advancing in the seek direction while the deadline continuation settles, so by the time
    /// the engine samples `rendered` a forward seek can sit a GOP PAST the target and a backward seek a
    /// hair past it (downward). Accept a landing at/past the target in the seek direction; keep the
    /// opposite bound tight (`tolerance`) so the pinned pre-seek playhead (which sits far BELOW the target
    /// for a forward seek and far ABOVE it for a backward seek until the seek completes) is never mistaken
    /// for a landing. Prevents the fallthrough from issuing a backward exact re-seek to "correct" a forward
    /// overshoot (which drags a playing playhead back and re-stalls it).
    nonisolated static func seekLandedAtTarget(
        rendered: Double,
        target: Double,
        forward: Bool,
        tolerance: Double = 0.75
    ) -> Bool {
        guard rendered.isFinite else { return false }
        return forward ? rendered >= target - tolerance : rendered <= target + tolerance
    }

    /// Deprecated alias. The engine clock is now unified onto source PTS; prefer `seek(to:)` in new code.
    @available(*, deprecated, renamed: "seek(to:)")
    public func seek(toSourceTime seconds: Double) async {
        await seek(to: seconds)
    }

    /// Stop playback and tear the session down.
    ///
    /// - Parameter resetDisplayCriteria: `true` (default) returns the panel to its default HDMI mode
    ///   (tvOS). Pass `false` for a stop that hands off to another load(): the current criteria stays on
    ///   AVDisplayManager, so a same-mode follow-up overwrites it in place instead of bouncing the panel
    ///   through SDR (#128). The caller owns the follow-up; if no load() happens after all, the app UI
    ///   stays in the playback mode until a plain stop() clears it. Note that back-to-back load() calls
    ///   preserve the criteria on their own; the flag only matters when stop() is called between items.
    ///
    /// - Parameter finalTeardown: whether this stop means "leaving playback entirely" rather than handing
    ///   off to another `load()`. Defaults to `resetDisplayCriteria`, which is the right answer for almost
    ///   every caller, but the two are separable: a host that keeps display criteria across a stop/load
    ///   pair (`resetDisplayCriteria: false`) and *is* genuinely leaving playback can pass
    ///   `finalTeardown: true`. Only a final teardown honours `deactivatesAudioSessionOnStop`.
    /// Keep the current native `AVPlayerItem` attached until the next `load()` replaces it atomically.
    ///
    /// Call immediately before a foreground playlist or episode replacement when the host mounts the
    /// engine's own player layer and a nil-item gap would leave it black. The request is consumed by
    /// the next `load()` and has no effect when the outgoing session is not on the native backend.
    /// It does not pause, stop, or otherwise change transport state; a `stop()` before the next load
    /// cancels it. PiP hosts do not need this: an active PiP window already forces the handover.
    public func prepareForItemReplacement() {
        nextLoadRequestsInPlaceItemHandover = true
    }

    public func stop(resetDisplayCriteria: Bool = true, finalTeardown: Bool? = nil) {
        cancelPendingAudioSelection()
        releaseHeldPicture(reason: "stop")
        nextLoadRequestsInPlaceItemHandover = false
        stopInternal(resetDisplayCriteria: resetDisplayCriteria,
                     finalTeardown: finalTeardown ?? resetDisplayCriteria,
                     cacheCleanupReason: .sessionStopped)
        state = .idle
        // #361: the sequence ends here without ever reaching its last checkpoint, which is the whole
        // point: nothing about a stop should read as a finished startup. Cleared in stop() and not in
        // stopInternal, because every load() runs stopInternal and a reroute's teardown must leave the
        // startup it is still serving alone.
        startupProgress = nil
        clock.currentTime = 0
        clock.bufferedPosition = 0
        clock.progress = 0
        // Clear session state; without this, metadata/track lists/format/pendingExternalMetadata from the
        // previous session survive until the next load and bleed into unrelated sessions.
        duration = 0
        metadata = nil
        audioTracks = []
        subtitleTracks = []
        teardownLiveSubtitleRenditions()   // AE#359
        externalSubtitleRegistry = [:]
        nextExternalSubtitleOrdinal = 0
        hostExplicitSubtitleAction = false
        setSecondarySubtitleIdentity()
        backgroundTeardownSelection = nil     // #357: leaving playback is not a reload
        pendingNativeRenderingRequest = nil   // #170: the session the latched request targeted is gone
        externalNativeStoreFillTask?.cancel()
        externalNativeStoreFillTask = nil
        resetSubtitleOCRState()   // Phase D: new session, new axis
        remoteHLSSubtitleDiscoveryTask?.cancel()
        remoteHLSSubtitleDiscoveryTask = nil
        audibleReadbackTask?.cancel()
        audibleReadbackTask = nil
        cancelNativeLegibleDeselectPin()   // Sodalite#65: the pin belongs to the item being torn down
        // #316: the proxy serves exactly one session's master; a standing socket outliving it would keep a
        // port and a decode task alive for a source nobody plays any more.
        remoteHLSSubtitleProxy?.tearDown()
        remoteHLSSubtitleProxy = nil
        injectedSubtitleRenditionNames = [:]
        detachRemoteHLSCueClock()   // AE#616
        // Font attachments are session-scoped but must survive stopInternal (audio-track-switch skips the probe;
        // clearing in stopInternal would leave the session with an empty font list after any audio switch).
        fontAttachments = []
        // Container chapters belong to the source URL, not to the pipeline: the internal reopens of the same
        // source (audio switch, iOS background return, #127 expiry) run through stopInternal without
        // re-probing, so stopInternal leaves them alone. This is the end of the session, so they go here,
        // and the next load probes the new source. Disc chapters are cleared by stopInternal: a title
        // switch really does change them, and the reload path recaptures them from the reopened demuxer.
        containerChapterSource = nil
        mediaChapters = []
        videoFormat = .sdr
        sourceDVBLCompatID = nil
        sourceDolbyVisionBaseLayerPresentable = false
        sourceVideoFormat = .sdr
        sourceDVProfile = nil
        dolbyVisionConversion = nil
        sourceCarriesHDR10PlusMetadata = false
        sourceElType = nil
        outputRouteFrameRate = nil
        sourceUpscalePlan = nil
        sourceUpscaleDisabled = nil
        sourceSoftwareOnlyForUpscale = false
        sourceUpscaleFrameRate = nil
        sourceDolbyVisionRPUProfile = nil
        sessionPanelHDRReadout = nil
        sessionObservedDisplayCaps = nil
        sourceVideoFrameRate = nil
        sourceVideoScan = .unknown
        sourceVideoBitrate = 0
        sourceVideoStreamFormat = nil
        decodedVideoFormat = nil
        sourceVideoCodecName = nil
        sourceContainerFormat = nil
        sourceVideoWidth = 0
        sourceVideoHeight = 0
        sourceVideoPixelAspectRatio = 1
        pendingExternalMetadata = []
        #if os(tvOS) || os(iOS)
        // Same lifetime as pendingExternalMetadata: session identity the host staged, cleared when the
        // host leaves playback so the next session cannot inherit the previous title's system card.
        // Surviving stopInternal is deliberate (a reload keeps the card through the seam).
        pendingVideoNowPlayingInfo = [:]
        #endif
        // #436: the speed belongs to the item, so it leaves with it. Same lifetime as the staged
        // Now-Playing card above, and for the same reason: a reload keeps it through the seam.
        desiredRate = nil
        // Clear loadedURL on public stop() so reloadAtCurrentPosition can't resurrect the URL after dismissal
        // and selectSubtitleTrack can't spawn a side demuxer against a stopped session.
        loadedURL = nil
        isCustomSource = false
        customSourceIsSeekable = false
    }

    /// Active AVPlayer on the native path, nil on SW path or when idle. Published so hosts driving an
    /// AVPlayerViewController can rebind `.player` on every audio-track reload (one-shot assignment goes stale).
    @Published public internal(set) var currentAVPlayer: AVPlayer? {
        didSet {
            observeExternalPlayback()
            observeCurrentItem()
            followAtmosOutput()
        }
    }

    /// Keeps the HDMI route in Atmos while `currentAVPlayer` plays APAC (tvOS; see `followAtmosOutput`).
    var atmosOutputActivator: AtmosOutputActivator?

    /// Item currently loaded into `currentAVPlayer` (#260). Published separately because items are swapped in
    /// place (`replaceCurrentItem`, on every audio-track reload and episode autoplay) without the player itself
    /// changing, so a host holding the item or its timebase gets no signal from `currentAVPlayer` alone.
    @Published public internal(set) var currentAVPlayerItem: AVPlayerItem?
    private var currentItemObservation: NSKeyValueObservation?

    private func observeCurrentItem() {
        currentItemObservation?.invalidate()
        currentItemObservation = nil
        guard let player = currentAVPlayer else {
            currentAVPlayerItem = nil
            return
        }
        currentAVPlayerItem = player.currentItem
        currentItemObservation = player.observe(\.currentItem, options: [.new]) { [weak self] _, change in
            guard let item = change.newValue else { return }
            Task { @MainActor in self?.currentAVPlayerItem = item }
        }
    }

    /// AirPlay (#86, DrHurt): true while the native AVPlayer reports external playback. loadNative reads it to
    /// serve the loopback over the device's LAN IP (the receiver can't reach 127.0.0.1), and for an HDR/DV
    /// source also to force the MEDIA playlist (AVPlayer rejects a DV/HDR MASTER playlist on an SDR receiver
    /// and won't auto-switch, DrHurt). An SDR master is kept so its subtitle renditions travel (#227).
    /// Loopback native path only; a remote-HLS source is already receiver-reachable, so it's left untouched.
    private(set) var airPlayActive = false
    private var externalPlaybackObservation: NSKeyValueObservation?

    /// True when the picture is on something other than this device's own layer: a wireless receiver or
    /// a wired external screen. The player flag alone is not trustworthy right after an item rebuild
    /// (#227), so the audio route, which survives the teardown, carries the wireless half.
    var externalPlaybackHoldsThePicture: Bool {
        guard Self.externalPlaybackCanCarryThePicture(backend: playbackBackend) else { return false }
        return isExternalPlaybackActiveNow || Self.isWirelessAirPlayRoute()
    }

    /// AE#550: whether the picture can leave this device on the backend that is playing.
    ///
    /// Only the native path can hand a picture anywhere: external playback is an AVPlayer feature, and
    /// the wireless half of it is this engine serving its own loopback to the receiver (#86). A software
    /// session renders into a local `AVSampleBufferDisplayLayer`, which no receiver picks up, and its
    /// audio reaches one only because `AVSampleBufferAudioRenderer` follows the audio route. So on that
    /// backend a wireless route means the sound left and the picture did not, and reading the route
    /// alone said the opposite: the field log announced that an external screen held a picture that was
    /// in fact still on the phone, and #315 latched its first-frame promise on that.
    nonisolated static func externalPlaybackCanCarryThePicture(backend: PlaybackBackend) -> Bool {
        backend == .native
    }

    /// Current external-playback state, or false where the platform has no such route.
    /// `AVPlayer.isExternalPlaybackActive` is unavailable on visionOS: video goes to the wearer's
    /// displays, there is no receiver to hand the stream to, so the whole #86 / #227 serve-the-loopback-
    /// over-the-LAN path is inert there.
    ///
    /// tvOS reads false for a different reason, and by decision rather than by platform accident
    /// (AE#460 round 3, cmcpherson274). AVFoundation declares the property back to tvOS 9 and an
    /// Apple TV is the RECEIVER, so nothing hands a stream anywhere; but the engine's two
    /// discriminators for such an edge (`isWirelessAirPlayRoute`, `isWiredHDMIExternalDisplay`) are
    /// both iOS-only, so a tvOS edge would be classified as a wireless receiver and buy a
    /// session-preserving reload for a route the platform has not got. A host playing a custom live
    /// source pays that rebuild out of its own spool, which is exactly the hole the reporter found
    /// by reading the route rather than by hitting it. Compiled out here instead of asserted in a
    /// comment: the reachability is now a property of the build, not of Apple's behaviour.
    private var isExternalPlaybackActiveNow: Bool {
        #if os(visionOS) || os(tvOS)
        return false
        #else
        return currentAVPlayer?.isExternalPlaybackActive ?? false
        #endif
    }

    private func observeExternalPlayback() {
        externalPlaybackObservation?.invalidate()
        externalPlaybackObservation = nil
        #if !os(visionOS) && !os(tvOS)
        guard let player = currentAVPlayer else { return }
        externalPlaybackObservation = player.observe(\.isExternalPlaybackActive, options: [.new]) { [weak self] _, change in
            let active = change.newValue ?? false
            Task { @MainActor in self?.handleExternalPlaybackChange(active: active) }
        }
        #endif
    }

    /// #227: an external-playback edge arrived while the reload this observer started was still running, so
    /// the real route state has to be re-read once the rebuilt item exists.
    private var externalPlaybackEdgeHeld = false

    /// #227: how long a master handed to a wireless AirPlay receiver gets to actually move the clock before
    /// it counts as refused. A receiver that will not play the offered variant does NOT fail the item and
    /// does not report `-11868`: it simply never starts, while the rate flickers to `playing` for a tick
    /// (device log 2026-07-27, DV master). That is invisible to the readiness gate, so progress is the only
    /// signal left. A receiver that does take the master fetches its init segment within about a second of
    /// the playlist, so this is generous without making a parked receiver wait for nothing.
    static let airPlayProgressWatchdogSeconds: Double = 5.0

    /// Master attempts on a wireless AirPlay hop before the media fallback (#227). Two, matching the #35
    /// gate: the first attempt is what makes a Match-Dynamic-Range receiver switch its output to HDR, and
    /// the second is the one that can be accepted once it has.
    static let airPlayMasterAttempts = 2
    private var airPlayProgressWatchdog: Task<Void, Never>?

    private var displayModeDiagnostic: Task<Void, Never>?

    private var playbackPanelProbe: Task<Void, Never>?

    /// Sodalite #49: read back what the Match-Frame-Rate switch actually landed on. `preferredDisplayCriteria`
    /// is a hint with no read-back, so a display-link sample once playback is running is the only way to tell
    /// three cases apart for a judder report: the panel ignored the criteria and kept the system rate (50.000
    /// under a 29.970 source), it took a rate that does not divide the content rate (60.000 vs 59.940, one
    /// repeated frame every ~16 s), or it is correct and the cadence problem is downstream of the panel.
    /// Logs both backends so the software path serves as the control for a native-path report.
    @MainActor
    func armDisplayModeDiagnostic(gen: UInt64, backend: String, contentRate: Double?, requestedRate: Double?) {
        #if os(tvOS)
        displayModeDiagnostic?.cancel()
        displayModeDiagnostic = Task { @MainActor [weak self] in
            try? await Task.sleep(for: .seconds(2.5))
            guard let self, !Task.isCancelled, self.loadGeneration == gen else { return }
            let sample = await self.displayCriteria.measureRefreshRate()
            guard !Task.isCancelled, self.loadGeneration == gen else { return }
            // currentVideoFrameRate is 0 on audio tracks and while paused, so the first non-zero entry is
            // the video track's own measure of how many frames the player is actually putting on screen.
            let playerRate = self.currentAVPlayer?.currentItem?.tracks
                .lazy.map(\.currentVideoFrameRate).first { $0 > 0 }
            func fmt(_ value: Double?) -> String {
                value.map { String(format: "%.3f", $0) } ?? "n/a"
            }
            EngineLog.emit(
                "[DisplayCriteria] mode check (\(backend)): content=\(fmt(contentRate)) "
                + "requested=\(fmt(requestedRate)) panel=\(fmt(sample?.measured))Hz "
                + "(nominal \(fmt(sample?.nominal))) player=\(fmt(playerRate.map(Double.init)))fps",
                category: .engine
            )
        }
        #endif
    }

    /// AE#459: re-ask the panel, once frames are running, whether it is presenting HDR.
    ///
    /// Every answer `panelPresentsHDR` gets is sampled around the criteria write, and an Apple TV whose
    /// output format is fixed to HDR has nothing to say at that moment: there is no dynamic-range
    /// transition, so the EDR headroom stays 1.00 and `panelProvenToEngageHDR` can never be armed either.
    /// Such a panel therefore reads SDR forever, which mislabels every HDR/DV session in Stats for Nerds
    /// and, through the same boolean, serves it media-direct with no HDR signaling.
    ///
    /// The probe does not re-route the running session; the proof it latches makes the next load in this
    /// process route correctly on its own. What it fixes here and now is the label.
    @MainActor
    func armPlaybackPanelProbe(gen: UInt64, effectiveFormat: VideoFormat,
                               panelPresentedHDRAtLoad: Bool, sessionIsPlaying: Bool) {
        #if os(tvOS)
        playbackPanelProbe?.cancel()
        playbackPanelProbe = nil
        guard DisplayCriteriaController.shouldProbePanelDuringPlayback(
            effectiveFormat: effectiveFormat,
            panelPresentedHDRAtLoad: panelPresentedHDRAtLoad,
            sessionIsPlaying: sessionIsPlaying) else { return }
        playbackPanelProbe = Task { @MainActor [weak self] in
            guard let self else { return }
            // AE#459: ask the cheaper and better question first. A display that takes an HDR master is
            // presenting HDR, and a display that is not refuses in well under a tenth of a second, so a
            // master still being served after the settle window was accepted. That beats waiting twelve
            // seconds for a headroom that has been measured staying at 1.00 through exactly this case.
            try? await Task.sleep(
                for: .milliseconds(DisplayCriteriaController.masterAcceptanceSettleMs))
            guard !Task.isCancelled, self.loadGeneration == gen else { return }
            if DisplayCriteriaController.masterAcceptanceProvesPanel(
                servingHDRMaster: self.nativeVideoSession?.servingMasterPlaylist == true
                    && self.nativeVideoSession?.servedSourceIsHDR == true,
                fellBackToMedia: self.masterFallbackUsed,
                sessionIsPlaying: self.state == .playing) {
                self.displayCriteria.notePanelEngagedHDR("AVFoundation accepted the HDR master")
                self.republishPanelPresentsHDR(
                    effectiveFormat: effectiveFormat,
                    because: "AVFoundation accepted the HDR master, which a display presenting SDR "
                        + "refuses with -11868/-11848")
                return
            }
            let presentsHDR = await self.displayCriteria.probePanelDuringPlayback()
            guard !Task.isCancelled, self.loadGeneration == gen, presentsHDR else { return }
            Self.withdrawPanelRefusalOnHDRReading()
            self.republishPanelPresentsHDR(
                effectiveFormat: effectiveFormat,
                because: "the panel answered HDR during playback and the load-time read could not see it")
        }
        #endif
    }

    /// AE#459: publish the label a late answer earned, from whichever of the two answers arrived.
    ///
    /// One funnel on purpose. The load-time read, the playback probe and now master acceptance all answer
    /// the same question, and three call sites composing `presentedVideoFormat` themselves is how the
    /// published format and the served stream drift apart.
    @MainActor
    func republishPanelPresentsHDR(effectiveFormat: VideoFormat, because reason: String) {
        let corrected = Self.presentedVideoFormat(
            effectiveFormat: effectiveFormat,
            panelPresentsHDR: true,
            sourceCarriesHDR10Plus: sourceCarriesHDR10PlusMetadata)
        guard corrected != videoFormat else { return }
        EngineLog.emit(
            "[AetherEngine] republishing videoFormat \(videoFormat) -> \(corrected): \(reason) (#459)",
            category: .engine)
        videoFormat = corrected
    }

    /// Receivers that failed to start on an HDR master this process, by route UID (#227). An Apple TV
    /// parked in SDR refuses one, and nothing in the public API reports the receiver's dynamic range, so
    /// the offer has to be made once and remembered. Per process on purpose: a user who switches the
    /// receiver's output format to HDR gets the offer again on the next launch.
    private var airPlayReceiversRefusingHDRMaster: Set<String> = []

    /// Route UID of the wireless AirPlay receiver currently holding the audio route, or nil.
    nonisolated static func currentAirPlayReceiverUID() -> String? {
        #if os(iOS)
        return AVAudioSession.sharedInstance().currentRoute.outputs
            .first { $0.portType == .airPlay }?.uid
        #else
        return nil
        #endif
    }

    /// Arm the progress watchdog for a load that handed the receiver a playlist with subtitle renditions.
    /// No-op otherwise: the media playlist is the fallback itself, and a local session cannot be refused.
    @MainActor
    func armAirPlayProgressWatchdog(gen: UInt64, position: Double) {
        airPlayProgressWatchdog?.cancel()
        airPlayProgressWatchdog = nil
        guard airPlayActive, airPlayServedMasterToReceiver else { return }
        let baseline = currentTime
        airPlayProgressWatchdog = Task { @MainActor [weak self] in
            let seconds = AetherEngine.airPlayProgressWatchdogSeconds
            try? await Task.sleep(nanoseconds: UInt64(seconds * 1_000_000_000))
            guard let self, !Task.isCancelled, self.loadGeneration == gen else { return }
            self.handleRefusedAirPlayMaster(baseline: baseline, position: position)
        }
    }

    /// The receiver never started on the playlist it was handed (#227): reload the LAN media playlist, which
    /// every receiver takes, and remember an HDR refusal so the same receiver is not made to wait again.
    ///
    /// A second master attempt was tried and dropped. The idea was that the first, refused attempt is what
    /// makes a Match-Dynamic-Range receiver switch its output to HDR, the way the #35 cold-DV gate's failed
    /// attempt warms the link; the receiver does switch during that window. On device it changed nothing and
    /// only doubled the wait before the picture appeared, so the honest answer for such a receiver is the
    /// media playlist plus a host telling the user to set the format to HDR or Dolby Vision.
    @MainActor
    private func handleRefusedAirPlayMaster(baseline: Double, position: Double) {
        guard airPlayActive, airPlayServedMasterToReceiver else { return }
        guard let host = nativeHost, let session = nativeVideoSession,
              let mediaURL = session.mediaPlaylistURL else { return }
        // Deliberately NOT gated on `state`: a refused session parks at paused, which is exactly the case
        // this exists for, and an earlier version guarded on `state == .playing` and therefore never fired
        // (device log 2026-07-27, where the #65 wedge recovery then nudged six times and gave up). The
        // honest discriminator is the server's: a receiver that refuses the manifest fetches playlists and
        // never a single segment, while a merely paused session has long since fetched its init segment.
        let advanced = currentTime - baseline
        guard advanced < 0.5, !session.hasServedMediaSegment else { return }

        let receiverUID = Self.currentAirPlayReceiverUID()
        if let receiverUID, session.servedSourceIsHDR {
            airPlayReceiversRefusingHDRMaster.insert(receiverUID)
        }
        EngineLog.emit(
            "[AirPlay] receiver did not start in "
            + "\(String(format: "%.0f", Self.airPlayProgressWatchdogSeconds))s (clock advanced "
            + "\(String(format: "%.2f", advanced))s, no segment fetched); the playlist it was handed is "
            + "refused, falling back to the LAN media playlist (subtitle renditions dropped"
            + (receiverUID != nil && session.servedSourceIsHDR
               ? ", and this receiver is remembered as refusing HDR masters" : "") + ")",
            category: .session)
        session.markServingMediaAfterFallback()
        nativeSubtitleRenditionsServed = false
        airPlayServedMasterToReceiver = false
        // A live session rejoins its playlist at the player's join point (`LiveReloadPolicy`): a seek to the
        // armed position would point the item at the start of the window.
        host.swapItem(url: airPlayHostSwapped(mediaURL),
                      startPosition: loadedOptions.isLive ? nil : position,
                      skipInitialSeek: LiveReloadPolicy.skipInitialSeek(isLive: loadedOptions.isLive, isRejoin: true))
        host.play()
    }

    private func handleExternalPlaybackChange(active: Bool) {
        // The AVPlayer-output FEL route draws the picture in a layer of this device; a screen that takes
        // the picture does not show it. Hand the picture back to AVPlayer (the 8.1 base layer) first, so
        // the reload or item swap below starts from a player that renders its own frames again.
        if active { handDualLayerOutputRouteToPlayer() }
        // #227 (device log 2026-07-27): the reload started below tears down the very item the KVO watches, so
        // AVPlayer reports a transient `false` in the middle of it. Acting on that edge cleared `airPlayActive`
        // before `loadNative` read it, the rebuilt session served 127.0.0.1 again, the receiver re-engaged
        // external playback, and that true edge started the next reload: one full session rebuild per turn,
        // forever (ports 51291, 51296, 51299, ... in the log), with the LAN swap never once applied. Hold any
        // edge for the duration of the reload and reconcile against the live route afterwards.
        if sessionPreservingReloadInFlight {
            externalPlaybackEdgeHeld = true
            EngineLog.emit("[AirPlay] external playback \(active) during a session-preserving reload; "
                           + "holding the edge until the rebuilt item settles", category: .engine)
            return
        }
        // #315: an already-ready session that only now loses the picture to an external screen gets no further
        // readiness edge, and on the wired path no reload either, so latch here too. No-op once latched.
        if active { latchFirstFrameForExternalPlaybackIfNeeded() }
        // A wired HDMI external display (USB-C/Lightning-to-HDMI adapter, Sodalite#34) keeps the device as the
        // stream origin: 127.0.0.1 loopback stays reachable and the panel carries DV/HDR (DrHurt measured his
        // adapter exposing SDR/HDR/DV in Display & Brightness), so AVPlayer just pushes the already-master
        // playlist item out fullscreen. No LAN-IP/MEDIA swap, which would strip VIDEO-RANGE=PQ down to SDR.
        // Only a wireless AirPlay receiver (#86) needs that reload (loopback unreachable, DV/HDR master rejected).
        let wired = active && Self.isWiredHDMIExternalDisplay()
        if wired {
            EngineLog.emit("[AirPlay] external playback active on wired HDMI -> keep loopback + master (DV/HDR passthrough)", category: .engine)
        }
        let wantAirPlay = active && !wired
        guard wantAirPlay != airPlayActive else { return }
        airPlayActive = wantAirPlay
        applyAirPlayImpliedNativeRendering(wirelessActive: wantAirPlay)
        // Reload so the load path rebuilds the playback URL on the LAN IP (active) or back on 127.0.0.1
        // (inactive). The remote-HLS bypass is exempt only while it plays the origin URL, which a receiver
        // reaches by itself; with a #316 subtitle proxy mounted it stands on the engine's own loopback
        // origin and needs the swap exactly like the loopback path. See AirPlayPlaylistDecision.
        guard playbackBackend == .native, loadedURL != nil,
              AirPlayPlaylistDecision.routeChangeNeedsReload(
                isRemoteHLSBypass: loadedOptions.nativeRemoteHLS,
                bypassServesLoopbackOrigin: remoteHLSSubtitleProxy != nil) else { return }
        if swapsItemForAirPlayEdge() { return }
        EngineLog.emit("[AirPlay] external playback \(wantAirPlay ? "active (wireless) -> LAN reload" : "ended -> loopback reload")"
                       + (loadedOptions.nativeRemoteHLS ? " (remote-HLS bypass on its #316 subtitle origin)" : ""),
                       category: .engine)
        Task { try? await reloadAtCurrentPosition() }
    }

    /// AE#955: a wireless receiver is a display the host's overlay cannot reach, so the rendition is the
    /// only subtitle it can show. A host that never called `setNativeSubtitleRendering(true)` left the
    /// Sodalite#38 pin holding the rendition off on the receiver, and even deselecting a pick made there.
    /// The engine raises the request itself when the host has not, and withdraws only its own.
    private func applyAirPlayImpliedNativeRendering(wirelessActive: Bool) {
        // Only a session that serves its own renditions. On the remote-HLS bypass the table is empty and
        // AVPlayer renders the origin's renditions itself, so a request here would map to no ordinal and
        // deselect exactly the subtitle the receiver is showing.
        let servesOwnRenditions = !loadedOptions.nativeRemoteHLS && !nativeSubtitleTrackTable.isEmpty
        switch Self.airPlayImpliedRenderingAction(
            wirelessActive: wirelessActive,
            servesOwnRenditions: servesOwnRenditions,
            hostRequested: nativeSubtitleRenderingRequested,
            impliedByEngine: nativeRenderingImpliedByAirPlay) {
        case true?:
            EngineLog.emit("[AirPlay] AE#955 wireless receiver is the display and the host has not asked for "
                           + "the native rendition; requesting it on the host's behalf", category: .engine)
            setNativeSubtitleRendering(true)
            nativeRenderingImpliedByAirPlay = true
        case false?:
            guard servesOwnRenditions else {
                // A later load moved onto the bypass; there is no rendition of ours left to take down.
                nativeSubtitleRenderingRequested = false
                nativeRenderingImpliedByAirPlay = false
                return
            }
            EngineLog.emit("[AirPlay] AE#955 receiver let go; withdrawing the native rendition the engine "
                           + "requested", category: .engine)
            setNativeSubtitleRendering(false)
        case nil:
            break
        }
    }

    /// AE#955: true raises the engine's own rendering request, false withdraws it, nil leaves the
    /// host's word standing.
    nonisolated static func airPlayImpliedRenderingAction(
        wirelessActive: Bool, servesOwnRenditions: Bool = true, hostRequested: Bool, impliedByEngine: Bool
    ) -> Bool? {
        if wirelessActive { return hostRequested || !servesOwnRenditions ? nil : true }
        return impliedByEngine ? false : nil
    }

    /// A session that cannot be reopened where it is crosses an AirPlay edge by swapping the item, not by
    /// rebuilding the session (`AirPlayPlaylistDecision.routeChangeHop`). Nothing about the session has to
    /// change for the hop. The server already listens on every interface and keeps every segment it cut,
    /// so only the address AVPlayer is handed differs (the LAN IP and the receiver's playlist, or the
    /// loopback again when the receiver lets go).
    ///
    /// - A sequential origin can only be read again from byte 0: the reload resumed at 0 instead of the
    ///   playhead and then sat seeking while the producer re-read the prefix. It resumes at the playhead.
    /// - A live session on a forward-only custom source (the live HLS ingest) cannot be rebuilt at all, so
    ///   the reload was refused (#526) and the receiver stayed on an address it cannot reach. It rejoins its
    ///   own live playlist the way a live reload does (`LiveReloadPolicy`): the player picks the join point.
    @MainActor
    private func swapsItemForAirPlayEdge() -> Bool {
        let hop = AirPlayPlaylistDecision.routeChangeHop(
            sequentialOrigin: loadedOptions.sequentialOrigin,
            isLive: loadedOptions.isLive,
            isCustomSource: isCustomSource,
            customSourceIsSeekable: customSourceIsSeekable)
        guard hop == .swapItem, !loadedOptions.nativeRemoteHLS,
              let host = nativeHost, let session = nativeVideoSession,
              let loopback = session.servingMasterPlaylist
                ? session.masterPlaylistURL : session.mediaPlaylistURL else { return false }
        // Live: no position, as for any live rejoin (a playhead taken here would be on the outgoing
        // item's axis). On demand: the playhead, as the sequential hop always did.
        let position: Double? = loadedOptions.isLive ? nil : currentTime
        let served = airPlayAdjustedPlayback(url: loopback, session: session)
        nativeSubtitleRenditionsServed = served.subtitleRenditionsServed
        let reason = loadedOptions.sequentialOrigin && !loadedOptions.isLive
            ? "the source cannot be reopened past byte 0"
            : "a forward-only custom source cannot be rebuilt, #526"
        EngineLog.emit(
            "[AirPlay] external playback \(airPlayActive ? "active (wireless)" : "ended") -> item swap to "
            + "\(served.url.absoluteString) "
            + (position.map { "at \(String(format: "%.2f", $0))s" } ?? "at the player's live join point")
            + " (\(reason))",
            category: .engine)
        host.swapItem(url: served.url, startPosition: position,
                      skipInitialSeek: LiveReloadPolicy.skipInitialSeek(isLive: loadedOptions.isLive, isRejoin: true))
        armAirPlayProgressWatchdog(gen: loadGeneration, position: position ?? 0)
        return true
    }

    /// Re-read external playback after a session-preserving reload and act on it if it really changed (#227).
    /// The player flag alone is not trustworthy at this instant: the rebuilt item may not have re-engaged the
    /// receiver yet, which would read as "AirPlay ended" and start the next reload of the same loop. The audio
    /// route survives the item teardown, so a receiver still holding the route keeps the session on its LAN URL.
    func reconcileExternalPlaybackAfterReload() {
        guard externalPlaybackEdgeHeld else { return }
        externalPlaybackEdgeHeld = false
        let active = externalPlaybackHoldsThePicture
        EngineLog.emit("[AirPlay] reconciling the held edge after the reload: active=\(active) "
                       + "(player=\(isExternalPlaybackActiveNow) "
                       + "route=\(Self.isWirelessAirPlayRoute()))", category: .engine)
        handleExternalPlaybackChange(active: active)
    }

    /// True when a wireless AirPlay receiver holds the current audio route. Unlike
    /// `AVPlayer.isExternalPlaybackActive` this survives an item teardown, which is what makes it the right
    /// signal for the post-reload reconcile (#227). Wired HDMI reports `.HDMI` and is excluded by construction.
    nonisolated static func isWirelessAirPlayRoute() -> Bool {
        #if os(iOS)
        return AVAudioSession.sharedInstance().currentRoute.outputs.contains { $0.portType == .airPlay }
        #else
        return false
        #endif
    }

    /// True when a wired HDMI external display is the active audio output (USB-C/Lightning-to-HDMI adapter).
    /// `usesExternalPlaybackWhileExternalScreenIsActive` flips `isExternalPlaybackActive` for both a wired screen
    /// and a wireless AirPlay receiver; the audio route tells them apart (`.HDMI` vs `.airPlay`). Wired keeps the
    /// loopback + master playlist (Sodalite#34); wireless takes the LAN-IP + MEDIA path (#86). Mirrors the port
    /// inspection in NativeAVPlayerHost.dumpAudioRoute. iOS-only, and since AE#460 round 3 tvOS does not
    /// observe external playback at all, so this is no longer the line that keeps an Apple TV off the
    /// wireless branch (see `isExternalPlaybackActiveNow`).
    nonisolated private static func isWiredHDMIExternalDisplay() -> Bool {
        #if os(iOS)
        return AVAudioSession.sharedInstance().currentRoute.outputs.contains { $0.portType == .HDMI }
        #else
        return false
        #endif
    }

    /// Playback URL and subtitle-rendition reality for a freshly started loopback session, after the AirPlay
    /// rewrite (#86, #227). Identity outside iOS and whenever external playback is off; when the LAN IP scan
    /// comes up empty the loopback URL stays as resolved (the receiver then simply cannot reach it, unchanged
    /// from #86). `subtitleRenditionsServed` is what the served playlist actually carries, which is what
    /// `nativeSubtitleRenditionsServed` promises hosts.
    func airPlayAdjustedPlayback(url: URL, session: HLSVideoEngine) -> (url: URL, subtitleRenditionsServed: Bool) {
        airPlayServedMasterToReceiver = false
        #if os(iOS)
        guard airPlayActive else { return (url, session.servingMasterPlaylist) }
        let receiverUID = Self.currentAirPlayReceiverUID()
        let refusedBefore = receiverUID.map { airPlayReceiversRefusingHDRMaster.contains($0) } ?? false
        let playlist = AirPlayPlaylistDecision.playlistForReceiver(
            servingMasterPlaylist: session.servingMasterPlaylist,
            sourceIsHDR: session.servedSourceIsHDR,
            receiverRefusedHDRMaster: refusedBefore)
        let carriesRenditions = AirPlayPlaylistDecision.carriesSubtitleRenditions(playlist)
        guard let lanURL = airPlayPlaybackURL(base: url, playlist: playlist) else {
            EngineLog.emit("[AirPlay] no LAN IP; keeping \(url.absoluteString)", category: .engine)
            return (url, session.servingMasterPlaylist)
        }
        airPlayServedMasterToReceiver = carriesRenditions
        EngineLog.emit("[AirPlay] loadNative serving via \(lanURL.absoluteString) (playlist=\(playlist) "
                       + "sourceIsHDR=\(session.servedSourceIsHDR) refusedBefore=\(refusedBefore) "
                       + "subtitle renditions \(carriesRenditions ? "carried" : "dropped"))", category: .engine)
        return (lanURL, carriesRenditions)
        #else
        return (url, session.servingMasterPlaylist)
        #endif
    }

    /// True while the current native load handed the receiver a MASTER playlist (#227 follow-up). Arms the
    /// startup-readiness gate on that hop: the sender cannot read the receiver's HDR mode, so a rejected or
    /// silently parked master has to be caught and downgraded to the LAN media playlist.
    private(set) var airPlayServedMasterToReceiver = false

    /// The same loopback URL on the device's LAN IP, path untouched (master, reduced master, media). For the
    /// readiness gate's reloads while AirPlaying, which otherwise hand the receiver a 127.0.0.1 URL it cannot
    /// reach. Identity when no LAN IP resolves.
    func airPlayHostSwapped(_ url: URL) -> URL {
        airPlayPlaybackURL(base: url, playlist: .master) ?? url
    }

    /// AirPlay loopback URL (#86): rewrite the loopback playback URL to the device's LAN IP so the receiver
    /// reaches the engine-processed stream. nil if no LAN IP (caller keeps the original 127.0.0.1 URL).
    ///
    /// `playlist` also picks the path: the resolved master for SDR (the renditions live only there, #227),
    /// the reduced HDR master or plain media for HDR. See `AirPlayPlaylistDecision`.
    func airPlayPlaybackURL(base: URL,
                            playlist: AirPlayPlaylistDecision.ReceiverPlaylist = .media) -> URL? {
        guard let lanIP = HLSLocalServer.localActiveIPAddress() else { return nil }
        return AirPlayPlaylistDecision.receiverURL(base: base, lanIP: lanIP, playlist: playlist)
    }

    #if os(tvOS) || os(iOS)
    /// MPNowPlayingSession for the active AVPlayer audio path, or nil. The host registers transport commands
    /// and writes metadata here to stay the active Now-Playing app across a background pause (tvOS drops a
    /// paused bare AVPlayer, killing the Home badge and remote play route). See AudioAVPlayerHost. Nil on
    /// the FFmpeg audio host (`audioOnlyUsesAVPlayer` false), which has no session of its own.
    public var audioNowPlayingSession: MPNowPlayingSession? {
        audioAVPlayerActive ? audioAVPlayerHost?.nowPlayingSession : nil
    }
    #endif

    /// Staged externalMetadata applied to the AVPlayerItem before replaceCurrentItem. Survives across native
    /// loads so audio-track-switch and background reopen replays the metadata.
    var pendingExternalMetadata: [AVMetadataItem] = []

    /// Stage AVKit externalMetadata for the on-screen info pane (video path / AVPlayerViewController). On the video
    /// path AVKit also republishes it as Now-Playing Info. The bare-AVPlayer audio path has no AVPlayerViewController,
    /// so for system Now-Playing on that path use `setAudioNowPlayingInfo` instead. Safe to call before load();
    /// items are replayed at host creation.
    public func setExternalMetadata(_ items: [AVMetadataItem]) {
        pendingExternalMetadata = items
        refreshSoftwareNowPlayingIdentity()
        nativeHost?.setExternalMetadata(items)
        audioAVPlayerHost?.setExternalMetadata(items)
    }

    #if os(tvOS) || os(iOS)
    /// Opt in to owning the system Now-Playing session on the native VIDEO path.
    ///
    /// Off by default, and that default is load-bearing. The native path is consumed both by hosts
    /// that build their own transport around a bare `AVPlayer` and by `AVPlayerViewController` hosts,
    /// and AVKit owns Now-Playing itself there through private MediaRemote: WWDC22's guidance is not
    /// to bring an `MPNowPlayingSession` when using AVKit, and doing so costs the host AVKit's card,
    /// its `externalMetadata`, and its working transport commands. Only a host with custom UI should
    /// set this. The audio path's AVPlayer host has no such fork (always a bare AVPlayer) and owns its
    /// session unconditionally.
    ///
    /// Read when a native host is created, so set it before `load()`. A host preserved across a
    /// native->native reload (issue #15) keeps whatever it was created with; the change takes effect
    /// on the next fresh host.
    public var ownsVideoNowPlayingSession: Bool = false

    /// MPNowPlayingSession for the native VIDEO path; nil unless `ownsVideoNowPlayingSession` was set
    /// before the session loaded (also nil on the software path and with no host). Same contract as
    /// `audioNowPlayingSession`: the host app registers transport commands on `remoteCommandCenter`
    /// and stages identity metadata via `setVideoNowPlayingInfo`; the session auto-publishes
    /// elapsed/rate/duration from the AVPlayer and survives native->native reloads with the host
    /// (issue #15), so system Now-Playing ownership holds across a background pause.
    public var videoNowPlayingSession: MPNowPlayingSession? {
        nativeHost?.nowPlayingSession
    }

    #endif

    /// Opt in to the software host (the Dolby Vision FEL route) publishing its own Now-Playing card and
    /// answering the system's remote commands. That host has no `AVPlayer`, so neither AVKit nor an
    /// auto-publishing session exists for it; with this set the engine writes the shared Now-Playing
    /// info and serves play, pause, toggle, skip and change-position, republishing on seek, pause, speed
    /// change, stall and end. Identity comes from `setExternalMetadata`, overlaid by
    /// `setVideoNowPlayingInfo` on iOS and tvOS. Off by default; independent of
    /// `ownsVideoNowPlayingSession`, so the native path is unaffected. Read when the software host is
    /// built, so set it before `load()`. A secondary `sharedOutputRole` never takes it.
    public var ownsSoftwareNowPlaying: Bool = false

    /// Skip distance advertised to, and used for, the software host's remote skip buttons. Read when the
    /// software host is built.
    public var remoteSkipInterval: Double = 10

    /// True while the engine is publishing Now-Playing for a software-host session. A host that wants
    /// next/previous registers them on `MPRemoteCommandCenter.shared()` only while this is true.
    @Published public internal(set) var softwareNowPlayingActive: Bool = false

    #if os(tvOS) || os(iOS)
    /// Staged per-item Now-Playing dictionary for the native video path. Replayed at host creation
    /// and onto every fresh AVPlayerItem (gate reloads, media fallback, in-place swaps). Caller-managed
    /// like the audio variant: pass an empty dict to clear.
    var pendingVideoNowPlayingInfo: [String: Any] = [:]

    /// Stage the system Now-Playing identity dictionary for the native video path (MPMediaItemProperty
    /// keys + a force-decoded, @Sendable-wrapped MPMediaItemArtwork). Elapsed/rate/duration keys are
    /// unnecessary, the session merges the player truth. Safe before `load()`; replayed at host
    /// creation. Ignored by a host that does not own the session (`ownsVideoNowPlayingSession`), but
    /// still staged, so a host that opts in on a later load keeps what it set.
    public func setVideoNowPlayingInfo(_ info: [String: Any]) {
        pendingVideoNowPlayingInfo = info
        refreshSoftwareNowPlayingIdentity()
        nativeHost?.setNowPlayingInfo(info)
    }
    #endif

    #if os(iOS) || os(tvOS)
    /// Staged per-item Now-Playing dictionary for the audio AVPlayer path. Replayed at host creation.
    var pendingAudioNowPlayingInfo: [String: Any] = [:]

    /// Stage the system Now-Playing dictionary for the audio AVPlayer path (MPMediaItemProperty /
    /// MPNowPlayingInfoProperty keys, including the host's already-force-decoded, @Sendable-wrapped MPMediaItemArtwork).
    /// The host owns the AVPlayer session with auto-publish ON; this is written to the per-item
    /// AVPlayerItem.nowPlayingInfo (the documented, queue-safe channel) and the session merges in the player-derived
    /// elapsed/rate/duration. Supplying a valid artwork keeps the system from falling back to the asset's embedded
    /// cover. Pass an empty dict to clear. Safe before load(); replayed at host creation.
    public func setAudioNowPlayingInfo(_ info: [String: Any]) {
        pendingAudioNowPlayingInfo = info
        audioAVPlayerHost?.setNowPlayingInfo(info)
    }
    #endif

    /// Playback volume (0.0-1.0). Routes to the active host only; writing all hosts changed subsequent music
    /// sessions. Remembered by `desiredVolume` so a pre-session write (e.g. app-init restore) isn't a no-op.
    public var volume: Float {
        get { activeTransportHost?.volume ?? desiredVolume ?? 1.0 }
        set {
            desiredVolume = newValue
            activeTransportHost?.volume = newValue
        }
    }

    var desiredVolume: Float?

    func applyDesiredVolume(to host: any TransportControllable) {
        if let v = desiredVolume { host.volume = v }
    }

    /// The speed the host asked for, remembered so the host rebuilds a session makes on its own
    /// (reload at position, audio-track switch, AirPlay LAN swap, background return) come back at it
    /// instead of silently at 1.0 (#436). Lifetime is the item: a load of a different source clears
    /// it, as does `stop()`, so a host whose speed control resets per item stays in step. Within a
    /// session the resume itself is the host's own business (`AVPlayer.defaultRate` on the native
    /// paths, `lastRate` on the software ones), which is what covers the play() calls neither the
    /// engine nor a client issues.
    var desiredRate: Float?

    func applyDesiredRate(to host: any TransportControllable) {
        // Seeded on every host the load builds, including the "no speed set" case: the native and
        // audio AVPlayer hosts are REUSED across loads, and the rate they resume at lives on that
        // player, so a new item would otherwise inherit the previous one's speed from a host object
        // the engine's own memory no longer describes.
        // Re-clamped per host: the cap is 3.0 for an audio-only session and 2.0 for video, so a rate
        // carried out of one must not outrun the other.
        host.setResumeRate(min(desiredRate ?? 1.0, maxSupportedRate))
    }

    /// #436: whether a speed set on the current item survives this load. A rebuild of the same source
    /// keeps it; a different item starts at 1.0. A custom source has no URL to compare, and the only
    /// way one is reopened is the engine reusing the retained reader, so a loaded session keeps it.
    static func rateSurvivesLoad(of source: MediaSource, loadedURL: URL?) -> Bool {
        guard let loaded = loadedURL else { return false }
        switch source {
        case .url(let url): return url == loaded
        case .custom: return true
        }
    }

    /// Maximum reliable forward rate: 3x for audio-only sessions, 2x for video.
    /// Above the cap AVPlayer fast-forward becomes unstable (AetherEngine#39).
    /// Hosts should size their speed picker against this. Query after load; returns 2.0 while idle.
    public var maxSupportedRate: Float {
        (audioAVPlayerActive || audioHost != nil) ? 3.0 : 2.0
    }

    /// Set playback speed. Clamped to `maxSupportedRate` (AetherEngine#39). 0 pauses. While paused a
    /// non-zero rate is kept for the next `play()` instead of resuming (#730).
    /// Both paths are pitch-preserving: the engine pins `audioTimePitchAlgorithm` to TimeDomain on the
    /// native `AVPlayerItem` and on the software path's audio renderer, so speed never depends on which
    /// decode route a title took (#434).
    public func setRate(_ rate: Float) {
        let cap = maxSupportedRate
        let clamped = min(rate, cap)
        if clamped != rate {
            EngineLog.emit("[AetherEngine] setRate(\(rate)) clamped to \(clamped) (max supported on this path)", category: .engine)
        }
        // Zero is a pause, not a speed: it must not become what a later resume comes back at (#436).
        if clamped != 0 { desiredRate = clamped }
        defer { refreshSoftwareNowPlaying() }
        if clamped == 0 {
            playDeferredByInterruption = false
            resumeAfterInterruption = false
            userPauseCount &+= 1
        }
        // #730: while paused a speed is a speed, not a play press. Handing it to the host would play
        // (`avPlayer.rate = x`) behind a state that still says paused; seeding the resume rate is what
        // the next play() reads on every host.
        if state == .paused && clamped != 0 {
            activeTransportHost?.setResumeRate(clamped)
            return
        }
        // F5: a speed change must not restart audio the system just paused for an interruption.
        if clamped != 0, Self.interruptionHoldsTransport(
            interrupted: audioInterruptionActive, rendererPath: softwareHost != nil || audioHost != nil
        ) {
            EngineLog.emit("[AetherEngine] setRate(\(clamped)) held: an audio interruption is active; the speed applies when playback resumes", category: .engine)
            activeTransportHost?.setResumeRate(clamped)
            return
        }
        activeTransportHost?.setRate(clamped)
        // A rate of zero parks the renderer path without a state change; the activator follows it.
        atmosOutputActivator?.refresh()
    }

    // MARK: - Audio / subtitle track selection

    /// A VOD session on a sequential origin switches audio by a fresh load at the host's position.
    nonisolated static func audioSwitchNeedsFreshLoad(isLive: Bool, sequentialOrigin: Bool) -> Bool {
        !isLive && sequentialOrigin
    }

    /// Switch the active audio track mid-playback. Rebuilds the pipeline at the current position;
    /// native audio handover retains the old item until replacement, but decoder readiness can still
    /// interrupt presentation. Software/forward-only sources cannot promise a seamless switch. Display-criteria handshake
    /// is suppressed (video unchanged). `index` is the container stream index (TrackInfo.id). No-op if
    /// out-of-range, pointing at a non-audio stream, or already active.
    ///
    /// Not available on `VideoRoute.remoteBypass`: there `audioTracks` lists what AVPlayer built and is
    /// informational, the selection belongs to AVFoundation, and a pick is logged and ignored rather than
    /// turned into a reload the bypass has no audio override for. A host that wants another language on
    /// that route loads a URL that carries it.
    ///
    /// Not available on a sequential origin either (AE#958): the rebuild could only reopen it at byte 0,
    /// which restarted the programme on the native route and failed the software route's reposition.
    public func selectAudioTrack(index: Int) {
        if videoRoute == .remoteBypass {
            EngineLog.emit(
                "[AetherEngine] selectAudioTrack(\(index)) ignored: AVPlayer owns the audio selection on "
                + "the remote-HLS bypass; audioTracks is informational there",
                category: .engine
            )
            return
        }
        // Forward-only custom sources (incl. live HLS-ingest) can't rewind; rebuilding would re-consume a
        // drained FIFO and stall silently. Logged so a picker that does nothing is explainable.
        if isCustomSource && !customSourceIsSeekable {
            EngineLog.emit(
                "[AetherEngine] selectAudioTrack(\(index)) ignored: forward-only custom "
                + "source cannot rebuild its pipeline (live ingest / demuxed-audio "
                + "sessions switch tracks only via a fresh load)",
                category: .engine
            )
            return
        }
        if Self.audioSwitchNeedsFreshLoad(isLive: isLive, sequentialOrigin: loadedOptions.sequentialOrigin) {
            EngineLog.emit(
                "[AetherEngine] selectAudioTrack(\(index)) ignored: a sequential origin can only "
                + "reopen at byte 0; load the source again at the position with audioSourceStreamIndex",
                category: .engine
            )
            return
        }
        guard let url = loadedURL else { return }
        guard audioTracks.contains(where: { $0.id == index }) else {
            EngineLog.emit(
                "[AetherEngine] selectAudioTrack: index=\(index) not in audioTracks (\(audioTracks.map { $0.id })), ignored",
                category: .engine
            )
            return
        }
        if activeAudioTrackIndex == index && audioSelectionTask == nil { return }

        EngineLog.emit(
            "[AetherEngine] selectAudioTrack: scheduling switch to stream \(index)",
            category: .engine
        )

        pendingAudioSelection = index
        guard audioSelectionTask == nil else { return }
        let epoch = audioSelectionEpoch
        audioSelectionTask = Task { @MainActor [weak self] in
            guard let self, self.audioSelectionEpoch == epoch else { return }
            defer {
                if self.audioSelectionEpoch == epoch {
                    self.audioSelectionTask = nil
                }
            }
            while let selected = self.pendingAudioSelection {
                self.pendingAudioSelection = nil
                guard !Task.isCancelled, self.audioSelectionEpoch == epoch else { return }
                if self.activeAudioTrackIndex == selected { continue }
                let beforeReload = self.loadGeneration
                let failure = await self.reloadWithAudioOverride(
                    url: url, audioStreamIndex: Int32(selected), expectedGeneration: beforeReload,
                    keepsDisplayRefusedMediaRoute: true)
                // This rebuild owns one stopInternal generation. Background teardown or
                // another SDK recovery cannot lend its successor to queued audio work.
                guard !Task.isCancelled, self.audioSelectionEpoch == epoch, failure == nil,
                      self.loadGeneration == beforeReload &+ 1 else { return }
            }
        }
    }

    /// Switch the active disc title (a Blu-ray playlist or DVD-Video title) mid-playback. Rebuilds the
    /// pipeline from the new title's start; expect a brief black frame like a fresh load. No-op when `id`
    /// is out of range, already selected, there is no disc, or the source is a forward-only custom reader.
    /// `id` is a `TitleInfo.id` from `discTitles`. (#67)
    public func selectTitle(id: Int) {
        if isCustomSource && !customSourceIsSeekable {
            EngineLog.emit(
                "[AetherEngine] selectTitle(\(id)) ignored: forward-only custom source cannot rebuild its pipeline",
                category: .engine
            )
            return
        }
        guard let url = loadedURL else { return }
        guard discTitles.contains(where: { $0.id == id }) else {
            EngineLog.emit(
                "[AetherEngine] selectTitle: id=\(id) not in discTitles (\(discTitles.map { $0.id })), ignored",
                category: .engine
            )
            return
        }
        if activeDiscTitleID == id { return }

        EngineLog.emit("[AetherEngine] selectTitle: scheduling switch to title \(id)", category: .engine)
        let gen = loadGeneration
        // Stream indices are per title, so an initial subtitle track id named for the old title could
        // activate an unrelated track on the new one. Drop it here (both reload paths read loadedOptions);
        // the language preference decides on the new title.
        loadedOptions.initialSubtitleTrackID = nil
        let options = loadedOptions
        let custom = isCustomSource
        Task { @MainActor [weak self] in
            guard let self = self else { return }
            if custom {
                // Custom readers (e.g. SMB ISO) have no URL to reopen; rebuild on the retained reader with the
                // title override, restarting at the new title's head.
                await self.reloadWithAudioOverride(
                    url: url,
                    audioStreamIndex: nil,
                    expectedGeneration: gen,
                    discTitleIDOverride: id,
                    resumeOverride: 0
                )
            } else {
                // Liveness guard: a stop()/load() enqueued between selectTitle and this body would otherwise be
                // resurrected by the load() below (selectAudioTrack gets this for free via reloadWithAudioOverride).
                guard self.loadGeneration == gen else {
                    EngineLog.emit("[AetherEngine] selectTitle reload superseded before start; ignored", category: .engine)
                    return
                }
                // URL/local disc: a full reload re-probes the new title and republishes audio/subtitle/title/
                // duration plus re-runs the display-criteria handshake. Correct because a title switch changes
                // content entirely (unlike the audio-switch fast path, which keeps the panel mode).
                do {
                    try await self.load(url: url, startPosition: 0, options: options, discTitleID: id)
                } catch is CancellationError {
                    // Superseded by a newer load/stop; it owns engine state.
                } catch {
                    EngineLog.emit("[AetherEngine] selectTitle reload failed: \(error)", category: .engine)
                }
            }
        }
    }

    /// Publishes `mediaChapters` from `containerChapterSource` on the axis of the current backend. While no
    /// backend is settled (the probe at load, before the route is chosen) nothing is published: the origin
    /// is not known, and raw container times must not reach a host as seek targets. The backend's `didSet`
    /// publishes once it is.
    func republishMediaChapters() {
        guard let source = containerChapterSource, playbackBackend != .none else {
            if !mediaChapters.isEmpty { mediaChapters = [] }
            return
        }
        let origin = PresentationAxis.containerChapterOrigin(
            backend: playbackBackend, formatStartSeconds: source.formatStartSeconds,
            sourceStartOrigin: source.sourceStartOrigin, softwareClockZero: softwareClockSessionZero,
            isLive: isLive)
        // Every reopen of the same source settles the backend again; an unchanged list must not re-fire.
        let rebased = Demuxer.chapterInfos(source, origin: origin)
        if rebased != mediaChapters { mediaChapters = rebased }
    }

    /// Seek to a chapter within the active disc title. `id` is a `ChapterInfo.id` from `discChapters`. A thin
    /// wrapper over `seek(to:)` (no pipeline rebuild, since the chapter lives in the playing title's stream).
    /// No-op when `id` is unknown. (#67)
    public func selectChapter(id: Int) {
        guard let chapter = discChapters.first(where: { $0.id == id }) else {
            EngineLog.emit(
                "[AetherEngine] selectChapter: id=\(id) not in discChapters (\(discChapters.map { $0.id })), ignored",
                category: .engine
            )
            return
        }
        // discChapters are title-relative (0-based: chapter 1 = 0), matching the disc timeline and the
        // 0-based title duration. `seek(to:)` takes the published axis of the active backend, which differs
        // by backend (native re-times onto a 0-based playlist shifted by playlistShiftSeconds; the software
        // path's published axis is the clock's session zero off the raw container start, so only the part of
        // sourceStartSeconds the zero did not take is added, see `PresentationAxis.discChapterSeekTarget`).
        let target = PresentationAxis.discChapterSeekTarget(
            chapterStart: chapter.startSeconds, backend: playbackBackend,
            sourceStartSeconds: sourceStartSeconds, playlistShiftSeconds: playlistShiftSeconds,
            softwareClockZero: softwareClockSessionZero)
        let base = target - chapter.startSeconds
        EngineLog.emit(
            "[AetherEngine] selectChapter: seeking to chapter \(id) @ title-relative "
            + "\(String(format: "%.2f", chapter.startSeconds))s -> seek target \(String(format: "%.2f", target))s "
            + "(base \(String(format: "%.2f", base))s, backend \(playbackBackend))",
            category: .engine
        )
        Task { @MainActor [weak self] in await self?.seek(to: target, exact: true) }
    }

    /// Most recent sidecar subtitle URL; rehydrated by selectAudioTrack after pipeline reload. Cleared on clearSubtitle/stop.
    var loadedSidecarURL: URL?
    /// Active secondary sidecar URL, or nil. Mirror of loadedSidecarURL.
    var loadedSecondarySidecarURL: URL?

    // MARK: - Internal teardown

    /// Whether a teardown may release the shared `AVAudioSession` (#215).
    ///
    /// Three independent conditions, all required:
    /// - `finalTeardown`: the caller declared "leaving playback", which only `stop()` does. `!keepNativeHost`
    ///   is NOT a usable proxy for it: it defaults to `false`, so every bare `stopInternal()` (the live-reload
    ///   watchdog, for one, which expects the host to retune immediately) would tear a process-wide session
    ///   down mid-cycle.
    /// - `!keepNativeHost`: belt and braces. A preserved host means audio keeps flowing into the next load.
    /// - `hostOptedIn`: `deactivatesAudioSessionOnStop`. The session is process-global state the engine
    ///   mostly does not own, so releasing it is the host app's call.
    /// Since Sodalite#175 the host opt-in is folded into `SharedOutputCoordinator.leave`, which owes it to the last engine out.
    nonisolated static func shouldDeactivateAudioSessionOnTeardown(finalTeardown: Bool,
                                                                   keepNativeHost: Bool,
                                                                   hostOptedIn: Bool) -> Bool {
        finalTeardown && !keepNativeHost && hostOptedIn
    }

    /// Sodalite#175: the session goes only with the last engine out, and only when a release is owed.
    nonisolated static func shouldDeactivateAudioSession(after outcome: SharedOutputCoordinator.LeaveOutcome) -> Bool {
        outcome == .lastOut(releaseSession: true)
    }

    /// Sodalite#175: a scheduled release is stale once another engine has joined in the meantime.
    nonisolated static func releaseStillWanted(coordinatorIsEmpty: Bool) -> Bool {
        coordinatorIsEmpty
    }

    #if os(iOS) || os(tvOS)
    /// Counterpart to the activations the engine takes part in (#215). The native path never activates the
    /// session itself (AVKit does it per playback, #24); the software and audio renderer paths do, in
    /// `activateRendererAudioSession()`. Either way, holding an active `.playback` session after playback is
    /// over is what strands an E-AC-3/JOC Atmos BITSTREAM PASSTHROUGH render ring on the HDMI sink: the
    /// receiver keeps looping the last MAT frame once the player is released (reported by Brandon Moore:
    /// audio stutters on after leaving the video and persists off-screen). `.notifyOthersOnDeactivation` so
    /// whatever was interrupted resumes. Best effort: a failure here costs the ring, not the teardown.
    nonisolated static func deactivateSharedAudioSession() {
        let started = DispatchTime.now()
        func elapsedMs() -> Int {
            Int((DispatchTime.now().uptimeNanoseconds - started.uptimeNanoseconds) / 1_000_000)
        }
        do {
            try AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
            EngineLog.emit(
                "[AetherEngine] AVAudioSession deactivated on final teardown in \(elapsedMs())ms "
                + "(release passthrough render ring)",
                category: .engine)
        } catch {
            // `.isBusy` is NOT a failure and must not be retried. Per AVAudioSession.h: since iOS 8,
            // deactivating with running I/O still DEACTIVATES the session and returns this code purely
            // "to indicate the misuse of the API" -- and since iOS/tvOS 26 it is not returned at all.
            // The ring is released either way; the only actionable part is that we were asked to
            // deactivate before the render path finished releasing its I/O. Retrying would be worse than
            // useless: a retry landing after a subsequent load() would deactivate the NEW session.
            let nsError = error as NSError
            if nsError.code == AVAudioSession.ErrorCode.isBusy.rawValue {
                EngineLog.emit(
                    "[AetherEngine] AVAudioSession deactivated on final teardown in \(elapsedMs())ms "
                    + "(session released; I/O was still running)",
                    category: .engine)
            } else {
                EngineLog.emit(
                    "[AetherEngine] AVAudioSession deactivate on teardown failed after \(elapsedMs())ms: "
                    + "\(error) (passthrough ring may keep looping)",
                    category: .engine)
            }
        }
    }

    /// Run the #215 deactivation off the main actor.
    ///
    /// `setActive(false)` is an XPC round trip to mediaserverd, and on an E-AC-3 / Atmos MAT passthrough
    /// route the sink renegotiates the HDMI link inside that call: measured at roughly half a second on an
    /// Apple TV 4K feeding an AVR, against a few milliseconds for the same call on a 5.1 route. Inline in
    /// the teardown that is half a second of frozen UI, because the host's dismiss cannot start until
    /// `stop()` returns. Same reasoning that moved `setCategory` off-main in #114; the difference is that
    /// this one has to stay ordered against a following `load()`, hence the generation guard.
    ///
    /// `loadGeneration` was bumped by the `stopInternal` that scheduled this, so any `load()` starting in
    /// the meantime bumps it again and the pending deactivation drops rather than releasing the session
    /// out from under the new item. `stopInternal` also cancels a pending task before scheduling a new one.
    /// The release queues behind a renderer activation still in flight (AE#538), see `enqueueAudioSessionTransition`.
    private func scheduleAudioSessionDeactivation() {
        let generation = loadGeneration
        audioSessionDeactivationTask = enqueueAudioSessionTransition { [weak self] in
            guard let self else { return }
            guard !Task.isCancelled, await self.loadGeneration == generation else { return }
            guard await Self.releaseStillWanted(coordinatorIsEmpty: SharedOutputCoordinator.shared.isEmpty) else {
                EngineLog.emit("[SharedOutput] release dropped: another engine joined before it ran", category: .engine)
                return
            }
            AetherEngine.deactivateSharedAudioSession()
        }
    }
    #endif

    /// Sodalite#175: the panel mode belongs to every engine still playing, so a reset waits for the last one out.
    private func resetDisplayCriteriaRespectingOthers() {
        let id = ObjectIdentifier(self)
        if SharedOutputCoordinator.shared.othersActive(besides: id) {
            let controller = displayCriteria
            SharedOutputCoordinator.shared.deferCriteriaReset(for: id) { controller.reset() }
        } else {
            displayCriteria.reset()
        }
    }

    /// - Parameter resetDisplayCriteria: When `true` (default), release
    ///   the `AVDisplayManager.preferredDisplayCriteria` so the panel
    ///   returns to its default mode. Used by `load()` and the public
    ///   `stop()` API where the next session may target a different
    ///   format. The audio-track-switch reload path passes `false`
    ///   because the same source is being re-prepared with only the
    ///   audio stream changing; keeping the criteria in place avoids
    ///   a redundant `apply` + `waitForSwitch` cycle that on some
    ///   panels (notably when paired with a Bluetooth A2DP audio route)
    ///   never settles and burns the full settle timeout (~12 s of
    ///   black-screen latency per audio switch on the old fixed 5 s
    ///   poll; capped at ~2 s since #117, but still worth skipping).
    func stopInternal(resetDisplayCriteria: Bool = true, keepNativeHost: Bool = false, keepCustomReader: Bool = false, keepCurrentItem: Bool = false, finalTeardown: Bool = false,
                      cacheCleanupReason: SessionCacheCleanupReason = .sourceChanged) {
        // AE#560: a recording never outlives its session. This covers stop(), a new load() and
        // every reload, all of which pass through here before the demuxer goes away.
        endRecordingIfRunning(reason: .sessionEnded)
        // Bump generation to invalidate in-flight load() checkpoints.
        loadGeneration &+= 1
        scrubPreviewSourceGeneration = UUID()
        resumeAfterInterruption = false
        playDeferredByInterruption = false
        audioInterruptionActive = false
        #if os(iOS) || os(tvOS)
        // A deactivation still queued from a previous teardown must not land on this session (#215).
        audioSessionDeactivationTask?.cancel()
        audioSessionDeactivationTask = nil
        #endif
        // tearDown() unloads the AVPlayer item before the loopback server is torn down to avoid noisy races.
        // keepNativeHost preserves NativeAVPlayerHost + currentAVPlayer across native->native reloads:
        // AVKit binds its MediaRemote registration to the AVPlayer instance once and never re-registers
        // against a swapped player ("Code=14 client callback"); reusing the instance keeps Control Center
        // populated across the seam (issue #15). SW-path callers must release the preserved host themselves.
        memoryProbeTask?.cancel()
        memoryProbeTask = nil
        placementVerificationTask?.cancel()
        placementVerificationTask = nil
        landingAxisTask?.cancel()
        landingAxisTask = nil
        // AE#446: the outage watcher belongs to the session whose window was closed with ENDLIST.
        liveOutageResumeWatcher?.cancel()
        liveOutageResumeWatcher = nil
        liveOutageSourceGivenUp = false
        liveReloadWatchdogTask?.cancel()
        liveReloadWatchdogTask = nil
        // Audit CORE-1: the #65/#93 recovery rungs belong to the session being torn down. Left
        // running across a background teardown, the item-death confirm could start a software
        // rebuild seconds later with the app suspended.
        stallReengageTask?.cancel()
        stallReengageTask = nil
        itemDeathConfirmTask?.cancel()
        itemDeathConfirmTask = nil
        // The master->media fallback single-shot is per SESSION, and the reload this teardown
        // precedes builds a new one (a fresh HLSVideoEngine with its own master). `load()` resets
        // it in loadSession's prologue, but the session-preserving rebuilds
        // (`reloadWithAudioOverride`, `reloadAtCurrentPosition`) reach loadNative directly and
        // never pass through there, so a fallback spent on the outgoing session's master used to
        // leak into the reload's, which then could not recover from its own master rejection and
        // surfaced `.masterPlaylistRejected` instead of falling back (#849).
        masterFallbackUsed = false
        masterRefusedByDisplay = false
        // #95: stop the tap reader before the session (and its SegmentCache) goes away.
        // #356: counterpart to the install line, because a session-preserving reload lands here
        // too. The host sees its stream finish and has to re-install; without this the device log
        // shows a tap that was installed once and then simply stopped delivering.
        if audioTapController != nil {
            EngineLog.emit("[AetherEngine] audio tap torn down with the session "
                + "(a reload finishes the stream; re-install to follow the new one)",
                category: .engine)
        }
        audioTapController?.teardown()
        audioTapController = nil
        // #214 follow-up: the confirmation ledger is NOT cleared here. It is keyed to loadedURL and a
        // session-preserving reload runs through stopInternal too; clearing would re-pay the pass on
        // every audio switch. A new item invalidates it in startAtmosConfirmation().
        cancelAtmosConfirmation()
        // markClosed() aborts a probe blocked in avformat_open_input/find_stream_info (lock-free, idempotent).
        inFlightProbeDemuxer?.markClosed()
        liveTelemetrySampler?.stop()
        liveTelemetrySampler = nil
        diagnostics.liveTelemetry = nil
        nativeCancellables.removeAll()
        // AE#158: keepCurrentItem defers the item detach to the next host.load(inPlaceSwap:) so a
        // system PiP window never sees a nil-item gap across a native->native load. Only meaningful
        // together with keepNativeHost; load() computes it via shouldHandOverItemInPlace.
        if keepCurrentItem && keepNativeHost {
            // Keep the presentation, not the outgoing session's publishers. loadNative subscribes
            // before host.load, and @Published would replay the old EOF, clock and readiness into
            // the successor otherwise.
            nativeHost?.prepareForItemHandover()
        } else {
            nativeHost?.tearDown()
        }
        if !keepNativeHost {
            nativeHost = nil
            currentAVPlayer = nil
        }
        // #314: detach before stop() so a pump still unwinding does not report frames into a table the
        // host has already retired for the next item. Only the session's slot is cleared; the engine
        // keeps the host's observer and re-arms the next session with it in load().
        nativeVideoSession?.setNativeVideoFrameTimeObserver(nil)
        if diagnostics.sessionCacheStatus.route == .nativeRemoteHLS {
            diagnostics.sessionCacheStatus = .inactive
        }
        stopDualLayerOutputRoute()
        nativeVideoSession?.stop(reason: cacheCleanupReason)
        nativeVideoSession = nil
        nativeSubtitleRenditionsServed = false
        dolbyVisionConversion = nil
        airPlayProgressWatchdog?.cancel()
        airPlayProgressWatchdog = nil
        displayModeDiagnostic?.cancel()
        displayModeDiagnostic = nil
        playbackPanelProbe?.cancel()
        playbackPanelProbe = nil
        airPlayServedMasterToReceiver = false
        extractorYieldState.deactivate()
        setPendingRecoverySeekTarget(nil)
        // #127: readiness + deferred host seeks are session-scoped; the host-side sink can't clear them
        // once nativeCancellables are gone.
        isSessionReady = false
        isSourceSeekable = nil
        // #315: session-scoped for the same reason, and the host mirrors are being cut here.
        hasFirstFrameReadyForDisplay = false
        // AE#440: so does "this session has moved once". A reused native host carries the outgoing
        // item's rate across the swap, and crediting the next load with it would publish `.playing`
        // over the new source's whole join.
        hasTransportRolled = false
        sessionPublishesVideoDisplaySignal = false
        pendingPreReadySeek = nil
        liveItemAxisOffsetSeconds = 0
        liveItemAxisOffsetGeneration = -1
        liveRejoinPlacementGeneration = -1
        liveItemAxisStatedGeneration = -1
        liveItemAxisArmedGeneration = -1
        liveAcceptedItemGeneration = -1

        // Shut down cache-backed scrub-thumbnail FrameExtractors with the session.
        let scrubThumbs = scrubThumbnailExtractors
        scrubThumbnailExtractors.removeAll()
        for entry in scrubThumbs {
            Task { await entry.extractor.shutdown() }
        }

        softwareCancellables.removeAll()
        stopSoftwareNowPlaying()
        softwareClockSessionZero = nil
        endClockHold()
        // #353: the picture belongs to the session. Left standing, the next source would be laid out
        // against this one's rectangle for as long as it takes its own first frame to arrive.
        softwareDisplaySize = nil
        activeUpscale = nil
        decodedVideoFormat = nil
        // #314: same detach on the software path, where the outgoing renderer's decode thread is what
        // can still hand a frame over while the next host comes up.
        // The window shows this session's layer: close it while the host still feeds that layer, and
        // drop the host-set flag so the keepalive policy does not treat a gone window as live (a host
        // that drops its controller with the source never sees a did-stop).
        if let pipSource = softwarePiPSource {
            pipSource.endPictureInPicture()
            isResettingPictureInPictureForStop = true
            pictureInPictureActive = false
            isResettingPictureInPictureForStop = false
        }
        softwareHost?.setVideoFrameTimeObserver(nil)
        softwareHost?.stop()
        softwarePiPSource = nil
        softwareHost = nil

        // Clear audioHost so music<->video handoffs start from a clean slate; the engine is a process-wide
        // singleton and a lingering host would keep the old synchronizer alive under the next session.
        audioCancellables.removeAll()
        audioHost?.stop()
        audioHost = nil

        // AVPlayer audio host is KEPT alive (MPNowPlayingSession must persist). Mark inactive; next audio load
        // reuses via replaceCurrentItem.
        audioNativeCancellables.removeAll()
        audioAVPlayerActive = false
        audioAVPlayerHost?.stop()

        // #215: release the shared AVAudioSession once every render path above is quiesced. Scheduled
        // last so the item is unloaded, the AVPlayer released and the software/audio outputs stopped
        // before the session goes away, and scheduled rather than called because the release itself can
        // block for ~0.5 s on a MAT passthrough route. The caller must declare an actual final teardown;
        // the host opt-in (deactivatesAudioSessionOnStop) goes to SharedOutputCoordinator.leave, and the
        // release belongs to the last engine out.
        if finalTeardown && !keepNativeHost {
            let coordinator = SharedOutputCoordinator.shared
            let label = coordinator.label(for: ObjectIdentifier(self))
            let outcome = coordinator.leave(ObjectIdentifier(self), releasesSession: deactivatesAudioSessionOnStop)
            switch outcome {
            case .othersRemain(let count):
                EngineLog.emit("[SharedOutput] \(label) left, \(count) still active, session kept", category: .engine)
            case .lastOut(let release):
                EngineLog.emit("[SharedOutput] \(label) left last, release=\(release)", category: .engine)
            case .notMember:
                break
            }
            #if os(iOS) || os(tvOS)
            if Self.shouldDeactivateAudioSession(after: outcome) {
                scheduleAudioSessionDeactivation()
            }
            #endif
        }

        // Close custom reader on final teardown. Internal reloads pass keepCustomReader=true to survive for reuse.
        if !keepCustomReader {
            customReader?.close()
            customReader = nil
            customFormatHint = nil
            customSourceIsSeekable = false
        }

        if resetDisplayCriteria {
            resetDisplayCriteriaRespectingOthers()
        }
        playbackBackend = .none
        activeVideoDecoder = nil
        activeAudioDecoder = nil
        lastDetectedVideoCodec = AV_CODEC_ID_NONE
        lastRequiresDeinterlaceWarmup = false
        playlistShiftSeconds = 0
        liveDisplayShiftSeconds = nil
        // AE#105 / AE#270: the display origin belongs to the session that published it. Clearing it here
        // rather than only in stop() keeps a load that reuses the engine (the common path: load() runs
        // stopInternal itself) from folding the previous source's PTS origin into the new one's clock.
        sourcePresentationOrigin = 0
        latchedPresentationOrigin = nil
        displayAxisIsItemAxis = false
        setPresentationAxis(PresentationAxisMap())
        nativeClockSeconds = 0
        clock.sourceTime = 0
        clock.bufferedPosition = 0
        isBuffering = false
        residentPlaylistRanges = []
        residentRanges = []
        readerStall = .flowing
        // Hard-clear in-flight seek state: late callbacks are dropped by generation guards, but isSeeking
        // must not strand (#38). Open tickets are rejected rather than left dangling, so a host tracking
        // "did my target land" never waits on a seek whose session is gone. A ticket kept open by the
        // give-up path (recovery intent) dies here too: the session it aimed at no longer exists.
        closeSeekTicket(&programmaticSeekTicket, with: .rejected(.noActiveSession))
        closeSeekTicket(&nativeScrubSeekTicket, with: .rejected(.noActiveSession))
        closeSeekTicket(&deferredSeekTicket, with: .rejected(.noActiveSession))
        pendingScrubLanding = nil
        scrubLandingWatchdog?.cancel()
        scrubLandingWatchdog = nil
        programmaticSeekInFlight = false
        nativeScrubSeekInFlight = false
        deferredSeekInFlight = false
        programmaticSeekTarget = nil
        nativeScrubSeekTarget = nil
        deferredSeekTarget = nil
        // Through the recompute rather than assigning the two properties: it also releases the #240 side
        // reader link gate, which a stop landing mid-seek otherwise leaves owned by the video path for the
        // whole next session (the gate is per engine, not per session).
        recomputeSeekSignal()

        liveWindowTimerTask?.cancel()
        liveWindowTimerTask = nil

        cancelSidecarTask()
        stopSubtitleDrainer(reason: .sessionStopped)   // #112 rework: both channels
        resetSubtitleOCRState()                // Phase D
        subtitleDrainTargets.removeAll()
        softwareSubtitlePacketStore = nil
        activeEmbeddedSubtitleStreamIndex = -1
        activeSubtitleTrackIndex = nil
        loadedSidecarURL = nil
        isSubtitleActive = false
        subtitleCues = []
        pgsStaleArrivalGates = [:]   // #100: both channels; a hold never survives the session
        sidecarASSHeader = nil
        secondarySidecarASSHeader = nil
        isLoadingSubtitles = false
        nativeSubtitleTrackTable = []
        nativeSubtitleReapplyOrdinal = nil
        nativeSubtitleTracks = []
        nativeSubtitleReaderParams = nil
        cancelNativeSubtitleReaders()
        nativeSubtitleRenditionAvailable = false
        cancelSidecarTask(channel: .secondary)
        setSecondarySubtitleIdentity()
        loadedSecondarySidecarURL = nil
        isSecondarySubtitleActive = false
        secondarySubtitleCues = []
        isLoadingSecondarySubtitles = false
        // Clear so a stale index from the previous session can't be re-applied before the next load() repopulates audioTracks.
        activeAudioTrackIndex = nil
        // Disc title state. activeDiscTitleID is plain state the reload paths snapshot BEFORE this runs, so
        // clearing it here can't strip a title carried across an audio switch / background-resume reopen (#67).
        discTitles = []
        selectedDiscTitle = nil
        discChapters = []
        activeDiscTitleID = nil
        sourceStartSeconds = 0
        isLive = false
        isSequentialOrigin = false
        liveWindow = nil
        liveBehindWhenLastAdvancing = 0
        lastPublishedLivePlayhead = nil
        lastLiveCadenceSamplePlayhead = nil
        // AE#524: the cushion state is per session too. Left standing, a session that ended thin
        // suppressed the next session's first line until that one had been healthy once.
        lastLiveCushionLogAt = nil
        liveThinRunwayNoted = false
        liveRunwayHealthyGeneration = nil
        clock.liveEdgeTime = 0
        clock.seekableLiveRange = nil
        clock.isAtLiveEdge = false
        clock.behindLiveSeconds = 0
    }

    // MARK: - App Lifecycle

    private func setupLifecycleObservers() {
        #if os(iOS) || os(tvOS)
        let nc = NotificationCenter.default

        // Tear the VIDEO pipeline down on background. Pausing left live sessions frozen across multi-hour
        // tvOS suspension: AVPlayer decode session in mediaserverd + loopback sockets + AVIO connection all
        // stayed allocated; on resume that wedged mediaserverd system-wide until reboot. teardownVideoForBackground()
        // releases the decode session synchronously so nothing crosses into suspension.
        //
        // AUDIO (music) keeps playing in the background (UIBackgroundModes audio). Flipping state to .paused
        // while AVPlayer keeps playing desyncs MPNowPlayingInfoPropertyPlaybackRate, breaking the Now-Playing
        // badge + Siri Remote routing. Skip teardown for audio backends.
        let bgObserver = nc.addObserver(
            forName: UIApplication.didEnterBackgroundNotification,
            object: nil, queue: .main
        ) { [weak self] _ in
            Task { @MainActor in
                guard let self = self else { return }
                self.noteDidEnterBackground()
                await self.applyBackgroundPolicy()
            }
        }
        lifecycleObservers.append(bgObserver)
        let fgObserver = nc.addObserver(
            forName: UIApplication.didBecomeActiveNotification,
            object: nil, queue: .main
        ) { [weak self] _ in
            Task { @MainActor in
                guard let self else { return }
                #if os(iOS)
                self.cancelBackgroundGraceWindow()
                self.softwareHost?.exitBackgroundAudioOnly()
                #endif
                // AE#588: read the flag before clearing it. `didBecomeActive` also follows a resign that
                // never backgrounded the app (a system alert, a volume HUD), and the user cannot have
                // reached the output format in that gap, so only a real return forgets the refusal.
                let returnedFromBackground = self.isBackgrounded
                self.isBackgrounded = false
                if returnedFromBackground { Self.clearPanelRefusalOnForegroundReturn() }
                self.backgroundActionOwed = false
                self.noteVideoPresentationToHost()
            }
        }
        lifecycleObservers.append(fgObserver)

        // AE#597: mediaserverd can reset or be lost underneath a running process, and the platform
        // contract is that every audio and video object the process holds is invalid afterwards and
        // must be rebuilt. Nothing here observed that, so a session came back from a suspension,
        // reused the AVPlayer it had deliberately kept (Sodalite#149), and spent its whole recovery
        // ladder reloading onto an object that could no longer work: item after item reaching
        // readyToPlay with no usable tracks and failing with CoreMedia 'nope'.
        //
        // The flag is consumed by the next load rather than acted on here, because a reset says
        // nothing about whether anyone still wants to watch: the host decides that, and the engine
        // only has to stop pretending its old objects survived.
        for name in [AVAudioSession.mediaServicesWereResetNotification,
                     AVAudioSession.mediaServicesWereLostNotification] {
            let observer = nc.addObserver(forName: name, object: nil, queue: .main) { [weak self] note in
                let lost = note.name == AVAudioSession.mediaServicesWereLostNotification
                Task { @MainActor in self?.noteMediaServicesReset(lost: lost) }
            }
            lifecycleObservers.append(observer)
        }

        #if os(iOS) || os(tvOS)
        AudioRouteDescription.changeLogger
        #endif

        #if os(iOS) || os(tvOS)
        installRouteRemovalObserver()
        installChannelCountChangeObserver()
        #endif

        #if os(iOS)
        let routeObserver = nc.addObserver(
            forName: AVAudioSession.routeChangeNotification,
            object: AVAudioSession.sharedInstance(), queue: .main
        ) { [weak self] _ in
            Task { @MainActor in self?.recomputeAirPlayPictureStaysLocal() }
        }
        lifecycleObservers.append(routeObserver)
        #endif

        // Foreign-session interruption handling (Sodalite device-verify 2026-07-15): a live-camera
        // PiP re-claims the audio session on every play() and the system pauses AVPlayer ~10ms after
        // .playing (interruption BEGAN reason=default). The system pause never goes through pause(),
        // so the native host's durable playIntent (#122) survives the interruption and anchors the
        // resume decision. Resume fires on ENDED only when the system explicitly grants .shouldResume
        // (calls, Siri); sessions that end without it (the camera PiP closing) stay paused by design,
        // the user resumes manually. An explicit user pause() disarms the resume.
        let interruptionObserver = nc.addObserver(
            forName: AVAudioSession.interruptionNotification,
            object: AVAudioSession.sharedInstance(), queue: .main
        ) { [weak self] note in
            let info = note.userInfo ?? [:]
            let began = (info[AVAudioSessionInterruptionTypeKey] as? UInt)
                .flatMap(AVAudioSession.InterruptionType.init(rawValue:)) == .began
            let optionsRaw = info[AVAudioSessionInterruptionOptionKey] as? UInt ?? 0
            #if os(iOS)
            let reason = (info[AVAudioSessionInterruptionReasonKey] as? UInt).map(String.init) ?? "n/a"
            #else
            let reason = "n/a"
            #endif
            Task { @MainActor in
                guard let self else { return }
                let session = AVAudioSession.sharedInstance()
                if began {
                    let intent = self.nativeHost?.transportIntentIsPlaying ?? (self.state == .playing)
                    let stateEligible: Bool
                    switch self.state {
                    case .idle, .error: stateEligible = false
                    default: stateEligible = true
                    }
                    self.resumeAfterInterruption = intent && stateEligible
                    // An idle or failed session has no playback to protect, and a stale BEGAN must not
                    // leave a later session unplayable.
                    if stateEligible { self.noteAudioInterruptionBegan() }
                    EngineLog.emit("[AetherEngine] AVAudioSession interruption BEGAN reason=\(reason) resumeArmed=\(self.resumeAfterInterruption) otherAudio=\(session.isOtherAudioPlaying) silenceHint=\(session.secondaryAudioShouldBeSilencedHint)", category: .engine)
                } else {
                    let shouldResume = AVAudioSession.InterruptionOptions(rawValue: optionsRaw).contains(.shouldResume)
                    // Background: only audio backends may resume (video is torn down / must not restart unseen).
                    #if os(iOS)
                    let backgroundSafe = !self.isBackgrounded
                        || self.audioAVPlayerActive || self.audioHost != nil || self.softwareHost != nil
                    #else
                    let backgroundSafe = true
                    #endif
                    let deferredPlay = self.noteAudioInterruptionEnded()
                    let firing = Self.interruptionEndShouldPlay(
                        armed: self.resumeAfterInterruption, shouldResume: shouldResume,
                        deferredPlay: deferredPlay, backgroundSafe: backgroundSafe)
                    let pausesBefore = self.userPauseCount
                    let loadBefore = self.loadGeneration
                    EngineLog.emit("[AetherEngine] AVAudioSession interruption ENDED shouldResume=\(shouldResume) otherAudio=\(session.isOtherAudioPlaying) resumeArmed=\(self.resumeAfterInterruption) autoResume=\(firing) deferredPlay=\(deferredPlay)", category: .engine)
                    if firing {
                        self.resumeAfterInterruption = false
                        // AE#549: the native path gets its session back from AVFoundation, the renderer
                        // paths own theirs and nothing reactivated it for them. An interrupted session
                        // that is not made active again stops the audio device, and with it the
                        // synchronizer timebase every software and audio-only session reads as its
                        // master clock: the field log resumed on paper (`autoResume=true`) and stood
                        // still for two minutes. Awaited, so the session is active before play() runs.
                        if self.softwareHost != nil || self.audioHost != nil {
                            EngineLog.emit("[AetherEngine] AE#549: reactivating the renderer audio session before the resume",
                                           category: .engine)
                            await self.activateRendererAudioSession()
                        }
                        // A pause pressed while the session was being reactivated wins.
                        guard self.userPauseCount == pausesBefore, self.loadGeneration == loadBefore else { return }
                        self.play()
                    }
                }
            }
        }
        lifecycleObservers.append(interruptionObserver)
        #endif
    }

    // MARK: Owed background decision (audit CORE-2, LIF-101)

    /// Audit LIF-101: whether a background decision can be made now. Not while a load is in flight:
    /// a teardown there unwinds the host's `load()` with the `CancellationError` that means "a newer
    /// load or stop took over", and the host treats it as a supersede (no observers, no start report,
    /// a spinner that never clears).
    nonisolated static func backgroundDecisionSettles(state: PlaybackState, loadInFlight: Bool) -> Bool {
        !loadInFlight && !backgroundActionIsOwed(state: state)
    }

    private var backgroundDecisionMustWait: Bool {
        !Self.backgroundDecisionSettles(state: state, loadInFlight: loadInFlight)
    }

    var loadInFlight: Bool { loadInFlightGeneration == loadGeneration }

    func beginLoadInFlight(_ generation: UInt64) {
        loadInFlightGeneration = generation
    }

    /// Called from the load's own exit, which is the settle point a state it passes through is not.
    func endLoadInFlight(_ generation: UInt64) {
        guard loadInFlightGeneration == generation else { return }
        loadInFlightGeneration = nil
        settleOwedBackgroundAction()
        settleOwedUpscaleNativeReturn()
    }

    /// didEnterBackground's bookkeeping. Audit CORE-2: a load or seek in flight has a pipeline
    /// (loopback server, AVIO connection, the item) but no settled state to judge it by, and it
    /// settles into `.playing` in the background with nothing left to look again. Owe it the decision.
    func noteDidEnterBackground() {
        isBackgrounded = true
        backgroundActionOwed = backgroundDecisionMustWait
        noteVideoPresentationToHost()
    }

    /// Tells the software host whether a refused video rebuild may be retried now. A backgrounded app with
    /// picture-in-picture on still shows the picture, and the software host keeps decoding for it, so only
    /// a background with no picture window counts as "nothing is showing video". Also called when a load
    /// installs a new host, which would otherwise start out believing it is on screen.
    func noteVideoPresentationToHost() {
        softwareHost?.noteAppInBackground(isBackgrounded && !pictureInPictureActive)
    }

    /// Audit LIF-105: the PiP window closed while backgrounded, so nothing keeps the app running and
    /// the wedge-safe teardown is due. Through the owed funnel, so a load or seek in flight in the
    /// window is torn down once it settles instead of never.
    func settleBackgroundDecisionAfterPictureInPictureClosed() {
        guard isBackgrounded, !audioAVPlayerActive, audioHost == nil, softwareHost == nil else { return }
        backgroundActionOwed = true
        settleOwedBackgroundAction()
    }

    /// Called from the `state` didSet and from a load's exit. A decision owed since the app went to
    /// the background is made once the session has settled into a transport state.
    private func settleOwedBackgroundAction() {
        guard backgroundActionOwed, !backgroundDecisionMustWait else { return }
        backgroundActionOwed = false
        guard isBackgrounded, state == .playing || state == .paused else { return }
        EngineLog.emit(
            "[AetherEngine] background: an owed decision settled (a load or seek in flight, or a "
            + "retained paused session resuming, AE#870; state=\(state)); applying the background "
            + "policy now (audit CORE-2)",
            category: .engine)
        Task { @MainActor [weak self] in await self?.runOwedBackgroundPolicy() }
    }

    private func runOwedBackgroundPolicy() async {
        if let policy = owedBackgroundPolicyForTesting {
            await policy(self)
            return
        }
        #if os(iOS) || os(tvOS)
        await applyBackgroundPolicy()
        #endif
    }

    /// The synchronous half of the background teardown. stopInternal's replaceCurrentItem(nil) +
    /// VTDecompressionSession invalidation frees the shared mediaserverd decode session.
    /// keepNativeHost=true preserves the NativeAVPlayerHost shell for AVKit's Now-Playing registration
    /// (issue #15); keepCustomReader=true retains the byte-source reader.
    /// clock.currentTime/loadedURL/loadedOptions are preserved so reloadAtCurrentPosition() resumes correctly.
    func releaseVideoPipelineForBackground() {
        // #357: park the selection first. The foreground reload snapshots at reload time, which on
        // this path is long after stopInternal wiped what it wants.
        captureBackgroundTeardownSelection()
        // AE#597: this path emitted nothing at all, so a field log could not say whether the
        // session was released before a suspension or carried through it whole. Which of the two
        // happened is the first question every wake-from-sleep report asks.
        EngineLog.emit(
            "[AetherEngine] #597 background teardown: releasing the video pipeline "
            + "(backend=\(playbackBackend), state=\(state))",
            category: .engine)
        let teardownStart = DispatchTime.now()
        stopInternal(resetDisplayCriteria: false, keepNativeHost: true, keepCustomReader: true)
        releaseSubtitleProxyForBackground()
        // Session torn down; host will reload + repause on foreground return.
        state = .paused
        let teardownMs = Double(
            DispatchTime.now().uptimeNanoseconds - teardownStart.uptimeNanoseconds) / 1_000_000
        EngineLog.emit(
            "[AetherEngine] #597 background teardown done in "
            + "\(String(format: "%.0f", teardownMs))ms; the audio session and the native host "
            + "shell stay",
            category: .engine)
    }

    /// AE#597: `stopInternal` does not touch the proxy, so without this its loopback socket rides
    /// the suspension. Both background teardowns call it, the awaited one and the synchronous
    /// backstop the system takes when it reclaims the grace assertion early.
    private func releaseSubtitleProxyForBackground() {
        guard Self.shouldReleaseSubtitleProxyForBackground(
            hasProxy: remoteHLSSubtitleProxy != nil, isCustomSource: isCustomSource) else { return }
        remoteHLSSubtitleProxy?.tearDown()
        remoteHLSSubtitleProxy = nil
        injectedSubtitleRenditionNames = [:]
        detachRemoteHLSCueClock()   // AE#616
        EngineLog.emit(
            "[AetherEngine] #597 background teardown: remote-HLS subtitle proxy released",
            category: .engine)
    }

    #if os(iOS) || os(tvOS)
    /// What didEnterBackground does with the running session. Runs again when a load or seek that
    /// was in flight at that moment settles while the app is still in the background (audit CORE-2).
    private func applyBackgroundPolicy() async {
        guard isBackgrounded else { return }
        // Audit LIF-101: a load in flight settles this from its own exit (`endLoadInFlight`).
        if backgroundDecisionMustWait {
            backgroundActionOwed = true
            return
        }
        #if os(iOS)
        // Keep the video pipeline alive for PiP / background audio while the app stays running.
        // Wedge-safe: a pause while backgrounded tears down via pause(), so nothing crosses
        // an idle suspension.
        let keepAlive = Self.shouldKeepVideoAlive(enabled: backgroundPlaybackEnabled,
                                                  pipActive: pictureInPictureActive,
                                                  state: state)
        let supportsGrace = true
        #else
        // tvOS: only an active PiP window defers the wedge-safe teardown (the system keeps the app
        // running while its PiP window lives); no grace window, no background-audio case. The
        // pictureInPictureActive didSet tears down the moment PiP ends while still backgrounded.
        let keepAlive = Self.shouldKeepVideoAliveTV(enabled: backgroundPlaybackEnabled,
                                                    pipActive: pictureInPictureActive)
        let supportsGrace = false
        #endif
        let action = Self.backgroundAction(
            isAudioBackend: audioAVPlayerActive || audioHost != nil,
            hasSoftwareHost: softwareHost != nil,
            softwareHostHasAudio: softwareHost?.deliversAudio == true,
            keepVideoAlive: keepAlive,
            pipActive: pictureInPictureActive,
            state: state,
            retainPausedVideoPipeline: retainsVideoPipelineWhenBackgrounded
        )
        switch Self.backgroundStep(
            action: action,
            state: state,
            supportsGraceWindow: supportsGrace,
            graceSeconds: backgroundTeardownGraceSeconds
        ) {
        case .perform(.doNothing):
            return
        case .perform(.enterSoftwareAudioOnly):
            softwareHost?.enterBackgroundAudioOnly()
        case .perform(.teardownVideo):
            if keepAlive {
                EngineLog.emit("[AetherEngine] AE#739 the software host renders no audio, releasing it "
                               + "instead of entering background audio-only", category: .engine)
            }
            await teardownVideoForBackground()
        case .deferTeardown(let seconds):
            #if os(iOS)
            scheduleBackgroundGraceTeardown(afterSeconds: seconds)
            #endif
        }
    }

    /// Release the video pipeline before tvOS suspension (`releaseVideoPipelineForBackground`).
    ///
    /// A UIApplication background-task assertion is held across teardown so the loopback server's detached
    /// socket close (HLSVideoEngine.stop drains the producer up to 3 s) completes before suspension.
    private func teardownVideoForBackground() async {
        let app = UIApplication.shared
        let bgTask = app.beginBackgroundTask(withName: "AetherEngine.bgVideoTeardown")
        releaseVideoPipelineForBackground()
        // Wait for the loopback server's detached cleanup (<=3 s producer drain + socket shutdown) before releasing.
        try? await Task.sleep(nanoseconds: 3_500_000_000)
        if bgTask != .invalid { app.endBackgroundTask(bgTask) }
    }

    #if os(iOS)
    // MARK: #127 paused-background grace window

    /// Hold the paused pipeline alive under a background-task assertion for the grace window, then
    /// re-evaluate and tear down. didBecomeActive cancels the window, making a quick app switch free.
    private func scheduleBackgroundGraceTeardown(afterSeconds seconds: Double) {
        guard backgroundGraceTask == nil else { return }  // window already armed
        let app = UIApplication.shared
        let assertion = app.beginBackgroundTask(withName: "AetherEngine.bgGraceWindow") { [weak self] in
            // System reclaimed the window early. UIKit calls this on the main thread; the synchronous
            // stopInternal releases the decode session, the 3.5 s socket drain is skipped (no time).
            MainActor.assumeIsolated {
                self?.expireBackgroundGraceNow()
            }
        }
        guard assertion != .invalid else {
            // Background execution unavailable: fall back to the immediate teardown.
            Task { @MainActor in await self.teardownVideoForBackground() }
            return
        }
        backgroundGraceAssertion = assertion
        // Clamp: the system allowance is ~30 s; longer values would just move the work into the
        // expiration backstop (and an unbounded host value must not overflow the ns conversion).
        let window = min(max(0, seconds), 60)
        EngineLog.emit("[AetherEngine] background grace window armed (\(String(format: "%.0f", window))s) before paused teardown (#127)", category: .engine)
        backgroundGraceTask = Task { @MainActor [weak self] in
            try? await Task.sleep(nanoseconds: UInt64(window * 1_000_000_000))
            guard let self, !Task.isCancelled else { return }
            await self.fireBackgroundGraceTeardown()
        }
    }

    /// Grace expiry: re-evaluate the background action (PiP can start and lock-screen play can resume
    /// mid-window) and perform it without further deferral.
    private func fireBackgroundGraceTeardown() async {
        backgroundGraceTask = nil
        if isBackgrounded, backgroundDecisionMustWait {
            // Audit LIF-101: a load the host started inside the window gets the decision at its exit.
            backgroundActionOwed = true
        } else if isBackgrounded {
            switch currentBackgroundAction() {
            case .teardownVideo:
                EngineLog.emit("[AetherEngine] background grace window expired, tearing down paused pipeline (#127)", category: .engine)
                await teardownVideoForBackground()
            case .enterSoftwareAudioOnly:
                softwareHost?.enterBackgroundAudioOnly()
            case .doNothing:
                EngineLog.emit("[AetherEngine] background grace window expired, session now kept alive (#127)", category: .engine)
            }
        }
        endBackgroundGraceAssertion()
    }

    /// Expiration-handler backstop: synchronous minimal teardown before the assertion is force-ended.
    private func expireBackgroundGraceNow() {
        backgroundGraceTask?.cancel()
        backgroundGraceTask = nil
        if isBackgrounded, currentBackgroundAction() == .teardownVideo {
            EngineLog.emit("[AetherEngine] background grace assertion expired early, synchronous teardown (#127)", category: .engine)
            captureBackgroundTeardownSelection()   // #357, as in teardownVideoForBackground
            stopInternal(resetDisplayCriteria: false, keepNativeHost: true, keepCustomReader: true)
            releaseSubtitleProxyForBackground()
            state = .paused
        }
        endBackgroundGraceAssertion()
    }

    private func cancelBackgroundGraceWindow() {
        guard backgroundGraceTask != nil || backgroundGraceAssertion != .invalid else { return }
        backgroundGraceTask?.cancel()
        backgroundGraceTask = nil
        endBackgroundGraceAssertion()
        EngineLog.emit("[AetherEngine] background grace window cancelled, session survives the app switch (#127)", category: .engine)
    }

    private func endBackgroundGraceAssertion() {
        guard backgroundGraceAssertion != .invalid else { return }
        UIApplication.shared.endBackgroundTask(backgroundGraceAssertion)
        backgroundGraceAssertion = .invalid
    }

    /// Live recomputation of the keepalive + background action for grace-window re-evaluation.
    private func currentBackgroundAction() -> BackgroundAction {
        let keepAlive = Self.shouldKeepVideoAlive(
            enabled: backgroundPlaybackEnabled,
            pipActive: pictureInPictureActive,
            state: state
        )
        return Self.backgroundAction(
            isAudioBackend: audioAVPlayerActive || audioHost != nil,
            hasSoftwareHost: softwareHost != nil,
            softwareHostHasAudio: softwareHost?.deliversAudio == true,
            keepVideoAlive: keepAlive,
            pipActive: pictureInPictureActive,
            state: state,
            retainPausedVideoPipeline: retainsVideoPipelineWhenBackgrounded
        )
    }
    #endif
    #endif
}

/// AE#444 follow-up (Sodalite#104): what a resume after a long pause had to do, for a host that wants
/// to say so.
public struct LiveResumeClamp: Sendable, Equatable {
    /// Seconds the playhead was moved FORWARD: the content the sliding window took while the session
    /// was paused, which is what the viewer does not get to see.
    public let skippedSeconds: Double
    /// How far behind the live edge the resumed position is. Zero when the clamp was an edge snap,
    /// which is what a live-only session with no DVR window gets.
    public let behindLiveSeconds: Double

    public init(skippedSeconds: Double, behindLiveSeconds: Double) {
        self.skippedSeconds = skippedSeconds
        self.behindLiveSeconds = behindLiveSeconds
    }
}

// MARK: - Errors

public enum AetherEngineError: Error, LocalizedError {
    case noVideoStream
    case noAudioStream
    /// AE#140: an HLS playlist body arrived on the generic raw-byte live path. Since AE#363 a `.url`
    /// source is routed onto the live ingest instead of throwing, so this reaches a host only for a
    /// custom `IOReader`, which has no playlist URL for the engine to ingest from: re-point the reader,
    /// or hand the playlist URL to `load(url:)` (with `isLive: true`) and let the engine route it.
    case hlsPlaylistOnRawLivePath
    /// #176 follow-up: HEVC P5 / AV1 P10.0 carry only an IPT-PQ-c2 signal (no compatible base layer);
    /// the software path would decode it as YCbCr (green/purple cast), so the load fails instead.
    /// AV1 P10.0 requires hardware AV1 decode; HEVC P5 requires a seekable source for the native path.
    case dolbyVisionUnplayableOnSoftwarePath(profile: String)
    /// AE#460: `reloadAtCurrentPosition(applying:)` was handed a change to a `LoadOptions` field
    /// that names the session rather than tunes it. The session is untouched and still playing;
    /// changing these means loading the source again.
    case loadIdentityNotCorrectable(fields: [String])
    /// AE#460: this session cannot be rebuilt in place. Read `sessionReloadRefusal` to ask the same
    /// question without attempting the reload.
    case sessionNotReloadable(SessionReloadRefusal)

    public var errorDescription: String? {
        switch self {
        case .noVideoStream: return "No video stream in source"
        case .noAudioStream: return "No audio stream in source"
        case .hlsPlaylistOnRawLivePath:
            return "HLS playlist supplied to the raw live path. Use LoadOptions.nativeRemoteHLS or HLSLiveIngestReader for m3u8 sources."
        case .dolbyVisionUnplayableOnSoftwarePath(let profile):
            return "Dolby Vision Profile \(profile) has no compatible base layer and cannot be color-correctly decoded on the software playback path"
        case .loadIdentityNotCorrectable(let fields):
            let named = "LoadOptions." + fields.joined(separator: ", LoadOptions.")
            return fields.count == 1
                ? "\(named) names the session and cannot be changed by a session-preserving reload; load the source again to change it"
                : "\(named) name the session and cannot be changed by a session-preserving reload; load the source again to change them"
        case .sessionNotReloadable(let refusal):
            return "The session cannot be rebuilt at its current position: \(refusal)"
        }
    }
}
