import Foundation
import os
import AetherLibavformat
import AetherLibavutil

/// Custom AVIO context feeding FFmpeg via URLSession. Three modes:
/// - **Persistent** (known size + prefetch=true, playback path): single long-lived
///   `Range: bytes=<pos>-` GET into a sliding window; reconnects on drop/429/503/509.
///   Fix for AetherEngine#25 (CDN stutter collapsing playback). See `readPersistent`.
/// - **Seekable chunked** (known size + prefetch=false, still/frame-extraction):
///   discrete Range chunks for random access. See `readSeekable`.
/// - **Streaming** (size=-1): single sequential GET, no reconnect. See `readStreaming`.
///
/// AVIO callbacks run on the demux queue; prefetch/delivery on background queues.
/// Shared state protected by locks.

/// Dedupes `ReaderNetworkPhase` emissions so a flapping origin does not spam the callback (#85).
/// Held under the reader's `networkPhaseLock` together with the sink it deduplicates for (#433).
///
/// The first statement always goes out, `.flowing` included (#410). The gate is per reader INSTANCE while
/// the phase it feeds is per engine, so a reader installed by a reopen starts with no opinion rather than
/// with the assumption that it already reported delivery: assuming it is what let a fresh reader recover in
/// silence and strand the engine on the previous reader's last word.
struct NetworkPhaseGate {
    private var last: ReaderNetworkPhase?
    mutating func shouldEmit(_ next: ReaderNetworkPhase) -> Bool {
        guard next != last else { return false }
        last = next
        return true
    }

    /// A listener that just attached has heard nothing, whatever this reader said before it arrived (#433).
    /// The gate deduplicates emissions to a SINK, and the restart's reopen forms its opinion during
    /// `open()`, one wiring step before the sink exists: without this, the reader that now serves the
    /// session has nothing left to say and the axis keeps describing the reader that was aborted.
    mutating func forgetForNewListener() {
        last = nil
    }
}

final class AVIOReader: AVIOProvider, @unchecked Sendable {

    private let url: URL
    private let openedHeaders: [String: String]
    /// AE#792: the session's live header set, when the reader was opened for one. Read per request,
    /// so a host that rotates a credential mid-session reaches the next request (a reconnect already
    /// backing off included) without a rebuild. Nil for every reader opened outside a session (a probe,
    /// a sidecar, a still), which keep the headers they were opened with.
    private let requestHeaderStore: RequestHeaderStore?
    private var extraHeaders: [String: String] { requestHeaderStore?.current ?? openedHeaders }
    /// #450: connections the BOUNDED pool may hold to one host. A throttle, and it is allowed to be
    /// one: every request on that pool ends (a 4 MB detour block, a size probe, the tail prefetch),
    /// so a request that waits here waits for one that is finishing.
    static let boundedConnectionsPerHost = 2

    /// #450: connections the LONG-LIVED pool may hold to one host. Deliberately above any plausible
    /// reader count rather than a limit, because the same number that throttles the bounded pool
    /// deadlocks this one. See `makeSessionConfig`.
    static let longLivedConnectionsPerHost = 64

    struct HopTiming {
        let host: String
        let port: Int
        let status: Int?
        let ttfbMs: Double
        let totalMs: Double
    }

    /// #377 follow-up: 32 MB at 100 Mbps takes about 3 seconds after a healthy first byte, while
    /// measured stalls waited 5.3 and 9.5 seconds before one; trigger on summed redirect-hop TTFB.
    static func slowFirstByteLine(taskSeconds: TimeInterval, hops: [HopTiming]) -> String? {
        let firstByteMs = hops.reduce(0) { $0 + $1.ttfbMs }
        guard firstByteMs > 1_000 else { return nil }
        let taskMs = Int((taskSeconds * 1_000).rounded())
        let summary = hops.map { hop in
            var fields = ["\(hop.host):\(hop.port)"]
            if let status = hop.status { fields.append("status=\(status)") }
            fields.append("ttfb=\(Int(hop.ttfbMs.rounded()))ms")
            fields.append("total=\(Int(hop.totalMs.rounded()))ms")
            return fields.joined(separator: " ")
        }.joined(separator: " -> ")
        return "[AVIOReader] slow first byte: task=\(taskMs)ms over \(hops.count) hops: \(summary)"
    }

    /// Signed redirect paths and queries carry tokens, so only host and port cross this adapter.
    static func hopTiming(_ transaction: URLSessionTaskTransactionMetrics) -> HopTiming? {
        guard let url = transaction.request.url,
              let host = url.host,
              let fetchStart = transaction.fetchStartDate,
              let responseStart = transaction.responseStartDate,
              let responseEnd = transaction.responseEndDate else { return nil }
        let port: Int
        if let explicitPort = url.port {
            port = explicitPort
        } else if url.scheme?.lowercased() == "https" {
            port = 443
        } else if url.scheme?.lowercased() == "http" {
            port = 80
        } else {
            return nil
        }
        return HopTiming(
            host: host,
            port: port,
            status: (transaction.response as? HTTPURLResponse)?.statusCode,
            ttfbMs: responseStart.timeIntervalSince(fetchStart) * 1_000,
            totalMs: responseEnd.timeIntervalSince(fetchStart) * 1_000
        )
    }

    /// Session config factory. Short-lived probes/chunks get a 60s resource timeout;
    /// long-lived persistent/streaming connections omit it (fires mid-stream, NSURLError
    /// -1001; stall detection is handled by `connStallTimeout`). `urlCache = nil` avoids
    /// the "N URLCaches racing async invalidation" leak (reverted in fef8ef4).
    ///
    /// #450: the two pools carry different requests, so they carry different cap policies.
    ///
    /// `persistentSession` is a `static let`, so its cap is not a per-reader allowance, it is the
    /// whole PROCESS's allowance to one origin, shared by every reader in it: the pump, the
    /// subtitle side reader, the forward prefetcher, and one more pump per playback surface. Its
    /// requests are open-ended by design, a live pump holding its connection for the whole session,
    /// so the request that arrives on top of the cap is not slowed, it is parked behind connections
    /// that are not going to end. URLSession parks it with no callback, no error and no metrics, so
    /// the wait is not even observable as a wait: `awaitFirstPersistentData` spends its full 15 s
    /// and the load reports a source that would not open, for a queue the engine built itself
    /// (measured, reporter of #450: four live tiles on one origin, tiles 3 and 4 zero bytes, while
    /// three concurrent `curl` pulls of the same endpoints flowed at full rate).
    ///
    /// What the engine asks of one origin is bounded by `OriginRequestBudget` (#377) instead. That
    /// one counts requests rather than connections, which is what an origin meters and the only
    /// thing that means anything over h2, it waits with a budget, it says that it waited, and it
    /// lowers itself when the origin answers 429/503/509. A second ceiling underneath it, silent
    /// and unyielding, made the documented contract of `LoadOptions.maxConcurrentSourceRequests ==
    /// nil` ("counts but does not cap") false from the third concurrent long-lived read on. A
    /// declared ceiling is a lie for as long as a lower one is silent.
    static func makeSessionConfig(longLived: Bool = false) -> URLSessionConfiguration {
        let config = URLSessionConfiguration.ephemeral
        if !longLived {
            config.timeoutIntervalForResource = 60
        }
        config.httpMaximumConnectionsPerHost =
            longLived ? longLivedConnectionsPerHost : boundedConnectionsPerHost
        config.requestCachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        // No URLCache instance, kills the in-memory cache that the
        // long-lived-session fix from fef8ef4 was working around.
        config.urlCache = nil
        return config
    }
    private var position: Int64 = 0
    private var fileSize: Int64 = -1

    /// Typed source-fetch network phase, pushed on every stall/reconnect/recovery transition (#85).
    /// Mirrors `HLSVideoEngine.onSeekStateChanged`. `@Sendable`: invoked from the demux thread, the
    /// consumer hops to the main actor. Set only on the MAIN playback reader, never the subtitle side reader.
    ///
    /// #433: the sink and its dedupe history are one thing, under one leaf lock. The sink is installed from
    /// whichever thread runs the handover (a producer restart, a live reopen) while the demux thread is the
    /// one emitting, and attaching a listener CLEARS the history: a listener that just arrived has heard
    /// nothing, whatever this reader said into a nil sink during its own `open()`.
    var onNetworkPhaseChanged: (@Sendable (ReaderNetworkPhase) -> Void)? {
        get {
            networkPhaseLock.lock(); defer { networkPhaseLock.unlock() }
            return _onNetworkPhaseChanged
        }
        set {
            networkPhaseLock.lock()
            _onNetworkPhaseChanged = newValue
            networkPhaseGate.forgetForNewListener()
            networkPhaseLock.unlock()
        }
    }

    /// Whether the consumer intends to play, mirrored from the same source the segment producer
    /// reads (`HLSVideoEngine.playIntentProvider`). Nil is an intent nobody reported, and that is
    /// read as stopped rather than as playing: every path that plays wires this, so the reader
    /// left without it is one whose consumer the engine cannot vouch for, and the safe answer
    /// there is the bounded one. Choosing "playing" would let such a reader hold a dormant flow
    /// for as long as it lives, which is the #310 exposure this flag is supposed to bound.
    ///
    /// Behind a leaf lock like the phase sink below, and for the same reason: the demuxer forwards
    /// it whenever the engine assigns it, which may be after `open()`, while the held connection's
    /// pump thread reads it. Taken UNDER `winCond`, never the other way round.
    var playIntentProvider: (@Sendable () -> Bool)? {
        get {
            playIntentLock.lock()
            defer { playIntentLock.unlock() }
            return _playIntentProvider
        }
        set {
            playIntentLock.lock()
            _playIntentProvider = newValue
            playIntentLock.unlock()
        }
    }
    private let playIntentLock = NSLock()
    private var _playIntentProvider: (@Sendable () -> Bool)?

    /// Leaf lock over the sink and its gate: takes no other lock, and no other lock is held across it.
    private let networkPhaseLock = NSLock()
    private var _onNetworkPhaseChanged: (@Sendable (ReaderNetworkPhase) -> Void)?
    private var networkPhaseGate = NetworkPhaseGate()

    /// Emit a phase transition through the gate. Called from the demux thread; the sink runs OUTSIDE the
    /// lock so a consumer hop can never serialize against the read loop.
    private func emitNetworkPhase(_ phase: ReaderNetworkPhase) {
        networkPhaseLock.lock()
        let sink = networkPhaseGate.shouldEmit(phase) ? _onNetworkPhaseChanged : nil
        networkPhaseLock.unlock()
        sink?(phase)
    }

    /// Cached CDN URL after redirect resolution; skips proxy hop on subsequent chunks.
    /// Auth-expiry statuses (401/403/404/410) against it invalidate and fall back to
    /// the source URL. See AetherEngine#12.
    private let resolvedURLLock = NSLock()
    private var _resolvedURL: URL?
    /// The pin the ladder most recently dropped, kept only to describe what answers next (#377).
    /// A source that re-mints the SAME target the ladder just dropped has not handed out a fresh
    /// lease, and off the responding host alone that case is indistinguishable from a fresh target
    /// refusing, which is the reading that puts metering back on the table. Two different causes,
    /// two different fixes, one log line to tell them apart.
    private var _droppedResolvedURL: URL?

    private func requestURL() -> URL {
        resolvedURLLock.lock()
        defer { resolvedURLLock.unlock() }
        return _resolvedURL ?? url
    }

    /// #392: when bytes for this source last came off the NETWORK, across generations. Wall clock
    /// on purpose: a lease expires in wall time, and a device that slept through the gap has let it
    /// expire too, which `uptimeNanoseconds` would hide. `lastDeliveryAt` cannot answer this
    /// question at all, since `startPersistentConnection` rebases it to the connection start and it
    /// therefore always reads as fresh at the moment a refusal is being judged.
    ///
    /// Leaf lock: these two take no other lock, and nothing takes `winCond` while holding this one,
    /// so the delivery path can stamp it from inside its own winCond section.
    private let deliveryClockLock = NSLock()
    private var _lastNetworkDeliveryAt = Date()

    private func noteNetworkDelivery() {
        deliveryClockLock.lock()
        _lastNetworkDeliveryAt = Date()
        deliveryClockLock.unlock()
    }

    /// Negative gaps (a wall clock stepped backwards) read as zero, i.e. as "not idle", which
    /// falls back to the keep-pin grace rather than dropping a pin on a clock adjustment.
    private func secondsSinceNetworkDelivery() -> TimeInterval {
        deliveryClockLock.lock()
        let last = _lastNetworkDeliveryAt
        deliveryClockLock.unlock()
        return max(0, Date().timeIntervalSince(last))
    }

    private func cachedResolvedURL() -> URL? {
        resolvedURLLock.lock()
        defer { resolvedURLLock.unlock() }
        return _resolvedURL
    }

    private func recordResolvedURL(_ resolved: URL?) {
        guard let resolved else { return }
        // #388: the pinned target is where every later request is keyed, so it has to share the
        // source's request budget. Idempotent, and stated here as well as at the redirect itself
        // because a pin is also how a resolve that no delegate of ours followed becomes visible.
        OriginRequestBudget.shared.noteRedirect(from: url, to: resolved)
        // #377 round 5: this runs off an ACCEPTED response, so the target is answering. Clearing it
        // from the dropped ledger is what keeps "dropped and minted again" meaning a target that is
        // still refusing, instead of a label a host wears for the rest of the process.
        OriginRequestBudget.shared.noteTargetHealthy(resolved)
        resolvedURLLock.lock()
        defer { resolvedURLLock.unlock() }
        if resolved != url && resolved != _resolvedURL {
            _resolvedURL = resolved
            // Release-visible, and rare by construction: only a pin that actually CHANGES logs, so
            // a healthy session emits this once. Which target is pinned is half of every field
            // trace about a redirecting origin (#307, #377, #380), and behind `#if DEBUG` it was
            // readable only by the reporters who happened to build the engine themselves.
            EngineLog.emit("[AVIOReader] Cached resolved URL host=\(resolved.host ?? "?")", category: .demux)
        }
    }

    private func invalidateResolvedURL(reason: String = "expiry status") {
        resolvedURLLock.lock()
        var droppedNow: URL?
        if _resolvedURL != nil {
            droppedNow = _resolvedURL
            _droppedResolvedURL = _resolvedURL
            _resolvedURL = nil
            // The other half, and the one #380 turned into a decision: dropping the pin is now a
            // policy the ladder makes (the bounded keep-pin grace), not just a reaction to an
            // expiry status. A rung the field cannot see is a rung the next trace cannot confirm.
            EngineLog.emit("[AVIOReader] Dropped resolved URL cache (\(reason))", category: .demux)
        }
        resolvedURLLock.unlock()
        // Outside the reader's lock, and outside the reader's lifetime: the ledger belongs to the
        // origin because the next request against it may well come from a demuxer that does not
        // exist yet (#377 round 5).
        if let droppedNow { OriginRequestBudget.shared.noteTargetDropped(droppedNow, from: url) }
    }

    /// #377/#380: this attempt is going through the source because the ladder dropped a pin, i.e.
    /// it is the re-resolve the drop was for. On the REQUEST side, because a target that never
    /// answers at all leaves no response line to read it off, and a drop whose next attempt cannot
    /// be seen going anywhere is a rung the field has to take on trust. Rare by construction: it
    /// stops as soon as a 2xx pins again.
    private func reResolveNote() -> String {
        resolvedURLLock.lock()
        defer { resolvedURLLock.unlock() }
        guard _resolvedURL == nil, _droppedResolvedURL != nil else { return "" }
        return " re-resolving through the source"
    }

    /// #377/#380: which target answered, in the terms the ladder decides in.
    ///
    /// A pin is only ever recorded from a 2xx, deliberately (pinning a target that just refused
    /// would key the whole session on it), so a re-resolve that lands on a refusing target is
    /// recorded nowhere. Read from outside, the absence of a `Cached resolved URL host=` line after
    /// a drop is then indistinguishable between three shapes that need three different fixes: the
    /// source refused the re-resolve itself, the source handed back the target just dropped, or a
    /// genuinely fresh target refused. Only the last one means the origin is metering us. This is
    /// the line that says which.
    private func respondingTargetDescription(_ responded: URL?) -> String {
        resolvedURLLock.lock()
        let pinned = _resolvedURL
        let dropped = _droppedResolvedURL
        resolvedURLLock.unlock()
        let droppedEarlier = OriginRequestBudget.shared.droppedTargets(for: url)
        return Self.describeRespondingTarget(
            responded: responded, source: url, pinned: pinned, dropped: dropped,
            droppedEarlier: droppedEarlier)
    }

    /// Compared on the ORIGIN KEY, never on the whole URL: a source that re-mints a link for the
    /// same edge host with a fresh signature has handed back the same target, and reading that as a
    /// fresh one is exactly the mistake that puts metering back on the table.
    ///
    /// `droppedEarlier` comes from the origin's books rather than from this instance (#377 round 5).
    /// A metered revive builds a fresh demuxer, so the reader asking here is routinely NOT the one
    /// that dropped the target seconds ago, and an instance-scoped ledger answered `resolved
    /// freshly` for exactly those attempts: one host, one refusal window, two verdicts depending on
    /// which reader happened to ask, and the rebuilds are both the majority of the asks and the ones
    /// with no history.
    static func describeRespondingTarget(
        responded: URL?, source: URL, pinned: URL?, dropped: URL?,
        droppedEarlier: Set<String> = []
    ) -> String {
        guard let responded, let host = responded.host,
              let key = OriginRequestBudget.originKey(for: responded) else { return "" }
        if key == OriginRequestBudget.originKey(for: source) {
            return " from the source itself (\(host)), not a redirect target"
        }
        if let pinned, key == OriginRequestBudget.originKey(for: pinned) {
            return " from the pinned target \(host)"
        }
        if let dropped, key == OriginRequestBudget.originKey(for: dropped) {
            return " from \(host), the target this session dropped and the source minted again"
        }
        if droppedEarlier.contains(key) {
            return " from \(host), a target an earlier window dropped and the source minted again"
                + (dropped == nil ? " (a drop this reader did not make)" : "")
        }
        return " from \(host), a target the source resolved freshly"
    }

    /// Statuses that say the RESOLVED address is the problem, so the productive move is one
    /// re-resolve through the source URL for a fresh redirect rather than another attempt against
    /// the same pinned target.
    ///
    /// #405: 407 belongs here and used to fall through all three classifiers (no pin drop from the
    /// status, mid-stream cap of 12, the pin dropped only later by the unproductive-streak rule).
    /// On a redirect chain a 407 from the pinned media host cannot mean "authenticate to your
    /// proxy": the request went out direct, which is exactly why CFNetwork logs it as *Received
    /// unexpected proxy response*, and a genuinely configured proxy is answered by URLSession's own
    /// auth challenge long before a status reaches us. What it means is that the pinned lease is
    /// gone or an interception answered in its place, and re-resolving is the only move that can
    /// work (field trace: two wasted attempts, then the reader re-resolved and connected).
    ///
    /// 402 and 451 are the same shape from panels that answer an expired subscription or a
    /// geo-refusal per edge node: the source still mints working targets, this one stopped being
    /// one. Rate-limit statuses stay OUT (429/503/509 mean the origin is metering us and the pin is
    /// fine, #71/#307); so does every 5xx, which `isResolvedHardServerError` handles with its own
    /// reason string.
    static func isResolvedExpiryStatus(_ status: Int) -> Bool {
        return status == 401 || status == 402 || status == 403 || status == 404
            || status == 407 || status == 410 || status == 451
    }

    /// Rate-limit-shaped statuses: the origin is metering us, not failing. 429/503 carry
    /// Retry-After (#71); 509 "Bandwidth Limit Exceeded" (nonstandard) is what a
    /// connection-capped IPTV panel answers while its slot is still occupied by the
    /// connection being replaced — the slot frees in seconds, the pinned redirect target
    /// is fine, and re-resolving through the portal spends the one request there is no
    /// room for (519ae26e, #307 follow-up). That grace is bounded, not absolute: a 509
    /// that outlives `rateLimitRepinStreak` paced attempts is a pinned edge target whose
    /// session expired (a resume after minutes of pause), and there the pin is dropped
    /// for one re-resolve through the source.
    static func isRateLimitStatus(_ status: Int) -> Bool {
        return status == 429 || status == 503 || status == 509
    }

    /// AE#925: an Xtream panel at its connection cap answers a live request with HTTP 200 and a
    /// short `text/plain` notice ("CONNECTION LIMIT REACHED ..."). Taken as media, the notice went
    /// into the window, the connection ended, and the reconnect counted the bytes as progress and
    /// asked again at once: 436 requests in 10 s against an origin holding the slot for 10 s.
    /// The header only makes a body a suspect, because a playlist or an MPD can be served the same
    /// way (one Xtream path answers TS or HLS by its query, and the AE#140/AE#363 reroute reads the
    /// body to tell). A text type without a length is not one either: a mislabelled TS feed never
    /// ends. 64 KiB is far above the panels' few hundred bytes and far below anything that plays.
    static let liveTextNoticeMaxBytes: Int64 = 64 * 1024

    static func isLiveTextNoticeCandidate(_ http: HTTPURLResponse) -> Bool {
        guard http.statusCode == 200 || http.statusCode == 206 else { return false }
        let type = (http.value(forHTTPHeaderField: "Content-Type") ?? "").lowercased()
        guard type.hasPrefix("text/") else { return false }
        let length = http.expectedContentLength
        return length > 0 && length <= liveTextNoticeMaxBytes
    }

    /// The suspect's whole body decides: a playlist or a manifest goes on to the reroute that reads
    /// it, a body opening on the TS sync byte is media whatever its label says, anything else is
    /// the origin saying no.
    static func isConnectionRefusalNotice(_ body: [UInt8]) -> Bool {
        guard let first = body.first, first != 0x47 else { return false }
        return !bodyBeginsWithHLSPlaylistTag(body) && !DASHManifest.bodyBeginsWithManifest(body)
    }

    /// The notice as one log line: printable ASCII, line breaks folded, capped.
    static func noticeExcerpt(_ body: [UInt8], limit: Int = 120) -> String {
        let printable = String(decoding: body.filter { (0x20...0x7E).contains($0) || $0 == 0x0A }, as: UTF8.self)
        let text = printable.split(separator: "\n").map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }.joined(separator: " / ")
        guard text.count > limit else { return text }
        return text.prefix(limit).trimmingCharacters(in: CharacterSet(charactersIn: " /")) + "..."
    }

    /// AE#792 part 2: the origin refused the request's credentials. An identical request carrying
    /// the identical credential cannot succeed, so these get a short ladder of their own instead of
    /// the twelve unproductive reconnects a dropped connection is given, and the refusal is stamped
    /// on the session's header store so the engine can tell "the token lapsed" from "the source is
    /// gone".
    static func isCredentialRefusalStatus(_ status: Int) -> Bool {
        return status == 401 || status == 403
    }

    /// Hard server errors answered by a pinned post-redirect URL: the redirect target
    /// may be dead or expired while the source URL would mint a fresh one. Rate-limit
    /// statuses are excluded — the origin is metering us, and the pin is not the
    /// problem there.
    static func isResolvedHardServerError(_ status: Int) -> Bool {
        return status >= 500 && !isRateLimitStatus(status)
    }

    // Cumulative bytes fetched since open; memory probe compares against RSS growth.
    private let counterLock = NSLock()
    private var _cumulativeBytesFetched: Int64 = 0
    var cumulativeBytesFetched: Int64 {
        counterLock.lock()
        defer { counterLock.unlock() }
        return _cumulativeBytesFetched
    }
    /// #377: the origin just answered 429/503/509. Charge it against the shared budget, which
    /// lowers the concurrency this origin is offered from here on and stamps the refusal so the
    /// engine's revive arm can tell "metered" from "gone" (the FFmpeg-side code is -1 and carries
    /// neither). Called from wherever a status is first read, once per refusal.
    ///
    /// `respondedBy` is the host that ANSWERED, which is not always the one we asked: once the
    /// ladder has dropped the pin the request goes to the source, and a 302 can still put the
    /// refusal on an edge target. Keying off `requestURL()` there names the source in the books for
    /// an answer it never gave. The chain folding (#388) lands both keys in one bucket either way,
    /// so this is about which host the books name, not about which budget moves.
    private func noteOriginRefusal(status: Int, retryAfter: TimeInterval? = nil,
                                   respondedBy: URL? = nil) {
        let refusing = respondedBy ?? requestURL()
        if isLive {
            // A live stream's refusal is retried on its own short cadence (`liveRefusalRetryInterval`),
            // which is the pacing: arming the pacer as well would hold the retry, and the reload or
            // reopen after it, for the quiet period (up to 15 s, and up to 10 s of waiting on each
            // request) over a refusal that clears in seconds. The books still carry the refusal, so
            // the engine's revive arm can tell a metered source from a lost one.
            OriginRequestBudget.shared.noteRefusalWitnessed(for: refusing)
            if OriginRequestBudget.originKey(for: refusing) != OriginRequestBudget.originKey(for: url) {
                OriginRequestBudget.shared.noteRefusalWitnessed(for: url)
            }
            return
        }
        OriginRequestBudget.shared.noteRefusal(for: refusing, status: status, retryAfter: retryAfter)
        // The refusal usually comes back from the post-redirect CDN, while the engine's revive arm
        // only knows the URL the host loaded. Where those differ (a proxy that 302s to a signed CDN
        // target, the shape in the #377 report) the verdict would never be found on the key the
        // engine asks about. Stamp the source URL as a witness, without moving its budget: the
        // proxy did not refuse us and should not be throttled for it.
        if OriginRequestBudget.originKey(for: refusing) != OriginRequestBudget.originKey(for: url) {
            OriginRequestBudget.shared.noteRefusalWitnessed(for: url)
        }
    }

    /// Charges a 429/503/509 to the origin. `parseRetryAfter` reads an absent header as 0, which has
    /// to reach the budget as nil: a zero would arm a quiet period of nothing instead of the ladder.
    private func noteRateLimitedResponse(_ response: HTTPURLResponse?) {
        guard let response, Self.isRateLimitStatus(response.statusCode) else { return }
        let retryAfter = Self.parseRetryAfter(response)
        noteOriginRefusal(status: response.statusCode, retryAfter: retryAfter > 0 ? retryAfter : nil,
                          respondedBy: response.url)
    }

    /// #377: true when this origin is down to one request at a time, so the reader's speculative
    /// parallel paths must not run. They exist to overlap with the pump, overlapping is the one
    /// thing a single-slot origin refuses, and each has a serial fallback that is merely slower.
    private var originRequiresSerialRequests: Bool {
        OriginRequestBudget.shared.requiresSerialRequests(requestURL())
    }

    private func addBytesFetched(_ n: Int) {
        counterLock.lock()
        _cumulativeBytesFetched &+= Int64(n)
        counterLock.unlock()
        // #392: every network delivery this reader makes passes through here (pump, chunk, tail
        // prefetch, detour fetch, streaming), which is why the idle clock is stamped here and not
        // in one of them. A serve out of memory does not reach this call, and must not: memory is
        // exactly what an idle reader lives on while its pin ages.
        noteNetworkDelivery()
    }

    private var isStreaming: Bool { fileSize <= 0 }

    /// #126: a VOD source that resolved no size runs the forward-only streaming reader
    /// (1 MB back-window, no reconnect); it must not be routed onto seek-dependent paths.
    /// Live keeps true: the persistent reader owns reconnection and live routing never
    /// seeks backward. Meaningful only after `open()` has resolved the mode.
    var isSeekable: Bool { isLive || !isStreaming }

    private(set) var context: UnsafeMutablePointer<AVIOContext>?
    private var buffer: UnsafeMutablePointer<UInt8>?

    // MARK: - Seekable Mode (Range requests)

    /// Default 4 MB. Delegate-based incremental delivery (ChunkFetchDelegate on a
    /// shared long-lived chunkSession) avoids the per-request URLSession task-pool
    /// leak that made 8 MB chunks bleed ~6 MB/s (e327e5e). 4 MB gives ~0.7 s
    /// cold-start on 45 Mbps 4K HEVC. Smaller values add HTTP roundtrip overhead
    /// at 5+ ops/sec without meaningful latency benefit. Still-extraction passes a
    /// smaller value for random-access single-keyframe fetches.
    private let chunkSize: Int
    /// When false, no speculative next-chunk prefetch (random-access: next read
    /// almost always seeks elsewhere, so prefetch would be wasted bandwidth).
    private let prefetchEnabled: Bool
    /// When set, the open-time data connection requests a finite `bytes=0-N` range instead of the
    /// open-ended `bytes=0-` stream (#93 residual). Scopes to the open connection only; read-loop
    /// reconnects and seek reconnects stay open-ended. nil = open-ended everywhere (playback).
    private let boundedInitialFetch: Int64?
    private static let avioBufferSize: Int32 = 256 * 1024  // 256 KB
    private static let streamTrimThreshold = 1024 * 1024  // 1 MB, keep for small backward seeks
    // Backpressure: suspend the streaming task above highWater, resume below lowWater.
    private static let streamHighWaterDefault = 64 * 1024 * 1024
    private let streamHighWater: Int
    private var streamLowWater: Int { streamHighWater / 2 }
    /// Audit DMX-7: the suspend above is advisory (#220 measured 911 MB arriving after one), and
    /// this path cannot re-request at an offset the way the persistent reader does, so a transport
    /// that keeps delivering past twice the high water is ended and the read fails with EIO once
    /// the buffered bytes are drained. Audit DMX-107: that failure is typed
    /// (`AVIOReaderError.originIgnoresFlowControl`, `lastReadFailure`), so it reads as what it is.
    private var streamHardCap: Int { 2 * streamHighWater }

    private let bufferLock = NSLock()
    private var currentBuffer = Data()
    private var currentOffset: Int64 = 0
    private var prefetchBuffer: Data?
    private var prefetchOffset: Int64 = 0
    private var isPrefetching = false
    private let prefetchReady = DispatchSemaphore(value: 0)
    private let prefetchQueue = DispatchQueue(label: "com.aetherengine.avio.prefetch", qos: .userInitiated)
    private static let maxRetries = 3

    // MARK: - Streaming Mode (sequential GET)

    /// Held as the delivered chunks, like the persistent window (AE#619): a read trims its consumed
    /// head by advancing an offset, where `Data.subdata` copied the whole 32-64 MB still ahead of the
    /// cut on every read (audit PERF-102). Guarded by `streamLock`.
    private var streamBuffer = ChunkedByteWindow()
    private var streamBytesRead: Int64 = 0
    /// Most bytes `streamBuffer` has held at once, for the bound tests. Guarded by `streamLock`.
    private var streamPeakBytes = 0
    private var streamEnded = false
    private let streamLock = NSLock()
    private let streamDataReady = DispatchSemaphore(value: 0)
    /// Advisory body length from the streaming response's Content-Length (-1 unknown). Only the
    /// sequential-origin path reads it: a connection that ends short of it (or stalls out) is a
    /// LOST source, not end-of-media, and must surface as a read error rather than EOF - the
    /// consumer treats EOF as "played to the end" and deliberately never retries it. Guarded by
    /// `streamLock`.
    private var streamExpectedBytes: Int64 = -1
    /// Audit DMX-6: the streaming GET ended in a transport error, or was ended at
    /// `streamHardCap`. Either way the bytes that did not arrive are lost, not absent, so the read
    /// that runs out reports EIO instead of end-of-media. Guarded by `streamLock`.
    private var streamFailed = false
    /// Audit DMX-107: why the streaming GET was ended by this reader when it was not the transport's
    /// doing. Guarded by `streamLock`.
    private var streamFailureCause: AVIOReaderError?
    /// The status the streaming GET was answered with when it was anything but 200/206, 0 while
    /// none. A status is not media: the delegate hangs up at the header, and `open()` fails typed
    /// on it rather than handing FFmpeg an empty stream to misreport as invalid data. Written on
    /// the delegate queue before `streamEnded`; guarded by `streamLock`.
    private var streamRefusedStatus = 0
    /// AE#495: the `NSURLErrorDomain` code of a TLS trust refusal seen on any of this reader's tasks,
    /// 0 when none. Recorded rather than thrown from where it happens, because the task that sees it
    /// is not the one the open is waiting on: without it the open fails as FFmpeg's invalid data and a
    /// self-signed origin is indistinguishable from a corrupt file. Guarded by `streamLock`.
    private var transportSecurityCode = 0
    private var streamURLFailureCode: Int?
    /// AE#818: the URL error (not our own cancel) a connection of this reader last ended with, since
    /// the last delivery. Diagnostic data only, never a reason to fail: the open and the read loop
    /// still ride transport failures out, and the caller that gives up attaches it as the cause.
    /// Guarded by `transportFailureLock`, which takes no other lock.
    private var recordedTransportFailure: Int?
    private let transportFailureLock = NSLock()

    // MARK: - Persistent Mode (single forward-streaming connection, playback path)

    // Backpressure: END the connection above highWater and re-request at the frontier once
    // the consumer drains below lowWater. Nothing is discarded and nothing is re-fetched:
    // every delivered byte stays in the window, and the next range starts exactly where
    // delivery stopped.
    //
    // This is the third design here, and the history is load-bearing. #174 replaced
    // delegate-blocking (no flow-control contract: TLS/H2 transports keep reading at line
    // rate into unbounded URLSession-internal allocations until jetsam) with task
    // suspend/resume. #220 then measured suspend() to be advisory — against an origin
    // serving 2.5x media rate, 911 MB arrived AFTER the task was suspended — so a hard cap
    // ended the connection when the suspend demonstrably had not taken.
    //
    // #310 is why the suspend is now gone entirely rather than capped: a data task left
    // suspended holding an undelivered window keeps a dormant established flow whose closed
    // receive window sits unread for as long as the consumer takes to drain — ~100 s per
    // cycle at 1 Mbps media rate, indefinitely while paused. On tvOS/iOS (user-space
    // networking: TCP for nw flows runs in the app process) that dormant state correlates,
    // dose-response by media bitrate, with 10-80 s episodes in which every
    // Network.framework flow in the process goes deaf at once — established WebSockets time
    // out unACKed, no new nw handshake completes — while raw BSD sockets from the same
    // process keep working. Ending the connection instead means the reader either has an
    // ACTIVELY delivering flow or NO flow: there is no parked state for the substrate to
    // rot in, and a paused player holds no connection at all. The price is one extra range
    // request per drain cycle (every ~100 s at 1 Mbps; connects measure ~2 ms on LAN). The
    // window peak is now bounded by construction at highWater plus one delivery's in-flight
    // overshoot, which subsumes the former winHardCap escape hatch and the realloc-doubling
    // peak it had to be sized against.
    //
    // Live raises the high water instead of changing the mechanism. Live connections are
    // open-ended by design (no ranges to bound them), so the high-water end is the ONLY
    // thing that ever terminates a healthy live connection — and "re-request at the
    // frontier" is a lie to a live origin: the bytes broadcast during the drain are gone,
    // so every cycle rejoined the stream on a corrupt TS packet. Worse, IPTV panels serve
    // their ring buffer as a join burst at line rate on EVERY (re)connect, so a 16 MB cap
    // made each reconnect the cause of the next one: burst to high water, end, drain ~8 MB
    // losing that much realtime, reconnect, absorb the next burst. The live threshold is
    // sized to absorb the burst ONCE; steady state then plateaus at burst size (arrival
    // rate == media rate once the burst is over) with the connection never voluntarily
    // ended. The end-and-refill stays, unchanged, as the memory backstop for a "live"
    // source that sustainedly outruns realtime (a misdeclared VOD). 64 MB matches
    // streamHighWater, the forward bound the engine already accepts for the other reader
    // that cannot bound by range request.
    private static let winHighWaterDefault = 16 * 1024 * 1024
    private static let liveWinHighWaterDefault = 64 * 1024 * 1024
    private static let winLowWater = 8 * 1024 * 1024
    // #220: how much the persistent reader asks for at a time. Bounds a single request's
    // exposure: `appendPersistentData` drops anything past the requested end and ends the
    // transfer (audit DMX-1), so an origin that ignores Range or answers wider than asked
    // cannot grow the window past it. It also keeps the request cadence modest on a healthy link:
    // one request per range boundary while the consumer keeps up, one per
    // highWater-to-lowWater drain cycle when the origin outruns it.
    static let persistentRangeBytes: Int64 = 32 * 1024 * 1024

    /// #377: the smallest window room worth a read on a held connection, and therefore the length
    /// of a dormant stretch in the steady state (this over media rate). #310's dose is that
    /// length: 16 MB of window at 1.2 Mbps is ~100 s dormant and produced 11 starvation episodes
    /// in 80 min, the same window at 88 Mbps is 1.4 s and produced none in 118 min. 64 KB is 0.4 s
    /// at that same 1.2 Mbps and 7 ms at 70 Mbps, so the steady state sits in the regime that
    /// never fired rather than relying on a measurement nobody can take on demand.
    private static let heldPullSlack = 64 * 1024
    /// How often a held connection on a full window re-reads the play intent. A pause is not
    /// broadcast on `winCond` -- nothing reads during one -- so this is what lets the paused
    /// budget below start at all.
    private static let heldPlayIntentPollSeconds: TimeInterval = 1
    /// How long a held connection may stay open while the consumer is PAUSED before it is ended.
    /// Playback never spends this: a parked producer is not a stopped one, and a reader that reads
    /// the first as the second re-requests every few seconds, which is what this flag exists to
    /// stop. A pause is the unbounded case #310's worst episode came from (11 minutes), so it is
    /// bounded here and nowhere else.
    ///
    /// The number is half the longest dormancy measured clean on the device, which is the whole of
    /// its derivation. Arm B on an Apple TV 4K 3rd gen (tvOS 26.6) held a stream task on a closed
    /// receive window for 600 s against the origin from #377: 1180 canary requests at 1 Hz, to that
    /// origin and to a host that is not it, all 206, and about 3 MB resident when the reads resumed
    /// against the ~12 GB the wire could have carried, so the window really was shut for the whole
    /// stretch. That is #310's wire condition itself rather than a proxy for it, and no cliff sits
    /// under twice this value. It stays at half of it because a clean run is not a threshold, and
    /// because being wrong here is cheap: one frontier request per pause that outlives the bound,
    /// against the 218 an hour this flag used to spend on parked producers alone.
    ///
    /// Media rate is not on this axis. A paused consumer takes no bytes, so the dormant stretch is
    /// the pause, whatever the file's rate; the rate only decides how quickly the socket buffer
    /// fills before the window shuts, which is the 3 MB above. #310's window-over-media-rate dose
    /// is the PLAYING case and it belongs to `heldPullSlack`, not here.
    static let heldPausedBudgetDefault: TimeInterval = 300

    /// Overridable so a test can express a pause without sleeping through the real budget.
    nonisolated(unsafe) var heldPausedBudgetSeconds: TimeInterval = AVIOReader.heldPausedBudgetDefault
    /// Ceiling on a single pull. The window's remaining room is normally the smaller number; this
    /// only keeps one read from asking the transport for an unbounded amount while the window is
    /// empty (an open, a seek).
    private static let heldMaxPullBytes = 1 * 1024 * 1024
    // #377: how long a pump range waits for an origin slot before going on the link anyway. The
    // pump is the main line and everything that can be holding a slot ahead of it is short (a 4 MB
    // detour block, a size probe), so this is "wait for the short thing", not "give up". Generous
    // on purpose: overrunning the budget costs one extra request against the origin, while
    // refusing the pump costs the session.
    private static let pumpSlotWaitSeconds: TimeInterval = 10
    // #377: a probe or detour block waits far less. Both have serial fallbacks and both run while
    // the consumer is waiting, so queueing them behind a 32 MB range would be felt as a stall.
    private static let shortFetchSlotWaitSeconds: TimeInterval = 4
    // Keep this many bytes behind the cursor for small matroska backward re-reads.
    private static let winLookback = 2 * 1024 * 1024
    // Trim in batches to avoid O(n^2) memmove storm on every 256 KB read.
    private static let winTrimBatch = 4 * 1024 * 1024
    // Forward seeks within this distance keep the live connection; beyond it, reconnect.
    private static let seekKeepForwardLimit = 8 * 1024 * 1024
    // CDN stall threshold: no bytes for this long triggers reconnect. Instance-captured (see
    // `connStallTimeout`) so tests can shorten it; the shipped value is this one.
    private static let connStallTimeoutDefault: TimeInterval = 20
    /// Trickle floor at `connStallTimeoutDefault`: fewer bytes than this over one stall period
    /// while a read waits is a connection that is not carrying playback. 2 MiB per 20 s is about
    /// 0.8 Mbit/s, far below any video bitrate and far above the field case's 256 KB per 40-100 s.
    /// A reader with a shorter `connStallTimeout` scales it by the same ratio (see the init).
    static let trickleFloorBytesDefault: Int64 = 2 * 1024 * 1024
    /// #450: fraction of the stall threshold at which a generation that has seen no first byte is
    /// REPORTED. Derived from the threshold rather than set beside it so the invariant holds at
    /// every value of the threshold, the shortened ones tests run with included: the witness speaks
    /// before the threshold acts.
    private static let firstByteWitnessFraction = 0.25
    /// Ceiling on that, so a long threshold cannot push the line past the arcs that give up on a
    /// source first. `awaitFirstPersistentData` allows an open 15 s, and the shipped threshold is
    /// 20 s: the one outcome the stall witness could never describe was the one where the first
    /// byte never comes, because the load was already over when it fired.
    private static let firstByteWitnessMaxSeconds: TimeInterval = 5
    // A reconnect that delivers at least this much counts as progress; resets streak.
    private static let minReconnectProgress: Int64 = 512 * 1024
    // Cap on CONSECUTIVE unproductive reconnects; resets on real progress.
    private static let reconnectMaxUnproductive = 12

    // MARK: - Cold-start round trips (#281)

    /// How much of the file's head to retain for the return trip after a parse excursion. Measured
    /// landings across six container layouts and a field trace: 48, 1161, 5752 and 265159, all well
    /// inside this. Sized to hold that return without becoming a second buffer worth worrying about
    /// next to the live window: this is charged against the same footprint the high-water end bounds.
    static let headSpanMaxBytes = 4 * 1024 * 1024

    /// Speculative suffix fetch issued with `open()`, sized to cover the small trailing objects a
    /// demuxer asks for before it can report a frame rate: `mfra` on fragmented MP4 (~1-2 KB), and
    /// the trailing `moov` of a non-faststart file whose sample tables are small enough to fit.
    ///
    /// Deliberately NOT sized to cover every trailing `moov`. Those grow with the sample count, so
    /// a feature-length file's runs into megabytes, and fetching that speculatively on every open
    /// would spend real bandwidth on a guess, competing with the first data connection on exactly
    /// the slow links this is meant to help. 64 KB is negligible on any link that plays video at
    /// all, and when it misses, the retained head still removes the return trip.
    static let tailPrefetchBytes = 64 * 1024

    // MARK: - Detour Block Cache (random-access parse reads; AetherEngine#69)

    // A non-faststart / coarsely-interleaved remote MP4 makes the demuxer ping-pong between
    // distant file regions (header, trailing moov, sample data) during find_stream_info /
    // index parse. Each non-sequential read used to tear down + reopen the persistent
    // connection (seekReconnect), so the parse storm hammered the origin into a 429.
    // Instead, serve those random-access reads through the pooled keep-alive chunkSession
    // (the one fetchChunk already uses), caching 4 MB aligned blocks. The streaming
    // connection stays ANCHORED; the ping-pong becomes cache hits; the storm collapses to
    // the two legitimate reconnects (open + the one seek to the moov). The sequential
    // playback fast path never enters this code, so it carries zero overhead.
    private static let detourBlockSize = 4 * 1024 * 1024
    private static let detourMaxBlocks = 8                       // ~32 MB, the resting LRU size
    /// #909: how far the cache may grow when its working set is larger than `detourMaxBlocks`. A flat
    /// MP4 that stores each subtitle track in its own byte range makes the demuxer visit one block per
    /// kept track in turn, and an LRU smaller than that cycle never hits: 14 `mov_text` tracks against
    /// 8 blocks re-fetched every block on every pass. The cache grows only on a re-fetch of a block it
    /// evicted, so a file without such a cycle stays at 8; the ceiling covers the 16-track files seen
    /// so far (#104, #909) with room for samples that straddle a block boundary.
    private static let detourCeilingBlocks = 24                  // ~96 MB
    /// Audit PERF-108: a detour block nobody has read or filled for this long is a scrub's leftover,
    /// not a parse's working set (a parser revisits its region within seconds).
    private static let detourBlockIdleSecondsDefault: TimeInterval = 30
    // Once detour reads turn sequential past this much, re-anchor the streaming connection
    // there so sustained playback returns to the cheap window path (e.g. after a backward scrub).
    private static let detourReanchorBytes: Int64 = 8 * 1024 * 1024
    // Interactive per-fetch budget for a detour block (#93/#96). A backward-scrub read serves via the
    // detour cache; a miss fetches a 4 MB block over the pooled session. On a per-connection-starved
    // origin that fetch used to ride the full chunkRequestTimeout (idle 15s / total 35s) before falling
    // through to the rescue reconnect, which opens a fresh connection the origin serves in ~30-190ms
    // (rrgomes' #93/#96 traces: the whole 15-35s sat here, invisibly, in the detour fetch). A 4 MB block
    // over a healthy remote 4K source lands in ~1s, so a tight budget aborts a starved fetch fast and
    // lets the reconnect serve, without tripping healthy parse-time detour fetches (#69 stays intact:
    // its fetches complete well under this, and a genuinely slow parse fetch reconnecting is bounded by
    // the #71 rate-limit streak, far gentler than the pre-cache per-read storm).
    private static let detourFetchBudgetSeconds: TimeInterval = 4

    /// Effective per-fetch budget for a detour block: the tight interactive cap, never exceeding the
    /// caller's chunk budget (still-extraction passes a smaller one; it never reaches this path, but
    /// the clamp keeps the invariant). Internal so the bound is unit-tested without a live origin.
    static func effectiveDetourBudget(chunkRequestTimeout: TimeInterval,
                                      cap: TimeInterval = detourFetchBudgetSeconds) -> TimeInterval {
        min(cap, chunkRequestTimeout)
    }

    // Cap on CONSECUTIVE rate-limited (429/503/509) network attempts before giving up cleanly.
    // Distinct axis from unproductiveReconnects: NOT reset by seekReconnect, so parse-driven
    // seeks cannot mask a throttled origin into an infinite reconnect loop (AetherEngine#71).
    private static let rateLimitMaxStreak = 6
    /// A LIVE stream refused mid-session is asked for again on a steady, short cadence rather than
    /// up the exponential ladder, and for a bounded while rather than a bounded count. The refusal
    /// this answers is a connection-limited IPTV panel's 509 while another device on the account
    /// holds its last slot: it lasts seconds to tens of seconds and clears the moment that slot is
    /// free, and every second of waiting past that is a second the picture stays frozen with the
    /// origin ready to serve. One small request a second is what the panel's own clients do, and
    /// what the live HLS ingest does for the same refusal (`HLSLiveIngestReader`). The origin's own
    /// Retry-After stretches the wait, up to `liveRefusalMaximumRetryWait`.
    static let liveRefusalRetryInterval: TimeInterval = 1
    static let liveRefusalMaximumRetryWait: TimeInterval = 5
    /// How long a live stream keeps asking before the refusal is the session's answer.
    static let liveRefusalRetryBudget: TimeInterval = 60

    /// The wait before a live stream's refused request is made again: a second, or the origin's
    /// Retry-After (0 for none) when that is longer, never more than `liveRefusalMaximumRetryWait`.
    static func liveRefusalWait(retryAfter: TimeInterval) -> TimeInterval {
        min(max(liveRefusalRetryInterval, retryAfter), liveRefusalMaximumRetryWait)
    }
    // Rate-limited attempts that keep the pinned redirect target before one attempt through the
    // source URL is spent on a fresh redirect. Three paced attempts (~7 s of ladder) ride out the
    // lingering-slot 509 of a connection-capped panel (#307 follow-up: the slot frees in seconds);
    // a streak that reaches this rung is the other shape — a pinned edge target whose session
    // expired during a long pause and refuses forever, where only a re-resolve heals. Internal so
    // the rung is unit-tested without a live origin.
    static let rateLimitRepinStreak = 3
    /// #392: how long the pin may carry no bytes at all before its FIRST rate-limited refusal is
    /// taken at face value instead of being ridden out by the grace above. The grace answers one
    /// specific shape, the lingering slot of a connection this reader just replaced, and that shape
    /// requires a recent byte of ours: the pump ends its connection at the window high water, so a
    /// reader that has been idle holds nothing at the origin for a slot to linger on (#310). A
    /// minute is far longer than a lingering slot lives (seconds) and far shorter than the pause
    /// that kills a lease (332 s in the #380 retest). Internal so the rung is unit-tested.
    static let pinIdleRepinSecondsDefault: TimeInterval = 60

    /// NSCondition guards all persistent-mode fields and serves as the
    /// edge-triggered condition variable for read waits and backpressure.
    private let winCond = NSCondition()
    /// Sliding window of bytes from the live connection, starting at `winStart`.
    /// `position - winStart` is the read offset within `window`. Held as the delivered chunks
    /// (AE#619), so trimming the consumed head copies nothing.
    private var window = ChunkedByteWindow()
    private var winStart: Int64 = 0
    // Connection state.
    private var connEnded = false
    private var connStatus = 0
    private var connURLFailureCode: Int?
    // AE#792: the header store's revision when the current generation's request was built.
    private var connHeaderRevision: UInt64 = 0
    // Retry-After seconds from a rate-limit status, honoured before reconnect.
    private var connRetryAfter: TimeInterval = 0
    // Bumped on every (re)connect; stale delegate callbacks are ignored.
    private var connGeneration = 0
    /// #377: what is on the link for this reader. Either shape is ONE request against the
    /// origin holding one slot of its budget; they differ only in who decides when bytes
    /// move, and every other piece of this reader (window, frontier, reconnect ladder,
    /// diagnostics) is written against the transfer rather than against a URLSession task.
    private var activeTransfer: (any PersistentTransfer)?

    /// #174: winCond-guarded snapshots, internal so the task-level backpressure is
    /// unit-tested against a loopback origin without private state access.
    /// #220: planned range ends must leave the failure budget alone.
    var unproductiveReconnectsForTesting: Int {
        winCond.lock()
        defer { winCond.unlock() }
        return unproductiveReconnects
    }

    /// The rate-limit ladder's charge. A test asserting what does and does not count as progress
    /// against a metered origin (#380) reads this rather than inferring it from request counts,
    /// which only separate the cases once the ladder has already run to one of its ends.
    var rateLimitStreakForTesting: Int {
        winCond.lock()
        defer { winCond.unlock() }
        return rateLimitStreak
    }

    /// Bytes the window holds ahead of the cursor. Caller holds `winCond`. The held pull budget
    /// and the delivery-gap watchdog both decide on the room this leaves, and they have to agree:
    /// the watchdog stands aside exactly where the pump waits.
    private func windowAheadLocked() -> Int {
        window.count - max(0, Int(position - winStart))
    }

    /// How many generations the trickle watchdog has ended on this reader.
    var trickleEndCountForTesting: Int {
        winCond.lock()
        defer { winCond.unlock() }
        return trickleEnds
    }

    /// How many generations the delivery-gap watchdog has ended on this reader.
    var deliveryGapEndCountForTesting: Int {
        winCond.lock()
        defer { winCond.unlock() }
        return deliveryGapEnds
    }

    /// The delivery gap the watchdog would judge right now. A test reads it to state the invariant
    /// the field case turns on: a stretch with no read outstanding does not accumulate against the
    /// read that follows it.
    var deliveryGapSecondsForTesting: Double {
        winCond.lock()
        defer { winCond.unlock() }
        return Double(DispatchTime.now().uptimeNanoseconds - lastDeliveryAt.uptimeNanoseconds) / 1_000_000_000
    }

    /// Whether a transfer is still installed. A test that needs a range to have COMPLETED, rather
    /// than merely to have delivered, waits on this instead of on a sleep: the completion callback
    /// is what clears `activeTransfer`, and that clearing is the state the behaviour turns on.
    var hasLiveConnectionForTesting: Bool {
        winCond.lock()
        defer { winCond.unlock() }
        return activeTransfer != nil
    }

    /// The URL error code the reader's last failed connection ended with, nil once data arrived.
    var lastTransportFailureCode: Int? {
        transportFailureLock.lock()
        defer { transportFailureLock.unlock() }
        return recordedTransportFailure
    }

    private func recordTransportFailure(_ error: Error?) {
        guard let code = SourceNetworkDiagnostics.urlErrorCode(error), code != NSURLErrorCancelled else { return }
        transportFailureLock.lock()
        recordedTransportFailure = code
        transportFailureLock.unlock()
    }

    private func clearRecordedTransportFailure() {
        transportFailureLock.lock()
        recordedTransportFailure = nil
        transportFailureLock.unlock()
    }

    /// Audit DMX-107: the typed cause of the read error the streaming path reports, nil while the
    /// source is healthy and for a plain transport loss (which has no cause of ours to name).
    var lastReadFailure: AVIOReaderError? {
        streamLock.lock()
        defer { streamLock.unlock() }
        return streamFailureCause
    }

    /// Detour blocks currently resident.
    var detourResidentBlocksForTesting: Int { detourCache.residentCount }

    /// One detour block fetch, true when it came back rate limited.
    func detourFetchIsRateLimitedForTesting(from offset: Int64, size: Int) -> Bool {
        if case .rateLimited = detourFetchBlock(from: offset, size: size) { return true }
        return false
    }

    /// The most the forward-only streaming buffer has held at once.
    var streamPeakBufferBytesForTesting: Int {
        streamLock.lock()
        defer { streamLock.unlock() }
        return streamPeakBytes
    }

    #if DEBUG
    /// Storage address of every chunk the streaming buffer still holds, first to last. A trim that
    /// copied the buffer would move all of them.
    var streamChunkAddressesForTesting: [UnsafeRawPointer?] {
        streamLock.lock()
        defer { streamLock.unlock() }
        return streamBuffer.chunkStorageAddresses()
    }
    #endif

    /// Bytes the persistent window holds, behind and ahead of the cursor.
    var windowBytesForTesting: Int {
        winCond.lock()
        defer { winCond.unlock() }
        return window.count
    }

    /// #220/#310: set when WE ended the connection at `winHighWater` (ending is the only
    /// non-advisory flow control, and a task left suspended instead is a dormant flow — see
    /// the backpressure doc block above). The read loop re-requests at the frontier — at low
    /// water like a completed range, or immediately once the window is empty — without
    /// charging the reconnect to the unproductive-reconnect streak. Left unset, a deliberate
    /// end would spend the streak that exists to detect a dead source and
    /// `recordReconnectAndShouldGiveUp` would kill the reader on a perfectly healthy link.
    /// winCond-guarded, cleared by `startPersistentConnection`.
    private var connEndedByBackpressure = false

    /// #310: bytes that arrived after `connEndedByBackpressure` was set, i.e. after our own
    /// cancel, and whether the one-shot "the cancel did not take" line has been emitted for
    /// this generation. Both winCond-guarded, both cleared by `startPersistentConnection`.
    private var postEndDeliveryBytes: Int64 = 0
    private var postEndOvershootLogged = false

    /// #309: when the current generation last delivered a byte, or when it started if it has
    /// delivered none yet. The single input to the delivery-gap watchdog, and the reason that
    /// watchdog can exist at all: the read loop's forward wait used to be the only place
    /// `connStallTimeout` was ever evaluated, so a flow that died while the window could still
    /// serve reads was noticed only once a consumer happened to block on it (observed in the field:
    /// 4.5 minutes across a pause). The transport does not fill that gap either, since the
    /// persistent request runs with `timeoutInterval = 0` on purpose. winCond-guarded.
    private var lastDeliveryAt = DispatchTime.now()

    /// Trickle watchdog inputs, winCond-guarded. `genDeliveredBytes` counts what the current
    /// generation appended; `trickleSamples` are (time, count) marks taken at each watchdog tick so
    /// the tick can read the volume of the last `connStallTimeout`. Both reset with the generation.
    private var genDeliveredBytes: Int64 = 0
    private var trickleSamples: [(at: DispatchTime, bytes: Int64)] = []
    /// Starved-since clock: when the consumer first blocked in the forward wait, and at which
    /// offset. It survives consecutive reads, because FFmpeg reads at most one AVIO buffer
    /// (256 KB) at a time, and a drip of 256 KB every 15 s finishes every read inside
    /// `connStallTimeout`: a per-read clock restarts with each one and never reaches the verdict.
    /// Cleared when a read is served without waiting (the window had the bytes), when a
    /// generation starts (a seek, a refill, a replacement), and on a full window.
    private var forwardWaitSince: DispatchTime?
    private var forwardWaitOffset: Int64 = 0
    /// True only while a read is blocked in the forward wait right now, so a consumer that has
    /// stopped reading (a paused player) is never judged on a clock it left running.
    private var forwardWaitActive = false
    private var trickleEnds = 0
    private var deliveryGapEnds = 0

    /// #309: earliest time the read loop may replace a FAULTED connection from the serve path.
    /// The failure ladder there cannot sleep (see `chargeFaultedRunwayRefill`), so its backoff is
    /// a timestamp instead. `.distantPast` = attempt now, `.distantFuture` = the bounded give-up
    /// has fired and only the empty-window path may still act. winCond-guarded, reset by
    /// `startPersistentConnection`.
    private var nextFaultedRefillAt = Date.distantPast

    /// #220: last byte the live connection was asked for, nil when the request was open-ended
    /// (live sources, and any source whose total size is not resolved yet). winCond-guarded.
    private var connRangeEnd: Int64?

    /// Audit DMX-101: true only while `open()` waits on the cold data connection, so that response
    /// alone is judged for range support. A 200 later in a session (a CDN cache miss on a refill)
    /// stays what it always was: rejected and retried, never a verdict on the origin. winCond-guarded.
    private var rangeVerdictPending = false
    /// Audit DMX-101: Content-Length of the cold connection's range-ignoring 200, -1 when it stated
    /// none, nil while the origin has not been caught ignoring. winCond-guarded.
    private var rangeIgnoredAtOpenLength: Int64?
    /// Audit DMX-101: the origin cannot address bytes, so this source plays forward-only on the
    /// streaming path. Written once by `open()` on the demux thread, read by `seek` on the same one.
    private(set) var originIgnoresRange = false

    /// Sodalite#117: contiguous range starts are summarised instead of logged one by one.
    /// winCond-guarded.
    private var connStartLogGate = ConnStartLogGate()

    /// #220: set when the connection ended because its range was delivered in full. That is a
    /// planned end, not a failure, and must not be charged to the reconnect budgets. Mirrors
    /// `connEndedByBackpressure`; cleared by `startPersistentConnection`.
    private var connEndedAtRangeEnd = false

    /// First byte the live connection was asked for. Distinct from `winStart` since #295: a
    /// continuation keeps the resident window, so the window no longer begins where the request
    /// did, and the checks that need the REQUESTED offset (a 200 that ignored Range, the size
    /// derived from a from-zero response) must not read the window's start instead. winCond-guarded.
    private var connRequestedOffset: Int64 = 0
    /// AE#958: the overlap check riding on the current generation, when its request was moved into
    /// bytes already held (see `RangeHonestyProbe`). winCond-guarded.
    private var rangeProbe: RangeHonestyProbe?
    /// AE#958: latched once a ranged answer carried bytes other than the ones it claimed. Every
    /// read fails from there: nothing this origin sends past byte 0 can be placed. winCond-guarded.
    private var rangeAnswersFabricated = false
    /// AE#958: how much of a ranged reconnect is spent re-reading bytes already held.
    static let rangeCheckBytes = 4096
    /// #331: latched once a live origin answers 416 to a nonzero offset, i.e. proves it has no
    /// byte addresses to resume at. From there every live request is the join shape (`bytes=0-`).
    /// Latched rather than unconditional because the two live origin shapes want opposite things:
    /// an IPTV panel serving a ring buffer cannot satisfy a frontier and rejects it outright,
    /// while a live source that IS a growing file (a Jellyfin live stream file, a misdeclared VOD)
    /// honours the frontier and resumes exactly where delivery stopped, and asking that one for
    /// byte zero re-delivers the whole buffer on top of the window. One rejected request per reader
    /// tells the two apart; guessing cannot. winCond-guarded.
    private var liveOffsetsUnsatisfiable = false

    /// #220: winCond-guarded snapshot of the sliding window for the periodic memprobe.
    /// `ahead` is the undrained forward extent, the quantity `appendPersistentData` gates the
    /// backpressure end on. `parked` is true while the connection has been deliberately ended
    /// at high water and the low-water refill has not fired yet (#310), so a long-lived
    /// `parked` with `ahead` holding above lowWater reads as a stalled consumer, not a
    /// transport fault.
    var windowDiagnostics: (windowBytes: Int, aheadBytes: Int, parked: Bool) {
        winCond.lock()
        defer { winCond.unlock() }
        return (window.count,
                window.count - max(0, Int(position - winStart)),
                connEndedByBackpressure)
    }
    // #93 restart latency diagnostics (winCond-guarded): bytes dropped by the stale-generation
    // guard, plus per-generation time-to-first-data tracking.
    private var staleGenDroppedBytes: Int64 = 0
    private var connStartedAt = DispatchTime.now()
    private var connFirstDataSeen = false
    /// AE#925 (winCond-guarded): the body of a live text suspect, held outside the window until it
    /// is complete or its connection ends. Tagged with its generation, because a connection can be
    /// abandoned by a generation bump that starts no new one, and a held body must never swallow
    /// the next connection's bytes.
    private var connTextNotice: (generation: Int, body: Data)?
    private var connTextNoticeLength: Int64 = 0
    private var connTextNoticeRetryAfter: TimeInterval = 0
    private var connEndedByTextNotice = false

    /// Takes the held suspect body of `generation`, if there is one. Caller holds winCond.
    private func takeTextNoticeLocked(generation: Int) -> Data? {
        guard let held = connTextNotice, held.generation == generation else { return nil }
        connTextNotice = nil
        return held.body
    }
    /// The last connection that carried bytes was ended by the peer or the network mid-range, not by
    /// us (cancel, range end, high water). Set where that connection ends, cleared by the next
    /// generation's first byte, so the refused attempts that follow a cut keep it. winCond-guarded.
    private var lastDeliveringConnCut = false
    /// The generation `awaitFirstPersistentData` is waiting on, while it waits. Its first byte is
    /// governed by the open policy's budget, not by the delivery-gap watchdog.
    private var openAwaitedGeneration: Int?
    // Consecutive unproductive reconnects (demux-thread-only).
    private var unproductiveReconnects = 0
    private var bytesAtLastReconnect: Int64 = 0
    // Consecutive rate-limited attempts; survives seekReconnect, resets on real read progress (#71).
    private var rateLimitStreak = 0
    // AE#792: consecutive 401/403 ends on one credential. Survives seekReconnect like the rate-limit
    // streak, resets on real read progress and whenever the header store's revision moves.
    private var credentialRefusalStreak = 0
    private var credentialStreakRevision: UInt64?
    /// When the current rate-limited streak began, for the live budget. Cleared with the streak.
    private var rateLimitStreakStartedAt: DispatchTime?

    /// Detour LRU block cache (its own leaf lock, never held across `fetchChunk`/network or
    /// `winCond`). Stores only full-size blocks; short bodies are served once but never cached
    /// (see serveFromDetour), so eviction never shadows a re-fetchable tail. Pure copy/eviction
    /// math lives on the cache and is unit-tested without any network.
    private let detourCache = DetourBlockCache(blockSize: AVIOReader.detourBlockSize,
                                               maxBlocks: AVIOReader.detourMaxBlocks,
                                               ceilingBlocks: AVIOReader.detourCeilingBlocks)
    /// When the detour cache was last swept for idle blocks (audit PERF-108). Demux-thread-only.
    private var lastDetourIdleSweepNs: UInt64 = 0
    /// How long a detour block may sit unread before the sweep releases it. An init parameter for
    /// the same reason `connStallTimeout` is one: a process-wide hook would leak into whatever suite
    /// runs concurrently.
    private let detourBlockIdleSeconds: TimeInterval
    // The interactive cap on a detour fetch; tests that assert a block lands raise it, since 4 s is
    // a wall clock a loaded runner can spend before the fetch does.
    private let detourFetchBudget: TimeInterval
    // Re-anchor run tracking (demux-thread-only): the file offset the next sequential detour read
    // would continue from, and how many contiguous bytes the current detour run has served.
    private var detourRunNextExpected: Int64 = -1
    private var detourRunBytes: Int64 = 0

    // MARK: - Cold-start spans (#281)

    /// The head of the FILE, retained for the open phase as the data connection delivers it, so the
    /// return trip after a parse excursion is a copy rather than a connection.
    ///
    /// #281 parked the window at seek time instead, cut from `winStart`, on the reasoning that the
    /// demuxer returns to the window's start. It returns to the FILE's start: measured landings of
    /// 48, 1161, 5752 across six container layouts and 265159 in a field trace. The two coincide
    /// only while the parse seeks away before reading anything, and the parked copy served nothing
    /// on any layout measured, so it is gone. Collected as the bytes arrive rather than copied at
    /// seek time, because `trimWindowLocked` has dropped the head long before a seek asks for it.
    /// winCond-guarded.
    private var headSpan: Data = Data()
    /// AE#958: the last `rangeCheckBytes` of the head, kept when the head itself is dropped, so the
    /// reconnect at its end can still be checked. winCond-guarded.
    private var headSpanCheckTail: ResidentSpan?

    /// Speculative tail bytes fetched alongside `open()`. winCond-guarded: the fetch completes on a
    /// URLSession queue while the demux thread reads.
    private var tailSpan: ResidentSpan?

    /// In-flight speculative tail fetch, cancelled by `close()`.
    private var tailPrefetchTask: URLSessionDataTask?

    /// Whether that fetch is still outstanding, and when it went out. A read landing in its range
    /// waits for it rather than connecting past bytes that are already on the wire, so this is the
    /// difference between the fetch being an optimisation and being a wasted request. Cleared by
    /// the fetch's own completion, by `markClosed` and by `close`, each of which broadcasts.
    /// winCond-guarded.
    private var tailPrefetchInFlight = false
    private var tailPrefetchStartedAt = DispatchTime.now()

    /// One log line per span per open, not per serve. winCond-guarded (set from the read loop).
    /// #551: the size this open took from a warm rather than from a response header. A size that
    /// came from a DIFFERENT response than the one now serving the session is the one adopted fact
    /// that could be wrong and could never be corrected, because the write-once rule below treats
    /// any positive `fileSize` as settled. Remembered so the frontier connection's own
    /// `Content-Range` can be checked against it, once.
    private var adoptedWarmSize: Int64?
    /// AE#860: the `Content-Type` of the first 2xx answer this open got (or the warm's), the one
    /// statement about the source an extensionless URL makes. winCond-guarded, write-once.
    private var openContentType: String?
    /// AE#860: the open's response declared a disc image, or served `application/octet-stream` over
    /// a body with a volume signature at sector 16. winCond-guarded, set once by `open()`.
    private var openSuggestsDisc = false
    private var headSpanServeLogged = false
    private var headSpanPlaybackServeLogged = false
    private var tailSpanServeLogged = false

    /// Measured time to first data of the most recent connection: what one round trip against this
    /// origin actually costs, which is the only honest bound on how long waiting for in-flight bytes
    /// can be worth. winCond-guarded (written by the delegate thread).
    private var lastFirstDataMs: Double = 0

    /// Test seam: pins the wait budget, so a test that wants the fetch held in flight does not have
    /// to keep an origin's simulated latencies on the right side of a bound derived from one of
    /// them. That margin was 250 ms and a loaded CI runner spent it (#281 flake, 2026-08-11).
    /// `Self.tailPrefetchWaitBudget(firstDataMs:)` is what guards the real bound.
    var tailPrefetchWaitBudgetForTesting: TimeInterval?

    /// True from `open()` until the demuxer reports its header/stream-info pass done. The parse
    /// seeks this fix targets all happen inside that window; a far seek afterwards is a real scrub,
    /// where the old window is worthless and parking it would only cost memory.
    /// winCond-guarded.
    private var openPhaseActive = false

    /// AE#585: true while the host runs a bounded index pass after the open phase, which is index
    /// work rather than playback. winCond-guarded.
    private var indexPassActive = false

    /// AE#782: a producer restart repositioned the demuxer. The next backward read that needs the
    /// network re-anchors the streaming connection there at once, instead of serving the new playback
    /// position as serial 4 MB detour blocks until `detourReanchorBytes` have gone by. winCond-guarded.
    private var playbackRepositionPending = false

    /// Playback path (known size + prefetch) or live feeds. Live always uses the
    /// persistent reader; the streaming reader has no reconnect machinery.
    private var usePersistentReader: Bool {
        if isLive { return prefetchEnabled }
        return !isStreaming && prefetchEnabled
    }

    /// True for endless live feeds. Suppresses `position >= fileSize` EOF synthesis;
    /// reports EIO (-5) instead of EOF when the reconnect cap is hit.
    let isLive: Bool
    /// AE#860: an open whose response declares a disc image throws `.discImageMediaType` instead
    /// of handing a filesystem to libavformat. Only the demuxer's URL open sets it, because only it
    /// has the disc adapter to reroute to.
    let routesDiscMediaType: Bool

    /// `LoadOptions.sequentialOrigin` (via `DemuxerOpenProfile.avioSequentialOnly`): the origin
    /// fabricates range answers, so only byte 0 is addressable. `open()` routes straight onto the
    /// forward-only streaming mode (one unranged GET) and never issues a ranged request - no tail
    /// prefetch, no optimistic persistent open, no size probe, no detours. `fileSize` stays -1 by
    /// construction, which keeps `isStreaming` true and the pb non-seekable (#126 block below).
    let sequentialOnly: Bool

    /// Detour cache is VOD-only: live feeds have no meaningful random access and a
    /// non-authoritative size, so they stay on the unchanged reconnect path.
    /// #377: a detour block is a SECOND request opened while the pump's is still on the link, which
    /// is exactly what a single-slot origin refuses. Falling back to repositioning the persistent
    /// connection (the path taken when the detour is ineligible anyway) costs the re-anchor and
    /// keeps the reader to one request, where queueing the detour behind a slot the pump holds
    /// would just spend its whole budget waiting.
    private var detourEligible: Bool { !isLive && fileSize > 0 && !originRequiresSerialRequests }

    /// Timestamp of the last unplanned reconnect (drop/stall, not a seek).
    /// Producer correlates with a backward source-PTS reset to detect Jellyfin
    /// transcode respawn (re-serves from byte 0 on re-GET, invisible at byte level).
    /// Demux-thread-only (AVIO callback executes synchronously inside av_read_frame).
    private(set) var lastUnplannedReconnectAt: Date?

    /// Seekable-path per-chunk Range-request budget (seconds) and retry passes.
    /// Defaults preserve the historical playback/probe behaviour; still extraction
    /// passes smaller values so a stalled scrub thumbnail aborts fast (issue #27).
    private let chunkRequestTimeout: TimeInterval
    private let chunkMaxRetries: Int

    /// TEST-ONLY slow-CDN throttle (kbit/s, 0 = unlimited), captured once from the static hook at init.
    private let throttleKbps: Int
    /// Reconnect-backoff scale, 1 in the shipped app; tests shrink it so a give-up spanning a dozen
    /// backoffs finishes in test time. An init parameter like `connStallTimeout` below, for the same
    /// reason: a process-wide hook leaked into every suite running alongside.
    private let backoffScale: Double
    /// #392: the idle gap this reader takes a first refusal at face value after. Shipped value
    /// unless a test shortens it.
    private let pinIdleSeconds: TimeInterval
    /// How long a live refusal streak is ridden out, `liveRefusalRetryBudget` unless a test shortens it.
    private let liveRefusalRetryBudgetSeconds: TimeInterval
    /// Stall threshold this reader runs with, `connStallTimeoutDefault` unless a caller overrides it.
    /// One value for both detectors, because they are one policy: a connection that has delivered
    /// nothing for this long is replaced, whether or not a read is waiting on it (#309).
    ///
    /// An init parameter rather than a process-wide test hook on purpose. A hook is
    /// read at every reader's init, so a test that sets one changes the behaviour of every reader any
    /// CONCURRENTLY running suite happens to build, and swift-testing runs suites in parallel. A
    /// shortened stall threshold leaking that way would make other suites reconnect early under
    /// load. It is not a `LoadOptions` field either: #272 measured that a shorter threshold is worse
    /// under CPU starvation, and that conclusion is unchanged.
    private let connStallTimeout: TimeInterval
    /// Bytes per `connStallTimeout` below which a connection a read is waiting on is ended as a
    /// trickle. `trickleFloorBytesDefault` scaled to this reader's stall threshold unless a caller
    /// overrides it.
    private let trickleFloorBytes: Int64
    /// #450: when this reader reports a generation that is on the link with nothing delivered.
    private var firstByteWitnessDelay: TimeInterval {
        min(Self.firstByteWitnessMaxSeconds, connStallTimeout * Self.firstByteWitnessFraction)
    }
    /// High-water mark this reader ends the connection at. Mode-dependent (live absorbs a
    /// join burst the VOD value was never sized for — see the backpressure doc block) and
    /// an init parameter for the same reason `connStallTimeout` is one: a process-wide
    /// hook would leak into whatever suite runs concurrently. The shipped values are the
    /// two statics above.
    private let winHighWater: Int
    /// `LoadOptions.heldSourceConnection` (#377): this reader asks the origin once and pulls,
    /// instead of ending at the high water and asking again at low water. Opt in, an init
    /// parameter rather than a process-wide hook for the same reason `winHighWater` is one, and
    /// off for every reader whose caller did not ask (the subtitle side reader included, whose
    /// deliberate multi-minute parks are the shape a held connection must not take).
    private let heldConnectionEnabled: Bool
    private var throttleVClockNs: UInt64 = 0
    private let throttleLock = NSLock()

    /// #240: which reader this is, for the connection log. Several readers run against the same
    /// origin at once and the line used to name none of them.
    private let label: String
    private let diagnosticContext: SourceNetworkDiagnostics.Context?
    private let sourceOpenPolicy: SourceOpenPolicy
    private let openDiagnosticID = String(UUID().uuidString.prefix(8))
    /// Only static controlled probes use this; playback retains its existing transport policy.
    private let probeControl: ProbeControl?
    private let probeRequestSession: URLSession?
    private let persistentRequestSession: URLSession?
    private let probeDrainLock = NSLock()
    private var drainingProbeRequest = false
    /// AE#927: grows a controlled probe's sequential ranges. Demux thread only, like `position`.
    private var probeRangeGrowth: ProbeRangeGrowth?

    init(url: URL, extraHeaders: [String: String] = [:], label: String = "source", chunkSize: Int = 4 * 1024 * 1024, prefetchEnabled: Bool = true, isLive: Bool = false, chunkRequestTimeout: TimeInterval = 35, chunkMaxRetries: Int = 3, boundedInitialFetch: Int64? = nil, sequentialOnly: Bool = false, connStallTimeout: TimeInterval = AVIOReader.connStallTimeoutDefault, trickleFloorBytes: Int64? = nil, windowHighWater: Int? = nil, streamHighWater: Int? = nil, detourIdleSeconds: TimeInterval? = nil, detourFetchBudget: TimeInterval? = nil, heldConnection: Bool = false, probeControl: ProbeControl? = nil, probeRequestSession: URLSession? = nil, probeRangeCeiling: Int? = nil, sourceOpenPolicy: SourceOpenPolicy = .init(), requestHeaderStore: RequestHeaderStore? = nil, backoffScale: Double = 1, pinIdleSeconds: TimeInterval = AVIOReader.pinIdleRepinSecondsDefault, liveRefusalRetryBudget: TimeInterval = AVIOReader.liveRefusalRetryBudget, persistentRequestSession: URLSession? = nil, diagnosticContext: SourceNetworkDiagnostics.Context? = SourceNetworkDiagnostics.context, routesDiscMediaType: Bool = false) {
        self.diagnosticContext = diagnosticContext
        self.routesDiscMediaType = routesDiscMediaType
        self.sourceOpenPolicy = sourceOpenPolicy
        self.persistentRequestSession = persistentRequestSession
        self.probeControl = probeControl
        self.probeRequestSession = probeControl == nil ? nil : probeRequestSession
        self.probeRangeGrowth = probeControl == nil ? nil : probeRangeCeiling.map {
            ProbeRangeGrowth(floor: chunkSize, ceiling: $0)
        }
        self.url = url
        self.label = label
        self.openedHeaders = extraHeaders
        self.requestHeaderStore = requestHeaderStore
        self.chunkSize = chunkSize
        self.prefetchEnabled = prefetchEnabled
        self.isLive = isLive
        self.sequentialOnly = sequentialOnly
        self.chunkRequestTimeout = chunkRequestTimeout
        self.chunkMaxRetries = max(1, chunkMaxRetries)
        self.boundedInitialFetch = boundedInitialFetch.map { max(1, $0) }
        self.throttleKbps = AetherEngine.sourceThrottleKbpsForTesting
        self.backoffScale = backoffScale
        self.pinIdleSeconds = pinIdleSeconds
        self.liveRefusalRetryBudgetSeconds = liveRefusalRetryBudget
        self.connStallTimeout = max(0.05, connStallTimeout)
        self.trickleFloorBytes = max(1, trickleFloorBytes ?? Int64(
            Double(Self.trickleFloorBytesDefault) * self.connStallTimeout / Self.connStallTimeoutDefault))
        self.winHighWater = max(1, windowHighWater
            ?? (isLive ? Self.liveWinHighWaterDefault : Self.winHighWaterDefault))
        self.streamHighWater = max(1, streamHighWater ?? Self.streamHighWaterDefault)
        self.detourBlockIdleSeconds = detourIdleSeconds ?? Self.detourBlockIdleSecondsDefault
        self.detourFetchBudget = detourFetchBudget ?? Self.detourFetchBudgetSeconds
        self.heldConnectionEnabled = heldConnection
    }

    /// Slow-CDN simulation: hold delivered bytes to `throttleKbps` by sleeping the demux thread before the
    /// bytes reach the demuxer. No-op unless the test hook is set. Lock-guarded: prefetch and demux paths
    /// can both deliver. Sleeping here is consistent with the existing reconnect backoff on this thread.
    private func applyThrottle(deliveredBytes: Int) {
        guard throttleKbps > 0, deliveredBytes > 0 else { return }
        throttleLock.lock()
        let sleepNs = SourceThrottle.advance(
            vclockNs: &throttleVClockNs,
            nowNs: DispatchTime.now().uptimeNanoseconds,
            deliveredBytes: deliveredBytes,
            kbps: throttleKbps
        )
        throttleLock.unlock()
        if sleepNs > 0 { Thread.sleep(forTimeInterval: Double(sleepNs) / 1_000_000_000) }
    }

    /// The caller's headers this request may carry, given where it is actually going.
    ///
    /// Not the same set for every target, and that is the point. `RedirectHeaderPolicy` (#126)
    /// keeps a media-server credential off a cross-origin redirect target, but it only ever ran on
    /// the redirect HOP. Once a session pinned that target (#12), every later request was built
    /// straight against it with the full header set, so the credential the hop had just stripped
    /// went to the edge on the next range anyway. Measured against a logging origin: the 302 hop
    /// arrived `auth=none`, and the post-seek request to the same pinned host 13 s later carried
    /// both `Authorization` and `X-Emby-Token`. One policy, applied where the request is built, so
    /// a pin cannot outflank it.
    private func headers(for target: URL?) -> [String: String] {
        RedirectHeaderPolicy.headersToReplay(
            extraHeaders: extraHeaders, originalURL: url, redirectURL: target ?? url)
    }

    private func applyExtraHeaders(_ request: inout URLRequest) {
        for (name, value) in headers(for: request.url) {
            request.setValue(value, forHTTPHeaderField: name)
        }
    }

    func open() throws {
        try probeControl?.check()
        guard !isClosed else { throw CancellationError() }
        guard let buf = av_malloc(Int(Self.avioBufferSize)) else {
            throw AVIOReaderError.allocationFailed
        }
        buffer = buf.assumingMemoryBound(to: UInt8.self)

        let opaque = Unmanaged.passUnretained(self).toOpaque()
        guard let ctx = avio_alloc_context(
            buffer,
            Self.avioBufferSize,
            0,
            opaque,
            readCallback,
            nil,
            seekCallback
        ) else {
            av_free(buf)
            buffer = nil
            throw AVIOReaderError.allocationFailed
        }

        context = ctx

        if sequentialOnly {
            // Sequential origin: the only trustworthy request shape is one unranged GET from
            // byte 0. Everything the branches below would issue on top - the suffix tail
            // prefetch, the optimistic `Range: bytes=0-` persistent open, the dedicated size
            // probe - is a ranged request the origin would answer with fabricated positions,
            // so none of it runs. `fileSize` stays -1: `isStreaming` routes read()/seek()
            // onto the forward-only streaming path and the #126 block below marks the pb
            // non-seekable.
            startStreamingDownload()
            _ = streamDataReady.wait(timeout: .now() + .seconds(15))
            try failIfStreamingRefused(fallbackStatus: 0)
        } else if prefetchEnabled {
            // #281: the parse seeks that follow this open are what the retained head exists for.
            winCond.lock()
            openPhaseActive = true
            winCond.unlock()
            // #551: bytes a host warmed for this source before anything asked to play it. When
            // they are here, this open owes the origin nothing for the span they cover.
            let warm = adoptPrewarmedSource()
            // #281: issued BEFORE the data connection so it overlaps the round trip that follows,
            // rather than queueing behind it. It asks for a suffix range, which needs no size and
            // therefore needs nothing this open has learned yet. A warm that already carries the
            // trailing object has no use for it.
            // A fully resident head already contains the suffix too. Do not start an asynchronous
            // request for bytes this open has adopted in their entirety.
            let fullyWarmed = warm.map { $0.head.end >= $0.contentLength } ?? false
            if warm?.tail == nil, !fullyWarmed {
                startTailPrefetch()
            }
            // Playback path. The persistent connection's `Range: bytes=0-` request is itself
            // the size probe: its 206 Content-Range is folded into fileSize by
            // persistentReceivedResponse (issue #70), so the common case skips the dedicated
            // probeFileSize() round-trip (and its HEAD fallback, the request some origins 429).
            //
            // #551: a warm open moves that connection to the warm frontier rather than skipping it.
            // Playback needs the bytes behind the head either way, and issuing it here is what
            // overlaps its round trip with the parse that the warm bytes are already serving.
            let warmFrontier = warm?.head.end ?? 0
            let gotData: Bool
            let openPrefix: [UInt8]
            if let warm {
                if warmFrontier < warm.contentLength {
                    startPersistentConnection(at: warmFrontier, boundedTo: boundedInitialFetch)
                }
                // The open has its first bytes in hand, so there is nothing to wait for. Waiting
                // anyway would spend the round trip this whole feature exists to remove.
                gotData = true
                openPrefix = Array(warm.head.data.prefix(Self.openSniffBytes))
            } else {
                winCond.lock()
                rangeVerdictPending = !isLive
                winCond.unlock()
                startPersistentConnection(at: 0, boundedTo: boundedInitialFetch)
                var opened = awaitFirstPersistentData()
                // A live open the origin answered with a status is reported as that answer, the
                // way the live HLS ingest reports a refused join: the host retries a 509 on its own
                // cadence with the right words for it, where the read loop's ladder would have spent
                // the open budget on the same request and handed back an untyped read failure.
                // A server error is asked once more first, as the read loop did before this was typed:
                // a 500/502 while a tuner or transcode spins up is the moment's, not the channel's.
                if !opened, isLive, let refusal = refusalOfLiveOpenConnection(),
                   Self.isResolvedHardServerError(refusal) {
                    EngineLog.emit(
                        "[AVIOReader] \(label) live open answered status=\(refusal); asking once more",
                        category: .demux)
                    backoffBeforeReconnect(streak: 1, retryAfter: 0)
                    try probeControl?.check()
                    guard !isClosed else { throw CancellationError() }
                    startPersistentConnection(at: 0, boundedTo: boundedInitialFetch)
                    opened = awaitFirstPersistentData()
                }
                if !opened, isLive, let refusal = refusalOfLiveOpenConnection() {
                    EngineLog.emit(
                        "[AVIOReader] \(label) live open refused status=\(refusal); failing the open typed",
                        category: .demux)
                    markClosed()
                    close()
                    throw AVIOReaderError.httpStatus(refusal)
                }
                // AE#693: one refusal is the origin's answer to that request, not yet to the
                // resource. The #378 path below takes a 401/403/404/410 here as final and settles
                // the session forward-only, which costs it every seek and the resume position. An
                // IPTV panel answered a ranged open 403 and the unranged GET right after it 200, and
                // ranged requests worked again later. Asking the same range once more decides it:
                // served, the source stays seekable; refused again, the #378 path runs as before.
                if !opened, !isLive, let refusal = refusalOfOpenConnection() {
                    EngineLog.emit(
                        "[AVIOReader] \(label) ranged open refused status=\(refusal) at offset 0; "
                        + "asking once more before settling the source forward-only (AE#693)",
                        category: .demux)
                    try probeControl?.check()
                    winCond.lock()
                    rangeVerdictPending = true
                    winCond.unlock()
                    startPersistentConnection(at: 0, boundedTo: boundedInitialFetch)
                    opened = awaitFirstPersistentData()
                }
                gotData = try recoverUnansweredOpenIfNeeded(gotData: opened)
                openPrefix = firstWindowPrefix(max: Self.openSniffBytes)
            }
            // AE#140: an HLS playlist URL misrouted onto the raw-byte live path. A live origin serves the
            // finite #EXTM3U body at HTTP 200 and closes the connection; the endless-feed reader then
            // re-fetches that body forever. Those reconnects look PRODUCTIVE (a full body at 200, and every
            // find_stream_info probe seek resets the unproductive streak via seekReconnect), so the #71
            // give-up counters never trip, avformat_open_input never returns, and load() hangs with no
            // terminal state. Fail closed here, before the reconnect loop is ever entered: a raw media
            // container never begins with '#' (TS syncs on 0x47; MP4/MKV open with binary box/EBML markers),
            // so an #EXTM3U prefix is an unambiguous misroute. The host is pointed at the HLS entry points.
            if isLive, gotData, Self.bodyBeginsWithHLSPlaylistTag(openPrefix) {
                EngineLog.emit("[AVIOReader] HLS playlist body on the raw live path (AE#140); stopping here. A URL source is routed onto the live ingest by load() (AE#363); a custom reader keeps the typed rejection.", category: .demux)
                markClosed()
                close()
                throw AVIOReaderError.hlsPlaylistOnRawLivePath
            }
            // AE#154: same classification on the non-live path. FFmpeg (--disable-network) can
            // neither probe an m3u8 behind a custom pb (no extension / MIME hint reaches the hls
            // probe) nor fetch a variant, so avformat_open_input dies with AVERROR_INVALIDDATA.
            // Fail typed instead; load() reroutes the URL onto the native remote-HLS bypass.
            if !isLive, gotData, Self.bodyBeginsWithHLSPlaylistTag(openPrefix) {
                EngineLog.emit("[AVIOReader] HLS playlist body on the VOD loopback path (AE#154); rerouting to the native remote-HLS bypass.", category: .demux)
                markClosed()
                close()
                throw AVIOReaderError.hlsPlaylistOnVODPath
            }
            // AE#859: the same misroute for an MPEG-DASH manifest. FFmpeg ships no DASH demuxer (it
            // needs libxml2) and could not fetch a representation if it had one; the demuxer lays
            // the manifest out as one fragmented MP4 instead (`DASHSourceOpener`).
            if gotData, DASHManifest.bodyBeginsWithManifest(openPrefix) {
                EngineLog.emit("[AVIOReader] \(label) MPEG-DASH manifest body (AE#859); handing it to the DASH opener.", category: .demux)
                markClosed()
                close()
                throw AVIOReaderError.dashManifest
            }
            if !isLive, routesDiscMediaType, gotData {
                let contentType = openResponseContentType
                var discPrefix: [UInt8] = []
                if DiscImageMediaType.isGeneric(contentType: contentType) {
                    discPrefix = warm.map { Array($0.head.data.prefix(DiscImageMediaType.volumeSignatureEnd)) }
                        ?? awaitWindowPrefix(count: DiscImageMediaType.volumeSignatureEnd)
                    try probeControl?.check()
                    guard !isClosed else { throw CancellationError() }
                }
                noteOpenSuggestsDisc(DiscImageMediaType.suggestsDiscImage(contentType: contentType, prefix: discPrefix))
            }
            if !isLive, routesDiscMediaType, gotData, openSuggestsDiscImage {
                EngineLog.emit("[AVIOReader] \(label) the source declares a disc image type or carries a volume signature (AE#860); handing it to the disc adapter.", category: .demux)
                markClosed()
                close()
                if let warm { SourcePrewarmStore.shared.store(warm, for: url) }
                throw AVIOReaderError.discImageMediaType
            }
            if isLive, !gotData { try failIfStreamingRefused(fallbackStatus: 0) }
            var tookFallback = false
            if !isLive {
                // Atomically decide, under winCond, whether the optimistic connection resolved
                // a size; if not, abandon it (generation bump ignores a size landing in the
                // race window). fileSize is read under the lock because the delegate thread now
                // writes it (issue #70 review #4/#5).
                let (haveSize, abandoned, pumpStatus, caughtIgnoringRange) = resolveOptimisticOpen()
                abandoned?.cancelTransfer()
                abandoned?.releaseOriginTicket()
                var ignoredRangeLength = caughtIgnoringRange
                if let length = caughtIgnoringRange {
                    tookFallback = true
                    try probeControl?.check()
                    if confirmRangeIsIgnored(contentLength: length) == .honoured { ignoredRangeLength = nil }
                    try probeControl?.check()
                }
                if let ignoredRangeLength {
                    openForwardOnlyBecauseRangeIsIgnored(contentLength: ignoredRangeLength)
                    try failIfStreamingRefused(fallbackStatus: 0)
                } else if !haveSize {
                    tookFallback = true
                    // A 401/403/404/410 at byte 0, given twice (AE#693: once can be the moment's),
                    // is the origin's answer to the RESOURCE, not to the range form: a HEAD or a
                    // `bytes=0-1` from the same client is answered
                    // alike, and a size learned from either would only re-issue the refused range
                    // on the persistent path (which then dies after one retry with the status
                    // lost). Skip the ladder. The one request still worth making is the unranged
                    // GET below: an origin that refuses `Range` but serves a plain GET plays
                    // forward-only (which is what the ladder's streaming fallback did for it
                    // anyway), and one that refuses both fails typed with its status.
                    let pumpRefusal = (!gotData && Self.isResolvedExpiryStatus(pumpStatus)) ? pumpStatus : 0
                    if pumpRefusal != 0 {
                        EngineLog.emit(
                            "[AVIOReader] \(label) data connection refused status=\(pumpRefusal) at offset 0; "
                            + "skipping the size probes, trying one unranged GET",
                            category: .demux)
                        fileSize = -1
                    } else {
                        // The data connection resolved no size (no-length origin, a transient 429,
                        // slow headers, or an origin whose length only comes via HEAD). Fall back to
                        // the exact pre-#70 probe path (Range bytes=0- then HEAD, on its own
                        // connection and budget): it keeps seekability whenever a size is reachable
                        // and only streams on a genuinely length-less source, restoring main's
                        // resilience to all of those cases (issue #70 review #1/#3/#4).
                        EngineLog.emit("[AVIOReader] Data connection resolved no size, falling back to probe", category: .demux, level: .verbose)
                        fileSize = resolveInitialFileSize()
                        try probeControl?.check()
                        guard !isClosed else { throw CancellationError() }
                    }
                    if isStreaming {
                        startStreamingDownload()
                        _ = streamDataReady.wait(timeout: .now() + .seconds(15))
                        try failIfStreamingRefused(fallbackStatus: pumpRefusal)
                    } else {
                        // Audit DMX-101: a cold open that was refused or slow never judged the
                        // origin's range support, and the probe above takes a 200's Content-Length
                        // for a size. This connection is then the first to see the origin's answer,
                        // so it gets the same head classification and confirmation.
                        winCond.lock()
                        rangeVerdictPending = true
                        winCond.unlock()
                        startPersistentConnection(at: 0)
                        let gotData = awaitFirstPersistentData()
                        if let caught = takeRangeVerdictAfterProbe() {
                            caught.abandoned?.cancelTransfer()
                            caught.abandoned?.releaseOriginTicket()
                            try probeControl?.check()
                            let confirmation = confirmRangeIsIgnored(contentLength: caught.contentLength)
                            try probeControl?.check()
                            if confirmation == .ignored {
                                openForwardOnlyBecauseRangeIsIgnored(contentLength: caught.contentLength)
                                try failIfStreamingRefused(fallbackStatus: 0)
                            } else {
                                startPersistentConnection(at: 0)
                                if !awaitFirstPersistentData() {
                                    EngineLog.emit("[AVIOReader] Persistent open (post-probe): no data within the open budget, proceeding to read-loop reconnect", category: .demux)
                                }
                            }
                        } else if !gotData {
                            EngineLog.emit("[AVIOReader] Persistent open (post-probe): no data within the open budget, proceeding to read-loop reconnect", category: .demux)
                        }
                    }
                }
            }
            // #551: a warm open asserts `gotData` instead of observing it, which is the whole point
            // (nothing waits on a first byte), and the cost is that the open-time refusal ladder
            // above never runs for it. A source whose token expired between the warm and the play
            // would then parse happily out of warm bytes and die several seconds later as an
            // untyped read failure instead of as the 401 it is.
            //
            // Checked, not waited for: if the refusal has already landed by the time the open gets
            // here, it is thrown typed exactly as the cold path throws it, and if it has not, the
            // read loop's ladder still ends the session correctly, just later and less precisely.
            // The alternative, waiting for the answer, is the round trip this feature removes.
            if warm != nil {
                winCond.lock()
                let refusal = (connEnded && Self.isResolvedExpiryStatus(connStatus)) ? connStatus : 0
                winCond.unlock()
                if refusal != 0 {
                    EngineLog.emit(
                        "[AVIOReader] \(label) the warm open found the source already refused: "
                        + "HTTP \(refusal); failing the open typed (#551)", category: .demux)
                    markClosed()
                    close()
                    throw AVIOReaderError.httpStatus(refusal)
                }
            }
            if !tookFallback && !gotData {
                // No first byte within the opening budget; read loop's stall/reconnect machinery takes over.
                EngineLog.emit("[AVIOReader] Persistent open: no first byte within the opening budget, proceeding to read-loop reconnect", category: .demux)
            }
        } else {
            // Non-prefetch (still extraction / one-shot seekable): the size is needed up
            // front for SEEK_END and container index seeks, so keep the dedicated probe.
            fileSize = resolveInitialFileSize()
            // A controlled probe's deadline/cancellation reason wins over the reader-close
            // signal used to interrupt its in-flight request.
            try probeControl?.check()
            guard !isClosed else { throw CancellationError() }
            if isStreaming {
                startStreamingDownload()
                _ = streamDataReady.wait(timeout: .now() + .seconds(15))
                try failIfStreamingRefused(fallbackStatus: 0)
            } else {
                if let data = fetchChunk(from: 0, size: chunkSize) {
                    currentBuffer = data
                    currentOffset = 0
                    // AE#859: the bounded probe reader opens here, past the persistent-window check.
                    if DASHManifest.bodyBeginsWithManifest([UInt8](data.prefix(Self.openSniffBytes))) {
                        EngineLog.emit("[AVIOReader] \(label) MPEG-DASH manifest body (AE#859); handing it to the DASH opener.", category: .demux)
                        markClosed()
                        close()
                        throw AVIOReaderError.dashManifest
                    }
                    // The probe reader's first chunk already covers sector 16, so this costs no request.
                    noteOpenSuggestsDisc(DiscImageMediaType.suggestsDiscImage(
                        contentType: openResponseContentType,
                        prefix: [UInt8](data.prefix(DiscImageMediaType.volumeSignatureEnd))))
                    if routesDiscMediaType, openSuggestsDiscImage {
                        EngineLog.emit("[AVIOReader] \(label) the source declares a disc image type or carries a volume signature (AE#860); handing it to the disc adapter.", category: .demux)
                        markClosed()
                        close()
                        throw AVIOReaderError.discImageMediaType
                    }
                }
            }
        }

        // AE#733: the AE#140/#154 classification above only reads the persistent window, and a
        // forward-only open (no size, or an origin that ignores Range) leaves that window empty. A
        // playlist endpoint answering 200 without a length lands exactly there, so the same check
        // runs on the stream's first bytes before FFmpeg is handed the m3u8 as container bytes.
        let streamPrefix = isStreaming ? firstStreamPrefix(max: Self.openSniffBytes) : []
        if isStreaming, Self.bodyBeginsWithHLSPlaylistTag(streamPrefix) {
            EngineLog.emit("[AVIOReader] \(label) HLS playlist body on the forward-only open (AE#733); rerouting like AE#140/#154.", category: .demux)
            markClosed()
            close()
            throw isLive ? AVIOReaderError.hlsPlaylistOnRawLivePath : AVIOReaderError.hlsPlaylistOnVODPath
        }
        if isStreaming, DASHManifest.bodyBeginsWithManifest(streamPrefix) {
            EngineLog.emit("[AVIOReader] \(label) MPEG-DASH manifest body on the forward-only open (AE#859); handing it to the DASH opener.", category: .demux)
            markClosed()
            close()
            throw AVIOReaderError.dashManifest
        }

        // #126: a VOD source that finishes open() without a resolved size runs the forward-only
        // streaming reader; FFmpeg must not believe pb is seekable. With a seekable-flagged pb the
        // mov demuxer far-forward-skips to a tail moov (buffering the entire skipped span in RAM),
        // parses an index it can never rewind to, and every sample read then dies with "partial
        // file" / zero produced packets. Non-seekable pb makes moov-at-end fail cleanly at open
        // and keeps faststart files on honest sequential reads.
        if !isLive, isStreaming, let ctx = context {
            ctx.pointee.seekable = 0
        }
    }

    /// Wait for the persistent connection's first window bytes within the open policy. The response
    /// (and thus any Content-Range size) has already been processed by the time data
    /// arrives. Demux thread, open-time only. Returns true if data arrived.
    private func awaitFirstPersistentData(timeout: TimeInterval? = nil, phase: String = "first-data") -> Bool {
        winCond.lock()
        let started = DispatchTime.now()
        let budget = timeout ?? (isLive ? 15 : sourceOpenPolicy.firstByteTimeout)
        let deadline = Date(timeIntervalSinceNow: budget)
        openAwaitedGeneration = connGeneration
        while window.isEmpty && !connEnded && !isClosed {
            if !winCond.wait(until: deadline) { break }
        }
        openAwaitedGeneration = nil
        let gotData = !window.isEmpty
        let result = gotData ? "data" : (isClosed ? "cancelled" : (connEnded ? "ended" : "timeout"))
        let generation = connGeneration
        let status = connStatus
        let knownSize = fileSize
        winCond.unlock()
        let elapsed = Double(DispatchTime.now().uptimeNanoseconds - started.uptimeNanoseconds) / 1_000_000
        EngineLog.emit("[SourceOpen] reader=\(openDiagnosticID) phase=\(phase) gen=\(generation) result=\(result) elapsed_ms=\(Int(elapsed)) budget=\(budget)s status=\(status) size=\(knownSize)", category: .demux)
        return gotData
    }

    /// A timeout is not evidence that the origin cannot seek. Retry the data request once,
    /// using the alternate open-ended Range shape, and keep its body for playback. Metadata-only
    /// probes would discard that body and open yet another connection, or silently downgrade an
    /// unanswered seekable resource to a forward-only stream. A definitive response still takes
    /// the ordinary range-validation/refusal path below. Known-size slow bodies keep their pump.
    private func recoverUnansweredOpenIfNeeded(gotData: Bool) throws -> Bool {
        guard !isLive, !gotData else { return gotData }
        try probeControl?.check()
        guard !isClosed else { throw CancellationError() }
        winCond.lock()
        let unanswered = fileSize <= 0 && connStatus == 0 && window.isEmpty
        winCond.unlock()
        guard unanswered else { return gotData }
        // A trust failure cannot be repaired by changing the Range header.
        try failIfStreamingRefused(fallbackStatus: 0)
        EngineLog.emit("[SourceOpen] reader=\(openDiagnosticID) phase=data-retry reason=no-response budget=\(sourceOpenPolicy.sizeProbeTimeout)s", category: .demux)
        startPersistentConnection(at: 0, openEnded: true)
        let recovered = awaitFirstPersistentData(timeout: sourceOpenPolicy.sizeProbeTimeout,
                                                  phase: "data-retry")
        try probeControl?.check()
        guard !isClosed else { throw CancellationError() }
        try failIfStreamingRefused(fallbackStatus: 0)
        winCond.lock()
        let unresolved = fileSize <= 0 && connStatus == 0 && window.isEmpty
        let ended = connEnded
        winCond.unlock()
        if unresolved {
            EngineLog.emit("[SourceOpen] reader=\(openDiagnosticID) phase=failed reason=no-response seekability=unknown not downgrading to sequential", category: .demux)
            markClosed()
            close()
            throw ended ? AVIOReaderError.noResponse : AVIOReaderError.requestTimeout
        }
        return recovered
    }

    /// The refusal status the current persistent connection ended on, nil when it did not end on one
    /// of the `isResolvedExpiryStatus` refusals. Demux thread, open-time only.
    private func refusalOfOpenConnection() -> Int? {
        winCond.lock()
        defer { winCond.unlock() }
        return (connEnded && Self.isResolvedExpiryStatus(connStatus)) ? connStatus : nil
    }

    /// The status a live open's first connection ended with before any data, when it was an answer
    /// (any 4xx or 5xx, the rate-limit statuses included); nil for a connection still open, one that
    /// delivered, or one that ended with no status (a transport failure, which the read loop rides).
    private func refusalOfLiveOpenConnection() -> Int? {
        winCond.lock()
        defer { winCond.unlock() }
        return (connEnded && window.isEmpty && connStatus >= 400) ? connStatus : nil
    }

    /// The streaming GET was answered with a status instead of a body, or the ranged open was
    /// already refused with one and the unranged GET then delivered nothing either. Either way the
    /// demuxer would be handed an empty stream (or an error page) and report it as invalid data;
    /// close and fail typed instead, the way the AE#140/AE#154 classifications do, so load()
    /// publishes the status. `fallbackStatus` is the ranged open's refusal (0 when there was
    /// none): a hung-up unranged GET whose header never arrived within the open budget still
    /// carries the verdict the origin already gave. Demux thread, open-time only.
    /// AE#495: record a TLS trust refusal off any task of this reader, and name it once in the log.
    /// Everything else is left to the caller's own error handling; this only classifies.
    func noteTransportSecurityFailure(_ error: Error?) {
        guard let code = TransportSecurityFailure.code(in: error) else { return }
        streamLock.lock()
        let first = transportSecurityCode == 0
        transportSecurityCode = code
        streamLock.unlock()
        guard first else { return }
        EngineLog.emit(
            "[AVIOReader] \(label) TLS refused (NSURLError \(code)): "
            + "\(TransportSecurityFailure.sentence(for: code))",
            category: .demux)
    }

    private func failIfStreamingRefused(fallbackStatus: Int) throws {
        streamLock.lock()
        let refused = streamRefusedStatus
        let ended = streamEnded
        let empty = streamBuffer.isEmpty && streamBytesRead == 0
        let streamCode = ended && empty ? streamURLFailureCode : nil
        streamLock.unlock()
        winCond.lock()
        let persistentEmpty = connEnded && window.isEmpty
        let persistentCode = persistentEmpty ? connURLFailureCode : nil
        let persistentStatus = persistentEmpty && connStatus >= 400 ? connStatus : 0
        winCond.unlock()
        let status = refused != 0 ? refused : ((ended && empty) ? fallbackStatus : (isLive ? persistentStatus : 0))
        // AE#495: a handshake the system refused outranks a status, because there was never a
        // response to carry one. Same reason this function exists at all: the demuxer would be handed
        // nothing and report invalid data.
        streamLock.lock()
        let tlsCode = transportSecurityCode
        streamLock.unlock()
        if tlsCode != 0 {
            EngineLog.emit(
                "[AVIOReader] \(label) source unreachable: \(TransportSecurityFailure.sentence(for: tlsCode)); "
                + "failing the open typed",
                category: .demux)
            markClosed()
            close()
            throw AVIOReaderError.transportSecurityFailed(code: tlsCode)
        }
        // A trust failure cannot be fixed by reconnecting. Any other transport failure (a reset or
        // a timeout while a tuner spins up) is left to the reconnect ladder, as before; its code is
        // only recorded (`lastTransportFailureCode`) for whoever finally gives up.
        if let code = streamCode ?? persistentCode, (-1206 ... -1200).contains(code), status == 0 {
            markClosed()
            close()
            throw AVIOReaderError.transportSecurityFailed(code: code)
        }
        guard status != 0 else { return }
        EngineLog.emit(
            "[AVIOReader] \(label) source refused: HTTP \(status); failing the open typed",
            category: .demux)
        markClosed()
        close()
        throw AVIOReaderError.httpStatus(status)
    }

    /// Snapshot up to `max` leading bytes of the first window (open-time, before any read has consumed
    /// it, so `winStart == 0`). winCond-guarded like every other window access. Used only by the AE#140
    /// misroute check; returns [] if no data has arrived.
    /// How much of the body the open classifies. `#EXTM3U` is in the first bytes, but an MPD root
    /// usually follows an XML declaration and a generator comment (GPAC writes about 120 bytes of
    /// them), so the classification reads further than a container signature needs (AE#859).
    static let openSniffBytes = 1024

    /// AE#860: the `Content-Type` the open learned, nil until a 2xx answer (or a warm) supplied one.
    var openResponseContentType: String? {
        winCond.lock()
        defer { winCond.unlock() }
        return openContentType
    }

    /// AE#860: what the open learned about a disc behind this source. `ProbeHTTPReader` turns its
    /// disc probe on from it; the demuxer's URL open reroutes on it before this reader is used.
    var openSuggestsDiscImage: Bool {
        winCond.lock()
        defer { winCond.unlock() }
        return openSuggestsDisc
    }

    private func noteOpenSuggestsDisc(_ suggests: Bool) {
        winCond.lock()
        openSuggestsDisc = suggests
        winCond.unlock()
    }

    /// How long the open waits for sector 16 of an `application/octet-stream` body (AE#860). The
    /// bytes are already on their way on the opening connection, so this is normally one window
    /// fill; a slower origin just goes unsniffed.
    static let discSignatureWait: TimeInterval = 2

    /// The first `count` bytes of the opening window, waiting on the same connection until they are
    /// there, it ended, or `discSignatureWait` passed. Shorter when the body is.
    private func awaitWindowPrefix(count: Int) -> [UInt8] {
        winCond.lock()
        defer { winCond.unlock() }
        let deadline = Date(timeIntervalSinceNow: Self.discSignatureWait)
        while window.count < count && !connEnded && !isClosed {
            if !winCond.wait(until: deadline) { break }
        }
        return window.prefix(Swift.min(count, window.count))
    }

    private func firstWindowPrefix(max: Int = 16) -> [UInt8] {
        winCond.lock()
        defer { winCond.unlock() }
        let n = Swift.min(max, window.count)
        return window.prefix(n)
    }

    /// Leading bytes of the forward-only stream at open, before any read has consumed them.
    private func firstStreamPrefix(max: Int = 16) -> [UInt8] {
        streamLock.lock()
        defer { streamLock.unlock() }
        guard streamBytesRead == 0 else { return [] }
        return streamBuffer.prefix(max)
    }

    /// True when a body's leading bytes are the HLS playlist tag `#EXTM3U`, tolerating a UTF-8 BOM and
    /// leading ASCII whitespace. A raw media container never opens with '#', so this is an unambiguous
    /// signal that an m3u8 playlist was handed to the raw-byte reader (AE#140). Static + internal so the
    /// classifier is unit-tested without a live origin.
    static func bodyBeginsWithHLSPlaylistTag(_ bytes: [UInt8]) -> Bool {
        var i = 0
        if bytes.count >= 3, bytes[0] == 0xEF, bytes[1] == 0xBB, bytes[2] == 0xBF { i = 3 }
        while i < bytes.count, bytes[i] == 0x20 || bytes[i] == 0x09 || bytes[i] == 0x0A || bytes[i] == 0x0D {
            i += 1
        }
        let tag = Array("#EXTM3U".utf8)
        guard bytes.count - i >= tag.count else { return false }
        return Array(bytes[i..<(i + tag.count)]) == tag
    }

    /// Under a single winCond critical section: snapshot whether the optimistic open-time
    /// connection resolved a size (fileSize > 0, written by the delegate thread in
    /// persistentReceivedResponse), and if not, atomically abandon that connection so the
    /// open can fall back to the probe path. Bumping the generation inside the same lock as
    /// the read means a size that lands in the race window is ignored rather than racing a
    /// half-done teardown (issue #70 review #4/#5). Returns the session to cancel outside
    /// the lock. Demux thread, open-time only; leaves the AVIO context intact (unlike close()).
    /// `pumpStatus` is the HTTP status the abandoned connection was answered with (0 when no
    /// response arrived), so the caller can tell a refused resource from a length-less one.
    private func resolveOptimisticOpen() -> (haveSize: Bool, abandoned: (any PersistentTransfer)?,
                                             pumpStatus: Int, caughtIgnoringRange: Int64?) {
        winCond.lock()
        defer { winCond.unlock() }
        rangeVerdictPending = false
        let ignoredLength = rangeIgnoredAtOpenLength
        rangeIgnoredAtOpenLength = nil
        if fileSize > 0 { return (true, nil, connStatus, nil) }
        let status = connStatus
        connGeneration &+= 1
        let transfer = activeTransfer
        activeTransfer = nil
        window.removeAll()
        connEnded = true
        // The replacement owns its failures; do not carry this retired connection's error.
        connURLFailureCode = nil
        winCond.broadcast()
        return (false, transfer, status, ignoredLength)
    }

    /// Audit DMX-101: the verdict of the post-probe connection, which `resolveOptimisticOpen` does
    /// for the cold one. The size is already resolved by the probe, so nothing here keys off it:
    /// a caught origin gets its connection abandoned under the lock, with the window emptied, and
    /// a connection that was not caught is left running. The flag is cleared either way, so a
    /// refill or reconnect later in the session is never read as a verdict. Demux thread,
    /// open-time only.
    private func takeRangeVerdictAfterProbe() -> (contentLength: Int64, abandoned: (any PersistentTransfer)?)? {
        winCond.lock()
        defer { winCond.unlock() }
        rangeVerdictPending = false
        guard let contentLength = rangeIgnoredAtOpenLength else { return nil }
        rangeIgnoredAtOpenLength = nil
        connGeneration &+= 1
        let transfer = activeTransfer
        activeTransfer = nil
        window.removeAll()
        connEnded = true
        connURLFailureCode = nil
        winCond.broadcast()
        return (contentLength, transfer)
    }

    private enum RangeConfirmation { case honoured, ignored }

    /// Audit DMX-101: the cold connection's 200 is one answer. Some CDNs send a 200 on a cache miss
    /// and a 206 for every request after it, so the verdict waits for a second, one byte request.
    /// Anything but a 206 that starts where asked (a 200, a refusal, a timeout, a misplaced range)
    /// leaves the origin judged as it was caught: a source that cannot address bytes. The body a
    /// 200 answer carries is cut after the one byte the request asked for (`ChunkFetchDelegate`).
    /// Demux thread, open-time only.
    private func confirmRangeIsIgnored(contentLength: Int64) -> RangeConfirmation {
        var request = URLRequest(engineURL: requestURL())
        request.setValue("bytes=1-1", forHTTPHeaderField: "Range")
        let budget = min(10, chunkRequestTimeout)
        request.timeoutInterval = budget
        applyExtraHeaders(&request)
        do {
            let (_, response) = try syncRequest(request, budget: budget)
            guard let http = response as? HTTPURLResponse else { return .ignored }
            switch Self.rangeAnswer(http, requestedStart: 1, requestedEnd: 1) {
            case .honoured:
                EngineLog.emit(
                    "[AVIOReader] \(label) the origin answered the ranged open with a 200 "
                    + "(Content-Length \(contentLength)) but honours a one byte range; "
                    + "keeping the seekable path (audit DMX-101)", category: .demux)
                return .honoured
            case .overWide:
                // A 206 is the origin addressing bytes, however wide it answered.
                return .honoured
            default:
                return .ignored
            }
        } catch {
            return .ignored
        }
    }

    /// Audit DMX-101: an origin that cannot address bytes is played forward-only, exactly what
    /// `sequentialOnly` does by declaration: one unranged GET, `fileSize` unresolved so the pb is
    /// non-seekable (#126 below), and the window bounded by the streaming path's high water. The
    /// Content-Length it stated stays advisory and is what `AVSEEK_SIZE` answers, because FFmpeg
    /// estimates an MPEG-TS duration from the size and a length-less source reports none.
    /// Demux thread, open-time only.
    private func openForwardOnlyBecauseRangeIsIgnored(contentLength: Int64) {
        EngineLog.emit(
            "[AVIOReader] \(label) origin does not honour Range (Content-Length \(contentLength)); "
            + "playing forward-only from one unranged GET (audit DMX-101)", category: .demux)
        originIgnoresRange = true
        winCond.lock()
        fileSize = -1
        winCond.unlock()
        streamLock.lock()
        streamExpectedBytes = contentLength > 0 ? contentLength : -1
        streamLock.unlock()
        winCond.lock()
        let tailTask = tailPrefetchTask
        tailPrefetchTask = nil
        tailPrefetchInFlight = false
        winCond.unlock()
        tailTask?.cancel()
        startStreamingDownload()
        _ = streamDataReady.wait(timeout: .now() + .seconds(15))
    }

    // Close flags written on the teardown thread (markClosed / fullyClose) and read on the demux
    // thread plus the URLSession delegate threads (persistent-connection callbacks). Backed by a
    // leaf unfair lock so every access is synchronized; the bare Bools were a TSan-confirmed data
    // race (markClosed write vs appendPersistentData read). The lock is only ever held for the
    // get/set itself (never across another lock), so it cannot invert with winCond/streamLock.
    private let isClosedLock = OSAllocatedUnfairLock<Bool>(initialState: false)
    private var isClosed: Bool {
        get { isClosedLock.withLock { $0 } }
        set { isClosedLock.withLock { $0 = newValue } }
    }
    private let isFullyClosedLock = OSAllocatedUnfairLock<Bool>(initialState: false)
    private var isFullyClosed: Bool {
        get { isFullyClosedLock.withLock { $0 } }
        set { isFullyClosedLock.withLock { $0 = newValue } }
    }

    /// #112 round 8: the resolved total byte size (Content-Length / Content-Range), nil until known.
    /// Read under winCond like every other fileSize access. Used by `Demuxer.seekByteEstimate` for the
    /// single-probe byte-position fallback when a timestamp seek on an index-less container times out.
    var resolvedByteSize: Int64? {
        winCond.lock()
        defer { winCond.unlock() }
        return fileSize > 0 ? fileSize : nil
    }

    /// Wall-clock deadline for reads. Armed by `beginReadDeadline` to abort
    /// a `avformat_seek_file` that degrades into a linear scan when MKV Cues
    /// index is missing or past EOF (tens of minutes on remote sources).
    private var readDeadline = Date.distantFuture
    private var isPastReadDeadline: Bool { Date() >= readDeadline }
    /// Set when a read returned early due to deadline. `seekBounded` uses this
    /// since matroska may still return success with a partial index after abort.
    private(set) var readDeadlineFired = false

    /// Contract: `readDeadline`/`readDeadlineFired` are demux-thread-only. The
    /// still-extraction (FrameExtractor) reader satisfies this because it runs on one
    /// serial decode queue and `avioPrefetch:false` means no background prefetch thread
    /// touches them. A future profile that re-enables prefetch on a deadline-armed
    /// reader would need these guarded.
    func beginReadDeadline(secondsFromNow seconds: TimeInterval) {
        readDeadlineFired = false
        readDeadline = Date(timeIntervalSinceNow: seconds)
        // Wake a read already parked in the forward-wait so it re-evaluates
        // against the new deadline instead of sleeping the full stall window.
        winCond.lock()
        winCond.broadcast()
        winCond.unlock()
    }

    func endReadDeadline() {
        readDeadline = .distantFuture
    }

    private var readByteBudget = ReadByteBudget()
    var readByteBudgetExhausted: Bool { readByteBudget.exhausted }
    func beginReadByteBudget(_ bytes: Int64) { readByteBudget.begin(bytes) }
    func endReadByteBudget() { readByteBudget.end() }

    /// Deadline expired; latches `readDeadlineFired` at the check sites.
    private var readDeadlinePassedOrAborted: Bool { isPastReadDeadline }

    // Streaming task/session held so teardown can cancel and unblock streamDownloadSync.
    private var streamingSession: URLSession?
    private var streamingTask: URLSessionDataTask?
    // Suspend/resume calls are balanced under streamLock.
    private var streamingTaskSuspended = false

    /// Unblock a suspended av_read_frame and release the live network connection.
    /// Must be called BEFORE acquiring the demuxer's access lock.
    func markClosed() {
        isClosed = true
        // Wake any semaphore waits so the read callbacks can exit
        prefetchReady.signal()
        streamDataReady.signal()
        streamLock.lock()
        let sTask = streamingTask
        let wasSuspended = streamingTaskSuspended
        streamingTaskSuspended = false
        streamLock.unlock()
        if wasSuspended { sTask?.resume() }
        sTask?.cancel()
        winCond.lock()
        connGeneration &+= 1
        // #93/#96 residual: cancel the persistent Range GET here, not only in close(). markClosed is
        // the abort used by the #79 reopen path (dem.markClosed() to unblock a wedged read); leaving
        // its long-lived open-ended connection alive lets it keep draining the origin for the whole
        // reopen + first-read window, and that connection fair-shares the origin's bandwidth with the
        // fresh reader's cold read, which is exactly the per-connection starvation behind the residual
        // 15-30s cold reads. The AVIO context is untouched (close() still frees it); only the socket
        // is released. Grab under winCond, invalidate outside it (mirrors close()).
        let transfer = activeTransfer
        activeTransfer = nil
        connEnded = true
        // #281: a speculative fetch outlives nothing. Same reasoning as the persistent GET above:
        // an abandoned reader's in-flight request fair-shares the origin with the fresh reader's
        // cold read, which is the starvation this whole area keeps paying for.
        let tailTask = tailPrefetchTask
        tailPrefetchTask = nil
        tailPrefetchInFlight = false
        openPhaseActive = false
        winCond.broadcast()
        winCond.unlock()
        transfer?.cancelTransfer()
        transfer?.releaseOriginTicket()   // #377: the fresh reader asks for this slot next
        tailTask?.cancel()
    }

    /// Free all resources. Separate from `markClosed` (step 1: unblock reads)
    /// because `isClosed` alone can't gate this: prior misuse of that guard
    /// silently leaked 64 MB current + 64 MB prefetch buffers on teardown.
    /// `isFullyClosed` is the idempotency latch for this step.
    func close() {
        guard !isFullyClosed else { return }
        isFullyClosed = true
        isClosed = true
        if let ctx = context {
            // avio_context_free does NOT free ctx->buffer (verified, aviobuf.c).
            // Free ctx.pointee.buffer, not original av_malloc ptr: FFmpeg can
            // realloc internally via ffio_set_buf_size.
            av_free(ctx.pointee.buffer)
            avio_context_free(&context)
        }
        context = nil
        buffer = nil

        bufferLock.lock()
        currentBuffer = Data()
        prefetchBuffer = nil
        bufferLock.unlock()

        detourCache.clear()

        streamLock.lock()
        streamEnded = true
        streamBuffer.removeAll()
        let sTask = streamingTask
        let sSession = streamingSession
        let wasSuspended = streamingTaskSuspended
        streamingTaskSuspended = false
        streamingTask = nil
        streamingSession = nil
        streamLock.unlock()
        if wasSuspended { sTask?.resume() }
        streamDataReady.signal()
        // Covers a close() without prior markClosed().
        sTask?.cancel()
        sSession?.invalidateAndCancel()

        winCond.lock()
        connGeneration &+= 1
        connEnded = true
        let transfer = activeTransfer
        activeTransfer = nil
        window.removeAll()
        // #281: both spans hold real bytes (up to headSpanMaxBytes + tailPrefetchBytes), so they
        // are released with the window rather than living until the reader is deallocated.
        headSpan = Data()
        headSpanCheckTail = nil
        tailSpan = nil
        openPhaseActive = false
        let tailTask = tailPrefetchTask
        tailPrefetchTask = nil
        tailPrefetchInFlight = false
        winCond.broadcast()
        winCond.unlock()
        tailTask?.cancel()
        // #220: the shared session is never invalidated, so the transfer has to be cancelled
        // explicitly. Invalidating used to be what released this connection.
        transfer?.cancelTransfer()
        transfer?.releaseOriginTicket()
    }

    // MARK: - Read (called by FFmpeg on demux thread)

    // Internal (not fileprivate) so the #174 backpressure tests can drive the consumer
    // side directly; production entry stays the C read callback below.
    func read(into buf: UnsafeMutablePointer<UInt8>, size: Int32) -> Int32 {
        guard !isClosed else { return -1 }
        if readDeadlinePassedOrAborted { readDeadlineFired = true; return -1 }
        guard let allowed = readByteBudget.allowance(size) else { return -1 }
        // Check usePersistentReader before isStreaming: live feeds without
        // Content-Length must use the reconnect-capable persistent path.
        let n: Int32
        if usePersistentReader { n = readPersistent(into: buf, size: allowed) }
        else if isStreaming { n = readStreaming(into: buf, size: allowed) }
        else { n = readSeekable(into: buf, size: allowed) }
        if n > 0 { applyThrottle(deliveredBytes: Int(n)) }
        readByteBudget.consumed(n)
        return n
    }

    // MARK: - Seekable Read (Range-based)

    private func readSeekable(into buf: UnsafeMutablePointer<UInt8>, size: Int32) -> Int32 {
        let requestSize = Int(size)
        var totalRead = 0

        while totalRead < requestSize {
            // Abort a superseded / torn-down / past-deadline still read between chunk
            // fetches so it cannot park the decode queue (issue #27). Mirrors the
            // checks readPersistent already does at its loop head.
            if isClosed { return totalRead > 0 ? Int32(totalRead) : -1 }
            if readDeadlinePassedOrAborted { readDeadlineFired = true; return totalRead > 0 ? Int32(totalRead) : -1 }

            bufferLock.lock()
            let bufEnd = currentOffset + Int64(currentBuffer.count)
            let inRange = position >= currentOffset && position < bufEnd
            bufferLock.unlock()

            if inRange {
                bufferLock.lock()
                let offsetInBuffer = Int(position - currentOffset)
                let available = currentBuffer.count - offsetInBuffer
                let toCopy = min(available, requestSize - totalRead)

                currentBuffer.withUnsafeBytes { raw in
                    let src = raw.baseAddress!.advanced(by: offsetInBuffer)
                        .assumingMemoryBound(to: UInt8.self)
                    buf.advanced(by: totalRead).update(from: src, count: toCopy)
                }
                position += Int64(toCopy)
                totalRead += toCopy

                let consumed = Double(position - currentOffset) / Double(currentBuffer.count)
                let nextPrefetchOffset = currentOffset + Int64(currentBuffer.count)
                let needsPrefetch = prefetchEnabled && consumed > 0.5 && !isPrefetching && prefetchBuffer == nil
                bufferLock.unlock()

                if needsPrefetch {
                    triggerPrefetch(from: nextPrefetchOffset)
                }
            } else {
                bufferLock.lock()
                if let prefetch = prefetchBuffer, position >= prefetchOffset &&
                    position < prefetchOffset + Int64(prefetch.count) {
                    currentBuffer = prefetch
                    currentOffset = prefetchOffset
                    prefetchBuffer = nil
                    bufferLock.unlock()
                    continue
                }
                let hasPrefetchInFlight = isPrefetching
                bufferLock.unlock()

                if hasPrefetchInFlight {
                    _ = prefetchReady.wait(timeout: .now() + .seconds(15))
                    bufferLock.lock()
                    if let prefetch = prefetchBuffer, position >= prefetchOffset &&
                        position < prefetchOffset + Int64(prefetch.count) {
                        currentBuffer = prefetch
                        currentOffset = prefetchOffset
                        prefetchBuffer = nil
                        bufferLock.unlock()
                        continue
                    }
                    bufferLock.unlock()
                }

                let rangeSize = probeRangeGrowth?.size(at: position, remainingInput: probeControl?.remainingInputBytes)
                    ?? chunkSize
                let fetchSize: Int
                if fileSize > 0 {
                    fetchSize = min(rangeSize, Int(fileSize - position))
                } else {
                    fetchSize = rangeSize
                }

                if fetchSize <= 0 { break }

                let fetched = fetchChunk(from: position, size: fetchSize)
                probeRangeGrowth?.record(offset: position, requested: fetchSize, received: fetched?.count ?? 0)
                guard let data = fetched, !data.isEmpty else {
                    // An aborted fetch (supersede/close/deadline) must report a read
                    // error, not EOF (which would truncate the stream cleanly). issue #27.
                    if isClosed || readDeadlinePassedOrAborted {
                        if readDeadlinePassedOrAborted { readDeadlineFired = true }
                        return totalRead > 0 ? Int32(totalRead) : -1
                    }
                    // Audit DMX-10: nil is a transport failure short of a known size, which is the
                    // same loss #25 stopped reporting as EOF on the persistent path; a probe that
                    // read it as end-of-file reported a truncated duration instead of failing.
                    if fetched == nil, fileSize > 0 {
                        return totalRead > 0 ? Int32(totalRead) : FFmpegErr.eio
                    }
                    // Empty = 2xx with no body (would loop forever otherwise).
                    break
                }

                bufferLock.lock()
                currentBuffer = data
                currentOffset = position
                prefetchBuffer = nil
                bufferLock.unlock()
            }
        }

        return totalRead > 0 ? Int32(totalRead) : FFmpegErr.eof
    }

    // MARK: - Streaming Read (sequential GET)

    private func readStreaming(into buf: UnsafeMutablePointer<UInt8>, size: Int32) -> Int32 {
        let requestSize = Int(size)
        var totalRead = 0

        while totalRead < requestSize {
            streamLock.lock()
            let posInBuffer = Int(position - streamBytesRead)
            let available = streamBuffer.count - posInBuffer
            let ended = streamEnded
            streamLock.unlock()

            if available > 0 && posInBuffer >= 0 {
                let toCopy = min(available, requestSize - totalRead)

                streamLock.lock()
                streamBuffer.copyBytes(to: buf.advanced(by: totalRead), from: posInBuffer, count: toCopy)
                streamLock.unlock()

                position += Int64(toCopy)
                totalRead += toCopy

                streamLock.lock()
                let consumed = Int(position - streamBytesRead)
                if consumed > Self.streamTrimThreshold {
                    let trimAmount = consumed - Self.streamTrimThreshold
                    streamBuffer.dropFirst(trimAmount)
                    streamBytesRead += Int64(trimAmount)
                }
                var toResume: URLSessionDataTask?
                if streamingTaskSuspended, streamBuffer.count < streamLowWater {
                    streamingTaskSuspended = false
                    toResume = streamingTask
                }
                streamLock.unlock()
                toResume?.resume()
            } else if ended {
                break
            } else {
                // Resume before waiting: a suspended task would never deliver.
                streamLock.lock()
                var toResume: URLSessionDataTask?
                if streamingTaskSuspended {
                    streamingTaskSuspended = false
                    toResume = streamingTask
                }
                streamLock.unlock()
                toResume?.resume()
                let timeout = streamDataReady.wait(timeout: .now() + .seconds(15))
                if timeout == .timedOut { break }
            }
        }

        if totalRead > 0 { return Int32(totalRead) }
        streamLock.lock()
        let refusedStatus = streamRefusedStatus
        streamLock.unlock()
        if refusedStatus != 0 {
            // The response header arrived after open()'s budget: still a refusal, not end-of-media.
            EngineLog.emit(
                "[AVIOReader] \(label) streaming GET refused status=\(refusedStatus) after open; reporting EIO",
                category: .demux)
            return FFmpegErr.eio
        }
        streamLock.lock()
        let ended = streamEnded
        let failed = streamFailed
        let cause = streamFailureCause
        let received = streamBytesRead + Int64(streamBuffer.count)
        let expected = streamExpectedBytes
        streamLock.unlock()
        // This path cannot be resumed at an offset, so a stalled-out wait, a transport error or a
        // body that ended short of its advisory length is a LOST source: report EIO so the pump
        // exits on a read error the session can surface. EOF here would read as end-of-media,
        // which the consumer deliberately never retries. Audit DMX-6: this held for the
        // sequential origin only, and a length-less source ended its film early on a Wi-Fi drop.
        if !ended || failed || (expected > 0 && received < expected) {
            EngineLog.emit(
                "[AVIOReader] \(label) stream \(!ended ? "stalled out" : failed ? "failed" : "ended short") at "
                + "\(received)\(expected > 0 ? "/\(expected)" : "") bytes"
                + (cause.map { " (\($0))" } ?? "") + "; reporting EIO",
                category: .demux
            )
            return FFmpegErr.eio
        }
        return FFmpegErr.eof
    }

    // MARK: - Persistent Read (single forward-streaming connection)

    /// Sliding-window read over a single long-lived Range: bytes=<offset>- connection.
    /// State machine: inside window -> copy; before window -> backward reconnect;
    /// position >= fileSize -> EOF (only EOF path); far forward -> reconnect;
    /// just ahead + live conn -> wait; conn ended -> reconnect + backoff.
    /// Fetch failures reconnect at the frontier, never collapse to AVERROR_EOF (AetherEngine#25).
    private func readPersistent(into buf: UnsafeMutablePointer<UInt8>, size: Int32) -> Int32 {
        let requestSize = Int(size)
        var totalRead = 0
        sweepIdleDetourBlocks()

        // #93 restart latency: accumulate where THIS read spends its time; one summary line fires
        // on completion when the whole call exceeded the threshold (see SlowReadDiagnostics).
        let readStart = DispatchTime.now()
        var diag = SlowReadDiagnostics()
        // #281 retest: fixed once per read, so a loop that wakes repeatedly cannot keep extending
        // its own patience for the speculative fetch.
        var tailWaitDeadline: Date?
        func msSince(_ t: DispatchTime) -> Double {
            Double(DispatchTime.now().uptimeNanoseconds - t.uptimeNanoseconds) / 1_000_000
        }
        // #93/#96 residual: count the reconnect AND time the synchronous connect path it drives
        // (the old session's invalidateAndCancel + new task setup, all on this demux thread), so a
        // slow read that sinks its time into reconnecting names it as `connect=` instead of `unaccounted=`.
        func timedReconnect(seek: Bool, at offset: Int64) {
            diag.recordReconnect()
            let connectStart = DispatchTime.now()
            if seek { seekReconnect(at: offset) } else { startPersistentConnection(at: offset) }
            diag.recordConnect(ms: msSince(connectStart))
        }
        winCond.lock()
        let diagEntryPosition = position
        let diagGenAtStart = connGeneration
        let diagDropsAtStart = staleGenDroppedBytes
        winCond.unlock()
        var enteredForwardWait = false
        defer {
            winCond.lock()
            forwardWaitActive = false
            if !enteredForwardWait { forwardWaitSince = nil }
            winCond.unlock()
        }
        defer {
            let elapsedMs = msSince(readStart)
            if elapsedMs >= diag.thresholdMs {
                winCond.lock()
                let genAtEnd = connGeneration
                let dropped = staleGenDroppedBytes - diagDropsAtStart
                winCond.unlock()
                diag.recordStaleGenerationDrop(bytes: dropped)
                let budget = OriginRequestBudget.shared.snapshot(for: requestURL()).map {
                    SlowReadDiagnostics.OriginBudgetLine(
                        inflight: $0.inflight, peak: $0.peakInflight,
                        limit: $0.limit, refusals: $0.refusals)
                }
                if let line = diag.line(elapsedMs: elapsedMs, offset: diagEntryPosition,
                                        generationSpan: (diagGenAtStart, genAtEnd),
                                        origin: budget) {
                    EngineLog.emit(line, category: .demux)
                }
            }
        }

        while totalRead < requestSize {
            diag.recordIteration()
            if isClosed { return totalRead > 0 ? Int32(totalRead) : -1 }
            if readDeadlinePassedOrAborted { readDeadlineFired = true; return totalRead > 0 ? Int32(totalRead) : -1 }

            // #93/#96 residual: time the loop-head lock acquisition. A delegate thread holding winCond
            // across its window copy blocks the read HERE with nothing to show for it, so this turns
            // that invisible wait into `lockWait=`.
            let lockWaitStart = DispatchTime.now()
            winCond.lock()
            diag.recordLockWait(ms: msSince(lockWaitStart))
            if rangeAnswersFabricated {
                winCond.unlock()
                return totalRead > 0 ? Int32(totalRead) : FFmpegErr.eio
            }

            // #281: bytes already in hand beat every network path below, so this is checked before
            // any of them, and before the reconnect decision that a dead connection would force.
            // Only when the live window cannot serve the position: a window hit is the cheap path
            // and stays first.
            let spanPos = position
            let windowCanServe = spanPos >= winStart && spanPos < winStart + Int64(window.count)

            // #281 retest: the head has now done the job it was kept past the parse for. This read
            // is not at the head, so playback has either moved beyond it or started nowhere near it,
            // and holding megabytes for a return that is not coming is just footprint.
            //
            // AE#585: unless the host is running its index pass, where neither half of that premise
            // holds. The cue prewarm seeks to the middle for the container's index and the cursor is
            // reset to zero straight after, so a drop here throws the head away one read before
            // playback asks for exactly those bytes.
            if !openPhaseActive, !indexPassActive, !headSpan.isEmpty,
               spanPos < 0 || spanPos >= Int64(headSpan.count) {
                // AE#958: the read that drops the head is usually the one about to reconnect at its
                // end, the first request that can show a fabricated range. Its last bytes stay.
                let n = min(Self.rangeCheckBytes, headSpan.count)
                headSpanCheckTail = ResidentSpan(start: Int64(headSpan.count - n),
                                                 data: Data(headSpan.suffix(n)))
                headSpan = Data()
            }
            if !windowCanServe, !headSpan.isEmpty || tailSpan != nil,
               let served = serveFromResidentSpansLocked(into: buf.advanced(by: totalRead),
                                                        maxLen: requestSize - totalRead,
                                                        at: spanPos) {
                let n = served.bytes
                // Once per span per open: the round trip that did not happen, named. Every serve
                // after the first says nothing new and would only make the log expensive.
                var spanLine: String? = nil
                switch served {
                // Two lines, not one, because they are two different findings: the parse's return to
                // the head was already true in 6.5.2, playback's first read being served is what the
                // head living past `markOpenPhaseFinished` added. One line could not tell a reporter
                // which of the two they were looking at.
                case .head where !openPhaseActive && !headSpanPlaybackServeLogged:
                    headSpanPlaybackServeLogged = true
                    spanLine = "[AVIOReader] \(label) retained file head served playback's first read"
                        + " at \(spanPos); no reconnect for it"
                case .head where !headSpanServeLogged:
                    headSpanServeLogged = true
                    spanLine = "[AVIOReader] \(label) retained file head served the return to \(spanPos)"
                        + "; no reconnect for it"
                case .tail where !tailSpanServeLogged:
                    tailSpanServeLogged = true
                    spanLine = "[AVIOReader] \(label) tail prefetch served the read at \(spanPos)"
                        + "; no reconnect for it"
                default:
                    break
                }
                position = spanPos + Int64(n)
                winCond.broadcast()
                winCond.unlock()
                if let spanLine { EngineLog.emit(spanLine, category: .demux) }
                totalRead += n
                diag.recordDetourServe(ms: 0, fetched: false)
                // No ladder reset, and no phase either (#410): these spans are bytes fetched earlier
                // and kept, and the line above says so itself ("no reconnect for it"). Clearing the
                // streaks here is the #380 window-serve mistake in the branch that runs FIRST, before
                // every network path, and unlike the detour it is not taken out of service on a metered
                // origin, so the parse's return to the head could hold a refusing origin at streak=0.
                // Reporting `.flowing` off the same serve made the host read a delivering source out of
                // read-ahead the origin paid for before it died.
                continue
            }

            // #281 retest: this read wants bytes the speculative fetch is on the wire for RIGHT NOW.
            // Reconnecting here is what made that fetch pure cost in the field: the demuxer arrives
            // microseconds after the data connection's first byte, so the fetch, which pays the same
            // round trip plus a body, has never landed yet. Waiting is bounded by what a round trip
            // against this origin was measured to cost, so it can never be the more expensive choice.
            if !windowCanServe, tailPrefetchInFlight, isInTailPrefetchRangeLocked(spanPos) {
                let deadline = tailWaitDeadline ?? Date(
                    timeIntervalSinceNow: max(0, tailPrefetchWaitBudget()
                        - Double(DispatchTime.now().uptimeNanoseconds
                                 - tailPrefetchStartedAt.uptimeNanoseconds) / 1_000_000_000))
                tailWaitDeadline = deadline
                if Date() < deadline {
                    let waitStart = DispatchTime.now()
                    _ = winCond.wait(until: min(deadline, readDeadline))
                    winCond.unlock()
                    diag.recordTailWait(ms: msSince(waitStart))
                    continue
                }
            }

            // Genuine EOF: the only path that returns AVERROR_EOF, and it is decided BEFORE any
            // reconnect, because a position at or past the last byte has nothing to connect for.
            // It used to sit below the reconnect, so a read at exactly `fileSize` opened
            // `bytes=<fileSize>-` first: an empty 206 whose reconnect reset `winStart` past the
            // end and dropped a window the parse was still reading. Skipped for live, where the
            // length is not authoritative.
            if !isLive, fileSize > 0, position >= fileSize {
                winCond.unlock()
                return totalRead > 0 ? Int32(totalRead) : FFmpegErr.eof
            }

            // #220: `connEndedByBackpressure` is excluded on purpose. This reconnects at the
            // READ position, which resets winStart and drops the window, so a backpressure
            // end would re-fetch up to winHighWater of already-resident bytes on every
            // cycle. That case refills at the frontier once the consumer draws down to low
            // water (or immediately once the window is empty), keeping every delivered byte.
            //
            // `windowCanServe` is excluded for exactly the same reason, and the omission was
            // measurable: a range delivered IN FULL also clears `activeTransfer`, so a consumer
            // slower than the transfer (the parse pass, which reads one 256 KB AVIO buffer at a
            // time) reached this branch with the rest of the range still resident and re-fetched
            // it. Measured against a Range-logging origin, a 764450 B trailing `moov` cost three
            // connections and 1506918 delivered bytes, 1.97x what was read. Serving what is in
            // hand first also lets the #220 frontier refill below run, which it could not while
            // this branch preempted it on every completed range.
            //
            // A connection that ended in ERROR without delivering a single byte of its
            // generation is excluded too: this branch reconnects via seekReconnect, which
            // clears the unproductive streak and applies no backoff, so an origin refusing
            // every request (e.g. a connection-capped panel answering 500) turned into an
            // unbounded reconnect spiral at ~15 connections/s. Falling through reaches the
            // ended-connection ladder below: status accounting, Retry-After, backoff,
            // `.reconnecting`, bounded give-up. Planned ends stay here — a completed range
            // (connEndedAtRangeEnd) and a hard-cap end delivered their bytes, and any
            // generation that delivered at least one byte keeps the fast path.
            let endedInError = connEnded && !connEndedAtRangeEnd && !connEndedByBackpressure
                && !connFirstDataSeen
            if activeTransfer == nil, !connEndedByBackpressure, !windowCanServe, !endedInError {
                let target = position
                winCond.unlock()
                timedReconnect(seek: true, at: target)
                continue
            }

            let curPosition = position
            let repositionedForPlayback = playbackRepositionPending
            if curPosition >= winStart { playbackRepositionPending = false }

            if curPosition < winStart {
                winCond.unlock()
                // AE#782: a producer restart landed here, so this is where playback continues, not a
                // parse read that returns. Bytes already resident still serve first; the first miss
                // anchors the connection here. Detouring cost a jump back three serial 4 MB fetches
                // (~2 s each against a 400 ms origin) before the 8 MB re-anchor below, while the old
                // connection kept streaming ahead of a position nobody would read.
                if repositionedForPlayback, detourEligible {
                    if case .served(let n, _) = serveFromDetour(into: buf.advanced(by: totalRead),
                                                               maxLen: requestSize - totalRead,
                                                               at: curPosition, allowFetch: false) {
                        diag.recordDetourServe(ms: 0, fetched: false)
                        winCond.lock(); position = curPosition + Int64(n); winCond.broadcast(); winCond.unlock()
                        totalRead += n
                        continue
                    }
                    winCond.lock(); playbackRepositionPending = false; winCond.unlock()
                    detourResetRun()
                    sweepIdleDetourBlocks(force: true)
                    timedReconnect(seek: true, at: curPosition)
                    continue
                }
                // Backward random-access read (MP4 parse ping-pong, or a large backward scrub).
                // Serve via the pooled detour cache so the anchored streaming connection is NOT
                // torn down (the reconnect storm + origin 429, AetherEngine#69).
                if detourEligible {
                    // Re-anchor the streaming connection once detour reads have turned sequential
                    // past the threshold (playback resumed here), so steady playback returns to
                    // the cheap window path instead of fetching 4 MB blocks forever.
                    if curPosition == detourRunNextExpected && detourRunBytes >= Self.detourReanchorBytes {
                        detourResetRun()
                        sweepIdleDetourBlocks(force: true)
                        timedReconnect(seek: true, at: curPosition)
                        continue
                    }
                    let detourStart = DispatchTime.now()
                    switch serveFromDetour(into: buf.advanced(by: totalRead),
                                           maxLen: requestSize - totalRead,
                                           at: curPosition, allowFetch: true) {
                    case .served(let n, let fetched):
                        diag.recordDetourServe(ms: msSince(detourStart), fetched: fetched)
                        winCond.lock(); position = curPosition + Int64(n); winCond.broadcast(); winCond.unlock()
                        totalRead += n
                        // Only a serve that crossed the network is progress against the origin. The
                        // resident-block hit is the detour twin of the window serve #380 fixed: it
                        // hands back read-ahead already paid for, so resetting the ladders on it lets
                        // a parser ping-ponging through a cached region hold a refusing origin at
                        // streak=0 for as long as the blocks last.
                        if fetched {
                            unproductiveReconnects = 0
                            rateLimitStreak = 0
                            rateLimitStreakStartedAt = nil
                            emitNetworkPhase(.flowing)   // the fetch crossed the network: the origin is serving (#85/#410)
                        }
                        detourTrackSequential(at: curPosition, length: n)
                        continue
                    case .rateLimited(let retryAfter):
                        // #93/#96: account the (throttled) fetch attempt's time so it leaves `unaccounted`.
                        diag.recordDetourFetchAttempt(ms: msSince(detourStart))
                        // Origin is throttling the detour fetch too (#71). Back off in place and
                        // RETRY the detour fetch; do NOT open a fresh connection (that re-enters
                        // the 429 churn the cache exists to remove). Give up cleanly at the cap.
                        if recordRateLimitAndShouldGiveUp() {
                            EngineLog.emit("[AVIOReader] Detour rate-limit gave up at offset \(curPosition) (\(rateLimitStreak) consecutive rate-limited)", category: .demux)
                            emitNetworkPhase(.exhausted)   // ladder spent on the detour arm too (#410)
                            return totalRead > 0 ? Int32(totalRead) : -1
                        }
                        // #392: the detour fetches through the same pinned target, and this arm
                        // carried no pin rung at all, so a pin whose lease had died could only be
                        // given up on here (a failed read), never re-resolved. It is also the arm a
                        // backward read after a long pause lands on, i.e. exactly when a lease has
                        // died. Same decision as both reconnect ladders, in the same one place.
                        // #410: a metered detour fetch is a source-connection problem by the same
                        // definition as a metered reconnect, and it is the arm that carries a throttling
                        // origin (#69/#71), so leaving it silent hid exactly the case `.stalled` was added
                        // for. The ladder was already charged above; only the axis was missing.
                        emitNetworkPhase(.reconnecting)
                        let repinned = dropPinIfTheRefusalCallsForIt(isRateLimited: true)
                        let backoffStart = DispatchTime.now()
                        backoffBeforeReconnect(streak: repinned ? 0 : rateLimitStreak, retryAfter: retryAfter)
                        diag.recordBackoff(ms: msSince(backoffStart))
                        continue
                    case .miss:
                        // #93/#96: this is where the residual cold read actually lived. A starved fetch
                        // rode its budget then missed; account that time (else it hides in `unaccounted`)
                        // before falling through to the rescue reconnect that serves in ~30-190ms.
                        diag.recordDetourFetchAttempt(ms: msSince(detourStart))
                        if isClosed { return totalRead > 0 ? Int32(totalRead) : -1 }
                        if readDeadlinePassedOrAborted { readDeadlineFired = true; return totalRead > 0 ? Int32(totalRead) : -1 }
                        // Hard transport failure: degrade to the OLD single-reconnect behavior.
                        timedReconnect(seek: true, at: curPosition)
                        continue
                    }
                }
                timedReconnect(seek: true, at: curPosition)
                continue
            }

            let posInWindow = Int(curPosition - winStart)
            let available = window.count - posInWindow
            if available > 0 {
                let copyNow = min(available, requestSize - totalRead)
                window.copyBytes(to: buf.advanced(by: totalRead), from: posInWindow, count: copyNow)
                position = curPosition + Int64(copyNow)
                totalRead += copyNow
                trimWindowLocked()
                // "Real progress" is the CURRENT generation having delivered — draining read-ahead
                // is not. An unguarded reset here ran in the same iteration as the faulted-refill
                // decision below, so a connection-capped origin refusing every replacement was
                // charged streak=1 forever while the runway drained (field trace: a post-pause 509
                // storm held streak=1 across 4 MB of served reads, and the bounded give-up and the
                // re-resolve rung were both unreachable until the window hit empty).
                if connFirstDataSeen {
                    unproductiveReconnects = 0      // real progress
                    rateLimitStreak = 0             // real progress clears the 429 give-up streak (#71)
                    credentialRefusalStreak = 0     // and the credential one (#792)
                    rateLimitStreakStartedAt = nil
                    emitNetworkPhase(.flowing)      // recovered: source delivering again (#85/#410)
                }
                // No flow installed and the consumer has drawn down to low water: request at the
                // frontier. #220/#310 built this for PLANNED ends (a range delivered in full, a
                // high-water end); #309 made it the rule for every reason there is no flow, because
                // the exception was the second half of that report. A generation that ended in
                // FAULT was replaced only once the window hit EMPTY, so the reader spent its whole
                // read-ahead first and playback rejoined the clock with a burst (the field trace's
                // +17 MB interval and 389 dropped frames). Which reason it was still decides the
                // POLICY: a planned end costs nothing, a fault pays the ladder
                // (`chargeFaultedRunwayRefill`).
                //
                // Requesting at the frontier rather than at the read position keeps every delivered
                // byte. A frontier AT the end of the file is not a frontier: the range that ended
                // was the last one, and requesting `bytes=<fileSize>-` asks for nothing: origins
                // answer it with an empty 206, the reconnect resets `winStart` past the last byte,
                // and the window that was about to be read is dropped for it. On a trailing `moov`
                // that turned one connection into three. Live keeps the old behaviour: its length is
                // not authoritative and its end moves.
                var refillFrom: Int64? = nil
                var refillFaulted = false
                var refillStatus = 0
                var refillRetryAfter: TimeInterval = 0
                let undrained = window.count - max(0, Int(position - winStart))
                let frontier = winStart + Int64(window.count)
                if activeTransfer == nil, undrained <= Self.winLowWater,
                   isLive || fileSize <= 0 || frontier < fileSize {
                    if connEndedAtRangeEnd || connEndedByBackpressure {
                        refillFrom = frontier
                    } else if connEnded, Date() >= nextFaultedRefillAt {
                        refillFrom = frontier
                        refillFaulted = true
                        refillStatus = connStatus
                        refillRetryAfter = connRetryAfter
                    }
                }
                winCond.broadcast()
                winCond.unlock()
                if let refillFrom {
                    if !refillFaulted || chargeFaultedRunwayRefill(at: refillFrom, ahead: undrained,
                                                                   status: refillStatus,
                                                                   retryAfter: refillRetryAfter) {
                        timedReconnect(seek: false, at: refillFrom)
                    }
                }
                continue
            }

            let frontier = winStart + Int64(window.count)
            let ended = connEnded
            let endedByBackpressure = connEndedByBackpressure
            let endedByRangeEnd = connEndedAtRangeEnd
            let status = connStatus
            let retryAfter = connRetryAfter

            if curPosition > frontier + Int64(Self.seekKeepForwardLimit) {
                winCond.unlock()
                // Far-forward seek. Serve from the detour cache ONLY if the block is already
                // resident (e.g. the moov region the parser revisits); a genuine forward scrub
                // misses and re-anchors the streaming window there, never chunk-serving forever.
                if detourEligible {
                    switch serveFromDetour(into: buf.advanced(by: totalRead),
                                           maxLen: requestSize - totalRead,
                                           at: curPosition, allowFetch: false) {
                    case .served(let n, _):
                        diag.recordDetourServe(ms: 0, fetched: false)   // resident-only path
                        winCond.lock(); position = curPosition + Int64(n); winCond.broadcast(); winCond.unlock()
                        totalRead += n
                        // No ladder reset and no phase: `allowFetch: false` cannot have crossed the
                        // network, so this serve says nothing about an origin that is refusing
                        // (#380/#410).
                        detourTrackSequential(at: curPosition, length: n)
                        continue
                    case .rateLimited, .miss:
                        break   // allowFetch:false never rate-limits; a miss falls through to reconnect
                    }
                }
                timedReconnect(seek: true, at: curPosition)
                continue
            }

            if !ended {
                // Wait for the live connection to fill forward. A false return
                // means connStallTimeout elapsed with no data (socket stall).
                let waitStart = DispatchTime.now()
                if forwardWaitSince == nil {
                    forwardWaitSince = waitStart
                    forwardWaitOffset = curPosition
                    // No mark from before the starvation began may be judged: one taken ahead of a
                    // full-window park would fold the park's zero delivery into the span.
                    trickleSamples = [(waitStart, genDeliveredBytes)]
                }
                enteredForwardWait = true
                forwardWaitActive = true
                let signaled = winCond.wait(until: min(Date(timeIntervalSinceNow: connStallTimeout), readDeadline))
                winCond.unlock()
                diag.recordStallWait(ms: msSince(waitStart), signaled: signaled)
                // Check deadline before stall handling to avoid misrouting a
                // deadline wake as a socket stall (which would reconnect).
                if isPastReadDeadline { continue }
                if !signaled {
                    if recordReconnectAndShouldGiveUp() {
                        EngineLog.emit("[AVIOReader] \(label) stall gave up at offset \(frontier) (\(unproductiveReconnects) unproductive)\(isLive ? " [live source lost]" : "")", category: .demux)
                        emitNetworkPhase(.exhausted)   // ladder spent; the reopen owns recovery, the source is still down (#410)
                        if isLive {
                            return totalRead > 0 ? Int32(totalRead) : FFmpegErr.eio
                        }
                        return totalRead > 0 ? Int32(totalRead) : -1
                    }
                    EngineLog.emit("[AVIOReader] \(label) stall at offset \(frontier), reconnecting", category: .demux)
                    lastUnplannedReconnectAt = Date()
                    emitNetworkPhase(.reconnecting)   // unplanned reconnect now in flight (#85)
                    let backoffStart = DispatchTime.now()
                    backoffBeforeReconnect(streak: unproductiveReconnects, retryAfter: 0)
                    diag.recordBackoff(ms: msSince(backoffStart))
                    timedReconnect(seek: false, at: frontier)
                }
                continue
            }

            // Connection ended before EOF; reconnect at frontier. Honour Retry-After when rate-limited.
            winCond.unlock()
            // #220/#310: we ended it ourselves at high water and the consumer has now emptied
            // the window (the low-water refill normally fires first; this is the backstop for
            // a position that jumped to the frontier). Re-request immediately: no backoff (the
            // origin never misbehaved), no streak charge (this is not an unproductive
            // reconnect), no `.reconnecting` phase and no `lastUnplannedReconnectAt` (nothing
            // here looks like a transcode respawn to the host). Without this the end would
            // spend the give-up budget on a healthy link.
            if endedByBackpressure {
                EngineLog.emit(
                    "[AVIOReader] \(label) window drained after backpressure end; re-requesting at \(frontier)",
                    category: .demux)
                timedReconnect(seek: false, at: frontier)
                continue
            }
            // #220: the range was delivered in full and the window has now drained, which is
            // the ordinary way a bounded read moves forward. No backoff and no streak charge:
            // nothing failed, and spending the give-up budget on range boundaries would kill
            // the reader on a healthy link.
            if endedByRangeEnd {
                timedReconnect(seek: false, at: frontier)
                continue
            }
            // A 429/503/509 is rate limiting, not a dead source: drive give-up + backoff off the
            // rate-limit streak, which (unlike unproductiveReconnects) survives the seekReconnect
            // that parse seeks fire, so a throttled origin fails cleanly instead of looping (#71).
            let isRateLimited = Self.isRateLimitStatus(status)
            let isCredentialRefusal = Self.isCredentialRefusalStatus(status)
            let giveUp = isRateLimited ? recordRateLimitAndShouldGiveUp()
                : isCredentialRefusal ? recordCredentialRefusalAndShouldGiveUp()
                : recordReconnectAndShouldGiveUp(status: status)
            if giveUp {
                let streakDesc = isRateLimited ? "\(rateLimitStreak) consecutive rate-limited"
                    : isCredentialRefusal ? "\(credentialRefusalStreak) consecutive credential refusals"
                    : "\(unproductiveReconnects) unproductive"
                EngineLog.emit("[AVIOReader] \(label) reconnect exhausted at offset \(frontier) status=\(status) (\(streakDesc))\(isLive ? " [live source lost]" : "")", category: .demux)
                emitNetworkPhase(.exhausted)   // ladder spent; the reopen owns recovery, the source is still down (#410)
                if isLive {
                    return totalRead > 0 ? Int32(totalRead) : FFmpegErr.eio
                }
                return totalRead > 0 ? Int32(totalRead) : -1
            }
            let backoffStreak = isRateLimited ? rateLimitStreak
                : isCredentialRefusal ? credentialRefusalStreak : unproductiveReconnects
            EngineLog.emit("[AVIOReader] \(label) conn ended at offset \(frontier) status=\(status), reconnecting (streak=\(backoffStreak) retryAfter=\(retryAfter)s)", category: .demux)
            lastUnplannedReconnectAt = Date()
            emitNetworkPhase(.reconnecting)   // unplanned reconnect now in flight (#85)
            // A credential refusal already dropped the pin where the status was read (an expired
            // signed redirect target answers 401/403 too), and its streak is not the unproductive one.
            let repinned = isCredentialRefusal ? false : dropPinIfTheRefusalCallsForIt(isRateLimited: isRateLimited)
            let backoffStart = DispatchTime.now()
            // #392: a pin dropped for idleness sends this attempt to the SOURCE, which has refused
            // nothing, so the exponential pacing charged against the target that did refuse is not
            // its debt. A server-sent Retry-After still applies: that is the origin's own ask, and
            // the source belongs to the same origin.
            backoffBeforeReconnect(streak: repinned ? 0 : backoffStreak, retryAfter: retryAfter,
                                   isRateLimited: isRateLimited)
            diag.recordBackoff(ms: msSince(backoffStart))
            timedReconnect(seek: false, at: frontier)
        }

        return Int32(totalRead)
    }

    /// Drop consumed bytes in ~winTrimBatch steps to avoid O(n^2) memmove.
    /// MUST use `subdata` (not `removeFirst`): removeFirst only advances the slice's
    /// lower bound but backing storage grows with count.setter in appendPersistentData,
    /// leaking ~14 MB/s on 80 Mbps remux (AetherEngine#31). subdata re-bases to compact
    /// storage. Caller holds `winCond`.
    private func trimWindowLocked() {
        let behind = Int(position - winStart)
        let dropThreshold = Self.winLookback + Self.winTrimBatch
        if behind > dropThreshold {
            let drop = behind - Self.winLookback
            window.dropFirst(drop)
            winStart += Int64(drop)
        }
    }

    /// Intentional reconnect for a seek; clears the unproductive streak.
    private func seekReconnect(at offset: Int64) {
        unproductiveReconnects = 0
        bytesAtLastReconnect = cumulativeBytesFetched
        // A reposition starts a new lineage: the faulted-refill pacing belongs to the frontier
        // it was charged at, and holding a seek's refill to it would pace a healthy target.
        winCond.lock()
        nextFaultedRefillAt = .distantPast
        winCond.unlock()
        startPersistentConnection(at: offset)
    }

    /// Increments the unproductive-reconnect streak (resets if progress exceeded
    /// `minReconnectProgress`). Returns true when the cap is hit. Demux-thread-only.
    private func recordReconnectAndShouldGiveUp(status: Int = 0) -> Bool {
        let now = cumulativeBytesFetched
        if now - bytesAtLastReconnect >= Self.minReconnectProgress {
            unproductiveReconnects = 0
        } else {
            unproductiveReconnects += 1
        }
        bytesAtLastReconnect = now
        // Hard 4xx/5xx (not the rate-limit statuses, which are metering) on a source that
        // has never delivered a byte = server-side failure (e.g. Jellyfin 500 after
        // transcode-failure latency ~15-20s/attempt). One retry, then out.
        let isHardError = status >= 400 && !Self.isRateLimitStatus(status)
        if now == 0 && isHardError {
            return unproductiveReconnects > 1
        }
        // Dead-on-arrival sources (never produced data) get a reduced budget;
        // sources that ever produced data keep the full budget for mid-stream resilience.
        let cap = now == 0
            ? Self.reconnectMaxUnproductiveNeverProductive
            : Self.reconnectMaxUnproductive
        return unproductiveReconnects > cap
    }

    // 4 attempts ride out a transient transcode spin-up (~10-15s with backoff)
    // without grinding a dead tuner for minutes.
    private static let reconnectMaxUnproductiveNeverProductive = 4

    /// The pin rungs of every path that takes a refusal, in one place. Returns true when the pin was
    /// dropped because it had gone IDLE, which callers use to skip their own backoff: the attempt
    /// that follows goes to the source, an address that has refused nothing.
    ///
    /// Two consecutive zero-progress failures through the pinned URL point at the pin itself (an
    /// expired redirect target answers every offset alike), not at a transient: drop it so the retry
    /// re-resolves through the source URL for a fresh redirect. No-op when nothing is pinned.
    ///
    /// A rate-limit streak keeps the pin for `rateLimitRepinStreak` attempts: 429/503/509 says the
    /// origin is metering us, not that the target is dead (#71), and re-resolving spends a second
    /// request on the very origin that is refusing them. On the connection-capped panel behind #307
    /// that is the request that cannot be spared, and its lingering-slot 509 clears within an attempt
    /// or two. But a streak that OUTLIVES that grace is the other 509 shape: a pinned edge target
    /// whose session died during a long pause answers 509 forever, while a fresh redirect through the
    /// source connects on the first try (field trace: 20 generations of 509 against the pin across
    /// ~85 s, then a source-resolved reader delivered in 452 ms). Past the grace the pin IS the
    /// problem; drop it once and let the 200/206 re-pin.
    ///
    /// #392: the grace answers that ONE shape, and the shape is defined by a byte of ours having
    /// just been in flight. Past `pinIdleSeconds` with nothing delivered there is no slot of ours
    /// left to linger (the pump ends its connection at the window high water, so an idle reader
    /// holds nothing at the origin, #310), so what is refusing is the stale lease and the grace only
    /// delays finding out: three paced attempts against an address that will refuse all of them,
    /// 12.5 s in the 6.30.0 retest of #380. There the first refusal is taken at face value.
    ///
    /// The lingering slot also needs a connection WE ended (range end, high water, a seek). When
    /// the origin or the network cut the last delivering connection mid-range instead, the refusals
    /// that follow are the edge revoking the pinned session, not our socket still counted: StreamX
    /// on 7.50.0, a CDN cut at 16 of 32 MB, three 509s against the pin across 9 s, then a fresh
    /// redirect through the source got its 206 on the first try, and the 12 s stall was the grace.
    /// There too the first refusal is taken at face value.
    ///
    /// Demux-thread-only: it reads the ladder streaks.
    @discardableResult
    private func dropPinIfTheRefusalCallsForIt(isRateLimited: Bool) -> Bool {
        guard isRateLimited else {
            if unproductiveReconnects >= 2 {
                invalidateResolvedURL(reason: "unproductive reconnect streak")
            }
            return false
        }
        let idle = secondsSinceNetworkDelivery()
        // The pin check is what makes the return value mean "the next attempt is going somewhere
        // else". An origin with nothing pinned refuses from the only address there is, and skipping
        // its backoff would just retry a refusing target faster.
        if idle >= pinIdleSeconds, cachedResolvedURL() != nil {
            invalidateResolvedURL(reason: "rate-limited after \(Int(idle))s idle through pinned URL")
            return true
        }
        // One re-resolve per cut: taking the flag means a re-pinned target that refuses before
        // its first byte is back on the grace instead of re-resolving on every refusal.
        winCond.lock()
        let cut = lastDeliveringConnCut
        lastDeliveringConnCut = false
        winCond.unlock()
        if cut, cachedResolvedURL() != nil {
            invalidateResolvedURL(reason: "rate-limited after the pinned connection was cut mid-range")
            return true
        }
        if rateLimitStreak >= Self.rateLimitRepinStreak {
            invalidateResolvedURL(reason: "rate-limited x\(rateLimitStreak) through pinned URL")
        }
        return false
    }

    /// Exponential backoff (0.5s..8s) growing with streak; immediate on streak=0. How long the
    /// ladder waits before its next attempt. Shared by the blocking backoff below and the
    /// non-blocking one in `chargeFaultedRunwayRefill`, so both pace an origin identically.
    private func backoffDelay(streak: Int, retryAfter: TimeInterval, isRateLimited: Bool = false) -> TimeInterval {
        if isLive, isRateLimited {
            return Self.liveRefusalWait(retryAfter: retryAfter) * backoffScale
        }
        let expo = streak <= 0 ? 0.0 : min(Double(1 << min(streak, 4)) * 0.5, 8.0)
        return min(max(expo, retryAfter), 15.0) * backoffScale
    }

    /// #309: account for replacing a FAULTED connection from the serve path, i.e. while the window
    /// still holds read-ahead. Returns true when the caller should open the replacement.
    ///
    /// This is the same ladder the empty-window path runs (status accounting, pin invalidation,
    /// bounded give-up), because a free reconnect off the books is exactly what #307 paid for. Two
    /// deliberate differences:
    ///
    /// - It does not SLEEP. It runs on the demux thread with megabytes still resident, and a backoff
    ///   sleep there would starve the demuxer of the very read-ahead that replacing early exists to
    ///   protect. The wait is a next-attempt timestamp instead, so reads keep being served at full
    ///   speed between attempts. The timestamp outlives the reconnect it authorises
    ///   (`startPersistentConnection` must not clear it) — it is released by first data or a seek.
    /// - It never returns the read as failed. A window that can still serve must not kill a session
    ///   that still holds seconds of playback. At the cap it stops attempting (`.distantFuture`) and
    ///   leaves termination to the empty-window ladder, where it has always lived.
    ///
    /// It also emits no `.reconnecting` phase: playback is uninterrupted here, and a phase that
    /// flapped between `.flowing` and `.reconnecting` on every read would describe the reader's
    /// bookkeeping rather than what the viewer sees. The empty-window path still emits it, which is
    /// when playback genuinely starves. Demux-thread-only.
    private func chargeFaultedRunwayRefill(at frontier: Int64, ahead: Int,
                                           status: Int, retryAfter: TimeInterval) -> Bool {
        let isRateLimited = Self.isRateLimitStatus(status)
        let isCredentialRefusal = Self.isCredentialRefusalStatus(status)
        let giveUp = isRateLimited ? recordRateLimitAndShouldGiveUp()
            : isCredentialRefusal ? recordCredentialRefusalAndShouldGiveUp()
            : recordReconnectAndShouldGiveUp(status: status)
        if giveUp {
            winCond.lock()
            nextFaultedRefillAt = .distantFuture
            winCond.unlock()
            EngineLog.emit(
                "[AVIOReader] \(label) faulted refill exhausted at offset \(frontier) status=\(status);"
                + " serving the remaining \(ahead / 1024)KB, then the read will fail",
                category: .demux)
            return false
        }
        let streak = isRateLimited ? rateLimitStreak
            : isCredentialRefusal ? credentialRefusalStreak : unproductiveReconnects
        let repinned = isCredentialRefusal ? false : dropPinIfTheRefusalCallsForIt(isRateLimited: isRateLimited)
        lastUnplannedReconnectAt = Date()
        let delay = backoffDelay(streak: repinned ? 0 : streak, retryAfter: retryAfter,
                                 isRateLimited: isRateLimited)
        winCond.lock()
        nextFaultedRefillAt = Date().addingTimeInterval(delay)
        winCond.unlock()
        EngineLog.emit(
            "[AVIOReader] \(label) replacing a faulted connection at offset \(frontier) with"
            + " \(ahead / 1024)KB of read-ahead left (streak=\(streak) status=\(status),"
            + " next attempt in \(String(format: "%.1f", delay))s)",
            category: .demux)
        return true
    }

    /// Blocking form of the wait above: sleeps in 0.1s slices so a close is honoured promptly.
    private func backoffBeforeReconnect(streak: Int, retryAfter: TimeInterval, isRateLimited: Bool = false) {
        let total = backoffDelay(streak: streak, retryAfter: retryAfter, isRateLimited: isRateLimited)
        if total <= 0 { return }
        var slept = 0.0
        while slept < total {
            if isClosed { return }
            let slice = min(0.1, total - slept)
            Thread.sleep(forTimeInterval: slice)
            slept += slice
        }
    }

    /// Increments the consecutive rate-limited streak; returns true once the bounded cap is hit.
    /// Demux-thread-only. Deliberately NOT reset by `seekReconnect` (parse seeks must not mask a
    /// throttled origin into an endless reconnect loop, #71); only real read progress clears it.
    /// Internal (not private) so the bounded give-up is unit-tested without a live origin.
    func recordRateLimitAndShouldGiveUp() -> Bool {
        rateLimitStreak += 1
        if isLive {
            // A live stream is given a while, not a count: at one attempt a second the count would
            // be spent in six seconds, inside the refusal this cadence exists to ride out.
            let now = DispatchTime.now()
            let started = rateLimitStreakStartedAt ?? now
            rateLimitStreakStartedAt = started
            let budget = liveRefusalRetryBudgetSeconds
            let elapsed = Double(now.uptimeNanoseconds &- started.uptimeNanoseconds) / 1_000_000_000
            return elapsed > budget
        }
        return rateLimitStreak > Self.rateLimitMaxStreak
    }

    /// AE#792: charges one 401/403 end; true once `credentialRefusalMaxStreak` attempts on one
    /// credential were refused. A host that replaced the headers since the last refusal starts a
    /// fresh streak, so a renewal arriving mid-ladder is always tried. Demux-thread-only.
    func recordCredentialRefusalAndShouldGiveUp() -> Bool {
        let revision = requestHeaderStore?.revision
        if revision != credentialStreakRevision {
            credentialRefusalStreak = 0
            credentialStreakRevision = revision
        }
        credentialRefusalStreak += 1
        return credentialRefusalStreak > Self.credentialRefusalMaxStreak
    }

    /// Two retries after the first refusal: the first goes out right after the pin was dropped, so
    /// an expired signed redirect is re-resolved through the source, and the second gives a host
    /// that renews on `sourceAuthorizationRefused` a moment to do so. About 3 s with the backoff,
    /// against roughly 80 s on the unproductive ladder.
    static let credentialRefusalMaxStreak = 2

    // MARK: - Detour Block Cache (AetherEngine#69)

    /// `fetched` says whether the served bytes crossed the network. The callers charge the
    /// reconnect ladders on it: a resident-block hit is a memcpy out of read-ahead already paid
    /// for, so it is no more "progress" against a refusing origin than a window serve is (#380).
    private enum DetourServe { case served(Int, fetched: Bool); case rateLimited(TimeInterval); case miss }
    private enum DetourFetch { case ok(Data); case rateLimited(TimeInterval); case failed }

    /// Serve `[offset, offset+maxLen)` (clamped to one 4 MB block) from the detour cache,
    /// fetching the block over the pooled keep-alive chunkSession on a miss when `allowFetch`.
    /// Demux-thread call; may block on the network via `detourFetchBlock` (no lock held across it).
    /// Returns `.miss` (never `.served(0)`) so callers fall back to a single reconnect.
    private func serveFromDetour(into dst: UnsafeMutablePointer<UInt8>, maxLen: Int,
                                 at offset: Int64, allowFetch: Bool) -> DetourServe {
        guard fileSize > 0, offset < fileSize, maxLen > 0 else { return .miss }

        // Resident-block hit: pure copy, no network.
        if let n = detourCache.serveCached(into: dst, maxLen: maxLen, at: offset) {
            return .served(n, fetched: false)
        }
        // A bounded position search may probe several distant offsets. Waiting for a whole
        // speculative 4 MB block at each offset can spend the seek's entire deadline before
        // the existing streaming reconnect gets a chance to deliver the requested bytes.
        // Keep resident hits above, but let a bounded miss re-anchor immediately. Ordinary
        // parse-time ping-pong still fills the detour cache and preserves its connection.
        guard allowFetch, readDeadline == .distantFuture else { return .miss }

        let blockStart = (offset / Int64(Self.detourBlockSize)) * Int64(Self.detourBlockSize)
        let blockLen = Int(min(Int64(Self.detourBlockSize), fileSize - blockStart))
        let block: Data
        switch detourFetchBlock(from: blockStart, size: blockLen) {
        case .ok(let fetched):
            // Cache only FULL-length blocks. A truncated 206 cached verbatim would shadow the
            // re-fetch path for its uncovered tail, so the parser ping-ponging into that tail
            // would cost one reconnect per read, reintroducing a mild storm (#69 review). Serve
            // the short body once; the next read of this block re-fetches.
            if fetched.count == blockLen, !isFullyClosed {
                detourCache.insert(blockStart / Int64(Self.detourBlockSize), fetched)
                #if DEBUG
                EngineLog.emit("[AVIOReader] detour fill block=\(blockStart / Int64(Self.detourBlockSize)) offset=\(blockStart) size=\(fetched.count) (resident=\(detourCache.residentCount) cap=\(detourCache.capacity))", category: .demux)
                #endif
            }
            block = fetched
        case .rateLimited(let retryAfter):
            return .rateLimited(retryAfter)
        case .failed:
            return .miss
        }

        let inBlock = Int(offset - blockStart)
        guard inBlock >= 0, inBlock < block.count else { return .miss }
        let n = min(maxLen, block.count - inBlock)
        block.withUnsafeBytes { raw in
            if let base = raw.baseAddress {
                dst.update(from: base.advanced(by: inBlock).assumingMemoryBound(to: UInt8.self), count: n)
            }
        }
        return .served(n, fetched: true)
    }

    /// Single Range fetch for a detour block over the pooled chunkSession. Surfaces rate limiting with
    /// its Retry-After so the caller can back off in place rather than churn the connection (#71).
    ///
    /// The origin ticket is `syncRequest`'s, and only that one (audit DMX-105): a second acquire here
    /// took the last slot of a two-request origin and left the inner one waiting its whole budget for
    /// a slot this same fetch was holding, +4 s per block, with a third request on the books.
    private func detourFetchBlock(from offset: Int64, size: Int) -> DetourFetch {
        let budget = Self.effectiveDetourBudget(chunkRequestTimeout: chunkRequestTimeout, cap: detourFetchBudget)
        let rangeEnd = offset + Int64(size) - 1
        var request = URLRequest(engineURL: requestURL())
        request.setValue("bytes=\(offset)-\(rangeEnd)", forHTTPHeaderField: "Range")
        // #93/#96: a starved backward-scrub detour fetch must abort fast (the rescue reconnect serves
        // instantly), so this path uses the tight interactive budget, not the full chunk timeout.
        request.timeoutInterval = budget
        applyExtraHeaders(&request)
        do {
            let (data, response) = try syncRequest(
                request, budget: budget, slotLabel: "detour",
                slotWait: min(budget, Self.shortFetchSlotWaitSeconds))
            if let http = response as? HTTPURLResponse {
                let status = http.statusCode
                // Already charged to the origin by `syncRequest`, before it returned the slot.
                if Self.isRateLimitStatus(status) {
                    return .rateLimited(Self.parseRetryAfter(http))
                }
                if status != 200 && status != 206 {
                    if Self.isResolvedExpiryStatus(status) { invalidateResolvedURL() }
                    return .failed
                }
                // VOD: 200 at offset > 0 = server ignored Range; silent corruption. Reject.
                if status == 200 && offset > 0 && !isLive {
                    EngineLog.emit("[AVIOReader] detour: server ignored Range (200 for offset \(offset)); rejecting", category: .demux, level: .verbose)
                    return .failed
                }
                if !isLive, let served = Self.misplacedRangeStart(http, requestedOffset: offset) {
                    EngineLog.emit("[AVIOReader] detour: 206 starts at \(served), not \(offset); rejecting (audit DMX-5)", category: .demux)
                    return .failed
                }
            }
            addBytesFetched(data.count)
            return .ok(data)
        } catch {
            return .failed
        }
    }

    /// Audit PERF-108: release detour blocks nothing has touched for `detourBlockIdleSeconds`, at most
    /// once a second from the read path and unconditionally when playback re-anchors, which is the
    /// moment a scrub's blocks stop being anyone's working set. Demux-thread-only.
    private func sweepIdleDetourBlocks(force: Bool = false) {
        let now = DispatchTime.now().uptimeNanoseconds
        guard force || now &- lastDetourIdleSweepNs >= 1_000_000_000 else { return }
        lastDetourIdleSweepNs = now
        let evicted = detourCache.evictIdle(olderThan: detourBlockIdleSeconds)
        if evicted > 0 {
            EngineLog.emit(
                "[AVIOReader] \(label) released \(evicted) idle detour block(s) "
                + "(\(detourCache.residentCount) resident)", category: .demux, level: .verbose)
        }
    }

    /// Tracks contiguity of detour reads for the re-anchor heuristic. Shared by BOTH the backward
    /// and far-forward branches; the re-anchor check itself lives only in the backward branch on
    /// purpose, so a forward-accumulated run later met by a contiguous backward read is an intended
    /// re-anchor, not an accident. A non-contiguous read restarts the run. Demux-thread-only.
    private func detourTrackSequential(at offset: Int64, length: Int) {
        if offset == detourRunNextExpected {
            detourRunBytes += Int64(length)
        } else {
            detourRunBytes = Int64(length)
        }
        detourRunNextExpected = offset + Int64(length)
    }

    private func detourResetRun() {
        detourRunNextExpected = -1
        detourRunBytes = 0
    }

    // MARK: - Cold-start spans (#281)

    /// #551: take whatever a host warmed for this source and install it as this open's resident
    /// bytes.
    ///
    /// Head, tail and size travel together because the open needs all three to stay off the
    /// network: the spans answer the parse reads, and the size is what keeps `resolveOptimisticOpen`
    /// from falling back to the probe ladder, which would spend the round trip the warm just saved.
    ///
    /// A take, not a copy. The bytes are this reader's from here on, and leaving a second copy in
    /// the store would hold megabytes for a source that is now playing.
    private func adoptPrewarmedSource() -> PrewarmedSource? {
        guard !isLive else { return nil }
        guard let warm = SourcePrewarmStore.shared.take(for: url) else { return nil }
        // The head is the one span an open cannot do without, and it is only usable where it says
        // it starts: at zero, which is where the parse begins.
        guard warm.head.start == 0, !warm.head.isEmpty, warm.contentLength > 0 else { return nil }
        // The URL is only half the request. An origin that varies on Referer, User-Agent or
        // Authorization answers a different body, and a different size, under the same URL, and
        // nothing about the bytes themselves would show it. A session whose headers differ from the
        // warm's opens cold instead.
        guard warm.requestHeaders == extraHeaders else {
            EngineLog.emit(
                "[AVIOReader] \(label) a warm exists for this URL but was fetched with different "
                + "headers; opening cold (#551)", category: .demux)
            return nil
        }
        winCond.lock()
        headSpan = warm.head.data
        if let tail = warm.tail { tailSpan = tail }
        fileSize = warm.contentLength
        adoptedWarmSize = warm.contentLength
        if openContentType == nil { openContentType = warm.contentType }
        winCond.unlock()
        SourceContentLengthCache.store(warm.contentLength, for: url)
        // The warm followed the redirect chain and knows where it ended. Pinning that target here
        // is what keeps this session from resolving it a second time: a resolver 302 measured
        // 800 ms on the AE#551 round 2 harness and 3.2 s on the reporter's panel, and it was paid
        // per fresh connection, not once. This is the same pin a redirect records (#12), so the
        // expiry ladder above handles a lease that has run out in the usual way: drop it and
        // re-resolve through the source URL. Credential headers do not follow it (`headers(for:)`).
        recordResolvedURL(warm.resolvedURL)
        EngineLog.emit(
            "[AVIOReader] \(label) adopted a prewarmed source: head=\(warm.head.data.count)B "
            + "tail=\(warm.tail?.data.count ?? 0)B of \(warm.contentLength)B; "
            + "the data connection starts at \(warm.head.end) (#551)",
            category: .demux)
        return warm
    }

    /// Fire-and-forget suffix fetch for the last `tailPrefetchBytes` of the source, running
    /// alongside the open connection.
    ///
    /// `bytes=-n` is the one range form that needs no size, which is the whole point: at this
    /// moment the reader has not seen a single response header, so an explicit `bytes=a-b` is not
    /// yet expressible. VOD only: a live feed's tail is meaningless and its length non-authoritative.
    ///
    /// A read that lands in this range WAITS for the fetch (`awaitTailPrefetchLocked`) instead of
    /// connecting past it. The first cut of this let nothing wait, on the reasoning that a late
    /// fetch costs no more than the reconnect it failed to save. That reasoning was wrong about the
    /// timing, and the #281 retest measured it: the demuxer reaches the tail within microseconds of
    /// the data connection's first byte, and the speculative fetch pays the SAME round trip plus a
    /// body, so it is ALWAYS still in flight at that moment on any origin whose first byte costs
    /// anything. It never once served the read it exists for; it only added a request. Only a
    /// loopback origin, which answers before the race can be lost, made it look like it worked.
    private func startTailPrefetch() {
        guard !isLive, !isClosed else { return }
        let url = requestURL()
        // #377: a speculative second request is the first thing to drop on an origin that allows
        // one at a time. It races the data connection's first byte even on a healthy origin (see
        // above), so on a metered one it is a request spent to lose that race AND to occupy the
        // slot the pump needs.
        if originRequiresSerialRequests {
            EngineLog.emit(
                "[AVIOReader] \(label) tail prefetch skipped: this origin is down to one request "
                + "at a time (#377)", category: .demux)
            return
        }
        // An origin that already answered this form with something else will answer it that way
        // again. Said out loud rather than skipped silently: "no issued line" and "issued, declined"
        // are different findings, and a reporter reading this log can only report what it prints.
        if let reason = SuffixRangeSupport.shared.denialReason(for: url) {
            EngineLog.emit(
                "[AVIOReader] \(label) tail prefetch skipped: this origin declined suffix ranges "
                + "earlier this session (\(reason))", category: .demux)
            return
        }
        var request = URLRequest(engineURL: url)
        request.setValue("bytes=-\(Self.tailPrefetchBytes)", forHTTPHeaderField: "Range")
        request.timeoutInterval = Self.effectiveDetourBudget(chunkRequestTimeout: chunkRequestTimeout, cap: detourFetchBudget)
        applyExtraHeaders(&request)

        // A delegate rather than a completion handler, and the distinction is load-bearing: a
        // completion handler only fires once the body is in hand, so an origin that does not
        // implement suffix ranges and answers 200 with the WHOLE file would be downloaded in full
        // before this code could look at the status. On a 4 GB source that is the entire file
        // fetched speculatively. The delegate decides at the response header and hangs up there
        // (the same shape ProbeDelegate uses, and the same failure #255 paid for once already).
        // #377: measured against a metered origin, this was the request that got the pump refused.
        // It goes out microseconds before the first data connection, so the origin sees two at once
        // on the very first open, which is the "429 before any real number of requests" in the
        // report. It is speculative and nobody waits on it, so it takes a slot only if one is free.
        guard let tailTicket = OriginRequestBudget.shared.tryAcquire(
            for: url, label: "\(label) tail prefetch") else {
            EngineLog.emit(
                "[AVIOReader] \(label) tail prefetch skipped: no origin request slot free (#377)",
                category: .demux)
            return
        }

        let delegate = TailPrefetchDelegate(
            expectedLength: Self.tailPrefetchBytes,
            diagnosticContext: diagnosticContext,
            extraHeaders: headers(for: request.url)
        )
        // #281 retest: one line per open, and the line the field needs. The advertised way to check
        // this fix was "does a bytes=-65536 request show up", which the engine never printed, so a
        // reporter reading the log could only report its absence. Names the outcome, not the intent.
        delegate.onOutcome = { [weak self] outcome in
            // Fires exactly once, whatever happened, which makes it the one release point.
            OriginRequestBudget.shared.release(tailTicket)
            guard let self else { return }
            let elapsedMs = Double(DispatchTime.now().uptimeNanoseconds
                                   - self.tailPrefetchStartedAt.uptimeNanoseconds) / 1_000_000
            self.winCond.lock()
            self.tailPrefetchInFlight = false
            var installed = false
            if case .span(let start, let data) = outcome, !self.isFullyClosed, self.tailSpan == nil {
                self.tailSpan = ResidentSpan(start: start, data: data)
                installed = true
            }
            self.winCond.broadcast()
            self.winCond.unlock()
            if case .span(let start, let data) = outcome {
                SuffixRangeSupport.shared.noteServed(url)
                self.addBytesFetched(data.count)
                EngineLog.emit(
                    "[AVIOReader] \(self.label) tail prefetch \(installed ? "installed" : "dropped") "
                    + "\(data.count)B at \(start) after \(Int(elapsedMs))ms",
                    category: .demux)
            } else if case .rejected(let reason, let verdict) = outcome {
                var learned = false
                switch verdict {
                case .declinedByOrigin:
                    SuffixRangeSupport.shared.noteDeclined(url, reason: reason)
                    learned = true
                case .transportFailure:
                    learned = SuffixRangeSupport.shared.noteTransportFailure(url, reason: reason)
                case .unrelated:
                    // A 403 during a connection-cap window, a 429, a 5xx: the origin has said
                    // nothing about suffix ranges, and the very next open may be served. Not a
                    // transport strike either — two opens inside one short outage would otherwise
                    // still latch for the rest of the process.
                    break
                }
                EngineLog.emit(
                    "[AVIOReader] \(self.label) tail prefetch rejected after \(Int(elapsedMs))ms: \(reason)"
                    + (learned ? "; not asking this origin again this session" : ""),
                    category: .demux)
            }
        }
        let task = Self.chunkSession.dataTask(with: request)
        task.delegate = delegate
        winCond.lock()
        tailPrefetchTask = task
        tailPrefetchInFlight = true
        tailPrefetchStartedAt = DispatchTime.now()
        winCond.unlock()
        task.resume()
        // Issue AND outcome, because "no outcome line" and "never issued" are different findings and
        // one line cannot carry both. A fetch that hangs to teardown prints this one and no other.
        EngineLog.emit("[AVIOReader] \(label) tail prefetch issued bytes=-\(Self.tailPrefetchBytes)",
                       category: .demux)
    }

    /// Whether `offset` lies in the range the speculative fetch asked for. Caller holds `winCond`.
    private func isInTailPrefetchRangeLocked(_ offset: Int64) -> Bool {
        guard fileSize > 0 else { return false }
        return offset >= fileSize - Int64(Self.tailPrefetchBytes) && offset < fileSize
    }

    /// How long a read may wait for the speculative fetch before giving up and reconnecting.
    ///
    /// Both requests left at the same instant against the same origin, so the fetch's first byte
    /// costs what the data connection's did: once it has been outstanding for materially longer
    /// than that, it is not about to land and a fresh connection is the better bet. Waiting up to
    /// that point can never cost more than the reconnect it replaces, which is what makes this
    /// bound the honest one rather than a tuned constant. The floor covers an origin that answered
    /// the first connection out of a warm cache; the cap keeps a hung fetch from owning the open.
    /// Caller holds `winCond`.
    private func tailPrefetchWaitBudget() -> TimeInterval {
        tailPrefetchWaitBudgetForTesting ?? Self.tailPrefetchWaitBudget(firstDataMs: lastFirstDataMs)
    }

    /// The bound itself, free of the reader's state so it can be checked without a socket.
    nonisolated static func tailPrefetchWaitBudget(firstDataMs: Double) -> TimeInterval {
        min(5.0, max(0.25, (firstDataMs / 1000) * 2))
    }

    /// Which non-206 answers to `bytes=-n` are the origin's verdict on the suffix-range FORM, and so
    /// worth remembering for the session: a 200 that ignored it (and would have sent the whole
    /// file), a 416 that rejected it. A 401/403/404/410 is the origin's verdict on the resource, a
    /// 429/503/509 on the moment, a 5xx a fault: those repeat only while their condition does, and
    /// latching on one of them silently disabled the prefetch for the origin for the process
    /// lifetime after a single refusal.
    static func suffixRangeStatusDeclinesTheForm(_ status: Int) -> Bool {
        return status == 200 || status == 416
    }

    /// Start offset of the bytes a 206 actually carries, from `Content-Range: bytes a-b/total`.
    /// Returns nil unless the header agrees with what arrived, so a proxy that answered a suffix
    /// request with some other region cannot install bytes at the wrong offset.
    ///
    /// Audit DMX-8: a suffix is the END of the source, so the span has to end on the byte before a
    /// numeric total. Without that, `bytes <2^63-65536>-<Int64.max>/*` installed a span whose `end`
    /// overflows on the first read that reaches it.
    static func suffixRangeStart(_ http: HTTPURLResponse, expectedLength: Int) -> Int64? {
        guard let value = http.value(forHTTPHeaderField: "Content-Range") else { return nil }
        let scanner = value.replacingOccurrences(of: "bytes ", with: "")
        let parts = scanner.split(separator: "/", maxSplits: 1)
        guard parts.count == 2,
              let total = Int64(parts[1].trimmingCharacters(in: .whitespaces)) else { return nil }
        let bounds = parts[0].split(separator: "-", maxSplits: 1)
        guard bounds.count == 2,
              let start = Int64(bounds[0].trimmingCharacters(in: .whitespaces)),
              let end = Int64(bounds[1].trimmingCharacters(in: .whitespaces)),
              start >= 0, end >= start, end == total - 1,
              end - start + 1 == Int64(expectedLength) else { return nil }
        return start
    }

    /// The demuxer is done parsing; a far seek from here on is playback. Stops COLLECTING into the
    /// head, but deliberately does not release it here.
    ///
    /// #281 retest: releasing it here was one read too early. The read that follows this call is
    /// playback's FIRST, and after a trailing-index parse the anchored connection sits at the END of
    /// the file, so that read is a backward one that lands at the head on every layout measured (48
    /// here, 5752 in the field trace). Dropping the head on the last parse read handed straight back
    /// the round trip the head exists to remove, and no `probe`-based measurement could see it,
    /// because `probe` exits at exactly this line. The head is released instead by the first
    /// post-open read it cannot answer, which is either playback moving past it or a resume position
    /// nowhere near it. The tail span stays for the same reason it always did: it is 64 KB, and a
    /// container that re-reads its trailing index during playback should keep hitting it.
    func markOpenPhaseFinished() {
        winCond.lock()
        openPhaseActive = false
        winCond.unlock()
    }

    /// AE#585: the reads that follow are a bounded index pass, not playback.
    func beginIndexPass() {
        winCond.lock()
        indexPassActive = true
        winCond.unlock()
    }

    /// AE#585: the index pass is over; the next read that cannot be answered from a resident span
    /// is playback's, and #281's rule applies to it unchanged.
    func endIndexPass() {
        winCond.lock()
        indexPassActive = false
        winCond.unlock()
    }

    /// AE#782: see `playbackRepositionPending`.
    func notePlaybackRepositioned() {
        winCond.lock()
        playbackRepositionPending = true
        winCond.unlock()
    }

    /// Which cold-start span answered, so the log can name the round trip that did not happen
    /// rather than leaving its absence to be inferred.
    enum SpanServe {
        case head(Int)
        case tail(Int)

        var bytes: Int {
            switch self {
            case .head(let n), .tail(let n): return n
            }
        }
    }

    /// Serve `offset` from either cold-start span. Caller holds `winCond` (the read loop already
    /// does, and `winCond` is an NSCondition, so re-acquiring here would deadlock). The copy runs
    /// under the lock on purpose: it is a memcpy out of a `Data` the delegate threads only ever
    /// install, never mutate.
    private func serveFromResidentSpansLocked(into dst: UnsafeMutablePointer<UInt8>, maxLen: Int,
                                              at offset: Int64) -> SpanServe? {
        if !headSpan.isEmpty,
           let n = ResidentSpan(start: 0, data: headSpan).serve(into: dst, maxLen: maxLen, at: offset) {
            return .head(n)
        }
        if let n = tailSpan?.serve(into: dst, maxLen: maxLen, at: offset) { return .tail(n) }
        return nil
    }

    /// AE#958: where the fabricated body really came from, when the retained head holds it, which
    /// turns "these are other bytes" into the origin's actual chunk offset for a report. Caller holds
    /// `winCond`.
    private func fabricatedBodyNoteLocked(_ received: Data) -> String {
        let needle = received.prefix(256)
        guard needle.count == 256, let hit = headSpan.range(of: needle) else { return "" }
        return " (the body is byte \(hit.lowerBound - headSpan.startIndex) of the source)"
    }

    /// AE#958: `count` bytes from `start` out of whatever still holds them whole (the window, the
    /// retained head, the tail prefetch), or nil. Caller holds `winCond`.
    private func heldBytesLocked(from start: Int64, count: Int) -> Data? {
        guard count > 0, start >= 0 else { return nil }
        let end = start + Int64(count)
        if start >= winStart, end <= winStart + Int64(window.count) {
            var bytes = Data(count: count)
            bytes.withUnsafeMutableBytes { raw in
                if let base = raw.baseAddress?.assumingMemoryBound(to: UInt8.self) {
                    window.copyBytes(to: base, from: Int(start - winStart), count: count)
                }
            }
            return bytes
        }
        if end <= Int64(headSpan.count) {
            let from = headSpan.startIndex + Int(start)
            return headSpan.subdata(in: from..<(from + count))
        }
        if let kept = headSpanCheckTail, start >= kept.start, end <= kept.end {
            let from = kept.data.startIndex + Int(start - kept.start)
            return kept.data.subdata(in: from..<(from + count))
        }
        if let tail = tailSpan, start >= tail.start, end <= tail.end {
            let from = tail.data.startIndex + Int(start - tail.start)
            return tail.data.subdata(in: from..<(from + count))
        }
        return nil
    }

    // MARK: - Persistent Connection (lifecycle + delegate callbacks)

    /// Open a fresh Range: bytes=<offset>- connection (live: always `bytes=0-`, see the
    /// request construction below). Bumps generation so late callbacks from the old
    /// connection are ignored.
    private func startPersistentConnection(at target: Int64, boundedTo: Int64? = nil, openEnded: Bool = false) {
        winCond.lock()
        connGeneration &+= 1
        let generation = connGeneration
        connHeaderRevision = requestHeaderStore?.revision ?? 0
        // AE#958: ask a few KB early when those KB are already held, so the answer can be checked
        // against them before any of it is kept. Live is exempt: its offsets are bookkeeping.
        var offset = target
        rangeProbe = nil
        // Never down to byte 0: that is the one offset every origin answers truthfully, so it would
        // check nothing and turn a forward request into a restart from the head.
        if !isLive, target > Int64(Self.rangeCheckBytes), !rangeAnswersFabricated {
            let n = Self.rangeCheckBytes
            if let held = heldBytesLocked(from: target - Int64(n), count: n) {
                offset = target - Int64(n)
                rangeProbe = RangeHonestyProbe(generation: generation, start: offset, expected: held)
            }
        }
        // #220: VOD asks for a fixed amount at a time, and anything an origin delivers past it is
        // dropped at the append (audit DMX-1), so the window is bounded by the ask. Two
        // cases keep the open-ended form: live, where the material is produced in real time so
        // the origin cannot outrun media rate and the end is moving, and a source whose total
        // size is not resolved yet, where there is nothing to clamp the last range against. An
        // explicit caller bound (boundedInitialFetch) still wins. `fileSize` is read here
        // because winCond is already held, as every fileSize access requires.
        // #377: a held connection is open-ended by construction. Bounded ranges (#220) exist
        // because a pushed transport delivers everything it was asked for whether or not the
        // consumer is ready, so the ASK is what bounds the window. A pull bounds it at the read
        // instead, and asking for a finite range would put the request cadence straight back. An
        // explicit caller bound still wins, because that caller wants a specific amount read.
        let resolvedBound: Int64? = boundedTo ?? {
            guard !openEnded else { return nil }
            guard !heldConnectionEnabled else { return nil }
            guard !isLive else { return nil }
            // fileSize is still 0 on the very first connection, since the response's
            // Content-Range is what resolves it. Asking for a fixed amount anyway is both safe
            // and necessary: safe because a server clamps a range that overruns the file (416
            // needs the START past the end, which cannot happen here), and necessary because
            // waiting for a resolved size would leave the first connection, the one that reads
            // from byte zero, open-ended.
            if fileSize > offset { return min(Self.persistentRangeBytes, fileSize - offset) }
            return fileSize <= 0 ? Self.persistentRangeBytes : nil
        }()
        // #295: a request that begins inside the resident window, or exactly at its end, is a
        // CONTINUATION rather than a reposition. Resetting `winStart` to it dropped every byte
        // below it, which for the #220 frontier refill is up to `winLowWater` of already delivered,
        // still undrained data: the very next read then sat below `winStart`, took the backward
        // branch, and pulled those same bytes back over the network 4 MB at a time on the demux
        // read thread. Keeping them costs nothing (the new range covers only what follows) and the
        // window stays bounded by `trimWindowLocked` and the high-water end exactly as before.
        // The truncating case is the narrow race where the old connection appended past the
        // frontier the read loop computed before it unlocked; those bytes are re-delivered by the
        // new range, which is correct if slightly wasteful, and never leaves a hole.
        // AE#958: on the TARGET, not on the request: the overlap a checked request re-reads is
        // dropped once it matched, so the window is laid out as if the request had started there.
        if target >= winStart, target <= winStart + Int64(window.count) {
            let keep = Int(target - winStart)
            if keep < window.count { window.truncate(to: keep) }
        } else {
            winStart = target
            window.removeAll()
        }
        connRequestedOffset = offset
        let askAsJoin = isLive && liveOffsetsUnsatisfiable
        connEnded = false
        connEndedByBackpressure = false
        connEndedAtRangeEnd = false
        postEndDeliveryBytes = 0
        postEndOvershootLogged = false
        let skippedConnStarts = connStartLogGate.admit(
            continuesPrevious: connRangeEnd.map { target == $0 + 1 } ?? false,
            now: TimeInterval(DispatchTime.now().uptimeNanoseconds) / 1_000_000_000)
        connRangeEnd = resolvedBound.map { offset + $0 - 1 }
        connStatus = 0
        connURLFailureCode = nil
        connRetryAfter = 0
        connTextNotice = nil
        connEndedByTextNotice = false
        connStartedAt = DispatchTime.now()   // #93: time-to-first-data per generation
        connFirstDataSeen = false
        lastDeliveryAt = connStartedAt       // #309: the gap is measured from here until data lands
        genDeliveredBytes = 0
        trickleSamples = [(connStartedAt, 0)]
        forwardWaitSince = nil
        // `nextFaultedRefillAt` is deliberately NOT reset here. The faulted-refill ladder sets it
        // just before authorising this very reconnect, so a reset on connection start erased the
        // pacing it had just announced — every "next attempt in Ns" fired as fast as the consumer
        // could read (field trace: a 509-refusing origin was retried on read cadence, streak=1).
        // The timestamp is cleared by proof of delivery (`appendPersistentData`, first data) and
        // by an intentional reposition (`seekReconnect`), the two events that genuinely end a
        // faulted lineage.
        let oldTransfer = activeTransfer
        activeTransfer = nil
        winCond.broadcast()
        winCond.unlock()

        oldTransfer?.cancelTransfer()
        // #377: hand the old range's origin slot back HERE rather than waiting for its
        // `didCompleteWithError`, which arrives asynchronously. On a single-slot origin the pump
        // would otherwise queue behind its own previous range at every 32 MB boundary and spend
        // its whole acquire budget waiting for itself.
        oldTransfer?.releaseOriginTicket()

        if isClosed { return }

        var request = URLRequest(engineURL: requestURL())
        // #93 residual: a bounded open connection asks for a finite range so an origin that dribbles
        // the open-ended `bytes=0-` stream serves it as a fast finite GET. The 206 Content-Range still
        // carries the total size, so fileSize resolution (issue #70) is unaffected.
        if let resolvedBound {
            request.setValue("bytes=\(offset)-\(offset + resolvedBound - 1)", forHTTPHeaderField: "Range")
        } else {
            // Live: `offset` is reader bookkeeping (the window frontier the delivered bytes are
            // appended at), and whether it means anything server-side depends on the origin.
            // Panels serving a ring buffer have no byte addresses at all: some ignore the offset
            // and serve from now (which is why the frontier request ever worked), others answer
            // 416 to every offset they cannot satisfy, which turned each reconnect into an
            // unrecoverable rejection loop (#331). A live source that is a growing FILE resumes
            // at the frontier correctly, and asking it for byte zero would re-deliver its whole
            // buffer on top of the window. So keep the frontier until an origin rejects it, then
            // ask the way a join does for the rest of the session; the append anchors the bytes
            // at the frontier either way.
            request.setValue("bytes=\(askAsJoin ? 0 : offset)-", forHTTPHeaderField: "Range")
        }
        request.timeoutInterval = 0  // long-lived; stalls handled by the reader
        applyExtraHeaders(&request)

        // #377: take the origin slot before the connection goes on the link. The pump is the one
        // path that must never be refused a slot for long: it is the main line, and everything
        // else holding a slot is short (a 4 MB detour block, a probe). A generous budget here
        // means "wait for the short thing to finish", not "give up".
        let requestURLForBudget = request.url ?? url
        let ticket = OriginRequestBudget.shared.acquire(
            for: requestURLForBudget, label: "\(label)#\(openDiagnosticID) pump", timeout: Self.pumpSlotWaitSeconds,
            shouldAbort: { [weak self] in self?.isClosed ?? true })
        // Audit DMX-112: a pump torn down while parked for its slot leaves without a transfer.
        if ticket == nil, isClosed { return }

        let transfer: any PersistentTransfer
        if heldConnectionEnabled {
            transfer = HeldSourceConnection(
                url: request.url ?? requestURLForBudget,
                offset: offset,
                extraHeaders: headers(for: request.url ?? requestURLForBudget),
                userAgent: nil,
                label: label,
                generation: generation,
                ticket: ticket,
                delegate: self
            )
        } else {
            let delegate = PersistentReadDelegate(
                reader: self,
                diagnosticContext: diagnosticContext,
                generation: generation,
                extraHeaders: headers(for: request.url),
                ticket: ticket,
                originURL: requestURLForBudget
            )
            let task = (persistentRequestSession ?? Self.persistentSession).dataTask(with: request)
            task.delegate = delegate
            transfer = task
        }

        winCond.lock()
        // A close() that raced in bumped the generation; don't install a stale connection.
        guard generation == connGeneration, !isClosed else {
            winCond.unlock()
            transfer.cancelTransfer()
            transfer.releaseOriginTicket()   // never started, so no completion callback will free it
            return
        }
        activeTransfer = transfer
        winCond.unlock()

        transfer.startTransfer()
        // #309: from here the generation is watched on wall-clock time, not on consumer cadence.
        armDeliveryGapWatchdog(generation: generation, after: connStallTimeout)
        armFirstByteWitness(generation: generation, originURL: requestURLForBudget)
        // #240: not DEBUG-only any more, and it names its reader. This is the line a field report
        // needs to answer "who is on the link": with bounded ranges every 32 MiB refill starts a
        // generation, so an unlabelled sequence of them reads like several concurrent connections
        // when it is one reader walking forward. On a fast link that walk is a range every few
        // hundred milliseconds, so contiguous ranges are summarised (see ConnStartLogGate).
        guard let skippedConnStarts else { return }
        EngineLog.emit(
            "[AVIOReader] \(label) conn start gen=\(generation) offset=\(target)"
            + (offset < target ? " check=\(target - offset)B" : "")
            + (resolvedBound.map { " len=\($0 / 1024 / 1024)MB" } ?? " open-ended")
            + " reader=\(openDiagnosticID) slot_ms=\(Int(ticket?.waitedMs ?? 0))"
            + (heldConnectionEnabled ? " held" : "")
            + (skippedConnStarts > 0 ? " (+\(skippedConnStarts) contiguous ranges since the last line)" : "")
            + reResolveNote(),
            category: .demux)
    }

    /// #309: timer queue for the delivery-gap watchdog. Shared and serial: the work is one
    /// timestamp comparison per armed generation and never touches the network.
    private static let deliveryGapQueue = DispatchQueue(label: "aether.avio.delivery-gap")

    /// #450: report a generation that has been on the link for `firstByteWitnessDelay` with no
    /// first byte. It REPORTS, it never acts: ending a connection stays with `checkDeliveryGap` and
    /// the read loop, so an early line cannot change when anything reconnects.
    ///
    /// The line carries the two facts that separate the causes, because they pick different fixes.
    /// A request parked in the transport behind this process's own long-lived connections looks,
    /// from every vantage point downstream, exactly like an origin sitting on the request: the task
    /// is resumed, no callback comes, no error comes, and no metrics come until it ends. `inflight`
    /// is what this engine has open against the origin, the pool cap is what the transport will let
    /// on the link, and a reporter who can read both off one line does not have to run curl to find
    /// out which side is quiet.
    private func armFirstByteWitness(generation: Int, originURL: URL) {
        Self.deliveryGapQueue.asyncAfter(deadline: .now() + firstByteWitnessDelay) { [weak self] in
            self?.reportMissingFirstByte(generation: generation, originURL: originURL)
        }
    }

    private func reportMissingFirstByte(generation: Int, originURL: URL) {
        if isClosed { return }
        winCond.lock()
        // Nothing to report: a newer generation owns the link, this one already ended, no transfer
        // is installed, or the first byte landed while this closure was queued.
        guard generation == connGeneration, !connEnded, activeTransfer != nil, !connFirstDataSeen else {
            winCond.unlock()
            return
        }
        let waited = Double(DispatchTime.now().uptimeNanoseconds - connStartedAt.uptimeNanoseconds)
            / 1_000_000_000
        let offset = connRequestedOffset
        winCond.unlock()
        // Outside winCond: the budget takes its own lock, and no lock of this reader is held across
        // another object's.
        let inflight = OriginRequestBudget.shared.snapshot(for: originURL)?.inflight
        EngineLog.emit(
            "[AVIOReader] \(label) gen=\(generation) no first byte after "
            + "\(String(format: "%.1f", waited))s at offset \(offset); "
            + (inflight.map { "\($0) request(s) open to this origin" } ?? "origin not in the budget's books")
            + ", transport pool allows \(Self.longLivedConnectionsPerHost) connections per host",
            category: .demux)
    }

    /// #309: schedule the delivery-gap check for `generation`. One pending closure at a time per
    /// generation: it either ends the connection or re-arms itself for the remaining gap, so a
    /// healthy transfer costs one comparison per `connStallTimeout` instead of a repeating timer,
    /// and a generation that has already ended arms nothing at all.
    private func armDeliveryGapWatchdog(generation: Int, after delay: TimeInterval) {
        Self.deliveryGapQueue.asyncAfter(deadline: .now() + delay) { [weak self] in
            self?.checkDeliveryGap(generation: generation)
        }
    }

    /// #309: end a generation that has an installed transfer and no delivery for
    /// `connStallTimeout`. Same threshold and same action as the read loop's forward wait, with the
    /// one precondition removed that made the field case invisible: that a consumer be blocked on
    /// it. A window holding read-ahead, or a paused player holding all of it, no longer defers the
    /// verdict.
    ///
    /// It ENDS, it never reconnects. Opening connections stays with the read thread, so a parked
    /// consumer cannot be turned into a timer-driven reconnect loop (the #307 failure mode), and a
    /// pause continues to hold no flow at all (the #310 invariant). The replacement is issued by
    /// the read loop: at low water while read-ahead remains, immediately once the window is empty.
    private func checkDeliveryGap(generation: Int) {
        if isClosed { return }
        winCond.lock()
        // Nothing to watch: a newer generation owns the link, the connection already ended
        // (delivered range, high-water end, transport error), or no transfer is installed.
        guard generation == connGeneration, !connEnded, let transfer = activeTransfer else {
            winCond.unlock()
            return
        }
        // The open is waiting on this generation's first byte with a budget of its own
        // (`SourceOpenPolicy`), which a host sets longer than the stall threshold for an origin that
        // is slow to answer. Ending it here cut both open attempts at the threshold instead.
        if openAwaitedGeneration == generation, !connFirstDataSeen {
            winCond.unlock()
            armDeliveryGapWatchdog(generation: generation, after: connStallTimeout)
            return
        }
        let gap = Double(DispatchTime.now().uptimeNanoseconds - lastDeliveryAt.uptimeNanoseconds)
            / 1_000_000_000
        // A held connection sitting on a full window has no read outstanding: the pump asked for a
        // budget, was told there was no room, and is waiting. Nothing is late, so there is no gap to
        // judge. The pushed path cannot reach this state -- it ends at the high water instead -- which
        // is why the verdict was safe to take on a full window before. Re-arm rather than end, and the
        // watchdog still owns the case this path can have: bytes asked for and none arriving.
        let heldAndFull = heldConnectionEnabled
            && (winHighWater - windowAheadLocked()) < Self.heldPullSlack
        if heldAndFull {
            // The clock restarts with the stretch it must not measure. Left running, it spends the
            // whole parked stretch, and the read the consumer's return issues is then born already
            // late: the next tick ends a connection that was healthy throughout, which is the
            // re-request this flag exists to remove, booked as a stall. A full period rather than
            // what is left of one, because once the gap has outgrown the timeout that remainder is
            // 20 ms and this would re-arm at 50 Hz for the length of the park.
            lastDeliveryAt = DispatchTime.now()
            // Same for the trickle marks: a park is not a slow stretch.
            trickleSamples = [(lastDeliveryAt, genDeliveredBytes)]
            forwardWaitSince = nil   // a full window is not a starved consumer
            winCond.unlock()
            armDeliveryGapWatchdog(generation: generation, after: connStallTimeout)
            return
        }
        if gap < connStallTimeout {
            // Live is never judged: a raw live source arrives at its own bitrate, so the read waits
            // on forward data by design, and a radio or SD channel sits below the floor for good.
            if !isLive, let trickle = trickleVerdictLocked() {
                endTrickleLocked(generation: generation, transfer: transfer, verdict: trickle)
                return
            }
            winCond.unlock()
            // Data landed since this closure was scheduled; wait out what is left of the window.
            armDeliveryGapWatchdog(generation: generation, after: max(0.02, connStallTimeout - gap))
            return
        }
        connEnded = true
        activeTransfer = nil
        deliveryGapEnds += 1
        let frontier = winStart + Int64(window.count)
        let ahead = window.count - max(0, Int(position - winStart))
        let sawData = connFirstDataSeen
        winCond.broadcast()
        winCond.unlock()
        transfer.cancelTransfer()
        transfer.releaseOriginTicket()   // #377: a stalled connection must not hold the slot
        // The witness the field case had no line for: `bytesFetched` sat frozen for minutes and
        // nothing said so. Release-visible, and rare by construction (one per faulted generation).
        EngineLog.emit(
            "[AVIOReader] \(label) gen=\(generation) no delivery for \(String(format: "%.1f", gap))s"
            + " at offset \(frontier) (\(ahead / 1024)KB read-ahead held,"
            + " \(sawData ? "had delivered" : "never delivered") data); ending it",
            category: .demux)
    }

    /// What `checkDeliveryGap` logs when it ends a trickling generation.
    private struct TrickleVerdict {
        let bytes: Int64
        let span: Double
        let waited: Double
        let offset: Int64
    }

    /// The gap watchdog measures only the time since the LAST delivery, so a drip defeats it: in the
    /// field (4K HDR over a debrid origin, held connection) a fresh generation delivered 256 KB every
    /// 40 to 100 s, each drip reset `lastDeliveryAt`, and for three minutes one read after another
    /// waited while no `no delivery` line ever fired and the forward buffer drained into a 25 s
    /// AVPlayer stall. The read loop's forward wait has the same blind spot (every drip signals it).
    /// This judges VOLUME instead: a consumer starved on forward data for `connStallTimeout` (across
    /// as many AVIO-sized reads as that takes), with a read blocked now and fewer than
    /// `trickleFloorBytes` delivered over the last `connStallTimeout`, ends the generation.
    /// Caller holds `winCond`; records this tick's mark either way.
    private func trickleVerdictLocked() -> TrickleVerdict? {
        let now = DispatchTime.now()
        let bytes = genDeliveredBytes
        trickleSamples.append((now, bytes))
        func seconds(since t: DispatchTime) -> Double {
            Double(now.uptimeNanoseconds - t.uptimeNanoseconds) / 1_000_000_000
        }
        // Keep the newest mark that is at least one period old, and everything after it.
        if let keep = trickleSamples.lastIndex(where: { seconds(since: $0.at) >= connStallTimeout }), keep > 0 {
            trickleSamples.removeFirst(keep)
        }
        guard forwardWaitActive, let since = forwardWaitSince, seconds(since: since) >= connStallTimeout,
              let mark = trickleSamples.first, mark.at.uptimeNanoseconds >= since.uptimeNanoseconds,
              seconds(since: mark.at) >= connStallTimeout else {
            return nil
        }
        let span = seconds(since: mark.at)
        let delivered = bytes - mark.bytes
        // Normalised to one period, so a mark older than a period cannot pass a trickle as healthy.
        guard Double(delivered) * connStallTimeout / span < Double(trickleFloorBytes) else { return nil }
        return TrickleVerdict(bytes: delivered, span: span, waited: seconds(since: since),
                              offset: forwardWaitOffset)
    }

    /// Ends a trickling generation exactly as the gap path ends a silent one: the read loop then
    /// replaces it through its ordinary ended-connection handling. Called with `winCond` held,
    /// returns with it released.
    private func endTrickleLocked(generation: Int, transfer: any PersistentTransfer, verdict: TrickleVerdict) {
        connEnded = true
        activeTransfer = nil
        trickleEnds += 1
        winCond.broadcast()
        winCond.unlock()
        transfer.cancelTransfer()
        transfer.releaseOriginTicket()   // #377: a trickling connection must not hold the slot
        EngineLog.emit(
            "[AVIOReader] \(label) gen=\(generation) trickle: \(verdict.bytes / 1024) KB in "
            + "\(String(format: "%.1f", verdict.span))s while a read waited "
            + "\(String(format: "%.1f", verdict.waited))s at offset \(verdict.offset); ending it",
            category: .demux)
    }

    /// Force-copies `data` into the sliding window and applies backpressure by ENDING the
    /// connection once the window exceeds winHighWater (#310); readPersistent re-requests at
    /// the frontier when the consumer drains below winLowWater. Never blocks: parking this
    /// delegate callback has no flow-control contract (TLS/H2 transports keep reading at
    /// line rate into unbounded internal buffers, the #174 EXC_RESOURCE). Force-copy
    /// releases source dispatch_data per delivery (same leak control as the chunk path).
    fileprivate func appendPersistentData(_ delivered: Data, generation: Int) {
        winCond.lock()
        guard generation == connGeneration, !isFullyClosed else {
            // #93: a slow read's summary line reports how much data the stale-generation
            // guard discarded while the read waited.
            staleGenDroppedBytes += Int64(delivered.count)
            winCond.unlock()
            return
        }
        // AE#925: a live text suspect is held back until its body is complete, and decided whole.
        if var held = takeTextNoticeLocked(generation: generation) {
            held.append(delivered)
            if Int64(held.count) < connTextNoticeLength {
                connTextNotice = (generation, held)
                winCond.unlock()
                return
            }
            winCond.unlock()
            settleTextNotice(held, generation: generation)
            return
        }
        // AE#958: nothing of a checked generation is kept until its first bytes matched the held ones.
        var incoming = delivered
        if var probe = rangeProbe, probe.generation == generation {
            switch probe.absorb(delivered) {
            case .pending:
                rangeProbe = probe
                lastDeliveryAt = DispatchTime.now()
                winCond.unlock()
                return
            case .honoured(let released):
                rangeProbe = nil
                incoming = released
            case .fabricated(let received):
                rangeProbe = nil
                rangeAnswersFabricated = true
                connEnded = true
                let transfer = activeTransfer
                activeTransfer = nil
                let note = fabricatedBodyNoteLocked(received)
                // The read can fail as soon as winCond is released. Publish its cause first:
                // error classification and the no-revive decision query this registry immediately.
                // record only takes its own short-lived lock; it cannot call back into the reader.
                FabricatedRangeOrigins.record(url)
                winCond.broadcast()
                winCond.unlock()
                transfer?.cancelTransfer()
                transfer?.releaseOriginTicket()
                EngineLog.emit(
                    "[AVIOReader] \(label) gen=\(generation) the 206 for bytes=\(probe.start)- carries other "
                    + "bytes than the \(probe.expected.count) B already held there\(note); this origin "
                    + "fabricates ranges, only byte 0 is addressable. Failing reads; the host should "
                    + "load it with LoadOptions.sequentialOrigin (AE#958)",
                    category: .demux)
                return
            }
        }
        // Audit DMX-1: the range is the bound only if bytes past its end are refused. A 200 that
        // ignored Range at offset 0, or a 206 wider than asked, otherwise kept appending under
        // `connEnded`, which also disarms the high-water end below, so the rest of the file
        // streamed into the window. The excess is dropped and the transfer ended; the frontier
        // refill asks for it properly.
        var data = incoming
        var overDelivered = false
        if let end = connRangeEnd {
            let room = end + 1 - (winStart + Int64(window.count))
            if Int64(data.count) > room {
                data = data.prefix(Int(max(0, room)))
                overDelivered = true
            }
        }
        lastDeliveryAt = DispatchTime.now()   // #309: the delivery-gap watchdog's only input
        genDeliveredBytes += Int64(data.count)
        var firstDataMs: Double? = nil
        if !connFirstDataSeen {
            connFirstDataSeen = true
            lastDeliveringConnCut = false
            clearRecordedTransportFailure()
            firstDataMs = Double(DispatchTime.now().uptimeNanoseconds - connStartedAt.uptimeNanoseconds) / 1_000_000
            // #281 retest: the price of one round trip against this origin, which is what bounds
            // how long a read may wait for bytes that are already on the wire.
            lastFirstDataMs = firstDataMs ?? 0
            // Delivery is the proof that ends a faulted lineage: release the refill pacing (and
            // a give-up latch — an origin that recovered after the faulted ladder capped out may
            // fault again later and deserves a fresh ladder, not `.distantFuture` forever).
            nextFaultedRefillAt = .distantPast
        }
        let count = data.count
        // #310: delivery that lands with the backpressure end ALREADY recorded, i.e. after our
        // own cancel. A bounded in-flight tail is expected. A figure that keeps climbing is the
        // witness that ending is as advisory as suspending was (#174 blocking, #220 suspend:
        // each mechanism here has failed exactly this way once), and without a line naming it
        // the next round would start from a memprobe and a guess. Counted before the append so
        // it is attributable to the transport rather than to our own bookkeeping.
        var overshootToLog: Int64? = nil
        if connEndedByBackpressure {
            postEndDeliveryBytes += Int64(count)
            if postEndDeliveryBytes > Int64(winHighWater), !postEndOvershootLogged {
                postEndOvershootLogged = true
                overshootToLog = postEndDeliveryBytes
            }
        }
        let base = window.count
        window.append(data)
        // #281 retest: retain the head of the file for the open phase, as it arrives. It cannot be
        // copied later out of the window, because `trimWindowLocked` drops it as the parse reads
        // forward, which is why the seek-time park misses on every layout whose parse reads more
        // than `winLookback` before its first excursion. Contiguity is checked rather than assumed:
        // only the connection anchored at zero, and only while it is still the tail of what is held.
        if openPhaseActive, winStart == 0, base == headSpan.count,
           headSpan.count < Self.headSpanMaxBytes {
            headSpan.append(data.prefix(Self.headSpanMaxBytes - headSpan.count))
        }
        addBytesFetched(count)
        // #220: the requested range has been delivered in full. That ends the connection on
        // purpose; the read loop re-requests at the frontier once the consumer has drawn down.
        var overDeliveredTransfer: (any PersistentTransfer)?
        if let end = connRangeEnd, winStart + Int64(window.count) > end {
            connEndedAtRangeEnd = true
            connEnded = true
            if overDelivered {
                overDeliveredTransfer = activeTransfer
                activeTransfer = nil
            }
        }
        winCond.broadcast()
        // #310: past high water the connection is ENDED, not suspended. suspend() is
        // advisory (#220: CFNetwork keeps draining and delivering), and a task that does
        // park under it holds a dormant established flow whose closed receive window is the
        // process-wide nw-starvation trigger this design replaces (see the backpressure doc
        // block at the water marks). Deliveries already dispatched before the cancel takes
        // effect still land here (same generation until the refill starts a new one), so
        // the window can overshoot highWater by the transport's in-flight amount; the
        // frontier is computed from what actually arrived, so nothing is discarded,
        // re-fetched, or left as a hole. The window keeps every byte already delivered
        // (they are valid and the consumer reads them) and the read loop re-requests at
        // the frontier once the consumer drains below low water.
        var toCancel: (any PersistentTransfer)?
        let ahead = window.count - max(0, Int(position - winStart))
        // #377: a demand-driven transfer is not ended here. Its backpressure is the pull budget,
        // which never asks for more than the window has room for, so reaching this point at all
        // would be a bookkeeping surprise rather than an origin outrunning the consumer; ending it
        // would put back exactly the request-per-drain-cycle cadence the flag exists to remove.
        if ahead > winHighWater, !connEnded, !isClosed,
           let installed = activeTransfer, !installed.isDemandDriven {
            connEndedByBackpressure = true
            connEnded = true
            toCancel = activeTransfer
            activeTransfer = nil
            winCond.broadcast()
        }
        winCond.unlock()
        if let overDeliveredTransfer {
            EngineLog.emit(
                "[AVIOReader] \(label) gen=\(generation) origin delivered past the requested range "
                + "end; ending the connection (audit DMX-1)",
                category: .demux)
            overDeliveredTransfer.cancelTransfer()
            overDeliveredTransfer.releaseOriginTicket()
        }
        if let toCancel {
            EngineLog.emit(
                "[AVIOReader] \(label) window high water: \(ahead / 1024 / 1024)MB ahead; ending the "
                + "connection, will re-request at the frontier once the consumer drains",
                category: .demux)
            toCancel.cancelTransfer()
            // #377: the frontier re-request follows as soon as the consumer drains, so give the
            // slot back now instead of leaving it to the completion callback.
            toCancel.releaseOriginTicket()
        }
        if let overshootToLog {
            EngineLog.emit(
                "[AVIOReader] \(label) gen=\(generation) \(overshootToLog / 1024 / 1024)MB delivered "
                + "AFTER the backpressure end; the cancel is not stopping this transport",
                category: .demux)
        }
        if let firstDataMs {
            // #93/#96 residual: a slow first-data gap is release-visible so a device trace can pair it
            // with the response-header timing above. Small header gap + large first-data gap = the body
            // stalled after headers; large header gap = server-side connection queuing. Fast reads stay
            // on the DEBUG-only path to keep the release log quiet.
            if firstDataMs > 2000 {
                EngineLog.emit("[AVIOReader] \(label) gen=\(generation) first data after \(Int(firstDataMs))ms",
                               category: .demux)
            } else {
                #if DEBUG
                EngineLog.emit("[AVIOReader] \(label) gen=\(generation) first data after \(Int(firstDataMs))ms",
                               category: .demux)
                #endif
            }
        }
    }

    /// `respondedBy` is where this response came from, redirects followed, and it is passed for
    /// EVERY status: the pin still moves on a 2xx only, but a refusal has to be able to name the
    /// host that refused (#377).
    fileprivate func persistentReceivedResponse(
        _ http: HTTPURLResponse,
        respondedBy: URL?,
        generation: Int
    ) -> Bool {
        let status = http.statusCode
        var isOK = status == 200 || status == 206
        var retryAfter: TimeInterval = 0
        if Self.isRateLimitStatus(status) {
            retryAfter = Self.parseRetryAfter(http)
            noteOriginRefusal(status: status, retryAfter: retryAfter > 0 ? retryAfter : nil,
                              respondedBy: respondedBy)
        }
        var headerMs: Double? = nil
        var sentRevision: UInt64? = nil
        winCond.lock()
        if generation == connGeneration {
            connStatus = status
            connRetryAfter = retryAfter
            sentRevision = connHeaderRevision
            // #93/#96 residual: time-to-first-response-header for this generation. A large value here
            // with a small subsequent first-data gap points at server-side connection queuing (the
            // origin accepted the socket but withheld the response while it served another connection
            // of the same file at full rate), the prime suspect for the ~15s cold reads.
            headerMs = Double(DispatchTime.now().uptimeNanoseconds - connStartedAt.uptimeNanoseconds) / 1_000_000
            if isLive, Self.isLiveTextNoticeCandidate(http) {
                connTextNotice = (generation, Data())
                connTextNoticeLength = http.expectedContentLength
                connTextNoticeRetryAfter = Self.parseRetryAfter(http)
            }
        }
        // VOD: 200 at offset > 0 means server ignored Range and sent the full body
        // from byte 0 (silent corruption). Reject it. Live is exempt: transcode
        // reconnect legitimately answers 200 with "from now".
        let requestedOffset = (generation == connGeneration) ? connRequestedOffset : 0
        // Audit DMX-101: the cold open asked for a bounded range at byte 0. A 200 whose body is not
        // that range is an origin that cannot address bytes, and this connection is abandoned at the
        // head: nothing below may adopt its Content-Length as a size the persistent reader could
        // seek by.
        var rangeIgnoredAtOpen = false
        if generation == connGeneration, !isLive, rangeVerdictPending,
           Self.rangeAnswer(http, requestedStart: requestedOffset, requestedEnd: connRangeEnd) == .ignored {
            rangeIgnoredAtOpen = true
            rangeIgnoredAtOpenLength = http.expectedContentLength
        }
        // #331: the origin just told us its live stream has no byte address to resume at. Latch
        // it, so every later request in this session is the join shape instead of repeating an
        // offset that can only ever be rejected again. Nonzero offsets only: a 416 at zero is a
        // different fault and must not silently change the request shape.
        var latchedJoinShape = false
        if generation == connGeneration, isLive, status == 416, requestedOffset > 0,
           !liveOffsetsUnsatisfiable {
            liveOffsetsUnsatisfiable = true
            latchedJoinShape = true
        }
        // Issue #70: the first from-0 data connection doubles as the size probe, so the
        // playback open skips probeFileSize() entirely. Derive the total from this
        // response (206 Content-Range, or Content-Length on a from-0 2xx). Write-once
        // (fileSize <= 0), current-gen only, and never for live (whose length is
        // non-authoritative). The response precedes any body and no read() reads fileSize
        // until open() returns, so this write is ordered behind winCond just like the data.
        // #551: the warm's size meets the connection that is actually serving this session. They
        // disagree only when the warm belongs to a different response, and then the warm is the
        // wrong one: these bytes are the ones being played. Drop the whole warm rather than keep
        // spans whose offsets belong to another body, and let the write-once rule below take the
        // real size.
        if generation == connGeneration, !isLive, let adopted = adoptedWarmSize,
           let total = Self.sizeFromResponse(http, requestedOffset: requestedOffset), total != adopted {
            EngineLog.emit(
                "[AVIOReader] \(label) the warm said \(adopted)B, this connection says \(total)B; "
                + "dropping the prewarmed bytes (#551)", category: .demux)
            headSpan = Data()
            headSpanCheckTail = nil
            tailSpan = nil
            fileSize = 0
            adoptedWarmSize = nil
        }
        if generation == connGeneration, !isLive, isOK, openContentType == nil {
            openContentType = http.value(forHTTPHeaderField: "Content-Type")
        }
        if generation == connGeneration, !isLive, fileSize <= 0, !rangeIgnoredAtOpen,
           let total = Self.sizeFromResponse(http, requestedOffset: requestedOffset) {
            fileSize = total
            // #112: share this resolved length so a later side demuxer on the same origin can skip a probe that
            // might be starved under this connection's load and would otherwise collapse it to forward-only.
            SourceContentLengthCache.store(total, for: url)
            #if DEBUG
            EngineLog.emit("[AVIOReader] File size: \(total) bytes (data connection)", category: .demux)
            #endif
        }
        winCond.unlock()
        if let headerMs, headerMs > 2000 {
            EngineLog.emit(
                "[AVIOReader] gen=\(generation) response headers after \(Int(headerMs))ms status=\(status)",
                category: .demux
            )
        }
        if let sentRevision, Self.isCredentialRefusalStatus(status), let requestHeaderStore {
            requestHeaderStore.noteCredentialRefusal(status: status, revision: sentRevision)
        }
        // #331: name the latch once. A field capture that shows the reconnect shape change is the
        // difference between "the origin has no byte addresses" and "the reconnect is broken".
        if latchedJoinShape {
            EngineLog.emit(
                "[AVIOReader] \(label) live origin rejected offset \(requestedOffset) (416); "
                + "requesting the stream as a join from here",
                category: .demux
            )
        }
        if status == 200 && requestedOffset > 0 && !isLive {
            EngineLog.emit(
                "[AVIOReader] server ignored Range (200 for offset \(requestedOffset)); rejecting body",
                category: .demux
            )
            isOK = false
        }
        if rangeIgnoredAtOpen {
            EngineLog.emit(
                "[AVIOReader] \(label) origin answered the ranged open with a 200 "
                + "(Content-Length \(http.expectedContentLength)); hanging up at the head (audit DMX-101)",
                category: .demux)
            isOK = false
        }
        // Live is exempt for the same reason as above: its offset is bookkeeping, and the append
        // anchors the bytes at the frontier whatever the origin calls them.
        if isOK, !isLive, generation == connGeneration,
           let served = Self.misplacedRangeStart(http, requestedOffset: requestedOffset) {
            EngineLog.emit(
                "[AVIOReader] \(label) gen=\(generation) 206 starts at \(served), not the requested "
                + "\(requestedOffset); rejecting body (audit DMX-5)",
                category: .demux
            )
            isOK = false
        }

        if isOK {
            recordResolvedURL(respondedBy)
            return true
        }
        // The 200-ignored-Range rejection logged above; every other rejected
        // status was previously silent, leaving the reconnect storm unexplained
        // in the log.
        if status != 200 {
            EngineLog.emit(
                "[AVIOReader] \(label) gen=\(generation) rejected response status=\(status) at offset \(requestedOffset)"
                    + respondingTargetDescription(respondedBy)
                    + (retryAfter > 0 ? " retryAfter=\(Int(retryAfter))s" : ""),
                category: .demux
            )
        }
        if Self.isResolvedExpiryStatus(status) {
            invalidateResolvedURL()
        } else if Self.isResolvedHardServerError(status) {
            invalidateResolvedURL(reason: "hard \(status) from pinned URL")
        }
        return false
    }

    /// AE#925: decides a held live text body. Media (a playlist, a manifest, TS) goes into the window
    /// as if it had never been held, where the open's reroute reads it; a notice ends the connection
    /// as the 509 it means, so the live refusal ladder paces the next request and the body never
    /// reaches the demuxer.
    private func settleTextNotice(_ body: Data, generation: Int) {
        let bytes = [UInt8](body)
        guard Self.isConnectionRefusalNotice(bytes) else {
            if !body.isEmpty { appendPersistentData(body, generation: generation) }
            return
        }
        winCond.lock()
        guard generation == connGeneration, !isFullyClosed else {
            winCond.unlock()
            return
        }
        let retryAfter = connTextNoticeRetryAfter
        connStatus = 509
        connRetryAfter = retryAfter
        connEndedByTextNotice = true
        connEnded = true
        let transfer = activeTransfer
        activeTransfer = nil
        winCond.broadcast()
        winCond.unlock()
        EngineLog.emit(
            "[AVIOReader] \(label) gen=\(generation) live origin answered 2xx with a \(bytes.count) B text "
            + "notice (\"\(Self.noticeExcerpt(bytes))\"); taking it as a connection-cap refusal, status=509 (AE#925)",
            category: .demux)
        noteOriginRefusal(status: 509, retryAfter: retryAfter > 0 ? retryAfter : nil)
        transfer?.cancelTransfer()
        transfer?.releaseOriginTicket()
    }

    fileprivate func persistentConnectionEnded(error: Error?, generation: Int) {
        // AE#925: a suspect whose body came up short of its length is decided on what arrived.
        winCond.lock()
        let heldNotice = takeTextNoticeLocked(generation: generation)
        winCond.unlock()
        if let heldNotice, !heldNotice.isEmpty {
            settleTextNotice(heldNotice, generation: generation)
        }
        winCond.lock()
        let isCurrentGen = (generation == connGeneration)
        if isCurrentGen {
            connURLFailureCode = SourceNetworkDiagnostics.urlErrorCode(error)
            recordTransportFailure(error)
            connEnded = true
            // #220: the refill below keys off there being no live connection, so the finished
            // task must not stay installed.
            activeTransfer = nil
        }
        // #310: our own high-water cancel completes here as NSURLErrorCancelled. That end was
        // already logged where it was decided; reporting it as an error too would make every
        // drain cycle against a fast origin read like a transport fault.
        let deliberateEnd = isCurrentGen && (connEndedByBackpressure || connEndedAtRangeEnd || connEndedByTextNotice)
        if isCurrentGen, connFirstDataSeen, !deliberateEnd, let error,
           (error as? URLError)?.code != .cancelled {
            lastDeliveringConnCut = true
        }
        let windowAhead = isCurrentGen ? (window.count - max(0, Int(position - winStart))) : 0
        winCond.broadcast()
        winCond.unlock()
        if let error, !(deliberateEnd && (error as? URLError)?.code == .cancelled) {
            EngineLog.emit("[AVIOReader] \(label) conn gen=\(generation) ended with error: \(error.localizedDescription)", category: .demux)
            noteTransportSecurityFailure(error)
        }
        if isCurrentGen && isLive {
            EngineLog.emit("[AVIOReader] Live source: connection ended gen=\(generation) buffered=\(windowAhead / 1024)KB; reconnect will fire when buffer drains", category: .demux)
        }
    }

    /// Parses delta-seconds Retry-After; HTTP-date form falls back to expo backoff. Cap 15s.
    private static func parseRetryAfter(_ http: HTTPURLResponse) -> TimeInterval {
        guard let raw = http.value(forHTTPHeaderField: "Retry-After"),
              let seconds = TimeInterval(raw.trimmingCharacters(in: .whitespaces)) else {
            return 0
        }
        return min(max(seconds, 0), 15)
    }

    // MARK: - Streaming Download (background)

    private func startStreamingDownload() {
        prefetchQueue.async { [weak self] in
            self?.streamDownloadSync()
        }
    }

    private func streamDownloadSync() {
        var request = URLRequest(engineURL: url)
        request.timeoutInterval = 0  // No timeout for live streams
        applyExtraHeaders(&request)

        // #377: this connection is open for the whole session, so it holds its slot for the whole
        // session, which is exactly what it costs the origin. Returned at network completion so a
        // lower-priority caller need not resume first. A streaming-mode source has no detour
        // or ranged probe to starve (they are all switched off on this path), so a held slot here
        // blocks nothing but a second reader on the same origin, which is the point.
        let streamTicket: OriginRequestBudget.Ticket?
        do {
            streamTicket = try requestTicket(
                for: request.url ?? url, label: "\(label) stream", timeout: Self.pumpSlotWaitSeconds)
        } catch {
            streamLock.lock()
            streamEnded = true
            streamLock.unlock()
            streamDataReady.signal()
            return
        }
        let lease = OriginRequestBudget.Lease(streamTicket)
        defer { lease.release() }

        let semaphore = DispatchSemaphore(value: 0)

        let delegate = StreamingDelegate(
            diagnosticContext: diagnosticContext,
            extraHeaders: headers(for: request.url),
            onResponse: { [weak self] response in
                // Advisory length for the EOF/EIO distinction; -1 (chunked / unknown) leaves the
                // clean-end path as the only EOF source.
                guard let self else { return }
                let expected = response.expectedContentLength
                guard expected > 0 else { return }
                self.streamLock.lock()
                self.streamExpectedBytes = expected
                self.streamLock.unlock()
            },
            onRefused: { [weak self] status, respondedBy in
                guard let self else { return }
                self.streamLock.lock()
                self.streamRefusedStatus = status
                self.streamLock.unlock()
                // #377: a metering origin is charged wherever a status is first read, and this was
                // the one path that read one without charging it. On a sequential origin this GET
                // is the session's only request (no ranged open, no probe, by construction), so its
                // 429 was seen by nobody: the budget kept offering that origin its full concurrency
                // and the revive arm had no stamp saying the source was metered rather than gone.
                if Self.isRateLimitStatus(status) {
                    self.noteOriginRefusal(status: status, respondedBy: respondedBy)
                }
                EngineLog.emit(
                    "[AVIOReader] \(self.label) streaming GET refused status=\(status); hanging up at the header",
                    category: .demux)
            }
        ) { [weak self] data in
            guard let self, !self.isClosed else { return }
            self.streamLock.lock()
            if self.streamFailed {
                self.streamLock.unlock()
                return
            }
            // Owned bytes: the chunk is retained until it is consumed, and a delivery that still
            // references the transport's dispatch_data would pin its buffer for that long.
            let firstDelivery = self.streamBuffer.isEmpty && self.streamBytesRead == 0
            self.streamBuffer.append(data.withUnsafeBytes { Data($0) })
            if firstDelivery { self.clearRecordedTransportFailure() }
            self.streamPeakBytes = max(self.streamPeakBytes, self.streamBuffer.count)
            var toCancel: URLSessionDataTask?
            if self.streamBuffer.count > self.streamHardCap {
                self.streamFailed = true
                self.streamFailureCause = .originIgnoresFlowControl
                toCancel = self.streamingTask
            }
            // Backpressure: park the transfer once the retained buffer
            // exceeds the high water mark; readStreaming resumes it when
            // the consumer drains below the low water mark (and before
            // any wait, so a far-forward seek can't deadlock against a
            // suspended producer).
            var toSuspend: URLSessionDataTask?
            if !self.streamingTaskSuspended, self.streamBuffer.count > self.streamHighWater {
                self.streamingTaskSuspended = true
                toSuspend = self.streamingTask
            }
            self.streamLock.unlock()
            if let toCancel {
                EngineLog.emit(
                    "[AVIOReader] \(self.label) streaming buffer passed \(self.streamHardCap / 1024)KB "
                    + "with the transfer suspended: the origin ignores flow control, so the source is "
                    + "ended here to keep memory bounded and the read will fail (audit DMX-7, DMX-107)",
                    category: .demux)
                toCancel.cancel()
            } else {
                toSuspend?.suspend()
            }
            self.addBytesFetched(data.count)
            self.streamDataReady.signal()
        } onComplete: { [weak self] error in
            lease.release()
            guard let self else {
                semaphore.signal()
                return
            }
            self.streamLock.lock()
            self.streamURLFailureCode = SourceNetworkDiagnostics.urlErrorCode(error)
            self.recordTransportFailure(error)
            if error != nil, !self.isClosed { self.streamFailed = true }
            self.streamEnded = true
            self.streamLock.unlock()
            self.streamDataReady.signal()
            semaphore.signal()
        }

        let streamSession = URLSession(
            configuration: Self.makeSessionConfig(longLived: true),
            delegate: delegate,
            delegateQueue: AVIOReader.makePlaybackDelegateQueue()
        )
        let task = streamSession.dataTask(with: request)

        // Register before resume so markClosed()/close() can cancel; re-check after.
        streamLock.lock()
        streamingSession = streamSession
        streamingTask = task
        streamLock.unlock()

        task.resume()
        if isClosed { task.cancel() }

        #if DEBUG
        EngineLog.emit("[AVIOReader] Streaming started: \(url.lastPathComponent)", category: .demux)
        #endif

        semaphore.wait()

        #if DEBUG
        EngineLog.emit("[AVIOReader] Streaming ended", category: .demux)
        #endif
        streamLock.lock()
        streamingSession = nil
        streamingTask = nil
        streamLock.unlock()
        streamSession.invalidateAndCancel()
    }

    // MARK: - Prefetch (background, seekable mode only)

    private func triggerPrefetch(from offset: Int64) {
        guard prefetchEnabled else { return }
        if fileSize > 0 && offset >= fileSize { return }

        bufferLock.lock()
        guard !isPrefetching else { bufferLock.unlock(); return }
        isPrefetching = true
        bufferLock.unlock()

        prefetchQueue.async { [weak self] in
            guard let self = self else { return }

            // Bail if close() ran to avoid writing stale data back into prefetchBuffer.
            if self.isFullyClosed {
                self.bufferLock.lock()
                self.isPrefetching = false
                self.bufferLock.unlock()
                self.prefetchReady.signal()
                return
            }

            let size: Int
            if self.fileSize > 0 {
                size = min(self.chunkSize, Int(self.fileSize - offset))
            } else {
                size = self.chunkSize
            }

            let data = size > 0 ? self.fetchChunk(from: offset, size: size) : nil

            self.bufferLock.lock()
            // Re-check: close() may have fired while fetchChunk was on the network.
            if !self.isFullyClosed {
                self.prefetchBuffer = data
                self.prefetchOffset = offset
            }
            self.isPrefetching = false
            self.bufferLock.unlock()

            self.prefetchReady.signal()
        }
    }

    // MARK: - Seek

    /// Internal rather than fileprivate (#281) so the seek-driven paths, the parse seek and the
    /// return trip behind it, are exercised against a real origin without going through FFmpeg,
    /// the same reason `recordRateLimitAndShouldGiveUp` is not private. Callers outside the file
    /// are tests; production reaches this through `seekCallback`.
    func seek(offset: Int64, whence: Int32) -> Int64 {
        if whence == AVSEEK_SIZE {
            guard fileSize <= 0, originIgnoresRange else { return fileSize }
            streamLock.lock()
            defer { streamLock.unlock() }
            return streamExpectedBytes
        }
        // For persistent mode, position is shared with the delegate thread;
        // read SEEK_CUR base under the window lock.
        let newPosition: Int64
        switch whence {
        case SEEK_SET:
            newPosition = offset
        case SEEK_CUR:
            if usePersistentReader {
                winCond.lock(); let cur = position; winCond.unlock()
                newPosition = cur + offset
            } else {
                newPosition = position + offset
            }
        case SEEK_END:
            guard fileSize >= 0 else { return -1 }
            newPosition = fileSize + offset
        default:
            return -1
        }

        if usePersistentReader {
            // Just move the cursor; the read loop decides whether to reconnect.
            // Coalesces the matroska seek-storm on open into minimal reconnects.
            winCond.lock()
            position = newPosition
            winCond.broadcast()
            winCond.unlock()
        } else if !isStreaming {
            position = newPosition
            bufferLock.lock()
            let inCurrent = position >= currentOffset &&
                position < currentOffset + Int64(currentBuffer.count)
            if !inCurrent {
                currentBuffer = Data()
                currentOffset = position
                prefetchBuffer = nil
            }
            bufferLock.unlock()
        } else {
            // Streaming: forward-only; backward seeks below the retained
            // window return failure so the demuxer doesn't silently wait 15s.
            streamLock.lock()
            let oldestRetained = streamBytesRead
            streamLock.unlock()
            if newPosition < oldestRetained { return -1 }
            position = newPosition
        }

        return newPosition
    }

    // MARK: - Network (seekable mode)

    /// These callbacks deliver foreground playback bytes and return origin slots to blocked
    /// demux threads. URLSession's implicit queue can run at utility QoS and cannot donate
    /// priority through a semaphore. Each session keeps its own serial callback queue.
    static func makePlaybackDelegateQueue() -> OperationQueue {
        let queue = OperationQueue()
        queue.name = "aether.avio.callbacks"
        queue.qualityOfService = .userInitiated
        queue.maxConcurrentOperationCount = 1
        return queue
    }

    /// Long-lived session for file-size probes. Per-request sessions force fresh TLS
    /// handshakes, which Cloudflare-fronted origins can flag as suspicious. Distinct
    /// from syncRequest's per-request pattern (load-bearing for chunk-fetch leak control).
    private static let probeSession: URLSession = {
        let config = URLSessionConfiguration.default
        config.urlCache = nil
        config.timeoutIntervalForRequest = 20
        return URLSession(configuration: config, delegate: EngineTLS.sessionDelegate, delegateQueue: AVIOReader.makePlaybackDelegateQueue())
    }()

    /// Audit DMX-5: where a 206 says its body starts, when that is not where it was asked to.
    /// Every ranged path here places the body at the REQUESTED offset, so a 206 aligned to an
    /// edge's own chunk boundary would shift every later read by the difference. Nil for any other
    /// status and for a Content-Range this cannot read (those keep the lenient historical path).
    static func misplacedRangeStart(_ http: HTTPURLResponse, requestedOffset: Int64) -> Int64? {
        guard let served = contentRangeSpan(http) else { return nil }
        return served.start == requestedOffset ? nil : served.start
    }

    /// First and last byte a 206 says it carries, nil for any other status and for a Content-Range
    /// this cannot read.
    static func contentRangeSpan(_ http: HTTPURLResponse) -> (start: Int64, end: Int64?)? {
        guard http.statusCode == 206,
              let value = http.value(forHTTPHeaderField: "Content-Range") else { return nil }
        let trimmed = value.trimmingCharacters(in: .whitespaces)
        guard trimmed.lowercased().hasPrefix("bytes ") else { return nil }
        let span = trimmed.dropFirst("bytes ".count).split(separator: "/", maxSplits: 1).first ?? ""
        guard let dash = span.firstIndex(of: "-"),
              let start = Int64(span[..<dash].trimmingCharacters(in: .whitespaces)) else { return nil }
        let end = Int64(span[span.index(after: dash)...].trimmingCharacters(in: .whitespaces))
        return (start, end)
    }

    /// Audit DMX-101, NET-102: what an origin did with `Range: bytes=a-b`, judged from the response
    /// head alone, so a reader can hang up before a body it would have to throw away. One
    /// classification for every reader (`HTTPDiscIOReader` uses it too).
    enum RangeAnswer: Equatable {
        /// A 206 that starts where asked and stays inside the ask.
        case honoured
        /// A 206 that starts where asked but runs past the requested end. The origin CAN address
        /// bytes, so the caller keeps what it asked for and hangs up (audit DMX-1).
        case overWide
        /// A 206 that starts elsewhere, the way an edge that aligns ranges to its own chunks answers.
        case misplaced(start: Int64)
        /// A 200 that is not the asked range: the body is the source from byte 0, whatever was
        /// asked, and its length is not the ask's or is not stated at all.
        case ignored
        /// A 200 at offset 0 whose Content-Length fits inside the ask: the whole file, and a small
        /// one. Nothing was ignored that matters, so the source stays sized and seekable.
        case wholeFile
        /// Any other status. It says nothing about range support.
        case unjudged
    }

    static func rangeAnswer(_ http: HTTPURLResponse, requestedStart: Int64,
                            requestedEnd: Int64?) -> RangeAnswer {
        switch http.statusCode {
        case 206:
            if let served = misplacedRangeStart(http, requestedOffset: requestedStart) {
                return .misplaced(start: served)
            }
            if let end = requestedEnd {
                if let servedEnd = contentRangeSpan(http)?.end, servedEnd > end { return .overWide }
                if http.expectedContentLength > end - requestedStart + 1 { return .overWide }
            }
            return .honoured
        case 200:
            guard requestedStart == 0 else { return .ignored }
            let length = http.expectedContentLength
            guard length > 0 else { return .ignored }
            if let end = requestedEnd, length > end + 1 { return .ignored }
            return .wholeFile
        default:
            return .unjudged
        }
    }

    /// Total size from a data-connection response: `Content-Range` total on a 206, or
    /// `Content-Length` on a from-0 2xx (origins that answer 200 ignoring Range). Nil when
    /// the origin gave no usable length (chunked, or an unknown `*` total). Issue #70.
    static func sizeFromResponse(_ http: HTTPURLResponse, requestedOffset: Int64) -> Int64? {
        // On a 206 the total lives ONLY in Content-Range; Content-Length is the partial span,
        // so a 206 with an unknown (`*`) or unparseable range must report no size, never fall
        // through to the partial length (issue #70 review #6).
        if http.statusCode == 206 {
            guard let cr = http.value(forHTTPHeaderField: "Content-Range"),
                  let total = HTTPDiscIOReader.parseContentRangeTotal(cr), total > 0 else {
                return nil
            }
            return total
        }
        if (200...299).contains(http.statusCode), requestedOffset == 0,
           http.expectedContentLength > 0 {
            return http.expectedContentLength
        }
        return nil
    }

    /// #112: resolve the source length for the open, preferring a live probe and falling back to a length another
    /// demuxer already resolved for the same origin. A fresh probe here can be 429'd or answered without a length
    /// while the video producer is hammering the origin, which would drop this reader to forward-only streaming so
    /// every `avformat_seek_file` returns -1 and PGS reconstruction reads nothing. The producer's persistent open
    /// caches the real length (SourceContentLengthCache.store at the data-connection response), so a starved probe
    /// reuses it and stays byte-seekable. A successful probe also seeds the cache for whoever opens next.
    private func resolveInitialFileSize() -> Int64 {
        let probed = probeFileSize()
        if probed > 0 {
            SourceContentLengthCache.store(probed, for: url)
            return probed
        }
        if let cached = SourceContentLengthCache.lookup(url), cached > 0 {
            EngineLog.emit("[AVIOReader] size probe empty; reusing cached \(cached) bytes to keep seekability (#112)", category: .demux)
            return cached
        }
        return probed
    }

    /// Each staggered open-time size probe gets its own thread, because each one blocks on a
    /// semaphore-driven URLSession round-trip. On a concurrent queue that is a global-pool worker
    /// held for the whole round-trip, and a process whose pool workers are all in a blocking wait
    /// gives the fallbacks no thread at all: `open()` spends its budget, falls back to streaming
    /// mode, and the source silently loses seekability although the origin would have answered.
    /// Seen on CI as the #255 HEAD fallback never running.

    /// How long the primary open-ended range probe runs alone before the two fallback
    /// probes fire. Fast origins resolve well inside this window and never see a
    /// fallback request (identical wire behavior to the old sequential ladder).
    static let sizeProbeStaggerSeconds: TimeInterval = 0.75

    private func probeFileSize() -> Int64 {
        if let probeControl {
            // Disposable probes retain their own cancellation and lifetime contract.
            if let size = rangeProbeFileSize(range: "bytes=0-"), size > 0 { return size }
            guard !probeControl.isStopped else { return -1 }
            let head = headProbeFileSize()
            if head > 0 { return head }
            guard !probeControl.isStopped else { return -1 }
            return rangeProbeFileSize(range: "bytes=0-1") ?? -1
        }
        let scope = SourceSizeProbeScope(timeout: min(sourceOpenPolicy.sizeProbeTimeout, chunkRequestTimeout))
        let serial = OriginRequestBudget.shared.requiresSerialRequests(url)
        let forms: [(method: String, range: String?)] = [
            ("GET", "bytes=0-"), ("HEAD", nil), ("GET", "bytes=0-1")
        ]
        EngineLog.emit("[SourceOpen] reader=\(openDiagnosticID) phase=size-probes mode=\(serial ? "serial" : "staggered") budget=\(sourceOpenPolicy.sizeProbeTimeout)s", category: .demux)

        if serial {
            // A fan of probes cannot win a race on a one-request origin. Reserve time for each
            // fallback and return the current ticket before trying the next request shape.
            scope.addWorker()
            Thread.detachNewThread { [self] in
                defer { scope.finishWorker() }
                for (index, form) in forms.enumerated() {
                    guard !scope.isStopped, !isClosed else { return }
                    let budget = scope.remaining / Double(forms.count - index)
                    let size = startupSizeProbe(method: form.method, range: form.range,
                                                budget: budget, scope: scope)
                    if size > 0 { scope.resolve(size); return }
                }
            }
        } else {
            for (index, form) in forms.enumerated() {
                scope.addWorker()
                Thread.detachNewThread { [self] in
                    defer { scope.finishWorker() }
                    guard scope.waitToStart(after: index == 0 ? 0 : Self.sizeProbeStaggerSeconds),
                          !isClosed else { return }
                    let size = startupSizeProbe(method: form.method, range: form.range,
                                                budget: scope.remaining, scope: scope)
                    scope.resolve(size)
                }
            }
        }
        // The scoped deadline and cancellation also observe a closed reader. Join every probe
        // before resuming playback so a losing request cannot occupy the origin's last slot.
        let size = scope.join { [weak self] in self?.isClosed ?? true }
        if size <= 0, !isClosed {
            EngineLog.emit("[SourceOpen] reader=\(openDiagnosticID) phase=size-probes result=unresolved", category: .demux)
        }
        return size
    }

    /// Header-only request used by the playback size discovery. Slot wait and response wait share
    /// one budget. A refused slot is never bypassed for speculative metadata work.
    private func startupSizeProbe(method: String, range: String?, budget: TimeInterval,
                                  scope: SourceSizeProbeScope) -> Int64 {
        let started = DispatchTime.now()
        let deadline = started + max(0, budget)
        func remaining() -> TimeInterval {
            let now = DispatchTime.now().uptimeNanoseconds
            return deadline.uptimeNanoseconds > now
                ? min(scope.remaining, Double(deadline.uptimeNanoseconds - now) / 1_000_000_000) : 0
        }
        var request = URLRequest(engineURL: requestURL())
        request.httpMethod = method
        if let range { request.setValue(range, forHTTPHeaderField: "Range") }
        applyExtraHeaders(&request)
        let ticket: OriginRequestBudget.Ticket?
        EngineLog.emit("[SourceOpen] reader=\(openDiagnosticID) phase=size-probe-start method=\(method) range=\(range ?? "none") budget=\(budget)s", category: .demux)
        do {
            ticket = try requestTicket(for: request.url ?? url,
                label: "\(label)#\(openDiagnosticID) size-\(method)-\(range ?? "none")",
                timeout: min(Self.shortFetchSlotWaitSeconds, remaining()),
                shouldAbort: { scope.isStopped || remaining() <= 0 }, requireGranted: true)
        } catch {
            EngineLog.emit("[SourceOpen] reader=\(openDiagnosticID) phase=size-probe-stop method=\(method) range=\(range ?? "none") reason=slot-unavailable-or-cancelled", category: .demux)
            return -1
        }
        let lease = OriginRequestBudget.Lease(ticket)
        defer { lease.release() }
        guard !scope.isStopped, !isClosed, remaining() > 0 else { return -1 }
        request.timeoutInterval = max(0.001, remaining())
        let delegate = ProbeDelegate(extraHeaders: headers(for: request.url), diagnosticContext: diagnosticContext)
        let task = Self.probeSession.dataTask(with: request)
        task.delegate = delegate
        let completion = DispatchSemaphore(value: 0)
        delegate.onCompletion = { [weak self] response in
            self?.noteRateLimitedResponse(response)
            lease.release()
            completion.signal()
        }
        delegate.onResolved = { [weak self] in
            guard !scope.isStopped else { return }
            self?.recordResolvedURL($0)
        }
        guard scope.resume(task) else { task.cancel(); return -1 }
        defer { scope.remove(task) }
        let outcome = Self.awaitSignal(completion, budget: remaining(), pollInterval: 0.05,
            shouldAbort: { [weak self] in scope.isStopped || self?.isClosed != false })
        // Read delegate fields only after completion transfers ownership. On timeout/cancellation
        // the delegate stays owned by URLSession until its callback; none of its state is read here.
        let size: Int64
        let status: Int
        if outcome == .signaled {
            size = delegate.totalSize ?? -1
            status = delegate.statusCode
            noteTransportSecurityFailure(delegate.error)
        } else {
            task.cancel()
            size = -1
            status = 0
        }
        let elapsed = Double(DispatchTime.now().uptimeNanoseconds - started.uptimeNanoseconds) / 1_000_000
        EngineLog.emit("[SourceOpen] reader=\(openDiagnosticID) phase=size-probe method=\(method) range=\(range ?? "none") slot_ms=\(Int(ticket?.waitedMs ?? 0)) total_ms=\(Int(elapsed)) status=\(status) size=\(size) outcome=\(outcome)", category: .demux)
        return size
    }

    /// Range GET cancelled at didReceive response (no body transfers). Returns the total from
    /// Content-Range on 206, or expectedContentLength on 2xx (origins that ignore Range).
    /// The primary probe is the open-ended bytes=0- form; bytes=0- over bytes=0-0: some origins
    /// special-case the single-byte form and omit length, then 429 the HEAD fallback (issue #70);
    /// bytes=0- answers with a proper Content-Range in one shot. The bounded bytes=0-1 form is
    /// the #126 last-resort probe for origins that answer bytes=0- without a length but honor
    /// real ranges.
    private func rangeProbeFileSize(range: String) -> Int64? {
        var request = URLRequest(engineURL: url)
        request.setValue(range, forHTTPHeaderField: "Range")
        request.timeoutInterval = 20
        applyExtraHeaders(&request)

        // #377: `probeSession` runs on `URLSessionConfiguration.default`, so its own cap is 6 and
        // it composes with nothing. The staggered fan fires two fallbacks at once by design, which
        // on a metered origin is three requests where one was refused. The budget serialises them
        // (each waits its short slot, then proceeds), so the fan keeps its latency win on a healthy
        // origin and stops being a burst on a capped one.
        let ticket: OriginRequestBudget.Ticket?
        do {
            ticket = try requestTicket(
                for: request.url ?? url, label: "\(label) size probe",
                timeout: Self.shortFetchSlotWaitSeconds)
        } catch {
            return nil
        }
        let lease = OriginRequestBudget.Lease(ticket)
        defer { lease.release() }

        let delegate = ProbeDelegate(extraHeaders: headers(for: request.url), diagnosticContext: diagnosticContext)
        let task = (probeRequestSession ?? Self.probeSession).dataTask(with: request)
        task.delegate = delegate

        let semaphore = DispatchSemaphore(value: 0)
        delegate.onCompletion = { [weak self] response in
            self?.noteRateLimitedResponse(response)
            lease.release()
            semaphore.signal()
        }
        delegate.onResolved = { [weak self] resolved in
            self?.recordResolvedURL(resolved)
        }
        task.resume()

        // Bound + make abortable: still extraction caps this at its small budget so a
        // reopen mid-scrub on a stalled source can't park ~25s, and a teardown during
        // open returns at once (issue #27). Playback keeps its 25s ceiling.
        let probeBudget = min(25, chunkRequestTimeout)
        if Self.awaitSignal(semaphore, budget: probeBudget, pollInterval: 0.1,
                            shouldAbort: { [weak self] in
                                self?.isClosed == true
                            }) != .signaled {
            task.cancel()
            finishCancelledProbeRequest(semaphore)
            EngineLog.emit("[AVIOReader] Range probe (\(range)) timed out", category: .demux, level: .verbose)
            return nil
        }

        if delegate.totalSize == nil {
            EngineLog.emit("[AVIOReader] Range probe (\(range)) didn't yield a size", category: .demux, level: .verbose)
        }
        return delegate.totalSize
    }

    /// HEAD probe fallback for live-transcode endpoints that reject Range.
    private func headProbeFileSize() -> Int64 {
        var request = URLRequest(engineURL: url)
        request.httpMethod = "HEAD"
        request.timeoutInterval = 5
        applyExtraHeaders(&request)

        do {
            // Honour the still budget here too so the open-time HEAD fallback can't
            // ride the default 35s on a stalled origin during a cold/reopen scrub (#27).
            let (_, response) = try syncRequest(request, budget: chunkRequestTimeout)
            guard let http = response as? HTTPURLResponse,
                  (200...299).contains(http.statusCode) else {
                let status = (response as? HTTPURLResponse)?.statusCode ?? -1
                EngineLog.emit("[AVIOReader] HEAD failed (HTTP \(status))", category: .demux, level: .verbose)
                return -1
            }
            let length = http.expectedContentLength
            #if DEBUG
            EngineLog.emit("[AVIOReader] File size: \(length) bytes (HEAD fallback)", category: .demux)
            #endif
            return length
        } catch {
            EngineLog.emit("[AVIOReader] HEAD probe failed: \(error.localizedDescription)", category: .demux, level: .verbose)
            return -1
        }
    }

    private func fetchChunk(from offset: Int64, size: Int) -> Data? {
        if let data = fetchChunkAttempt(from: offset, size: size, forceSource: false) {
            return data
        }
        // Retry against source URL only if a cached resolved URL was used
        // (so the proxy can re-issue a fresh signed redirect).
        if cachedResolvedURL() != nil {
            return fetchChunkAttempt(from: offset, size: size, forceSource: true)
        }
        return nil
    }

    private func fetchChunkAttempt(from offset: Int64, size: Int, forceSource: Bool) -> Data? {
        let usingCachedURL = !forceSource && cachedResolvedURL() != nil
        let target = forceSource ? url : requestURL()
        let rangeEnd = offset + Int64(size) - 1
        var request = URLRequest(engineURL: target)
        request.setValue("bytes=\(offset)-\(rangeEnd)", forHTTPHeaderField: "Range")
        request.timeoutInterval = min(15, chunkRequestTimeout)
        applyExtraHeaders(&request)

        var lastError: Error?
        for attempt in 0..<chunkMaxRetries {
            do {
                let budget = probeRangeGrowth?.budget(for: size, base: chunkRequestTimeout) ?? chunkRequestTimeout
                let (data, response) = try syncRequest(request, budget: budget)
                if let http = response as? HTTPURLResponse {
                    let status = http.statusCode
                    if status != 200 && status != 206 {
                        if usingCachedURL && Self.isResolvedExpiryStatus(status) {
                            invalidateResolvedURL()
                        }
                        EngineLog.emit("[AVIOReader] chunk fetch got HTTP \(status) at offset \(offset)\(usingCachedURL ? " (cached URL, will retry source)" : "")", category: .demux, level: .verbose)
                        return nil
                    }
                    // VOD: 200 at offset > 0 = server ignored Range; silent corruption. Reject.
                    if status == 200 && offset > 0 && !isLive {
                        EngineLog.emit(
                            "[AVIOReader] server ignored Range (200 for offset \(offset)); rejecting chunk",
                            category: .demux
                        )
                        return nil
                    }
                    if !isLive, let served = Self.misplacedRangeStart(http, requestedOffset: offset) {
                        EngineLog.emit(
                            "[AVIOReader] chunk fetch: 206 starts at \(served), not \(offset); rejecting (audit DMX-5)",
                            category: .demux
                        )
                        return nil
                    }
                }
                if !isLive, let http = response as? HTTPURLResponse {
                    winCond.lock()
                    if openContentType == nil { openContentType = http.value(forHTTPHeaderField: "Content-Type") }
                    winCond.unlock()
                }
                addBytesFetched(data.count)
                return data
            } catch {
                // Superseded / closed / past the read deadline: this read is disposable,
                // bail at once instead of retrying into the abort (issue #27).
                if isClosed || isPastReadDeadline { return nil }
                lastError = error
                if attempt < chunkMaxRetries - 1 {
                    Thread.sleep(forTimeInterval: Double(1 << attempt) * 0.5)
                }
            }
        }

        EngineLog.emit("[AVIOReader] Fetch failed after \(chunkMaxRetries) retries at offset \(offset): \(lastError?.localizedDescription ?? "?")", category: .demux, level: .verbose)
        return nil
    }

    /// Long-lived session for seekable-path chunk fetches paired with per-task
    /// ChunkFetchDelegate. Delegate-based incremental delivery (not completion-handler)
    /// releases source dispatch_data per delivery on the delegate queue, so the body never
    /// reaches the demux thread's autorelease pool, which is what drove the original leak.
    /// No invalidation overhead.
    private static let chunkSession: URLSession = {
        let config = makeSessionConfig()
        return URLSession(configuration: config, delegate: EngineTLS.sessionDelegate, delegateQueue: AVIOReader.makePlaybackDelegateQueue())
    }()

    /// #220: long-lived session for the persistent streaming path, paired with a per-task
    /// `PersistentReadDelegate`. Bounded ranges end a connection every `persistentRangeBytes`,
    /// and a session per connection would make each of those a fresh TLS handshake against the
    /// origin. The delegate carries the connection generation, so per-task assignment is all
    /// that was ever needed here. The old per-request-session rule does not apply, and #243
    /// showed why it never could: measured against a range origin, a session per request leaks
    /// exactly as much as a shared one (+973 MB vs +968 MB per 480 MB fetched). What retains a
    /// completion-handler body is the never-draining autorelease pool of the demux thread that
    /// bridges it out, not the session. This path is delegate-based, so the body is released on
    /// the delegate queue and never reaches that pool.
    ///
    /// Never invalidated. Releasing a connection is `task.cancel()` now, not session teardown.
    private static let persistentSession: URLSession = {
        URLSession(configuration: makeSessionConfig(longLived: true), delegate: EngineTLS.sessionDelegate, delegateQueue: AVIOReader.makePlaybackDelegateQueue())
    }()

    /// Outcome of an abortable semaphore wait (issue #27).
    enum WaitOutcome: Equatable { case signaled, timedOut, aborted }

    /// Wait on `semaphore` up to `budget` seconds, polling `shouldAbort` every
    /// `pollInterval`. Returns `.signaled` the moment the semaphore fires,
    /// `.aborted` within one poll of `shouldAbort()` going true, or `.timedOut`
    /// when the budget elapses. Lets a seekable chunk read bail promptly on
    /// supersede / close / read-deadline instead of parking the decode queue in a
    /// flat 35s wait (the root cause of the frozen scrub preview, issue #27).
    static func awaitSignal(
        _ semaphore: DispatchSemaphore,
        budget: TimeInterval,
        pollInterval: TimeInterval,
        shouldAbort: () -> Bool
    ) -> WaitOutcome {
        let deadline = Date(timeIntervalSinceNow: budget)
        while true {
            if shouldAbort() { return .aborted }
            let now = Date()
            if now >= deadline { return .timedOut }
            let slice = min(pollInterval, deadline.timeIntervalSince(now))
            if semaphore.wait(timeout: .now() + max(0.001, slice)) == .success {
                return .signaled
            }
        }
    }

    // MARK: - Response Body Bounds (#255)

    /// Reservation ceiling for a response whose request set no bounded `Range`. `Data` grows on
    /// demand, so the cap costs at most one reallocation on a legitimately larger body, while a
    /// bogus or whole-source declared length stays harmless.
    static let maxBodyReserve = 8 * 1024 * 1024

    /// Bytes the request can legitimately deliver: the span of a bounded `Range: bytes=a-b`, 0 for a
    /// HEAD (bodyless by definition), nil when the request is open-ended and the body is whatever the
    /// origin chooses to stream.
    ///
    /// #255: the declared `Content-Length` is not that number and never was. A HEAD answers with the
    /// whole source's length and no body at all, and an origin that ignores `Range` answers a bounded
    /// chunk request with `200` plus the whole source's length, so sizing an allocation from it asked
    /// malloc for the entire 12.4 GB movie at open time. `Data`'s storage force-unwraps the NULL that
    /// a failing malloc returns, so it traps: a host app can neither catch it nor degrade.
    static func expectedBodyBytes(for request: URLRequest) -> Int? {
        if request.httpMethod?.uppercased() == "HEAD" { return 0 }
        guard let value = request.value(forHTTPHeaderField: "Range") else { return nil }
        return boundedRangeSpan(value)
    }

    /// Span of a single bounded byte range (`bytes=a-b`). Nil for the open-ended (`bytes=a-`), suffix
    /// (`bytes=-n`), multi-range and malformed forms: none of those bound the body, so they fall back
    /// to the flat ceiling rather than a wrong limit.
    static func boundedRangeSpan(_ headerValue: String) -> Int? {
        let spec = headerValue.trimmingCharacters(in: .whitespaces)
        guard spec.lowercased().hasPrefix("bytes=") else { return nil }
        let set = spec.dropFirst("bytes=".count)
        guard !set.contains(",") else { return nil }
        let parts = set.split(separator: "-", omittingEmptySubsequences: false)
        guard parts.count == 2,
              let lower = Int64(parts[0]), let upper = Int64(parts[1]),
              lower >= 0, upper >= lower else { return nil }
        let span = upper - lower + 1
        return span <= Int64(Int.max) ? Int(span) : nil
    }

    /// Bytes to reserve up front for a response body: the origin's declared length clamped to what
    /// the request itself can deliver, or to `maxBodyReserve` when the request is open-ended.
    static func bodyReservation(declaredLength: Int64, limit: Int?) -> Int {
        guard declaredLength > 0 else { return 0 }
        let ceiling = Int64(limit ?? maxBodyReserve)
        guard ceiling > 0 else { return 0 }
        return Int(min(declaredLength, ceiling))
    }

    /// #255 test hook: the largest up-front body reservation any of THIS reader's chunk fetches has
    /// asked for. Per reader, not process-wide, so a suite running in parallel cannot raise it.
    /// Lock-protected; raised from each fetch's delegate.
    var peakBodyReserveForTesting: Int { peakBodyReserveLock.withLock { peakBodyReserve } }
    private let peakBodyReserveLock = NSLock()
    private var peakBodyReserve = 0

    private func requestTicket(for url: URL, label: String,
                               timeout: TimeInterval, shouldAbort: (() -> Bool)? = nil,
                               requireGranted: Bool = false) throws -> OriginRequestBudget.Ticket? {
        guard let probeControl else {
            let ticket = OriginRequestBudget.shared.acquire(
                for: url, label: label, timeout: timeout,
                allowOvercommit: !requireGranted,
                shouldAbort: { [weak self] in (self?.isClosed ?? true) || (shouldAbort?() ?? false) })
            if isClosed || (shouldAbort?() ?? false) || (requireGranted && ticket?.granted != true) {
                OriginRequestBudget.shared.release(ticket)
                throw CancellationError()
            }
            return ticket
        }
        guard !isClosed else { throw CancellationError() }
        try probeControl.check()
        // Wait for the slot, but never past the probe's own deadline. A slot wait is the one wait the
        // watchdog cannot interrupt (it fires at reads), so the deadline has to bound it here instead.
        // Not waiting at all would fail a probe that merely arrived while one other request held the
        // origin, which is the ordinary shape when a host probes several items off one server.
        let slotWait = probeControl.remainingTime.map { min(timeout, $0) } ?? timeout
        guard let ticket = OriginRequestBudget.shared.acquire(
            for: url, label: label, timeout: slotWait) else {
            probeControl.stop(ProbeError.sourceBusy)
            throw ProbeError.sourceBusy
        }
        do { try probeControl.check() }
        catch {
            OriginRequestBudget.shared.release(ticket)
            throw error
        }
        return ticket
    }

    /// Only the probe adapter calls this, after cancelling the transfer.
    func finishProbeTransfers() {
        precondition(probeControl != nil)
        prefetchQueue.sync {}
    }

    var isDrainingProbeRequestForTesting: Bool {
        probeDrainLock.withLock { drainingProbeRequest }
    }

    private func finishCancelledProbeRequest(_ completion: DispatchSemaphore) {
        guard probeControl != nil else { return }
        probeDrainLock.withLock { drainingProbeRequest = true }
        defer { probeDrainLock.withLock { drainingProbeRequest = false } }
        // Keep the origin ticket and callback state until this task acknowledges cancellation.
        completion.wait()
    }

    private func syncRequest(_ request: URLRequest, budget: TimeInterval = 35,
                             slotLabel: String = "fetch",
                             slotWait: TimeInterval = AVIOReader.shortFetchSlotWaitSeconds) throws -> (Data, URLResponse) {
        // #377: every short fetch the reader makes (detour blocks, size probes, HEAD) funnels
        // through here, so this is the one place that has to take an origin slot for all of them.
        // Refusals are charged before the completion callback returns the slot. Early exit
        // releases the same lease idempotently.
        let slotURL = request.url ?? url
        let ticket = try requestTicket(
            for: slotURL, label: "\(label) \(slotLabel)", timeout: slotWait)
        let lease = OriginRequestBudget.Lease(ticket)
        defer { lease.release() }

        let delegate = ChunkFetchDelegate(extraHeaders: headers(for: request.url),
                                          bodyLimit: Self.expectedBodyBytes(for: request), diagnosticContext: diagnosticContext)
        let task = (probeRequestSession ?? Self.chunkSession).dataTask(with: request)
        task.delegate = delegate
        delegate.onBodyReserve = { [weak self] reserve in
            guard let self else { return }
            self.peakBodyReserveLock.withLock { self.peakBodyReserve = max(self.peakBodyReserve, reserve) }
        }

        let semaphore = DispatchSemaphore(value: 0)
        delegate.onCompletion = { [weak self] response in
            self?.noteRateLimitedResponse(response)
            lease.release()
            semaphore.signal()
        }
        delegate.onResolved = { [weak self] resolved in
            self?.recordResolvedURL(resolved)
        }
        task.resume()

        // Poll for close / read-deadline so a superseded or torn-down still-extraction
        // read aborts within ~100ms instead of riding the full budget (issue #27).
        let outcome = Self.awaitSignal(
            semaphore, budget: budget, pollInterval: 0.1,
            shouldAbort: { [weak self] in self?.isClosed == true || self?.readDeadlinePassedOrAborted == true }
        )
        guard outcome == .signaled else {
            task.cancel()
            finishCancelledProbeRequest(semaphore)
            throw AVIOReaderError.requestTimeout
        }

        // A truncating cancel is this reader hanging up on purpose, so the cancellation error it
        // produces is not a failed fetch: the prefix the request asked for is in hand (#255).
        if let err = delegate.error, !delegate.truncated {
            noteTransportSecurityFailure(err)
            throw err
        }
        guard let response = delegate.response else { throw AVIOReaderError.noResponse }
        if delegate.truncated {
            EngineLog.emit(
                "[AVIOReader] response body ran past the requested range; kept \(delegate.body.count) bytes and hung up (origin ignored Range?)",
                category: .demux, level: .verbose
            )
        }
        return (delegate.body, response)
    }
}

// MARK: - Detour Block Cache

/// Fixed-block LRU cache backing the persistent reader's detour path (AetherEngine#69). Random-access
/// parse reads on a non-faststart remote MP4 are served from here over the pooled keep-alive session
/// instead of tearing down the anchored streaming connection. Thread-safe via a single leaf lock
/// (demux-thread reads + teardown-thread `clear`); never held across the network. Stores only
/// full-size blocks (the fetch/insert decision is the caller's), so eviction can't shadow a
/// re-fetchable short-body tail. The copy + eviction math is pure and unit-tested without a network.
///
/// #909: the capacity starts at `maxBlocks` and grows by one, up to `ceilingBlocks`, each time a block
/// it evicted is inserted again, which is the signature of a cyclic working set larger than the cache.
/// The idle sweep shrinks it back toward what is still resident.
final class DetourBlockCache: @unchecked Sendable {
    private let lock = NSLock()
    private var blocks: [Int64: Data] = [:]
    private var lru: [Int64] = []
    /// When each resident block was last inserted or served, on `now`'s clock (audit PERF-108).
    private var lastHit: [Int64: TimeInterval] = [:]
    /// Blocks evicted for capacity, oldest first, at most `ceilingBlocks` of them.
    private var evictedForCapacity: [Int64] = []
    private let maxBlocks: Int
    private let ceilingBlocks: Int
    private var currentCapacity: Int
    private let now: @Sendable () -> TimeInterval
    let blockSize: Int

    /// `now` is injectable so the idle test moves a clock instead of waiting one out. Without a
    /// `ceilingBlocks` the cache never grows past `maxBlocks`.
    init(blockSize: Int, maxBlocks: Int, ceilingBlocks: Int? = nil,
         now: @escaping @Sendable () -> TimeInterval = { ProcessInfo.processInfo.systemUptime }) {
        self.blockSize = blockSize
        self.maxBlocks = maxBlocks
        self.ceilingBlocks = max(maxBlocks, ceilingBlocks ?? maxBlocks)
        self.currentCapacity = maxBlocks
        self.now = now
    }

    var capacity: Int {
        lock.lock(); defer { lock.unlock() }
        return currentCapacity
    }

    /// Returns the resident block for `idx` and bumps its recency, or nil on a miss.
    func block(_ idx: Int64) -> Data? {
        lock.lock(); defer { lock.unlock() }
        guard let data = blocks[idx] else { return nil }
        if let i = lru.firstIndex(of: idx) {
            lru.remove(at: i)
            lru.append(idx)
        }
        lastHit[idx] = now()
        return data
    }

    /// Inserts a (full-size) block, evicting the least-recently-used tail beyond the capacity.
    func insert(_ idx: Int64, _ data: Data) {
        lock.lock(); defer { lock.unlock() }
        if blocks[idx] == nil {
            if let i = evictedForCapacity.firstIndex(of: idx) {
                // The evictions since this one are about how far the working set outruns the cache. A
                // cycle the ceiling cannot hold misses at every capacity, so growing toward it only
                // holds more memory for the same fetches.
                let outrun = evictedForCapacity.count - i
                evictedForCapacity.remove(at: i)
                if currentCapacity + outrun <= ceilingBlocks { currentCapacity += 1 }
            }
            lru.append(idx)
        }
        blocks[idx] = data
        lastHit[idx] = now()
        while lru.count > currentCapacity {
            let evicted = lru.removeFirst()
            blocks.removeValue(forKey: evicted)
            lastHit[evicted] = nil
            evictedForCapacity.append(evicted)
            if evictedForCapacity.count > ceilingBlocks { evictedForCapacity.removeFirst() }
        }
    }

    /// Drops every block nothing has read or filled for `seconds`, and returns how many went. The
    /// cache is otherwise only emptied at close, so the blocks of a backward scrub (up to 32 MB)
    /// outlived the scrub for the whole session (audit PERF-108). Age rather than a clear at the
    /// re-anchor, because a parser ping-ponging through a region keeps hitting its blocks.
    @discardableResult
    func evictIdle(olderThan seconds: TimeInterval) -> Int {
        lock.lock(); defer { lock.unlock() }
        let cutoff = now() - seconds
        let idle = lru.filter { (lastHit[$0] ?? 0) < cutoff }
        guard !idle.isEmpty else { return 0 }
        let gone = Set(idle)
        lru.removeAll { gone.contains($0) }
        for idx in idle {
            blocks.removeValue(forKey: idx)
            lastHit[idx] = nil
        }
        currentCapacity = max(maxBlocks, min(currentCapacity, lru.count))
        return idle.count
    }

    func clear() {
        lock.lock()
        blocks.removeAll()
        lru.removeAll()
        lastHit.removeAll()
        evictedForCapacity.removeAll()
        currentCapacity = maxBlocks
        lock.unlock()
    }

    var residentCount: Int {
        lock.lock(); defer { lock.unlock() }
        return blocks.count
    }

    /// Copy up to `maxLen` bytes covering `offset` from the resident block into `dst`, returning the
    /// byte count. Returns nil if the covering block is not resident, or if `offset` lands in the
    /// uncovered tail of a short block (so the caller re-fetches rather than serving stale bytes).
    /// One call serves at most to the block boundary; a read spanning blocks is driven by the caller
    /// re-entering at the advanced offset. Pure given the cache contents; bumps recency on a hit.
    func serveCached(into dst: UnsafeMutablePointer<UInt8>, maxLen: Int, at offset: Int64) -> Int? {
        guard maxLen > 0, offset >= 0 else { return nil }
        let idx = offset / Int64(blockSize)
        let blockStart = idx * Int64(blockSize)
        guard let blk = block(idx) else { return nil }
        let inBlock = Int(offset - blockStart)
        guard inBlock >= 0, inBlock < blk.count else { return nil }
        let n = min(maxLen, blk.count - inBlock)
        blk.withUnsafeBytes { raw in
            if let base = raw.baseAddress {
                dst.update(from: base.advanced(by: inBlock).assumingMemoryBound(to: UInt8.self), count: n)
            }
        }
        return n
    }
}

/// Preserves Range + extra headers across cross-host redirects. URLSession strips
/// custom headers on host change; without this, CDN behind AIOStreams proxy gets a
/// plain GET and either streams the full body or 400s. Credential headers follow
/// RedirectHeaderPolicy (#126): same-host destinations only, never cross-origin.
private func redirectPreservingHeaders(
    task: URLSessionTask,
    newRequest request: URLRequest,
    extraHeaders: [String: String]
) -> URLRequest {
    // #388: this is the moment the request the reader budgeted for stops being answered by the
    // origin it was budgeted against. Every fetch the reader makes passes through here, so it is
    // the one place that sees the whole chain, including the hops no response ever pins (a target
    // that answers the very first request with a 509 is never recorded as resolved).
    // Noted after the policy so an https-upgraded hop (#954) books the origin it actually reaches.
    let next = RedirectHeaderPolicy.redirectRequest(
        request,
        originalURL: task.originalRequest?.url,
        originalRange: task.originalRequest?.value(forHTTPHeaderField: "Range"),
        extraHeaders: extraHeaders)
    if let from = task.originalRequest?.url, let to = next.url {
        OriginRequestBudget.shared.noteRedirect(from: from, to: to)
    }
    return next
}

// MARK: - Persistent Read Delegate

/// Forwards deliveries into the reader's sliding window with generation tagging
/// so stale-connection late callbacks are no-ops. @unchecked Sendable: only
/// mutable coupling is weak reader, guarded by winCond.
// MARK: - #377 held connection

extension AVIOReader: HeldSourceConnectionDelegate {
    func heldConnection(_ connection: HeldSourceConnection,
                        didReceive response: HTTPURLResponse,
                        from url: URL) -> Bool {
        persistentReceivedResponse(response, respondedBy: url, generation: connection.generation)
    }

    func heldConnection(_ connection: HeldSourceConnection, didReceive data: Data) {
        appendPersistentData(data, generation: connection.generation)
    }

    /// How many bytes the held connection may pull next, and the one place this flag's #310
    /// exposure is decided.
    ///
    /// #310's dose is the LENGTH of a dormant stretch rather than its existence, and a pull that
    /// tops the window up as the consumer takes bytes is dormant for `heldPullSlack` over media
    /// rate, which is the regime the starvation never fired in. The stretch that is NOT bounded
    /// that way is a consumer which has STOPPED: a paused viewer holds one for the length of the
    /// pause, and that is where #310's worst episode came from. So a pause carries a budget, and
    /// running it out ends the connection exactly the way the high water ends a pushed one. The
    /// read loop then re-requests at the frontier when playback resumes, which is the same path a
    /// completed range takes.
    ///
    /// A FULL WINDOW IS NOT THAT CASE, and reading it as one is what this method got wrong until
    /// the field hour on the reporter's origin: 213 connections ended in 60 minutes with the viewer
    /// never pausing once, because the segment producer races ahead, parks with a full cache while
    /// the muxer works, and looks from here exactly like a consumer that stopped. That is 218
    /// requests where the design describes one, and against an origin that refuses requests it is
    /// 218 chances to be refused. So a playing consumer on a full window is waited out, not ended.
    /// Waiting costs nothing on the wire: no read is issued, the socket buffer fills, and the
    /// sender stops itself, which is what ffmpeg's reader does whenever its demuxer stops reading.
    /// The 16 MB window stays what it always was, a ceiling on a transport that could not be
    /// stopped (#174 crashed at 3.4 GB still delivering, #220 measured 911 MB after a suspend);
    /// a pull transport has no such problem, so here the window fills and drains rather than being
    /// held under. On the device, arm B of the transport probe held a stream task on a closed
    /// window for 600 s with 1 Hz canaries against the origin and a neutral host clean throughout,
    /// 1180 requests and not one refusal.
    ///
    /// Blocks on `winCond`, which is what the consumer broadcasts on after every read, so a
    /// generation that is abandoned (a seek, a close, a reconnect) wakes this immediately and
    /// answers 0 rather than waiting out its budget.
    func heldConnectionPullBudget(_ connection: HeldSourceConnection) -> Int {
        var budget = 0
        var pausedEndAhead: Int? = nil
        // Only a paused consumer carries a deadline, and only from the moment it paused.
        var pauseDeadline: Date? = nil
        winCond.lock()
        while true {
            guard connection.generation == connGeneration, !connEnded, !isClosed else { break }
            let ahead = windowAheadLocked()
            let room = winHighWater - ahead
            if room >= Self.heldPullSlack {
                budget = min(room, Self.heldMaxPullBytes)
                // A read begins here, and the gap watchdog judges an OUTSTANDING one. Without this
                // the wait that preceded the grant counts against the read it granted: coming back
                // from a park longer than connStallTimeout, the first tick after this would see a
                // gap older than the timeout and end a connection nothing is wrong with.
                lastDeliveryAt = DispatchTime.now()
                break
            }
            let playing = playIntentProvider?() ?? false
            if playing {
                // A full window under a playing consumer is the producer parked with a full
                // segment cache, not a stopped one. Issue no read and wait: no byte is on the
                // wire, the socket fills, and the sender stops itself.
                //
                // The wait carries a poll rather than blocking outright, because the thing it is
                // waiting to hear about does not broadcast: nobody reads during a pause, so a
                // consumer that pauses AFTER the window filled would never wake this loop and the
                // paused budget below would never start. Measured: a 420 s pause held the
                // connection to the end of the drill with no bound spent.
                pauseDeadline = nil
                _ = winCond.wait(until: Date().addingTimeInterval(Self.heldPlayIntentPollSeconds))
                continue
            }
            let deadline = pauseDeadline ?? Date().addingTimeInterval(heldPausedBudgetSeconds)
            pauseDeadline = deadline
            if Date() >= deadline {
                connEndedByBackpressure = true
                connEnded = true
                activeTransfer = nil
                pausedEndAhead = ahead
                winCond.broadcast()
                break
            }
            _ = winCond.wait(until: deadline)
        }
        winCond.unlock()
        if let pausedEndAhead {
            EngineLog.emit(
                "[AVIOReader] \(label) held connection paused for "
                + "\(Int(heldPausedBudgetSeconds))s with \(pausedEndAhead / 1024 / 1024)MB "
                + "ahead; ending it, will re-request at the frontier when playback resumes",
                category: .demux)
        }
        return budget
    }

    func heldConnection(_ connection: HeldSourceConnection, didEndWith error: Error?) {
        connection.releaseOriginTicket()
        persistentConnectionEnded(error: error, generation: connection.generation)
    }
}

// MARK: - Persistent transfer

/// #377: the one request this reader has on the link, whichever transport carries it.
///
/// Two shapes exist. A `URLSessionDataTask` is PUSHED: it delivers on the transport's schedule and
/// the only backpressure available is to end it, which is why the reader ends its connection at the
/// window high water and asks again at low water (#310, after #220 measured the suspend advisory).
/// A `HeldSourceConnection` is PULLED: nothing arrives that was not asked for, so one request can
/// serve a whole file, which is the entire point of `LoadOptions.heldSourceConnection`.
protocol PersistentTransfer: AnyObject {
    /// Put it on the link. Called once, after the reader has installed it.
    func startTransfer()
    /// End it. Idempotent, and never called while `winCond` is held.
    func cancelTransfer()
    /// Hand the origin slot back synchronously. The transfer's own completion would do it too, but
    /// that arrives asynchronously and every caller here is about to ask for a slot again.
    /// Idempotent, so the later callback is a no-op.
    func releaseOriginTicket()
    /// True when bytes only move because the reader asked. The high-water end exists to stop a
    /// transport delivering on its own schedule; against a pull it would end a healthy connection
    /// and put back the request cadence the held path exists to remove.
    var isDemandDriven: Bool { get }
}

extension URLSessionDataTask: PersistentTransfer {
    func startTransfer() { resume() }
    func cancelTransfer() { cancel() }
    /// The ticket lives on the delegate because the delegate's lifetime IS the task's; see the
    /// note on `PersistentReadDelegate.ticket`.
    func releaseOriginTicket() { (delegate as? PersistentReadDelegate)?.releaseTicket() }
    var isDemandDriven: Bool { false }
}

private final class PersistentReadDelegate: NSObject, URLSessionDataDelegate, @unchecked Sendable {
    private let sourceTrace: SourceNetworkDiagnostics.Trace
    weak var reader: AVIOReader?
    let generation: Int
    let extraHeaders: [String: String]
    /// #377: the origin slot this connection occupies, held here because the delegate's lifetime
    /// IS the task's. Seven paths in the reader clear `activeTransfer` and only one of them is the
    /// task ending, so a ticket released alongside `activeTransfer` would leak on the other six.
    /// `didCompleteWithError` is the one point every ending passes through, cancels included.
    private let ticketLock = NSLock()
    private var ticket: OriginRequestBudget.Ticket?
    /// The URL this connection was opened against, for the one-per-origin transport line.
    private let originURL: URL

    init(reader: AVIOReader, diagnosticContext: SourceNetworkDiagnostics.Context?, generation: Int, extraHeaders: [String: String],
         ticket: OriginRequestBudget.Ticket?, originURL: URL) {
        self.sourceTrace = .init(role: .persistentRead, context: diagnosticContext)
        self.reader = reader
        self.generation = generation
        self.extraHeaders = extraHeaders
        self.ticket = ticket
        self.originURL = originURL
    }

    /// Backstop. A slot that is never returned would cap this origin one lower for the life of the
    /// process, and at a limit of 1 that means every later request waits out its full budget before
    /// proceeding. `didCompleteWithError` covers every ending a task actually reaches; this covers
    /// a delegate that is released without its task ever completing.
    deinit { releaseTicket() }

    /// Give the slot back. Idempotent: a reconnect releases synchronously so the pump does not
    /// queue behind its own previous range, and `didCompleteWithError` then finds nothing to do.
    func releaseTicket() {
        ticketLock.lock()
        let held = ticket
        ticket = nil
        ticketLock.unlock()
        OriginRequestBudget.shared.release(held)
    }

    func urlSession(
        _ session: URLSession,
        task: URLSessionTask,
        didReceive challenge: URLAuthenticationChallenge,
        completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void
    ) {
        EngineTLS.resolve(challenge, completionHandler: completionHandler)
    }

    func urlSession(
        _ session: URLSession,
        task: URLSessionTask,
        willPerformHTTPRedirection response: HTTPURLResponse,
        newRequest request: URLRequest,
        completionHandler: @escaping (URLRequest?) -> Void
    ) {
        sourceTrace.redirect(task: task, response: response, request: request)
        completionHandler(redirectPreservingHeaders(
            task: task, newRequest: request, extraHeaders: extraHeaders))
    }

    func urlSession(
        _ session: URLSession,
        dataTask: URLSessionDataTask,
        didReceive response: URLResponse,
        completionHandler: @escaping (URLSession.ResponseDisposition) -> Void
    ) {
        sourceTrace.response(task: dataTask, response: response)
        guard let http = response as? HTTPURLResponse, let reader else {
            completionHandler(.cancel)
            return
        }
        // #377: unconditional, and the 2xx gate for pinning moved into the reader with the comment
        // that explains it. A refused response has a host too, and after a pin drop that host is
        // the whole question (source, the dropped target minted again, or a fresh one).
        let respondedBy = dataTask.currentRequest?.url ?? http.url
        let allow = reader.persistentReceivedResponse(
            http, respondedBy: respondedBy, generation: generation
        )
        completionHandler(allow ? .allow : .cancel)
    }

    func urlSession(
        _ session: URLSession,
        dataTask: URLSessionDataTask,
        didReceive data: Data
    ) {
        reader?.appendPersistentData(data, generation: generation)
    }

    func urlSession(
        _ session: URLSession,
        task: URLSessionTask,
        didCompleteWithError error: Error?
    ) {
        sourceTrace.completed(task: task, error: error)
        releaseTicket()
        reader?.persistentConnectionEnded(error: error, generation: generation)
    }

    /// #377: the reporter's open question was whether a per-session connection cap can do anything
    /// against their CDN, and it is unanswerable from outside the engine. This is the only place
    /// that names the transport.
    func urlSession(
        _ session: URLSession,
        task: URLSessionTask,
        didFinishCollecting metrics: URLSessionTaskMetrics
    ) {
        sourceTrace.metrics(task: task, metrics: metrics)
        ReaderTransportLog.note(metrics, for: originURL)
        let hops = metrics.transactionMetrics.compactMap(AVIOReader.hopTiming)
        if let line = AVIOReader.slowFirstByteLine(
            taskSeconds: metrics.taskInterval.duration,
            hops: hops
        ) {
            EngineLog.emit(line, category: .engine)
        }
    }
}

// MARK: - Chunk Fetch Delegate

/// Single-use per fetch; force-copies each delivery into `body` so source
/// dispatch_data is released per delivery. @unchecked Sendable: ownership
/// via semaphore ensures no concurrent access to mutable fields.
private final class ChunkFetchDelegate: NSObject, URLSessionDataDelegate, @unchecked Sendable {
    private let sourceTrace: SourceNetworkDiagnostics.Trace
    let extraHeaders: [String: String]
    /// Most this fetch will ever buffer, nil when the request is open-ended (#255). Derived from
    /// the request, never from the response: a declared length is the origin's claim about the
    /// whole source, not about this body.
    let bodyLimit: Int?
    var body = Data()
    var response: URLResponse?
    var error: Error?
    /// Set when the origin sent past `bodyLimit` and the task was cancelled mid-body, so the
    /// caller reads the kept prefix as a success instead of a cancellation failure.
    var truncated = false
    var onCompletion: ((HTTPURLResponse?) -> Void)?
    var onResolved: ((URL) -> Void)?
    /// Reports the up-front reservation each response asked for (#255 test hook).
    var onBodyReserve: ((Int) -> Void)?

    init(extraHeaders: [String: String], bodyLimit: Int?, diagnosticContext: SourceNetworkDiagnostics.Context?) {
        self.sourceTrace = .init(role: .chunkFetch, context: diagnosticContext)
        self.extraHeaders = extraHeaders
        self.bodyLimit = bodyLimit
    }

    func urlSession(
        _ session: URLSession,
        task: URLSessionTask,
        didReceive challenge: URLAuthenticationChallenge,
        completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void
    ) {
        EngineTLS.resolve(challenge, completionHandler: completionHandler)
    }

    func urlSession(
        _ session: URLSession,
        task: URLSessionTask,
        willPerformHTTPRedirection response: HTTPURLResponse,
        newRequest request: URLRequest,
        completionHandler: @escaping (URLRequest?) -> Void
    ) {
        sourceTrace.redirect(task: task, response: response, request: request)
        completionHandler(redirectPreservingHeaders(
            task: task, newRequest: request, extraHeaders: extraHeaders))
    }

    func urlSession(
        _ session: URLSession,
        dataTask: URLSessionDataTask,
        didReceive response: URLResponse,
        completionHandler: @escaping (URLSession.ResponseDisposition) -> Void
    ) {
        sourceTrace.response(task: dataTask, response: response)
        self.response = response
        if let http = response as? HTTPURLResponse {
            let reserve = AVIOReader.bodyReservation(
                declaredLength: http.expectedContentLength, limit: bodyLimit)
            onBodyReserve?(reserve)
            if reserve > 0 { body.reserveCapacity(reserve) }
            let status = http.statusCode
            if status == 200 || status == 206,
               let resolved = dataTask.currentRequest?.url {
                onResolved?(resolved)
            }
        }
        completionHandler(.allow)
    }

    func urlSession(
        _ session: URLSession,
        dataTask: URLSessionDataTask,
        didReceive data: Data
    ) {
        var count = data.count
        var overshoot = false
        if let bodyLimit {
            // Past what the request asked for means the origin ignored the Range and is streaming
            // the whole source at us. Keep the prefix the caller wanted and hang up, rather than
            // buffer a 12 GB movie in order to reject it afterwards (#255).
            let room = bodyLimit - body.count
            if count > room {
                count = max(0, room)
                overshoot = true
            }
        }
        if count > 0 {
            // Force-copy: body.append(data) may retain source dispatch_data via CoW,
            // defeating the per-delivery release. Manual memcpy guarantees drop on return.
            let baseCount = body.count
            body.count = baseCount + count
            body.withUnsafeMutableBytes { dst in
                data.withUnsafeBytes { src in
                    if let dstBase = dst.baseAddress, let srcBase = src.baseAddress {
                        (dstBase + baseCount).copyMemory(from: srcBase, byteCount: count)
                    }
                }
            }
        }
        if overshoot {
            truncated = true
            dataTask.cancel()
        }
    }

    func urlSession(
        _ session: URLSession,
        task: URLSessionTask,
        didCompleteWithError error: Error?
    ) {
        sourceTrace.completed(task: task, error: error)
        self.error = error
        onCompletion?(response as? HTTPURLResponse)
    }
    func urlSession(_ session: URLSession, task: URLSessionTask, didFinishCollecting metrics: URLSessionTaskMetrics) {
        sourceTrace.metrics(task: task, metrics: metrics)
    }

}

// MARK: - Streaming Delegate

private final class StreamingDelegate: NSObject, URLSessionDataDelegate {
    private let sourceTrace: SourceNetworkDiagnostics.Trace
    let onData: @Sendable (Data) -> Void
    let onComplete: @Sendable (Error?) -> Void
    /// Response hook (advisory Content-Length capture on the sequential-origin path).
    let onResponse: (@Sendable (URLResponse) -> Void)?
    /// The origin answered with a status instead of media (anything but 200/206). Called at the
    /// response header, before the hang-up, so the reader can fail the open typed. Carries the URL
    /// that answered, redirects followed: on a source that 302s to an edge target, the refusing
    /// host is not the one the request named (#377).
    let onRefused: (@Sendable (Int, URL?) -> Void)?
    /// Re-applied across cross-host redirects like every other delegate in this file;
    /// IPTV origins routinely 302 twice (portal -> panel -> archive host) and the final
    /// host must still see the caller's User-Agent / auth headers.
    let extraHeaders: [String: String]

    init(
        diagnosticContext: SourceNetworkDiagnostics.Context?,
        extraHeaders: [String: String] = [:],
        onResponse: (@Sendable (URLResponse) -> Void)? = nil,
        onRefused: (@Sendable (Int, URL?) -> Void)? = nil,
        onData: @escaping @Sendable (Data) -> Void,
        onComplete: @escaping @Sendable (Error?) -> Void
    ) {
        self.extraHeaders = extraHeaders
        self.sourceTrace = .init(role: .streaming, context: diagnosticContext)
        self.onResponse = onResponse
        self.onRefused = onRefused
        self.onData = onData
        self.onComplete = onComplete
    }

    func urlSession(
        _ session: URLSession,
        task: URLSessionTask,
        willPerformHTTPRedirection response: HTTPURLResponse,
        newRequest request: URLRequest,
        completionHandler: @escaping (URLRequest?) -> Void
    ) {
        sourceTrace.redirect(task: task, response: response, request: request)
        completionHandler(redirectPreservingHeaders(
            task: task, newRequest: request, extraHeaders: extraHeaders))
    }

    func urlSession(
        _ session: URLSession,
        task: URLSessionTask,
        didReceive challenge: URLAuthenticationChallenge,
        completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void
    ) {
        EngineTLS.resolve(challenge, completionHandler: completionHandler)
    }

    func urlSession(
        _ session: URLSession,
        dataTask: URLSessionDataTask,
        didReceive response: URLResponse,
        completionHandler: @escaping (URLSession.ResponseDisposition) -> Void
    ) {
        sourceTrace.response(task: dataTask, response: response)
        // Redirects never reach here (willPerformHTTPRedirection follows them), so anything but
        // a 200/206 is the origin's verdict, not media: a 401/403 refusal, a 404, a 429, a 5xx.
        // Hang up at the header so the error page never enters the stream buffer, where FFmpeg
        // would probe it as container bytes and report "Invalid data found when processing
        // input" for what was a refusal (#378).
        if let http = response as? HTTPURLResponse, http.statusCode != 200, http.statusCode != 206 {
            onRefused?(http.statusCode, dataTask.currentRequest?.url ?? http.url)
            completionHandler(.cancel)
            return
        }
        onResponse?(response)
        completionHandler(.allow)
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        onData(data)
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        sourceTrace.completed(task: task, error: error)
        #if DEBUG
        if let error {
            EngineLog.emit("[AVIOReader] Stream error: \(error.localizedDescription)", category: .demux)
        }
        #endif
        onComplete(error)
    }
    func urlSession(_ session: URLSession, task: URLSessionTask, didFinishCollecting metrics: URLSessionTaskMetrics) {
        sourceTrace.metrics(task: task, metrics: metrics)
    }

}

// MARK: - Probe Delegate

/// File-size Range probe delegate. Preserves Range across cross-host redirects,
/// captures total from Content-Range, cancels before the body streams.
/// @unchecked Sendable: single-use per probe, semaphore ownership prevents concurrency.
private final class ProbeDelegate: NSObject, URLSessionDataDelegate, @unchecked Sendable {
    private let sourceTrace: SourceNetworkDiagnostics.Trace
    let extraHeaders: [String: String]
    var totalSize: Int64?
    var statusCode: Int = 0
    var response: HTTPURLResponse?
    var error: Error?
    var onCompletion: ((HTTPURLResponse?) -> Void)?
    var onResolved: ((URL) -> Void)?

    init(extraHeaders: [String: String], diagnosticContext: SourceNetworkDiagnostics.Context?) {
        self.sourceTrace = .init(role: .probe, context: diagnosticContext)
        self.extraHeaders = extraHeaders
    }

    func urlSession(
        _ session: URLSession,
        task: URLSessionTask,
        didReceive challenge: URLAuthenticationChallenge,
        completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void
    ) {
        EngineTLS.resolve(challenge, completionHandler: completionHandler)
    }

    func urlSession(
        _ session: URLSession,
        task: URLSessionTask,
        willPerformHTTPRedirection response: HTTPURLResponse,
        newRequest request: URLRequest,
        completionHandler: @escaping (URLRequest?) -> Void
    ) {
        sourceTrace.redirect(task: task, response: response, request: request)
        completionHandler(redirectPreservingHeaders(
            task: task, newRequest: request, extraHeaders: extraHeaders))
    }

    func urlSession(
        _ session: URLSession,
        dataTask: URLSessionDataTask,
        didReceive response: URLResponse,
        completionHandler: @escaping (URLSession.ResponseDisposition) -> Void
    ) {
        sourceTrace.response(task: dataTask, response: response)
        defer { completionHandler(.cancel) }
        guard let http = response as? HTTPURLResponse else { return }
        let status = http.statusCode
        statusCode = status
        self.response = http
        if (200...299).contains(status), let resolved = dataTask.currentRequest?.url {
            onResolved?(resolved)
        }
        // The probe requests `bytes=0-`, so requestedOffset is 0. Shared with the
        // data-connection path so a 206 with an unknown (`*`) total never reports its
        // partial Content-Length as the size (issue #70 review #6).
        totalSize = AVIOReader.sizeFromResponse(http, requestedOffset: 0)
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        sourceTrace.completed(task: task, error: error)
        self.error = error
        onCompletion?(response)
    }
    func urlSession(_ session: URLSession, task: URLSessionTask, didFinishCollecting metrics: URLSessionTaskMetrics) {
        sourceTrace.metrics(task: task, metrics: metrics)
    }

}

/// Which origins have already shown they cannot answer a suffix range, so the next open does not
/// ask them again.
///
/// #281 retest: the reporter's origin answers `bytes=-65536` with a 200 and the WHOLE file, on every
/// single open. The delegate hangs up at the response header so the body is never taken, but the
/// request is not therefore free: it is a second connection opened at the same instant as the data
/// connection whose first byte IS the cold start, sharing that uplink, against a server that has
/// already demonstrated it cannot serve it. A request that structurally cannot be answered belongs
/// once per origin, not once per open.
///
/// Only the origin's own answer to the RANGE FORM latches (a 200 that ignored it, a 416 that rejected
/// it, a Content-Range that does not describe the span, a short body). A transport failure is the
/// network's rather than the server's, and a link bad enough to time out this request will time out
/// others, so it takes two before the origin is judged by it. A status about the resource or the
/// moment (401/403/404/410, 429/503/509, other 5xx) says nothing about suffix ranges and never
/// latches: it repeats only while its condition does. Process lifetime: a server does not gain
/// suffix-range support mid-session, and forgetting across launches costs exactly one request.
final class SuffixRangeSupport: @unchecked Sendable {
    static let shared = SuffixRangeSupport()

    private static let transportFailuresBeforeDenying = 2

    private let lock = NSLock()
    private var denied: [String: String] = [:]      // origin -> how it declined, for the log line
    private var transportFailures: [String: Int] = [:]

    /// Scheme + host + port. Suffix-range support is a property of the server, not of one file.
    static func originKey(for url: URL) -> String? {
        guard let host = url.host else { return nil }
        return "\(url.scheme ?? "http")://\(host):\(url.port.map(String.init) ?? "-")"
    }

    /// How this origin declined, or nil if it has not (yet) declined.
    func denialReason(for url: URL) -> String? {
        guard let key = Self.originKey(for: url) else { return nil }
        lock.lock(); defer { lock.unlock() }
        return denied[key]
    }

    func noteDeclined(_ url: URL, reason: String) {
        guard let key = Self.originKey(for: url) else { return }
        lock.lock(); defer { lock.unlock() }
        denied[key] = reason
    }

    /// Returns true when this failure was the one that tipped the origin into being denied.
    @discardableResult
    func noteTransportFailure(_ url: URL, reason: String) -> Bool {
        guard let key = Self.originKey(for: url) else { return false }
        lock.lock(); defer { lock.unlock() }
        guard denied[key] == nil else { return false }
        let count = (transportFailures[key] ?? 0) + 1
        transportFailures[key] = count
        guard count >= Self.transportFailuresBeforeDenying else { return false }
        denied[key] = reason
        return true
    }

    /// A served fetch clears the transport tally: whatever those failures were, they were not this
    /// origin refusing the form.
    func noteServed(_ url: URL) {
        guard let key = Self.originKey(for: url) else { return }
        lock.lock(); defer { lock.unlock() }
        transportFailures[key] = nil
    }

    func resetForTesting() {
        lock.lock(); defer { lock.unlock() }
        denied.removeAll()
        transportFailures.removeAll()
    }
}

/// #281: collects the speculative tail fetch, and refuses everything that is not the tail.
///
/// The guarantee that matters is that this never downloads a body it did not ask for. Suffix
/// ranges are not universally implemented: an origin may answer `bytes=-65536` with a 200 and the
/// whole file. That body is rejected at the header, before a byte of it is accepted, and the
/// collected length is capped besides, so a lying `Content-Range` cannot grow this either.
private final class TailPrefetchDelegate: NSObject, URLSessionDataDelegate, @unchecked Sendable {
    private let sourceTrace: SourceNetworkDiagnostics.Trace
    enum Outcome {
        case span(Int64, Data)
        /// Named so the log says WHICH way an origin declined, since "no suffix ranges", "a 200 with
        /// the whole file" and "a short body" are three different origins to talk to a reporter about.
        ///
        /// `verdict` separates what the answer was about. Only the origin's answer to the RANGE FORM
        /// is a property of the server that repeats on every open and is worth remembering after
        /// one occurrence (`SuffixRangeSupport`); a transport failure is the network's; and a status
        /// about the resource or the moment (a 403, a 404, a 429, a 5xx) says nothing about suffix
        /// ranges at all and must not disable the prefetch for the origin once the condition passes.
        case rejected(String, verdict: Verdict)
    }

    enum Verdict {
        case declinedByOrigin
        case transportFailure
        case unrelated
    }

    private let expectedLength: Int
    private let extraHeaders: [String: String]
    private var buffer = Data()
    private var spanStart: Int64?
    private var rejection: (String, Verdict)?

    /// Called exactly once, on completion, whatever happened. A caller waits on this fetch, so a
    /// silent failure would be a caller waiting out its whole budget for bytes that are never coming.
    var onOutcome: ((Outcome) -> Void)?

    init(expectedLength: Int, diagnosticContext: SourceNetworkDiagnostics.Context?, extraHeaders: [String: String]) {
        self.sourceTrace = .init(role: .tailPrefetch, context: diagnosticContext)
        self.expectedLength = expectedLength
        self.extraHeaders = extraHeaders
    }

    func urlSession(
        _ session: URLSession,
        task: URLSessionTask,
        willPerformHTTPRedirection response: HTTPURLResponse,
        newRequest request: URLRequest,
        completionHandler: @escaping (URLRequest?) -> Void
    ) {
        // Same policy as every other delegate here: credential headers do not follow a redirect
        // to another host (the #126 cross-origin token replay).
        sourceTrace.redirect(task: task, response: response, request: request)
        completionHandler(redirectPreservingHeaders(
            task: task, newRequest: request, extraHeaders: extraHeaders))
    }

    func urlSession(
        _ session: URLSession,
        dataTask: URLSessionDataTask,
        didReceive response: URLResponse,
        completionHandler: @escaping (URLSession.ResponseDisposition) -> Void
    ) {
        sourceTrace.response(task: dataTask, response: response)
        guard let http = response as? HTTPURLResponse else {
            rejection = ("no HTTP response", .declinedByOrigin)
            completionHandler(.cancel)
            return
        }
        guard http.statusCode == 206 else {
            let status = http.statusCode
            rejection = AVIOReader.suffixRangeStatusDeclinesTheForm(status)
                ? ("status=\(status) (no suffix range support)", .declinedByOrigin)
                : ("status=\(status) (about the resource, not the range form)", .unrelated)
            completionHandler(.cancel)
            return
        }
        guard let start = AVIOReader.suffixRangeStart(http, expectedLength: expectedLength) else {
            let cr = http.value(forHTTPHeaderField: "Content-Range") ?? "absent"
            rejection = ("Content-Range: \(cr) does not describe the \(expectedLength)B asked for",
                         .declinedByOrigin)
            completionHandler(.cancel)
            return
        }
        spanStart = start
        completionHandler(.allow)
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        guard buffer.count < expectedLength else { return }
        // Audit DMX-9: clamped, as `RangeFetchDelegate` does. Appended whole, an origin that sends a
        // few bytes past its own Content-Range read as a SHORT body and latched the origin as one
        // that declines suffix ranges for the rest of the process.
        buffer.append(data.prefix(expectedLength - buffer.count))
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        sourceTrace.completed(task: task, error: error)
        let outcome = self.outcome(error: error)
        onOutcome?(outcome)
        onOutcome = nil
    }

    private func outcome(error: Error?) -> Outcome {
        if let (reason, verdict) = rejection { return .rejected(reason, verdict: verdict) }
        if let error { return .rejected("transport: \(error.localizedDescription)", verdict: .transportFailure) }
        guard let start = spanStart else {
            return .rejected("no usable response header", verdict: .declinedByOrigin)
        }
        // A short body would put later offsets in the span at the wrong place, so a partial
        // delivery is dropped rather than trimmed: this is an optimisation, and a wrong
        // optimisation is worse than none.
        guard buffer.count == expectedLength else {
            return .rejected("short body: \(buffer.count)B of \(expectedLength)B", verdict: .declinedByOrigin)
        }
        return .span(start, buffer)
    }
    func urlSession(_ session: URLSession, task: URLSessionTask, didFinishCollecting metrics: URLSessionTaskMetrics) {
        sourceTrace.metrics(task: task, metrics: metrics)
    }

}

// MARK: - C Callbacks


private func readCallback(
    opaque: UnsafeMutableRawPointer?,
    buf: UnsafeMutablePointer<UInt8>?,
    size: Int32
) -> Int32 {
    guard let opaque = opaque, let buf = buf else { return -1 }
    let reader = Unmanaged<AVIOReader>.fromOpaque(opaque).takeUnretainedValue()
    return reader.read(into: buf, size: size)
}

private func seekCallback(
    opaque: UnsafeMutableRawPointer?,
    offset: Int64,
    whence: Int32
) -> Int64 {
    guard let opaque = opaque else { return -1 }
    let reader = Unmanaged<AVIOReader>.fromOpaque(opaque).takeUnretainedValue()
    return reader.seek(offset: offset, whence: whence)
}

// MARK: - Errors

enum AVIOReaderError: Error, Equatable, CustomStringConvertible, LocalizedError {
    case allocationFailed
    case noResponse
    case requestTimeout
    /// AE#140: an HLS playlist body arrived on the raw-byte live reader (misroute). Surfaced to load()
    /// so it can fail closed with a typed rejection instead of looping the endless-feed reconnect.
    case hlsPlaylistOnRawLivePath
    /// AE#154: an HLS playlist body arrived on the non-live loopback reader. FFmpeg (built with
    /// --disable-network) can never demux it; surfaced to load() so it reroutes the source onto the
    /// native remote-HLS bypass instead of dying with a bare AVERROR_INVALIDDATA.
    case hlsPlaylistOnVODPath
    /// AE#859: an MPEG-DASH manifest body arrived where container bytes belong. `Demuxer.openHTTP`
    /// catches it and opens the manifest through `DASHSourceOpener`; it only escapes for a source
    /// the demuxer cannot reopen by URL.
    case dashManifest
    /// AE#860: the opening response declared a disc image type (`DiscImageMediaType`). Internal
    /// routing only: `Demuxer.openHTTP` catches it and tries the disc adapter.
    case discImageMediaType
    /// The origin answered the source request with an HTTP status instead of media: a 401/403
    /// refusal, a 404, a 5xx. Typed so load() publishes the status (`PlaybackErrorKind.sourceRefused`)
    /// instead of the AVERROR_INVALIDDATA FFmpeg reports for an empty or error-page stream, and so the
    /// error page never reaches the demuxer.
    case httpStatus(Int)
    /// AE#495: the transport was refused over certificate trust, so no body ever existed. Typed for
    /// the same reason `httpStatus` is: without it the open surfaces FFmpeg's invalid data and a
    /// self-signed origin reads as a corrupt file.
    case transportSecurityFailed(code: Int)
    /// Audit NET-102: a remote disc image on an origin that answers a range request with the whole
    /// source (a 200). A disc image is a filesystem, which no reader can walk forward-only, so this
    /// fails at the first response head. A plain media URL on such an origin plays forward-only
    /// instead (audit DMX-101).
    case originIgnoresRange
    /// Audit DMX-107: a forward-only source kept delivering after the reader paused it, past the
    /// streaming buffer's hard cap, so the source was ended to keep memory bounded. The read that
    /// follows fails with EIO, and `AVIOReader.lastReadFailure` says why.
    case originIgnoresFlowControl

    var description: String {
        switch self {
        case .allocationFailed: return "Failed to allocate AVIO buffer"
        case .noResponse: return "No response from server"
        case .requestTimeout: return "Request timed out"
        case .hlsPlaylistOnRawLivePath: return "HLS playlist supplied to the raw live path"
        case .hlsPlaylistOnVODPath: return "HLS playlist supplied to the VOD loopback path"
        case .dashManifest: return "MPEG-DASH manifest supplied where container bytes belong"
        case .discImageMediaType: return "Disc image supplied where container bytes belong"
        case .httpStatus(let status): return "Origin answered HTTP \(status) for the source"
        case .transportSecurityFailed(let code):
            return TransportSecurityFailure.sentence(for: code)
        case .originIgnoresRange:
            return "The origin ignores HTTP Range requests, which a remote disc image needs"
        case .originIgnoresFlowControl:
            return "The origin kept sending after the reader paused it, past the streaming buffer's bound"
        }
    }

    var errorDescription: String? { description }
}
