import Foundation
import AVFoundation
import Combine
import AetherLibavformat
import AetherLibavcodec
import AetherLibavutil

extension AetherEngine {

    /// Apply an AVPlayer clock tick (native VOD/live path) to the engine clock. `nativeClockSeconds`
    /// (the raw pre-shift clock, re-derived against by `onPlaylistShiftChanged`) and the active seam
    /// shift always track it. The UI scrub clock (`clock.currentTime`) is HELD while a recovery seek is
    /// pending (#37 wedge resurface): the original seek's `seekInFlight` clears when it reconciles, so
    /// the 100ms periodic observer resumes publishing, but the recovery nudges (`reengageStalledConsumer`
    /// issues raw AVPlayer seeks to the target) bounce AVPlayer's reported clock between the frozen
    /// position and the transient nudge target (device: engineClock 824 -> 634 -> 824 -> 634 while
    /// avpClock holds). Holding the scrub clock at the reconciled position until the recovery lands
    /// (`pendingRecoverySeekClockTarget` cleared) stops the scrubber from bouncing. `sourceTime` is owned
    /// by the `$renderedTime` sink and is unaffected here (issue #49).
    func applyNativeHostClockTick(_ value: Double) {
        // nativeClockSeconds preserves the raw AVPlayer clock for onPlaylistShiftChanged to re-derive against.
        nativeClockSeconds = value
        // AE#446 round 4: before anything folds, establish which axis this item's clock is even on.
        measureLiveItemAxisOffset()
        // AE#454: and if it could not be established, publish nothing derived from it. The raw clock
        // above is kept (it is a reading of the item, not of the session), but the seam lookup, the
        // published playhead and the live window all fold an offset that belongs to the item that
        // just left, and the window's edge is a running maximum a single wrong sample latches.
        if liveItemPlacementPending { return }
        // Newest seam at or before the raw clock wins: activates seams on forward play, re-applies pre-seam shift on backward DVR seeks.
        // Audit PERF-106: published on the engine, so an unchanged write would fire its
        // objectWillChange on every 10 Hz tick (the reason `clock` exists).
        if let active = presentationAxis.shiftSeconds(atItemSeconds: value), active != playlistShiftSeconds {
            playlistShiftSeconds = active
        }
        if pendingRecoverySeekClockTarget == nil {
            // AE#105: fold the disc's clip-0 STC base back out so the published playhead sits on the same
            // 0-based axis as the MPLS duration (origin 0 for normal/live -> no-op).
            clock.currentTime = isLive && videoRoute == .loopback
                ? value + liveSessionShiftSeconds + liveItemAxisOffsetSeconds
                : PresentationAxis.display(
                    sourcePTS: value + playlistShiftSeconds + liveItemAxisOffsetSeconds,
                    origin: displayOrigin(forShift: playlistShiftSeconds))
        }
        // The live edge and playhead use the same stable session shift across source PTS rebases.
        if isLive {
            publishLiveWindow(edgeSessionTime: nativeItemSeekableEnd + liveSessionShiftSeconds
                              + liveItemAxisOffsetSeconds)
        }
    }

    /// A deadline-expired seek remains alive inside AVPlayer. Its current-time publication arrives
    /// before rendered-time; while the recovery target is pending, the first publication is held.
    /// Settle the public clock from the rendered frame when that late landing retires the target so
    /// a paused landing does not wait forever for another periodic clock tick.
    @discardableResult
    func settleRecoveryClockIfRenderedTargetLanded(
        rendered: Double,
        shift: Double,
        completionRenderedTimePublished: Bool
    ) -> Bool {
        guard pendingRecoverySeekDeadlineExpired,
              let pending = pendingRecoverySeekClockTarget,
              Self.pendingSeekHasRenderedLandingEvidence(
                  rendered: rendered,
                  target: pending,
                  initialRendered: pendingSeekInitialRenderedPosition,
                  completionRenderedTimePublished: completionRenderedTimePublished
              ) else {
            return false
        }
        if Self.shouldReanchorSubtitlesOnLateSeekLanding(
            alreadyReanchored: pendingRecoverySeekSubtitlesReanchored
        ) {
            reanchorSubtitleOverlays()
        }
        setPendingRecoverySeekTarget(nil)
        clock.currentTime = PresentationAxis.display(
            sourcePTS: rendered + shift,
            origin: sourcePresentationOrigin
        )
        return true
    }

    /// #123: publish `sourceTime` at seek finalize. `sourceTime` is the on-screen frame (#49), not the
    /// scrub target. Settle it onto the landed `target` (source PTS) only when the frame is actually
    /// presented; while the player is still buffering toward the target (a queued-burst chase on heavy
    /// 4K, `bufferingTowardTarget`) the picture is frozen behind it, so leave `sourceTime` on the frame
    /// the `$renderedTime` sink last published. Stamping the target while buffering parks `sourceTime`
    /// tens of seconds ahead of the picture for the whole chase, because the 100 ms periodic observer is
    /// silent while waiting and cannot walk it back, so a host pacing cues off `sourceTime` draws them
    /// over a stale frame (rrgomes' #123 report). The sink settles `sourceTime` onto the target when
    /// playback resumes and the frame is delivered. Extracted from `seek(to:)`'s finalize so the
    /// hold-vs-settle decision is unit-testable without driving a live AVPlayer.
    func applySeekFinalizeSourceTime(target: Double, bufferingTowardTarget: Bool) {
        if Self.seekLandingSettlesToTarget(bufferingTowardTarget: bufferingTowardTarget) {
            // AE#616: zero except on a remote-HLS bypass whose item time leads its frames.
            clock.sourceTime = max(0, target - remoteHLSItemOffset)
        }
    }

    /// Wire `$duration`, `$isReady`, `$failure`, `$didReachEnd` into the cancellable set.
    /// `isReady` always feeds the public `isSessionReady` mirror and replays a deferred pre-ready host
    /// seek (#127); pass `settlePausedAtReadiness: false` for paths that skip the readiness -> .paused
    /// waypoint (autostarting loadRemoteHLS, where the terminal play() runs and readiness is a waypoint).
    /// #315: fold a host's raw `isVideoReadyForDisplay` level into the load-scoped public latch.
    ///
    /// Two operators carry the whole contract. `dropFirst()` discards the value the publisher
    /// replays on subscribe: every call site wires its sinks BEFORE it loads the host, so on a
    /// reused native host that replay is still the outgoing item's picture, and taking it would
    /// latch this load's flag on the previous load's frame. `prefix(1)` is the latch itself: after
    /// the first rise nothing can lower it again, which is what keeps a host from re-covering the
    /// few tens of milliseconds an item swap spends without a picture.
    func latchFirstFrameReadyForDisplay(
        from publisher: Published<Bool>.Publisher,
        storeIn cancellables: inout Set<AnyCancellable>
    ) {
        publisher
            .dropFirst()
            .filter { $0 }
            .prefix(1)
            .sink { [weak self] _ in
                self?.hasFirstFrameReadyForDisplay = true
                self?.recordStartupCheckpoint(.presenting)   // #361: the picture is up
            }
            .store(in: &cancellables)
    }

    /// #315, measured on a device (iPhone -> Apple TV, 2026-08-09): while external playback is active the
    /// local `AVPlayerLayer` never reaches `isReadyForDisplay`. Not once in four external loads, two of them
    /// titles started while the receiver already held the route, while the three loads either side of them
    /// reached it in 0.16 to 0.22 s. Folding only the layer therefore leaves the latch false for the whole
    /// AirPlay session, and a host lifting a cover on it covers the session instead of the load.
    ///
    /// There is no local first frame coming there and no way to see the receiver's screen, so the readiness
    /// of the item is the honest edge: past it the picture is the receiver's business. Deliberately NOT the
    /// clock advancing, which would hang the paused mount this signal exists for.
    ///
    /// Split into a pure decision so the matrix is testable without an AVPlayer and a receiver.
    nonisolated static func shouldLatchFirstFrameForExternalPlayback(
        alreadyLatched: Bool,
        hasVideoDisplaySignal: Bool,
        isSessionReady: Bool,
        externalPlaybackHoldsThePicture: Bool
    ) -> Bool {
        guard !alreadyLatched else { return false }
        // Audio-only has a picture nowhere, so nothing about a receiver makes a first frame exist.
        guard hasVideoDisplaySignal else { return false }
        return isSessionReady && externalPlaybackHoldsThePicture
    }

    func latchFirstFrameForExternalPlaybackIfNeeded() {
        guard Self.shouldLatchFirstFrameForExternalPlayback(
            alreadyLatched: hasFirstFrameReadyForDisplay,
            hasVideoDisplaySignal: sessionPublishesVideoDisplaySignal,
            isSessionReady: isSessionReady,
            externalPlaybackHoldsThePicture: externalPlaybackHoldsThePicture) else { return }
        EngineLog.emit(
            "[AetherEngine] #315: an external screen holds the picture, so no local first frame is coming; "
            + "latching hasFirstFrameReadyForDisplay at readiness",
            category: .engine
        )
        hasFirstFrameReadyForDisplay = true
        recordStartupCheckpoint(.presenting)   // #361
    }

    /// #353: mirror a software host's settled picture size onto the public `softwareDisplaySize`.
    ///
    /// A mirror rather than the latch `hasFirstFrameReadyForDisplay` gets, because the two answer
    /// different questions. A picture that exists cannot stop existing for the rest of the load, but
    /// the size it presents at can change under it: a live source that switches resolution
    /// mid-stream re-shapes the rectangle a host already laid out against, and a latched first value
    /// would keep the overlay on the old one.
    ///
    /// No `dropFirst()` here either, and that is a property of this path rather than a style choice:
    /// the software path builds a new host per load (one construction site, and `stopInternal` nils
    /// it), so what a fresh mirror replays is that host's own nil and not the outgoing item's size.
    /// The native hosts, which are the ones reused across a load, have no size to mirror.
    func mirrorSoftwareDisplaySize(
        from publisher: Published<CGSize?>.Publisher,
        storeIn cancellables: inout Set<AnyCancellable>
    ) {
        publisher
            .sink { [weak self] size in self?.softwareDisplaySize = size }
            .store(in: &cancellables)
    }

    /// `videoReadyForDisplay` is the host's raw layer level (#315); nil on the audio hosts, which
    /// have nothing to display. It is folded, never mirrored: the engine's published flag is latched
    /// for the load, so the seams that reuse a host and briefly lose the picture do not surface.
    private func wireCommonHostSinks(
        duration: Published<Double>.Publisher,
        isReady: Published<Bool>.Publisher,
        settlePausedAtReadiness: Bool = true,
        failure: Published<PlaybackErrorInfo?>.Publisher,
        didReachEnd: Published<Bool>.Publisher,
        videoReadyForDisplay: Published<Bool>.Publisher? = nil,
        storeIn cancellables: inout Set<AnyCancellable>
    ) {
        if let videoReadyForDisplay {
            sessionPublishesVideoDisplaySignal = true
            latchFirstFrameReadyForDisplay(from: videoReadyForDisplay, storeIn: &cancellables)
        }
        duration
            .sink { [weak self] value in
                guard let self else { return }
                // A caller-declared duration outranks the host's: a sequential session's append
                // playlist grows while it plays, so the item duration is the produced span, not
                // the window length the host UI should scale its scrubber to.
                if let declared = self.loadedOptions.declaredDurationSeconds, declared > 0 {
                    self.duration = declared
                } else if value > 0 {
                    self.duration = value
                }
            }
            .store(in: &cancellables)
        isReady
            .sink { [weak self] ready in
                guard let self = self else { return }
                self.isSessionReady = ready
                // AE#454: the item the session's published position describes. Until a fresh item says
                // it can play, nothing it reports is a reading of where the session is; see
                // `liveItemPlacementPending`.
                if ready {
                    self.noteLiveItemStart()
                    // The placement is spent here, on every path rather than only on the one that
                    // replays the stashed seek: a pre-ready seek can be superseded by a host scrub
                    // (latest-wins), and an arm left standing would be inherited by whatever item the
                    // session loads next for an unrelated reason.
                    self.nativeVideoSession?.clearLiveRejoinStart()
                    // An item with a rejoin placement still outstanding is not yet describing the
                    // session: the hold runs to the PLACEMENT, not to readiness, or whether the
                    // hand-off is reported depends on where a 100 ms tick happens to fall inside it.
                    if self.pendingPreReadySeek?.origin != .liveRejoin {
                        self.acceptCurrentItemForPublishing()
                    }
                }
                if ready {
                    // #361: an audio session has a picture nowhere, so its ladder ends at readiness
                    // rather than stalling one checkpoint short of the end forever.
                    self.recordStartupCheckpoint(.ready)
                    if !self.sessionPublishesVideoDisplaySignal {
                        self.recordStartupCheckpoint(.presenting)
                    }
                }
                if ready, settlePausedAtReadiness, self.state == .loading {
                    self.state = .paused
                }
                // #315: on an external screen this readiness IS the edge; the local layer never rises.
                if ready { self.latchFirstFrameForExternalPlaybackIfNeeded() }
                // #127: replay the latest host seek that arrived while the item was pre-ready.
                // #178: not while still .loading (autostart paths hold .loading past readiness);
                // replaying now would just re-stash. The state didSet resolves that case.
                if ready, self.state != .loading, let pending = self.pendingPreReadySeek {
                    self.pendingPreReadySeek = nil
                    EngineLog.emit("[AetherEngine] replaying deferred pre-ready seek to \(String(format: "%.2f", pending.seconds))s (#127)", category: .engine)
                    // AE#454: a placement the playlist already carried out does not need a seek to
                    // carry it out again, and the seek is not free: a zero-tolerance seek bounces
                    // transport and costs a rebuffer at the exact moment the picture is coming back
                    // (measured on the harness: 250 ms of the 485 ms hand-off). Read where the item
                    // actually came up and let the fact decide, so a client that ignored the tag, or
                    // honoured it only to a segment boundary, still gets the correcting seek.
                    //
                    // Round 2: ask the playlist what it STATED before reconstructing it. The
                    // reconstruction subtracts an axis the fresh item has not established yet, and on
                    // the session's first swap that axis read 0 and the check moved an item that was
                    // already exactly where the manifest had put it (reported on 6.57.0).
                    if pending.origin == .liveRejoin, let host = self.nativeHost,
                       let resolved = Self.liveRejoinPlacementTarget(
                           served: self.liveRejoinPlacementGeneration == host.itemGeneration
                               ? self.nativeVideoSession?.servedLiveRejoinPlacement?.timeOffset : nil,
                           reconstructed: self.liveRejoinItemAxisTarget(pending.seconds)) {
                        let distance = abs(host.currentTime - resolved.target)
                        let provenance = resolved.stated ? "the playlist served" : "the rejoin asked for"
                        if distance <= Self.liveRejoinPlacementSatisfiedSeconds {
                            EngineLog.emit(
                                "[AetherEngine] #454 the playlist already placed this item at its own "
                                + "\(String(format: "%.2f", host.currentTime))s, "
                                + "\(String(format: "%.3f", distance))s from the "
                                + "\(String(format: "%.2f", resolved.target))s \(provenance); no correcting seek",
                                category: .engine)
                            self.acceptCurrentItemForPublishing()
                            return
                        }
                        EngineLog.emit(
                            "[AetherEngine] #454 the fresh item came up at its own "
                            + "\(String(format: "%.2f", host.currentTime))s of "
                            + "\(String(format: "%.2f", host.seekableStart))..\(String(format: "%.2f", host.seekableEnd))s, "
                            + "\(String(format: "%.2f", distance))s from the "
                            + "\(String(format: "%.2f", resolved.target))s \(provenance); the placement seek follows",
                            category: .engine)
                    }
                    Task { @MainActor in
                        await self.seek(to: pending.seconds, origin: pending.origin, exact: pending.exact)
                        if pending.origin == .liveRejoin { self.acceptCurrentItemForPublishing() }
                    }
                }
            }
            .store(in: &cancellables)
        failure
            .compactMap { $0 }
            .sink { [weak self] info in
                guard let self else { return }
                self.publishError(Self.reclassifiedForCredentialRefusal(
                    info, refusal: self.sessionRequestHeaders.recentCredentialRefusal(
                        within: HLSVideoEngine.rateLimitVerdictWindowSeconds)))
            }
            .store(in: &cancellables)
        didReachEnd
            .filter { $0 }
            .sink { [weak self] _ in
                guard let self else { return }
                // AE#446: a live window served as a finished asset (its source stopped delivering while
                // the viewer still had resident runway) reaches an end that is not the end of anything.
                // `.ended` is terminal (#63/#164), so forwarding it here would turn a source hiccup into
                // a dead session for the rest of the tune.
                if self.handleLiveOutageWindowExhausted() { return }
                self.state = .ended
            }
            .store(in: &cancellables)
    }

    /// Lean native-HLS live path: AVPlayerItem from the remote URL on the reused NativeAVPlayerHost. No Demuxer, no HLSVideoEngine, no loopback, no display-criteria handshake (AVKit drives match-content). Live-window surfaces come from `host.seekableEnd`.
    /// `startPosition` (AE#154): resume anchor for VOD playlists on the loopback reroute; nil keeps
    /// the historical no-initial-seek behavior every live caller relies on.
    /// Build a native host carrying the current Now-Playing ownership choice. Read at creation only:
    /// a host preserved across a native->native reload (issue #15) keeps what it was created with,
    /// which is the point, since re-creating it is what breaks AVKit's MediaRemote registration.
    func makeNativeHost() -> NativeAVPlayerHost {
        #if os(tvOS) || os(iOS)
        let host = NativeAVPlayerHost(ownsNowPlayingSession: Self.ownsNowPlaying(
            hostOptIn: ownsVideoNowPlayingSession, role: loadedOptions.sharedOutputRole))
        #else
        let host = NativeAVPlayerHost()
        #endif
        host.pictureInPictureActive = pictureInPictureActive
        host.onVideoPresentationRecovery = { [weak self, weak host] action, position in
            guard let self, let host, self.nativeHost === host,
                  self.state == .playing, !self.pictureInPictureActive,
                  self.pendingRecoverySeekClockTarget == nil,
                  !self.liveItemPlacementPending else { return }
            switch action {
            case .nudge:
                self.reengageStalledConsumer(position: position, trigger: "video presentation")
            case .reload:
                // A live native URL with no retained session cannot promise this placement.
                guard !self.isLive || self.nativeVideoSession != nil else { return }
                self.reloadStalledConsumerItem(position: position,
                    preserveLivePosition: self.isLive ? self.currentTime : nil)
            }
        }
        return host
    }

    /// Replay the staged Now-Playing identity onto a host, and re-assert session ownership. The
    /// re-assert mirrors the audio path: a preserved host never re-runs init, so a session another
    /// app took over in the meantime would otherwise never be claimed back. Both no-op for a host
    /// that owns no session.
    func replayVideoNowPlayingInfo(to host: NativeAVPlayerHost) {
        #if os(tvOS) || os(iOS)
        guard host.ownsNowPlayingSession else { return }
        if !pendingVideoNowPlayingInfo.isEmpty {
            host.setNowPlayingInfo(pendingVideoNowPlayingInfo)
        }
        host.becomeActiveNowPlaying()
        #endif
    }

    /// AE#561: hands a host's escalation request to the engine under the session it was raised for.
    private func wireSoftwarePathEscalation(host: NativeAVPlayerHost, generation: UInt64) {
        host.$pendingSoftwarePathEscalation
            .compactMap { $0 }
            .sink { [weak self] request in
                self?.hop(for: generation) { [weak self] in
                    await self?.escalateToSoftwarePath(request, expectedGeneration: generation)
                }
            }
            .store(in: &nativeCancellables)
    }

    func loadRemoteHLS(
        url: URL, options: LoadOptions, startPosition: Double? = nil, generation: UInt64? = nil
    ) async throws {
        // Audit CORE-6: the generation of the load() that routed here, not a fresh read of it, so a
        // stale caller cannot adopt its successor's generation.
        if let generation { try checkLoadCurrent(generation) }
        playbackBackend = .native
        sessionCacheStatusToken &+= 1
        diagnostics.sessionCacheStatus = .nativeRemoteHLS(
            requestedBudgetBytes: options.sessionCacheByteBudget.map { max(0, $0) })
        // #168 follow-up: detect a superseding load()/stop() between the carriage verdict and the reroute.
        let bypassGeneration = generation ?? loadGeneration

        let host: NativeAVPlayerHost
        if let existing = nativeHost {
            host = existing
        } else {
            host = makeNativeHost()
        }
        host.playerLayer.videoGravity = _videoGravity
        if !pendingExternalMetadata.isEmpty {
            host.setExternalMetadata(pendingExternalMetadata)
        }
        replayVideoNowPlayingInfo(to: host)
        self.nativeHost = host
        // A surface bound BEFORE load ran presentCurrentLayer() while nativeHost was still nil
        // (no-op); without this re-present nothing ever attaches host.playerLayer and AVPlayer
        // plays audio into a black view (#120). Mirrors loadNative's post-host call.
        presentCurrentLayer()
        applyDesiredVolume(to: host)
        applyDesiredRate(to: host)
        // No loopback producer; playhead is the raw AVPlayer clock. Shift stays 0.
        self.playlistShiftSeconds = 0
        detachRemoteHLSCueClock()
        self.setPresentationAxis(PresentationAxisMap())
        if currentAVPlayer !== host.avPlayer {
            self.currentAVPlayer = host.avPlayer
        }

        nativeCancellables.removeAll()
        host.$currentTime
            .sink { [weak self] value in
                guard let self = self else { return }
                self.nativeClockSeconds = value
                self.clock.currentTime = value
                // sourceTime owned by $renderedTime to track the picture across a seek (issue #49); shift=0 here so it equals currentTime in steady play.
                if self.isLive {
                    self.publishLiveWindow(edgeSessionTime: host.seekableEnd)
                }
            }
            .store(in: &nativeCancellables)
        host.$renderedTime
            .sink { [weak self] value in
                guard let self else { return }
                // AE#616: item time, less what the injected renditions measured it leads the picture by.
                self.clock.sourceTime = max(0, value - self.remoteHLSItemOffset)
                // Feed the playhead mirror the remote-HLS audio tap (#95) reads off its ingest task;
                // shift 0 on this path, so the rendered position is the source-PTS playhead.
                self.renderedPositionMirror.set(value)
                self.refreshRemoteHLSBufferedPosition(rendered: value, ranges: host.loadedVideoRanges)
            }
            .store(in: &nativeCancellables)
        host.$loadedVideoRanges
            .sink { [weak self] ranges in
                self?.refreshRemoteHLSBufferedPosition(rendered: host.renderedTime, ranges: ranges)
            }
            .store(in: &nativeCancellables)
        // #168: mirror the item's parsed dynamic range into the published format AND program the panel.
        // This bypass runs no libav probe, so without this both fields stayed at the `.sdr` reset default
        // even for HDR10 / Dolby Vision streams (the reporter's `fmt=sdr` on 4K50 HDR10), and more
        // importantly nothing ever programmed preferredDisplayCriteria, so an HDR item was handed to a bare
        // AVPlayerLayer with the panel in SDR and AVPlayer presented no video (audio-only, black).
        // sourceVideoFormat = what the stream carries; videoFormat = the effective badge.
        host.$detectedVideoFormat
            .compactMap { $0 }
            .sink { [weak self] fmt in
                guard let self else { return }
                self.sourceVideoFormat = fmt
                self.videoFormat = fmt
                if let rate = self.nativeHost?.detectedVideoFrameRate { self.sourceVideoFrameRate = rate }
                // Same reason as the rate: this bypass runs no libav probe, so without the read-back the
                // codec row on a remote-HLS session stays empty for a source that is plainly playing.
                if let codec = self.nativeHost?.detectedVideoCodecName { self.sourceVideoCodecName = codec }
                self.applyRemoteHLSDisplayCriteria(format: fmt, options: options)
            }
            .store(in: &nativeCancellables)
        // What was DELIVERED, which on a capped transcode is not what the host's library holds: without it
        // a stats panel fell back to the original file's 3840x2160 for a 1280x720 stream. Its own sink,
        // because a later read can refine the description without changing the dynamic range.
        // dropFirst on both: a reused host replays the outgoing item's reading on subscribe, before load resets it.
        host.$detectedVideoDescription
            .dropFirst()
            .compactMap { $0 }
            .sink { [weak self] video in
                guard let self else { return }
                self.publishRemoteHLSVideoDescription(video)
            }
            .store(in: &nativeCancellables)
        // No probe lists this route's audio, so AVPlayer's own tracks are the list. Informational: AVPlayer
        // owns the audio selection here, and `selectAudioTrack` refuses the route rather than reload it.
        host.$detectedAudioTracks
            .dropFirst()
            .sink { [weak self] readings in
                guard let self else { return }
                let (tracks, active) = RemoteHLSStreamDescription.audioTracks(readings)
                self.audioTracks = tracks
                self.activeAudioTrackIndex = active
            }
            .store(in: &nativeCancellables)
        // #168 follow-up: an advertised video rendition that never builds an item track means HEVC carried
        // in MPEG-TS segments, which AVFoundation's HLS demuxer does not support (audio-only, black). The
        // loopback ingest remuxes TS to fMP4 and plays the same stream, so reroute there transparently.
        host.$remoteHLSVideoCarriageRejected
            .filter { $0 }
            .prefix(1)
            .sink { [weak self] _ in
                guard let self else { return }
                Task { @MainActor in
                    await self.rerouteRemoteHLSOntoLiveIngest(url: url, expectedGeneration: bypassGeneration)
                }
            }
            .store(in: &nativeCancellables)
        // AE#363: same destination, different evidence. The origin refused AVPlayer (401 / 403) rather
        // than serving something it could not demux, and the ingest fetcher is a different client at that
        // origin. The verdict is NOT remembered for the next load: a refusal can be a token that expired
        // or a connection cap that was momentarily full, neither of which is a property of the master.
        host.$remoteHLSOriginRefused
            .filter { $0 }
            .prefix(1)
            .sink { [weak self] _ in
                guard let self else { return }
                Task { @MainActor in
                    await self.rerouteRemoteHLSOntoLiveIngest(url: url, expectedGeneration: bypassGeneration,
                                                              rememberVerdict: false, evidence: "origin refusal")
                }
            }
            .store(in: &nativeCancellables)
        // AE#990: the AE#561 rung on this route too. A finite playlist AVPlayer refuses on its media
        // is rebuilt with `.software`, which the TS ingest serves. Assigned on every mount, because a
        // host kept from a loopback session still carries that session's closure and budget, and
        // with its subscriber gone an escalation it granted would swallow the failure.
        let escalationBudget = softwarePathEscalationBudget
        host.softwarePathAvailability = {
            SoftwarePathEscalation.Availability(
                alreadyEscalated: escalationBudget.isSpent,
                preferredDecodePath: options.preferredDecodePath,
                nativeRemoteHLS: true,
                hostAllowsEscalation: options.escalatesToSoftwarePath,
                finitePlaylist: !options.isLive
            )
        }
        wireSoftwarePathEscalation(host: host, generation: bypassGeneration)
        startLiveWindowTimer(host: host)
        // settlePausedAtReadiness off when autostarting: the terminal host.play() runs, so readyToPlay is only a waypoint. Flipping to .paused here would drop the spinner during Jellyfin's ~10 s transcode spin-up. timeControlStatus sink holds .loading until AVPlayer renders.
        // #124: a paused mount (autoplay=false) skips that play(), so the readiness sink settles .loading -> .paused.
        wireCommonHostSinks(
            duration: host.$duration,
            isReady: host.$isReady,
            settlePausedAtReadiness: !Self.loadPerformsAutostart(options),
            failure: host.$failure,
            didReachEnd: host.$didReachEnd,
            videoReadyForDisplay: host.$isVideoReadyForDisplay,
            storeIn: &nativeCancellables
        )
        // Track AVPlayer's REAL transport state. Eager .playing caused a ~10 s black screen during Jellyfin transcode spin-up.
        host.$timeControlStatus
            .sink { [weak self] status in
                guard let self = self else { return }
                if case .error = self.state { return }
                // .ended is terminal like .idle: a late .waitingToPlayAtSpecifiedRate from AVPlayer parked at
                // end must not flip it back to .loading (live HLS can reach real end-of-media).
                if self.state == .idle || self.state == .ended { return }
                // isBuffering only once playing (not during live startup spin-up).
                self.isBuffering = self.state == .playing
                    && Self.nativeWaitIsRebuffer(status: status, reason: host.waitingReason)
                switch status {
                case .playing:
                    if self.state != .playing { self.state = .playing }
                case .waitingToPlayAtSpecifiedRate:
                    // Hold .loading through startup (hasStartedPlaying gate on the host side).
                    if self.state != .playing { self.state = .loading }
                case .paused:
                    // Only an explicit user pause; ignore transient pre-roll paused at load. AE#440: the
                    // pre-play reading is delivered AFTER the autostart has written .playing, so before
                    // the first roll a .paused is the outgoing value rather than anyone's intent.
                    // Unless the session was ASKED to pause before it ever rolled (a host that pauses
                    // the resumed frame after a background reload): its own pause carries the same
                    // status and must still land, or `state` stays where the start left it on a
                    // transport that is not moving and the phase reads `.loading` for good.
                    // `.loading` is a source state here, not just `.playing`: this bypass autostarts
                    // without writing `.playing` (the sink does that when AVPlayer renders), so a pause
                    // that lands during startup finds `.loading` and has nowhere else to settle.
                    // `.seeking` is left alone, the seek finalize owns it.
                    if Self.publishesTransportPause(
                        hasTransportRolled: self.hasTransportRolled,
                        transportIntentIsPlaying: self.nativeHost?.transportIntentIsPlaying ?? true
                    ), self.state == .playing || self.state == .loading { self.state = .paused }
                @unknown default:
                    break
                }
                // AE#440: the rate is rolling, which is what `playbackPhase` reports as `.playing`.
                // Last, so this load's `state` and `isBuffering` writes are already in and the phase
                // recomputes once, onto the roll.
                if status == .playing { self.hasTransportRolled = true }
            }
            .store(in: &nativeCancellables)
        // Sodalite#168: the reason moves inside one waiting stretch, from the resume's evaluation to a
        // real stall, without a status edge.
        host.$waitingReason
            .sink { [weak self] reason in
                // A cleared reason arrives just ahead of the status that ends the wait; that edge settles it.
                guard let self, reason != nil else { return }
                if case .error = self.state { return }
                if self.state == .idle || self.state == .ended { return }
                self.isBuffering = self.state == .playing
                    && Self.nativeWaitIsRebuffer(status: host.timeControlStatus, reason: reason)
            }
            .store(in: &nativeCancellables)

        // #316: sidecars declared at load time can only reach media selection through the playlist, so
        // when there are any, the engine writes a master of its own and AVPlayer opens that instead. The
        // rewritten master's variants still point at the origin, so this changes nothing about where the
        // media comes from. Any refusal (live, a playlist that will not rewrite, a slow origin) returns
        // the origin URL and leaves the sidecars on the host overlay, which is the pre-#316 behaviour.
        //
        // AE#495: a host that answered the trust evaluator needs the media on a session the engine
        // owns, and the same stand-in does that. With sidecars it mounts a relay behind the
        // rewritten master, without them the relay stands alone.
        let playbackURL = await prepareRemoteHLSStandIn(
            originURL: url, options: options, expectedGeneration: bypassGeneration) ?? url
        // With a relay in front, the item AVPlayer fails is a loopback 502 and the refused handshake
        // happened out of its sight, so the classification has to be able to ask the side that made it.
        if let relay = remoteHLSSubtitleProxy?.server.relay {
            host.upstreamTrustRefusal = { [weak relay] in relay?.upstreamTrustRefusalCode }
        }

        // Jellyfin HLS URLs carry auth (ApiKey / PlaySessionId / LiveStreamId) as query params, but
        // generic live HLS origins (IPTV / Stremio add-on channels) enforce per-stream Referer /
        // User-Agent / Authorization headers, so LoadOptions.httpHeaders rides into the AVURLAsset (#119).
        // forwardBufferDuration: 0 = system-adaptive; the 4 s VOD floor caused a 3-4 s black screen on live startup.
        // AE#158: consume-and-reset, mirroring the loopback callsite, so the bypass honours a PiP or
        // host-requested handover instead of dropping the item to nil across the swap.
        let inPlaceHandover = pendingInPlaceItemHandover
        pendingInPlaceItemHandover = false
        if loadGeneration == bypassGeneration { recordStartupCheckpoint(.sessionConstructed) }   // #361
        host.load(url: playbackURL,
                  startPosition: startPosition,
                  perFrameHDR: true,
                  // AE#154: a VOD resume anchor seeks; nil keeps the live no-initial-seek contract.
                  skipInitialSeek: startPosition == nil,
                  inPlaceSwap: inPlaceHandover,
                  diagnosticContext: options.sourceDiagnosticsContext,
                  contract: .init(
                      isLive: options.isLive,
                      // AE#440: the same join tail exists where AVPlayer owns the buffer; the engine only
                      // owns the moment it is told to stop waiting.
                      liveJoinStartsImmediately: options.liveJoinStartsImmediately,
                      forwardBufferDuration: 0,
                      liveEdgeOffsetSeconds: LiveEdgePolicy.edgeCushion(options.liveEdgeCushionSeconds),
                      // This lean path has no live-reopen / readiness watchdog; let AVPlayer's "gave up"
                      // signal surface a dead upstream (segment 404 / token expiry) so the host can retune.
                      surfaceEndFailures: true,
                      httpHeaders: options.httpHeaders,
                      // #168 follow-up: live-only (VOD remote HLS is the AE#154 reroute target; ingesting
                      // it back would ping-pong), and hosts can opt out via LoadOptions.
                      armIngestFallback: RemoteHLSIngestFallback.shouldArm(
                          isLive: options.isLive, fallbackEnabled: options.nativeRemoteHLSIngestFallback),
                      // #334: the ceiling on silence this path never had. AVPlayer's "gave up" covers an
                      // origin that stops answering; it does not cover one that answers everything while
                      // AVFoundation builds no track, where nothing terminal is ever published.
                      readinessDeadline: RemoteHLSReadinessDeadline.defaultBudgetSeconds,
                      // No probe lists this route's audio, so the item's own tracks are the list.
                      readsBackAudioTracks: true))

        attachRemoteHLSCueClock(host: host, expectedGeneration: bypassGeneration)

        // AE#154: surface the item's legible AVMediaSelectionGroup as `subtitleTracks` so hosts with
        // their own picker see the external WebVTT renditions AVPlayer renders on this bypass.
        // Selection routes back through `selectSubtitleTrack(index:)` / `clearSubtitle()`.
        publishRemoteHLSSubtitleTracks(host: host)

        // VOD path triggers play() at the tail of load(); this lean path early-returns, so self-start here. AVKit drives match-content; automaticallyWaitsToMinimizeStalling handles play-before-ready. Without this call the item reaches readyToPlay but timeControlStatus stays .paused.
        // State stays .loading; flips to .playing only when timeControlStatus sink sees AVPlayer rendering.
        // #124: a paused mount skips the self-start; the wired isReady waypoint settles .loading -> .paused.
        if Self.loadPerformsAutostart(options) {
            host.play()
        }
        startMemoryProbe()
        // The sampler reads AVPlayer's access log on this route: both bitrates, network rate and transfer,
        // dropped frames and forward buffer. The loopback counters (producer, muxer, server) read zero.
        startLiveTelemetrySampler()
    }

    /// AE#616: on this bypass `sourceTime` would otherwise be item time, which an origin that restarts
    /// its transcode at the keyframe before a slot puts ahead of the picture. The engine wrote the
    /// injected renditions, so it can match what AVPlayer presents back to the cue and read the offset.
    /// Without injected renditions nothing is measurable and `sourceTime` stays item time.
    private func attachRemoteHLSCueClock(host: NativeAVPlayerHost, expectedGeneration: UInt64) {
        detachRemoteHLSCueClock()
        // Item time until a line says otherwise, and for the whole session without injected renditions.
        clock.sourceTimeFollowsPicture = false
        guard let provider = remoteHLSSubtitleProxy?.provider,
              let item = host.currentPlayerItem else { return }
        remoteHLSCueClock = RemoteHLSCueClockObserver(
            item: item, provider: provider,
            onOffset: { [weak self] offset in
                guard let self, self.loadGeneration == expectedGeneration else { return }
                self.remoteHLSItemOffset = offset
                if let rendered = self.nativeHost?.renderedTime {
                    self.clock.sourceTime = max(0, rendered - offset)
                }
                self.clock.sourceTimeFollowsPicture = true
            },
            onTimeJump: { [weak self] in
                guard let self, self.loadGeneration == expectedGeneration else { return }
                self.clock.sourceTimeFollowsPicture = false
            })
    }

    func detachRemoteHLSCueClock() {
        remoteHLSCueClock?.detach()
        remoteHLSCueClock = nil
        remoteHLSItemOffset = 0
        clock.sourceTimeFollowsPicture = true
    }

    /// Stand a loopback origin in front of the remote master and return the URL AVPlayer should open.
    /// Nil means "play the origin directly", which is the answer for a live source, and for a session
    /// with neither text sidecars to inject (#316) nor a trust evaluator to honor (AE#495).
    ///
    /// Bitmap sidecars (`.sup`) are excluded: WebVTT is a text rendition, and promising one for a PGS file
    /// would serve an empty `.vtt` that AVPlayer never re-fetches. Those keep the overlay (and Phase D OCR).
    ///
    /// The relay is not decided by asking the evaluator, which would mean asking about a protection
    /// space no handshake produced, with no `serverTrust` for a host that reads one. It is decided by
    /// the system's own answer to one handshake with this origin: an origin the system trusts is one
    /// AVPlayer can reach on its own, and relaying it would move a whole session's bytes through the
    /// process for nothing. A host commonly answers for a LAN address and holds a WAN address with a
    /// real certificate, so "an evaluator exists" says very little about the origin in hand.
    ///
    /// The evaluator's own answer is still put at the handshake the relay makes, so an origin it
    /// declines fails there rather than being laundered.
    @MainActor
    private func prepareRemoteHLSStandIn(originURL: URL,
                                         options: LoadOptions,
                                         expectedGeneration: UInt64) async -> URL? {
        let mayNeedRelay = EngineTLS.serverTrustEvaluator != nil
            && originURL.scheme?.lowercased() == "https"
        let tracks = options.isLive
            ? []
            : externalSubtitleRegistry
                .filter { $0.value.isTextFormat }
                .sorted { $0.key < $1.key }
                .map { RemoteHLSSubtitleProvider.Track(externalID: $0.key, source: $0.value) }
        // Nothing to stand in for, so the origin is never asked.
        guard !tracks.isEmpty || mayNeedRelay else { return nil }
        let needsRelay = mayNeedRelay
            ? await HLSOriginRelay.systemTrustRefuses(originURL, headers: options.httpHeaders)
            : false
        guard !options.isLive || needsRelay else { return nil }
        guard !tracks.isEmpty || needsRelay else { return nil }

        guard let prepared = await RemoteHLSSubtitleProxy.prepare(
            originURL: originURL, tracks: tracks, httpHeaders: options.httpHeaders,
            needsRelay: needsRelay) else { return nil }
        // The playlist fetches suspend; a load()/stop() can have superseded this session meanwhile, and a
        // proxy nobody owns would keep its socket and decode task for the rest of the process.
        guard loadGeneration == expectedGeneration else {
            prepared.tearDown()
            return nil
        }
        remoteHLSSubtitleProxy = prepared
        // Audit NAT-2: the NAMEs the served master carries, which the selection and the legible-list
        // filter match against, not the names the tracks asked for (the rewriter disambiguates and
        // escapes them).
        injectedSubtitleRenditionNames = prepared.servesSubtitleRenditions
            ? Dictionary(
                uniqueKeysWithValues: zip(tracks.map(\.externalID), prepared.renditionNames))
            : [:]
        #if os(iOS)
        // #86 / #227: a receiver cannot reach 127.0.0.1. Mounting while already AirPlaying has to hand out
        // the LAN address straight away; the route-change reload re-enters this path and re-resolves it.
        return airPlayActive ? airPlayHostSwapped(prepared.masterURL) : prepared.masterURL
        #else
        return prepared.masterURL
        #endif
    }

    /// #168: program `preferredDisplayCriteria` for an HDR range detected on the probe-free nativeRemoteHLS
    /// bypass. The loopback path applies criteria before item load from its libav probe; this path has no
    /// probe, so it applies late, once AVPlayer's parsed video-track format resolves the range. Without the
    /// panel switch a bare AVPlayerLayer presents no HDR video (audio-only, black; the reporter's symptom).
    /// SDR needs no switch, and criteria owned by AVKit or the host are left untouched (AE#842). No-op off
    /// tvOS (apply() returns .applied there) and where Match Content is off (apply() skips the write).
    @MainActor
    private func applyRemoteHLSDisplayCriteria(format: VideoFormat, options: LoadOptions) {
        guard RemoteHLSFormatDetection.shouldApplyDisplayCriteria(
            format: format, engineWritesCriteria: options.engineWritesDisplayCriteria) else { return }
        _ = displayCriteria.apply(
            format: format,
            frameRate: nativeHost?.detectedVideoFrameRate,
            codecTag: nil,
            omitColorExtensions: options.omitCriteriaColorExtensions
        )
    }

    /// AetherEngine#168 follow-up: reload the current live remote-HLS source through the loopback ingest
    /// path (`HLSLiveIngestReader` remuxes TS to fMP4), because AVPlayer reached readyToPlay without ever
    /// building a video track for a master that advertises one (HEVC-in-MPEG-TS carriage). The rerouted
    /// session runs the full loopback pipeline, including the probe-time display-criteria handshake the
    /// bypass lacks. `LoadOptions.httpHeaders` ride onto the ingest fetches so header-enforcing origins
    /// keep working (#119). The generation guard drops a verdict that a newer load()/stop() has outrun.
    ///
    /// AE#363 added a second caller with different evidence (the origin refused the mount) and therefore
    /// a different memory contract: only a carriage verdict is a property of the master and worth
    /// remembering, a refusal can be an expired token or a full connection cap.
    @MainActor
    private func rerouteRemoteHLSOntoLiveIngest(url: URL, expectedGeneration: UInt64,
                                                rememberVerdict: Bool = true,
                                                evidence: String? = nil) async {
        guard loadGeneration == expectedGeneration else {
            EngineLog.emit("[AetherEngine] #168: ingest reroute dropped (session superseded)", category: .engine)
            return
        }
        let reason = evidence.map { "AE#363: \($0)" }
            ?? "#168: nativeRemoteHLS built no video track for a master that advertises video"
        EngineLog.emit(
            "[AetherEngine] \(reason); rerouting onto the live-ingest loopback path (TS -> fMP4 remux)",
            category: .engine
        )
        // #199: remember the verdict so the next load of this master (host retune after an ingest
        // death, zap-back) skips the doomed native mount and its watchdog grace entirely.
        if rememberVerdict { rerouteVerdictMemory.record(url, now: Date()) }
        var options = loadedOptions
        options.nativeRemoteHLS = false
        let reader = HLSLiveIngestReader(playlistURL: url, httpHeaders: options.httpHeaders,
                                        diagnosticContext: options.sourceDiagnosticsContext)
        do {
            _ = try await load(source: .custom(reader, formatHint: "mpegts"), options: options)
        } catch is CancellationError {
        } catch {
            // load() has already surfaced .error state on its failure paths; nothing to add here.
            EngineLog.emit("[AetherEngine] #168: ingest reroute load failed: \(error)", category: .engine)
        }
    }

    func loadNative(
        url: URL,
        sourceHTTPHeaders: [String: String] = [:],
        startPosition: Double?,
        audioSourceStreamIndex: Int32? = nil,
        keepDvh1TagWithoutDV: Bool = false,
        forceDolbyVisionOnNonDVDisplay: Bool = false,
        dolbyVisionHandling: DolbyVisionHandling = .automatic,
        dolbyVisionRPUProfile: Int? = nil,
        matchContentEnabled: Bool = true,
        panelIsInHDRMode: Bool = false,
        sessionDisplayCaps: DisplayCapabilities,
        audioBridgeMode: AudioBridgeMode = .surroundCompat,
        isLive: Bool = false,
        dvrWindowSeconds: Double? = nil,
        liveRejoin: Bool = false,
        preopenedDemuxer: Demuxer? = nil,
        keepsMediaPlaylistRoute: Bool = false,
        generation: UInt64,
        resolvePanelRouting: (() async throws -> Bool)? = nil
    ) async throws {
        // companionAudioReader is set by the reader's resolver before any main-stream byte flows, so it is
        // final by the time loadNative runs; nil means muxed audio.
        let liveIngest = customReader as? LiveIngestSourceInfo
        let companionAudioReader = liveIngest?.companionAudioReader
        // AE#359: same guarantee as the companion reader, the resolver has published these before any
        // main-stream byte flows, so the list is final here.
        if let liveIngest { surfaceLiveSubtitleRenditions(liveIngest.subtitleRenditions) }
        // Observed-cadence closure for live-ingest LL-HLS shaping (AetherEngine#167): read per manifest
        // render, so the engine reacts to how the origin ACTUALLY delivers segments rather than trusting its
        // self-reported TARGETDURATION. weak so it never retains the host-owned reader past teardown. The
        // self-reported TARGETDURATION rides along only as a valid lower bound on the floor.
        let liveCadenceObservation: (@Sendable () -> Double?)?
        if let liveIngest {
            liveCadenceObservation = { [weak liveIngest] in liveIngest?.observedLiveCadenceSeconds }
        } else {
            liveCadenceObservation = nil
        }
        // AE#447: the floor is measured (arrival cadence + the longest segment the upstream really
        // served), the advert rides along for the seal log only. Both weak, same reason as above.
        let liveClosedCadenceObservation: (@Sendable () -> Double?)?
        let liveUpstreamSegmentDurationObservation: (@Sendable () -> Double?)?
        let liveJoinBacklogObservation: (@Sendable () -> Double?)?
        let liveJoinSpentObservation: (@Sendable () -> Bool?)?
        if let liveIngest {
            liveJoinBacklogObservation = { [weak liveIngest] in liveIngest?.joinBacklogSeconds }
            liveJoinSpentObservation = { [weak liveIngest] in liveIngest?.joinIsSpent }
            liveClosedCadenceObservation = { [weak liveIngest] in liveIngest?.closedLiveCadenceSeconds }
            liveUpstreamSegmentDurationObservation = { [weak liveIngest] in
                liveIngest?.upstreamSegmentDurationSeconds
            }
        } else {
            liveClosedCadenceObservation = nil
            liveUpstreamSegmentDurationObservation = nil
            liveJoinBacklogObservation = nil
            liveJoinSpentObservation = nil
        }
        let upstreamSelfReportedTargetDuration = liveIngest?.upstreamTargetDuration
        // #199: in-engine reopen transport for live ingest sessions. Only HLSLiveIngestReader main
        // readers are reconstructible blind (immutable URL + headers, hint always "mpegts"); the
        // demuxed-audio shape is excluded because a reopen would also have to rebuild the side audio
        // demuxer over the fresh companion. Other custom readers (disc, SMB) have no transport and
        // keep the host-retune contract.
        let ingestReopenFactory: HLSVideoEngine.CustomSourceReopenFactory?
        if isLive, let ingestReader = customReader as? HLSLiveIngestReader, companionAudioReader == nil {
            ingestReopenFactory = {
                ingestReader.makeFreshMainReader().map { (reader: $0 as IOReader, formatHint: "mpegts") }
            }
        } else {
            ingestReopenFactory = nil
        }
        // AE#493 / AE#535: the session table arrives as a parameter because it has to be the ONE the
        // caller composed. This line used to re-read `Self.displayCapabilities`, and the comment above it
        // claimed it was the table the format clamp had used; two reads of a property that answers at call
        // time are not one table. Measured 203 ms apart on a device, they disagreed, and an HDR10+ title
        // whose load had read `dv=true` was served media-direct with its master withheld.
        let session = HLSVideoEngine(
            url: url,
            sourceHTTPHeaders: sourceHTTPHeaders,
            dvModeAvailable: sessionDisplayCaps.supportsDolbyVision,
            displaySupportsHDR: sessionDisplayCaps.supportsHDR,
            keepDvh1TagWithoutDV: keepDvh1TagWithoutDV,
            forceDolbyVisionOnNonDVDisplay: forceDolbyVisionOnNonDVDisplay,
            dolbyVisionHandling: dolbyVisionHandling,
            dolbyVisionRPUProfile: dolbyVisionRPUProfile,
            matchContentEnabled: matchContentEnabled,
            panelIsInHDRMode: panelIsInHDRMode,
            audioSourceStreamIndexOverride: audioSourceStreamIndex,
            undecodableAudioStreamIndices: undecodableLiveAudioStreamIndices,
            audioBridgeMode: audioBridgeMode,
            objectAudioRendering: loadedOptions.objectAudioRendering,
            stereoPresentation: loadedOptions.stereoPresentation,
            isLiveSession: isLive,
            dvrWindowSeconds: dvrWindowSeconds,
            // AE#195/#208: the session resolves the cut target and enables the bounded first-manifest
            // path only for the host's explicit fastZap profile.
            liveJoinProfile: loadedOptions.liveJoinProfile,
            sourceOpenPolicy: loadedOptions.sourceOpenPolicy,
            diagnosticContext: loadedOptions.sourceDiagnosticsContext,
            liveStartupGraceSeconds: loadedOptions.liveStartupGraceSeconds,
            liveStartupSingleSegmentMinimumSeconds: loadedOptions.liveStartupSingleSegmentMinimumSeconds,
            liveEdgeCushionSeconds: loadedOptions.liveEdgeCushionSeconds,
            blockingReloadOverride: loadedOptions.liveBlockingReload,
            liveCadenceObservation: liveCadenceObservation,
            liveClosedCadenceObservation: liveClosedCadenceObservation,
            liveUpstreamSegmentDurationObservation: liveUpstreamSegmentDurationObservation,
            liveJoinBacklogObservation: liveJoinBacklogObservation,
            liveJoinSpentObservation: liveJoinSpentObservation,
            upstreamSelfReportedTargetDuration: upstreamSelfReportedTargetDuration,
            preopenedDemuxer: preopenedDemuxer,
            sourceReopenableByURL: !isCustomSource,
            customSourceReopenFactory: ingestReopenFactory,
            companionAudioReader: companionAudioReader,
            liveSourceAnnouncesDiscontinuities: liveIngest != nil,
            // Caller-bounded probe budget (#68) for the fallback open / live reopen; the happy path reuses preopenedDemuxer.
            probesize: loadedOptions.probesize,
            maxAnalyzeDuration: loadedOptions.maxAnalyzeDuration,
            sequentialOrigin: loadedOptions.sequentialOrigin,
            // #377: the session's own opens (fallback, live reopen, restart reopen) keep the transport
            // the host asked for; without it the flag lasts exactly as long as the pre-opened demuxer.
            heldSourceConnection: loadedOptions.heldSourceConnection,
            declaredDurationSeconds: loadedOptions.declaredDurationSeconds,
            forwardBufferSegments: forwardBufferSegmentsForSession(loadedOptions.forwardBufferSegments),
            sessionCacheByteBudget: loadedOptions.sessionCacheByteBudget
        )
        sessionCacheStatusToken &+= 1
        let cacheStatusToken = sessionCacheStatusToken
        session.onSessionCacheStatusChanged = { [weak self] status in
            Task { @MainActor [weak self] in
                self?.acceptSessionCacheStatus(status, token: cacheStatusToken)
            }
        }

        // AE#792: the session's live header store, shared with the playback demuxer it was handed, so
        // `updateRequestHeaders(_:)` reaches that reader and every reopen the producer makes. Set before start().
        session.requestHeaders = sessionRequestHeaders
        // AE#464: every producer this session builds reads it off the session. Set before start().
        session.audioDelaySeconds = loadedOptions.audioDelaySeconds
        session.audioShaping = loadedOptions.audioShaping
        session.servesSegmentsProgressively = loadedOptions.progressiveSegmentDelivery
        // #240: the pump claims the source link through this gate while it is fetching, so the
        // subtitle side readers can stay out of its way. Set before start().
        session.sideReaderLinkGate = sideReaderLinkGate
        // AE#682: set before start(), where the session decides whether it can serve the rendition.
        // A custom-IO source is not reopenable by URL, so the side reader gets a clone of its own;
        // a reader that cannot clone leaves the rendition absent.
        session.generatesBackgroundScrubPreviews = loadedOptions.generatesBackgroundScrubPreviews
        if loadedOptions.serveIFramePlaylist {
            session.requestIFramePlaylist()
            if isCustomSource, let clone = customReader?.makeIndependentReader() {
                session.customIFrameReader = (reader: clone, formatHint: customFormatHint)
            }
        }
        // #260: an observer installed before load has to reach this session's producers too.
        session.setNativeVideoFrameTimeObserver(nativeVideoFrameTimeObserver)
        prepareDualLayerOutputRoute(session: session)
        // A load that fails or is superseded before the session is handed over stops only its own route: a
        // newer load may already have prepared the next one.
        weak var preparedOutputRoute = dualLayerOutputRouteObject
        var outputRouteHandedOver = false
        defer { if !outputRouteHandedOver { stopDualLayerOutputRoute(ifStill: preparedOutputRoute) } }
        // Audit Vcore-101: every hop below is dropped once this session has ended (`hop(for:)`).
        session.onFirstHDR10PlusDetected = { [weak self] in
            self?.hop(for: generation) { [weak self] in self?.handleHDR10PlusDetected() }
        }
        installPlaylistShiftRelay(on: session, generation: generation)
        session.onSeekStateChanged = { [weak self] inFlight, playlistTime in
            self?.hop(for: generation) { [weak self] in
                guard let self = self else { return }
                // Fold playlist-axis segment time onto the published display axis (#38); the origin keeps a disc
                // scrub target 0-based like currentTime (0 off disc). nil clears without disturbing the last value.
                let target = playlistTime.map { self.displaySeconds(forPlaylistSeconds: $0) }
                self.setNativeScrubSeek(inFlight: inFlight, target: target)
                // #112: a producer restart settles here (out-of-range fetch on a fast-forward, or a wedge reconcile)
                // without going through seek()'s landing, so the embedded PGS side reader is never re-armed. Give it
                // a debounced re-anchor once the restart run drains; it no-ops unless the retained store fails to
                // cover the playhead. onSeekStateChanged is emitted only from the restart path, never for an ordinary
                // in-budget seek, so this does not disturb the normal seek re-arm.
            }
        }
        session.onNetworkPhaseChanged = { [weak self] phase in
            self?.hop(for: generation) { [weak self] in self?.setReaderNetworkPhase(phase) }
        }
        // #65: let the producer read AVPlayer's real position off-main when it re-anchors on a backpressure wedge.
        session.currentPlaybackPositionProvider = { [renderedPositionMirror] in renderedPositionMirror.get() }
        // #65 pause false-positive: let the producer read AVPlayer's play intent off-main so its backpressure
        // wedge detector suspends while the consumer is paused. Set before start() so makeProducer captures it.
        session.playIntentProvider = { [playIntentMirror] in playIntentMirror.get() }
        // #35/#93 cold-startup: let the producer read whether the first frame has landed, so its wedge
        // detector stays suspended through a slow DV-master pre-roll instead of re-anchoring and livelocking.
        session.hasStartedRenderingProvider = { [hasRenderedFirstFrameMirror] in hasRenderedFirstFrameMirror.get() }
        // AE#520 round 2: let the outage close read how much the consumer can still play without being
        // handed anything, off-main and without blocking a playlist build on an AVFoundation read.
        session.consumerBufferedSecondsProvider = { [consumerContiguousBufferMirror] in
            consumerContiguousBufferMirror.get()
        }
        // #93 retest: let the wedge re-anchor aim the producer at a pending unlanded user seek target
        // instead of the frozen clock (same decision the nudge and stage-2 reload apply).
        session.recoverySeekTargetProvider = { [recoverySeekTargetMirror] in recoverySeekTargetMirror.get() }
        // #93 residual: after a wedge re-anchor with a consumer that stopped requesting entirely,
        // nudge AVPlayer: a zero-tolerance seek to its own position rebuilds AVFoundation's loading
        // pipeline (the effect a manual back-out had). Opens the spurious-pause window too, since
        // the nudge can bounce the transport state.
        session.onConsumerReengageNeeded = { [weak self] position in
            self?.hop(for: generation) { [weak self] in
                guard let self else { return }
                self.reengageStalledConsumer(position: position, trigger: "wedge re-anchor")
                // #93 startup: a loader that died BEFORE the first frame never posts
                // playbackStalled, so this path arms its own stage-2 escalation instead of
                // relying on the stall watchdog. Same contract as the watchdog's stage 2:
                // fetches still frozen after the grace window while waitingToPlay on a
                // healthy item means only a fresh AVPlayerItem revives the loader.
                let fetchesAfterNudge = self.nativeVideoSession?.mediaFetchCountSnapshot ?? 0
                self.stallReengageTask?.cancel()
                self.stallReengageTask = Task { @MainActor [weak self] in
                    try? await Task.sleep(
                        nanoseconds: UInt64(Self.stallReengageGraceSeconds * 1_000_000_000))
                    guard !Task.isCancelled, let self else { return }
                    let fetchesFinal = self.nativeVideoSession?.mediaFetchCountSnapshot ?? 0
                    guard fetchesFinal == fetchesAfterNudge,
                          let player = self.currentAVPlayer,
                          player.timeControlStatus == .waitingToPlayAtSpecifiedRate,
                          player.currentItem?.status != .failed else { return }
                    // #115: read the position at reload time, same as the stall watchdog's
                    // stage 2; the wedge-trip capture is two grace windows stale by now.
                    // AE#422: the mirror, not a sync XPC read on the main actor from inside a stall.
                    self.reloadStalledConsumerItem(position: self.renderedPositionMirror.get())
                }
            }
        }
        session.onPlaylistShiftRebased = { [weak self] seconds, seamOutputSeconds in
            self?.hop(for: generation) { [weak self] in
                guard let self = self else { return }
                // Program boundary: keep the source-PTS seam for rendered cues while the item clock
                // continues forward. The live display/seek axis stays on its initial shift.
                var map = self.presentationAxis
                // Cap inside appendSeam; losing the oldest only reduces fidelity for DVR positions past 60+ program boundaries.
                map.appendSeam(shiftSeconds: seconds, activatingAtItemSeconds: seamOutputSeconds)
                self.setPresentationAxis(map)
            }
        }
        session.onLiveSourceReopening = { [weak self, weak session] in
            self?.hop(for: generation) { [weak self, weak session] in
                guard let self, let session, self.nativeVideoSession === session else { return }
                self.endRecordingIfRunning(reason: .sourceReset)
            }
        }
        // Unset, the session reports the exhaustion through `onLiveSourceReset`: a host that never
        // subscribed to `liveSourceReplayExhausted` would otherwise hold the last frame for good.
        if loadedOptions.hostRetriesExhaustedLiveReplay {
            session.onLiveSourceReplayExhausted = { [weak self, weak session] in
                self?.hop(for: generation) { [weak self, weak session] in
                    guard let self, let session, self.nativeVideoSession === session else { return }
                    self.noteLiveSourceGivenUp()
                    self.endRecordingIfRunning(reason: .sourceReset)
                    self.liveSourceReplayExhausted.send()
                }
            }
        }
        session.onLivePlaylistRenewal = { [weak self, weak session] in
            self?.hop(for: generation) { [weak self, weak session] in
                guard let self, let session, self.nativeVideoSession === session,
                      let oldURL = (self.currentAVPlayer?.currentItem?.asset as? AVURLAsset)?.url,
                      let url = session.renewedLivePlaylistURL(replacing: oldURL), url != oldURL else { return }
                self.stallReengageTask?.cancel()
                self.stallReengageTask = nil
                self.liveOutageResumeWatcher?.cancel()
                self.liveOutageResumeWatcher = nil
                session.clearLiveOutageEndlist()
                self.reloadStalledConsumerItem(position: self.renderedPositionMirror.get(),
                    allowPausedConsumer: true, liveRejoinOverride: self.currentTime,
                    replacementURL: url)
            }
        }
        session.onLiveSourceReset = { [weak self, weak session] in
            Task { @MainActor in
                // Stale session (superseded by a zap) must not retune the current channel.
                guard let self, let session else {
                    EngineLog.emit(
                        "[AetherEngine] onLiveSourceReset dropped: self/session deallocated",
                        category: .session
                    )
                    return
                }
                guard self.nativeVideoSession === session else {
                    EngineLog.emit(
                        "[AetherEngine] onLiveSourceReset dropped: session superseded (not current)",
                        category: .session
                    )
                    return
                }
                EngineLog.emit(
                    "[AetherEngine] onLiveSourceReset → publishing liveSourceReset to host",
                    category: .session
                )
                // AE#446 round 3: a #446 outage hold is waiting on this read; it has to stop saying so.
                self.noteLiveSourceGivenUp()
                // AE#560: a reset can bring back different codecs, different parameter sets or a
                // different program, and writing that into streams declared from the old source
                // produces a file that is unplayable or silently wrong past the seam. The recording
                // ends here; the host has the event and starts part two if it wants one.
                self.endRecordingIfRunning(reason: .sourceReset)
                self.liveSourceReset.send()
            }
        }
        // AE#627: the first join found no entry point the native route can open. Reopening joins the
        // same bitstream, so the session goes to the software path, or straight to the host when
        // that rung is not on offer, instead of spending three 15 s reopen cycles first.
        session.onLiveJoinWithoutEntryPoint = { [weak self, weak session] in
            Task { @MainActor in
                guard let self, let session, self.nativeVideoSession === session else { return }
                let request = SoftwarePathEscalation.Request(
                    domain: SoftwarePathEscalation.liveJoinErrorDomain,
                    code: 0,
                    message: "live join found no entry point the native route can open",
                    positionSeconds: 0
                )
                let offered = SoftwarePathEscalation.shouldEscalate(
                    errorDomain: request.domain,
                    availability: SoftwarePathEscalation.Availability(
                        alreadyEscalated: self.softwarePathEscalationBudget.isSpent,
                        preferredDecodePath: self.loadedOptions.preferredDecodePath,
                        nativeRemoteHLS: self.loadedOptions.nativeRemoteHLS,
                        hostAllowsEscalation: self.loadedOptions.escalatesToSoftwarePath))
                guard offered else {
                    EngineLog.emit(
                        "[AetherEngine] AE#627 software path not on offer for this session; "
                        + "handing the join failure to the host",
                        category: .session
                    )
                    session.giveUpLiveJoinWithoutEntryPoint()
                    return
                }
                await self.escalateToSoftwarePath(request, expectedGeneration: generation)
            }
        }
        // AE#641: the live bridge decoded nothing, so the served media carries an audio track that
        // will never be filled and AVPlayer waits on it forever. The session is rebuilt video-only.
        session.onLiveAudioDecodesNothing = { [weak self, weak session] streamIndex, summary in
            Task { @MainActor in
                guard let self, let session, self.nativeVideoSession === session else { return }
                await self.dropUndecodableLiveAudio(streamIndex: streamIndex, bridgeSummary: summary)
            }
        }
        // #126: zero-progress VOD pump death (readError before any packet/segment), and #169:
        // mid-session readError after the revive cap. Without this the host sees
        // isPlayable=true / a stalled item and waits until its own timeout.
        session.onVODVideoConfigurationChanged = { [weak self, weak session] epoch, summary in
            Task { @MainActor in
                guard let self, let session else { return }
                await self.handleVODVideoConfigurationChange(session: session, epoch: epoch,
                    summary: summary, generation: generation)
            }
        }
        session.onVODSourceFailed = { [weak self, weak session] code, reason, kind in
            Task { @MainActor in
                guard let self, let session, self.nativeVideoSession === session else {
                    EngineLog.emit(
                        "[AetherEngine] onVODSourceFailed dropped: session superseded or deallocated",
                        category: .session
                    )
                    return
                }
                self.publishError(PlaybackErrorInfo(kind: kind,
                                                    message: "\(reason) (code \(code))",
                                                    underlyingCode: Int(code)))
            }
        }
        // prepareNativeSubtitles + non-bitmap text tracks: builds the native subtitle table; must be set before start().
        // Each text track becomes one WebVTT rendition served by HLSLocalServer (#15 / Sodalite#32, all-tracks; NOT
        // muxed into the A/V segments). Load-declared external tracks are already merged into subtitleTracks and join
        // the table (#88); VOD only, a live program's renditions cannot cover an unbounded timeline. Runtime sidecar
        // selections stay table-less.
        // Bitmap codecs excluded via the shared decoder-name classifier (a prior exact-match Set used descriptor
        // names that never matched TrackInfo.codec's decoder names, so PGS/DVB/DVD leaked in).
        // Exclude in-band CEA-608/708 (#77): no demuxable packets for a text rendition; served by the CC tap.
        var textTracks = subtitleTracks.filter {
            !Self.isBitmapSubtitleCodec($0.codec) && !Self.isEmbeddedClosedCaptionCodec($0.codec)
                && (!$0.isExternal || !loadedOptions.isLive)
        }
        // Sodalite#32: AVKit reliably renders only the FIRST native subtitle rendition (ordinal 0 / subs_0);
        // device-confirmed that a programmatic selection of a later rendition is fetched then dropped after one
        // segment. So move the preferred-language track to ordinal 0 and have the host select ordinal 0.
        // #590: the same BCP-47 ranking the overlay path uses, so an inline pick and the native
        // rendition cannot disagree about which zh-Hant track was meant.
        if let idx = AetherEngine.bestLanguageMatchIndex(
            languages: textTracks.map(\.language),
            preferredLanguages: loadedOptions.nativeSubtitlePreferredLanguages,
            kind: .subtitle,
            secondaryRank: { AetherEngine.subtitlePickRank(textTracks[$0]) }
        ), idx != 0 {
            textTracks.insert(textTracks.remove(at: idx), at: 0)
        }
        nativeSubtitleTrackTable = textTracks.map { track in
            NativeSubtitleTrackEntry(sourceStreamIndex: track.isExternal ? nil : track.id,
                                     externalID: track.isExternal ? track.id : nil,
                                     language: track.language,
                                     isForced: track.isForced)
        }
        // Rendition metadata built ONCE (unique NAMEs + FORCED); the published track list and the
        // master's EXT-X-MEDIA tags must agree, and duplicate names collapse AVFoundation's
        // legible options (device: 3 declared renditions, 2 options, wrong-language selection).
        // Phase D: bitmap tracks (PGS/DVB/DVD) become OCR-fed renditions, appended AFTER the
        // text and CC entries so existing ordinals stay byte-stable. Unique NAMEs are computed
        // over text+bitmap together: a same-language pair must get the numbered suffix, or
        // AVFoundation collapses the legible options.
        let bitmapEntries = Self.bitmapOCRSubtitleEntries(from: subtitleTracks, isLive: loadedOptions.isLive)
        let combinedInfos = Self.nativeSubtitleRenditionInfos(for: nativeSubtitleTrackTable + bitmapEntries)
        let renditionInfos = Array(combinedInfos.prefix(nativeSubtitleTrackTable.count))
        let bitmapInfos = Array(combinedInfos.suffix(bitmapEntries.count))
        nativeSubtitleTracks = renditionInfos.enumerated().map { ordinal, info in
            NativeSubtitleTrack(ordinal: ordinal, language: info.language, displayName: info.name)
        }
        let hasTextSubtitleTrack = !nativeSubtitleTrackTable.isEmpty
        // #98: an in-band CEA-608 track (no text track needed) also warrants the native path so its
        // decoded cues can ride a WebVTT rendition (survives PiP/AirPlay) instead of overlay-only.
        // Load-bearing (#131): must exclude the synthetic A53 entry. With a stale synthetic track
        // after a no-reprobe reload (e.g. an audio switch), a plain codec match here would flip
        // this true and arm a #98 rendition bound to nonexistent stream 99608.
        let hasCC608 = demuxableClosedCaptionTrack != nil
        let hasBitmapOCRTrack = !bitmapEntries.isEmpty
        session.enableNativeSubtitleTrackForSession = loadedOptions.prepareNativeSubtitles
            && (hasTextSubtitleTrack || hasCC608 || hasBitmapOCRTrack)
        // Sodalite#32 Phase 2: tap decoders honor the host's markup preference (overlay renders styled
        // ASS; the WebVTT rendition strips at serve). #112 rework: the overlay itself is fed by the
        // packet-store drainer, not by tap-event forwarding.
        session.preserveASSMarkupForSubtitleTap = loadedOptions.preserveASSMarkup
        session.teletextPageForSubtitleTap = loadedOptions.teletextPage
        EngineLog.emit("[AetherEngine] native subtitles: prepare=\(loadedOptions.prepareNativeSubtitles) eager=\(loadedOptions.eagerNativeSubtitleReaders) textTracks=\(nativeSubtitleTrackTable.count) bitmapOCR=\(bitmapEntries.count) enable=\(session.enableNativeSubtitleTrackForSession)", category: .engine)

        // #77: arm the in-band CC tap before start() so the first producer keeps the CC stream.
        setupClosedCaptionTapIfNeeded(session: session)

        // #15: create the native subtitle cue stores BEFORE start() so the VideoSegmentProvider receives the
        // references at init (the WebVTT rendition master tags + /subs endpoints read them; readers fill them
        // lazily on selection). The shift is applied after start() once the playlist shift is known.
        if session.enableNativeSubtitleTrackForSession,
           (!nativeSubtitleTrackTable.isEmpty || hasCC608 || hasBitmapOCRTrack) {
            session.nativeSubtitleCueStoresForSession = nativeSubtitleTrackTable.map { _ in NativeSubtitleCueStore() }
            session.nativeSubtitleLanguagesForSession = nativeSubtitleTrackTable.map { $0.language }
            session.nativeSubtitleRenditionInfosForSession = renditionInfos
            // Sodalite#32: stream indices arm the producer's subtitle pump tap, which harvests cue packets
            // from the main pump's existing read (no side-channel bandwidth) for the produced region.
            session.nativeSubtitleSourceStreamIndicesForSession = nativeSubtitleTrackTable.map { $0.sourceStreamIndex.map(Int32.init) }
            // Sodalite#32: the native rendition matching the preferred subtitle language must be the master's
            // DEFAULT=YES one, because a host-selected legible track only renders if it is the group default
            // (AVKit hides a non-default selection as mute-only). Resolved here, before start() builds the
            // master, so the default is correct on AVKit's first fetch; the host selects this same ordinal.
            let defaultOrdinal = AetherEngine.bestLanguageMatchIndex(
                languages: nativeSubtitleTrackTable.map(\.language),
                preferredLanguages: loadedOptions.nativeSubtitlePreferredLanguages,
                kind: .subtitle
            ) ?? 0
            session.nativeSubtitleDefaultOrdinal = defaultOrdinal
            nativeSubtitleDefaultOrdinal = defaultOrdinal
            // #98: bridge the in-band CEA-608 track into a native rendition. Its cues come from the
            // ClosedCaptionTap (no FFmpeg decoder, so the side-demuxer reader self-skips it), so we
            // append a store the tap fills and expose it as the last native subtitle ordinal. Never
            // the default: 608 is user-selected.
            if let ccTrack = demuxableClosedCaptionTrack {
                let ccStore = NativeSubtitleCueStore()
                self.ccNativeStore = ccStore
                let ccOrdinal = session.nativeSubtitleCueStoresForSession.count
                let ccName = ccTrack.language.map { "CC (\($0))" } ?? "Closed Captions"
                session.nativeSubtitleCueStoresForSession.append(ccStore)
                session.nativeSubtitleLanguagesForSession.append(ccTrack.language)
                session.nativeSubtitleRenditionInfosForSession.append(
                    NativeSubtitleRenditionInfo(language: ccTrack.language, name: ccName, isForced: false))
                session.nativeSubtitleSourceStreamIndicesForSession.append(Int32(ccTrack.id))
                nativeSubtitleTrackTable.append(
                    NativeSubtitleTrackEntry(sourceStreamIndex: ccTrack.id, language: ccTrack.language))
                nativeSubtitleTracks.append(
                    NativeSubtitleTrack(ordinal: ccOrdinal, language: ccTrack.language, displayName: ccName))
            }
            // Phase D: append the bitmap OCR renditions last. Stores stay empty until the OCR
            // worker (embedded) or the sidecar OCR fill (external .sup) recognizes cues. The tap
            // index is nil ON PURPOSE: the pump tap decodes inline on the pump thread, where
            // bitmap decode + OCR must never run; the worker reads the packet store instead.
            for (i, entry) in bitmapEntries.enumerated() {
                let ordinal = session.nativeSubtitleCueStoresForSession.count
                session.nativeSubtitleCueStoresForSession.append(NativeSubtitleCueStore())
                session.nativeSubtitleLanguagesForSession.append(entry.language)
                session.nativeSubtitleRenditionInfosForSession.append(bitmapInfos[i])
                session.nativeSubtitleSourceStreamIndicesForSession.append(nil)
                nativeSubtitleTrackTable.append(entry)
                nativeSubtitleTracks.append(NativeSubtitleTrack(
                    ordinal: ordinal, language: entry.language, displayName: bitmapInfos[i].name))
            }
            // Sodalite#32: with eager readers the whole cue set is available up front, so serve the rendition as
            // one whole-program .vtt (the AVPlayer-reliable shape). VOD only (a live program has no fixed end).
            // Sodalite#32: whole-program renders reliably but is anchored to the stream start, so it breaks on
            // scrub (the loopback producer-restarts + re-anchors the video on seek, but AVKit keeps the cached
            // VOD .vtt). Use the WINDOWED shape (per-segment, 1:1 with the video segments) which AVKit re-fetches
            // at each position and is seek-robust; combined now with a COMPLETE store (read-to-EOF) so no window
            // is served empty (the earlier windowed sparse-fetch was tested with an incomplete parking reader).
            session.nativeSubtitleWholeProgram = false
            session.subtitleStreamStartSeconds = startPosition ?? 0
            EngineLog.emit("[AetherEngine] native subtitle default ordinal=\(defaultOrdinal) wholeProgram=\(session.nativeSubtitleWholeProgram) prefLangs=\(loadedOptions.nativeSubtitlePreferredLanguages) trackLangs=\(nativeSubtitleTrackTable.map { $0.language ?? "?" })", category: .engine)
        }

        // #93 residual: hand the resume position to the session so the FIRST producer anchors at
        // the matching segment instead of producing seg0 into an immediate teardown.
        session.initialStartSeconds = startPosition
        if keepsMediaPlaylistRoute {
            session.keepsMediaPlaylistRoute = true
            EngineLog.emit(
                "[AetherEngine] #849 audio switch keeps the media playlist: the display refused this "
                + "session's HDR master, and the switch does not change what it was asked",
                category: .session)
        }

        // session.start() opens its own Demuxer + prewarm seek (~1-3 s on slow CDN); detach so @MainActor doesn't block.
        var playbackURL: URL
        if let resolvePanelRouting {
            // AE#348: the panel is still switching. Produce the first segments now and choose the
            // playlist once `resolvePanelRouting` has the settled answer; `panelIsInHDRMode` above was
            // read before that and is not what routes this session.
            try await BlockingWork.detached(priority: .userInitiated) { [session] in
                do { try session.prepare() }
                catch { session.stop(reason: .loadFailed); throw error }
            }.value
            let routesAsHDRPanel: Bool
            do {
                routesAsHDRPanel = try await resolvePanelRouting()
            } catch {
                session.stop(reason: .loadFailed)
                throw error
            }
            playbackURL = try await BlockingWork.detached(priority: .userInitiated) { [session] in
                do { return try session.serve(panelIsInHDRMode: routesAsHDRPanel) }
                catch { session.stop(reason: .loadFailed); throw error }
            }.value
        } else {
            playbackURL = try await BlockingWork.detached(priority: .userInitiated) { [session] in
                do { return try session.start() }
                catch { session.stop(reason: .loadFailed); throw error }
            }.value
        }
        // AirPlay (#86): while external playback is active, serve the loopback over the device's LAN IP so
        // the receiver reaches the engine-processed stream (DV/Atmos/subtitles preserved). An HDR/DV master
        // is downgraded to the media playlist there (an SDR receiver rejects it, DrHurt); an SDR master is
        // kept so its subtitle renditions survive the trip (#227). Reverts on the reload when AirPlay ends.
        let served = airPlayAdjustedPlayback(url: playbackURL, session: session)
        playbackURL = served.url
        // Superseded while starting: stop and unwind before touching shared state.
        if loadGeneration != generation {
            session.stop(reason: .sourceChanged)
            try checkLoadCurrent(generation)
        }
        self.nativeVideoSession = session
        outputRouteHandedOver = true
        if let event = session.pendingVODVideoConfigurationMismatch {
            await handleVODVideoConfigurationChange(session: session, epoch: event.epoch,
                summary: event.summary, generation: generation, reportRefusal: false)
            try checkLoadCurrent(generation)
            // If no takeover occurred, the explicitly selected route cannot serve this source.
            throw HLSVideoEngine.HLSVideoEngineError.openFailed(reason: event.summary)
        }
        isSourceSeekable = session.openedSourceIsSeekable
        // AE#270: anchor the display axis on the container's own start time, which is what `duration` is
        // measured from. Taking it from the session rather than latching the first published shift keeps a
        // 0-based source byte-identical to the pre-#270 behaviour: the shift also carries the producer's
        // initial drift (-0.08 s on a B-frame MP4 whose first PTS is 0), the container start does not.
        // Live and disc keep their own rule (`PresentationOriginPolicy`).
        if !isLive, discTitles.isEmpty {
            latchedPresentationOrigin = session.sourceStartSeconds
            sourcePresentationOrigin = session.sourceStartSeconds
        }
        // #368: a sequential archive's source timestamps restart at every chunk seam, so no single
        // source PTS anchors its display axis. It publishes the item axis instead, which the producer
        // pins to 0 and `declaredDurationSeconds` measures.
        displayAxisIsItemAxis = session.sequentialOriginPinsProducerToZero
        nativeSubtitleRenditionsServed = served.subtitleRenditionsServed
        dolbyVisionConversion = session.servedDolbyVisionConversion
        extractorYieldState.activate(session: session)

        // #15: the stores were created before start() (above) so the VideoSegmentProvider got the references at
        // init for the WebVTT rendition. Now that the playlist shift is known, apply it, and arm the lazy
        // readers (started only when a native track is selected / PiP). The producer no longer muxes subtitles.
        if session.enableNativeSubtitleTrackForSession {
            let stores = session.nativeSubtitleCueStoresForSession
            if !stores.isEmpty {
                let shift = session.playlistShiftSeconds
                stores.forEach { $0.setShiftSeconds(shift) }
                nativeSubtitleReaderParams = (url: url, stores: stores)
                // #88: load-declared external tracks fill their stores with one whole-file decode
                // each (no side demuxer); embedded tracks keep the pump-tap / reader paths below.
                startExternalNativeStoreFill(session: session)
                // Sodalite#32: the producer's pump tap fills these stores for the whole produced region at
                // zero side-channel bandwidth, so the eager at-load readers (which competed with playback
                // for the remote link at startup) are only a fallback for sessions whose tap could not arm
                // (no demuxable stream indices, e.g. all-sidecar). The lazy reader on PiP selection stays:
                // it covers AVKit's ~240s forward .vtt prefetch burst beyond the produced region.
                let tapArmed = session.nativeSubtitleSourceStreamIndicesForSession.contains { $0 != nil }
                if loadedOptions.eagerNativeSubtitleReaders && !tapArmed {
                    // Anchor at the SESSION START POSITION (resume), not 0, and read straight to EOF (no
                    // read-ahead parking). A from-0 read behind a resume position spent the whole session
                    // catching up over a remote link and never covered the playhead (device: readMax 48s vs
                    // playhead 304s, every .vtt served empty).
                    let readEOF = !loadedOptions.isLive
                    startNativeSubtitleReaders(url: url, stores: stores,
                                               readToEOF: readEOF, startAtSeconds: startPosition ?? 0)
                    EngineLog.emit("[AetherEngine] native subtitle eager readers started: stores=\(stores.count) readToEOF=\(readEOF) startAt=\(String(format: "%.1f", startPosition ?? 0))", category: .engine)
                } else if tapArmed {
                    EngineLog.emit("[AetherEngine] pump tap active; eager readers skipped (lazy reader covers the select burst)", category: .engine)
                }
            }
        }

        // Reuse the existing host across native->native reloads (issue #15): a fresh AVPlayer breaks AVKit's MediaRemote re-registration ("Code=14 client callback"), blanking the Control Center widget. stopInternal kept the host alive (keepNativeHost).
        let host: NativeAVPlayerHost
        if let existing = nativeHost {
            host = existing
        } else {
            host = makeNativeHost()
        }
        host.playerLayer.videoGravity = _videoGravity
        // Forward pre-load externalMetadata so the AVPlayerItem picks it up before AVPlayer assigns it.
        if !pendingExternalMetadata.isEmpty {
            host.setExternalMetadata(pendingExternalMetadata)
        }
        replayVideoNowPlayingInfo(to: host)
        self.nativeHost = host
        startDualLayerOutputRoute(player: host.avPlayer)
        // AE#446 round 5: an item's axis is stated by the playlist it loads, so the statement has to be
        // keyed to the item that loaded it. Installed on the one funnel every attach passes through, so
        // the session's FIRST item is covered as well as every swap: both used to reconstruct the axis
        // from the cache instead, and a reconstruction is only as good as the older of its two samples.
        host.iFramePlaylistWithheld = { [weak session] in session?.iFrameRenditionWithheld ?? false }
        host.onWillAttachItem = { [weak self] in
            // The host owns this closure, so it reaches back for the host rather than capturing it.
            guard let self, let attaching = self.nativeHost else { return }
            self.nativeVideoSession?.armLiveItemAxisStatement()
            self.liveItemAxisArmedGeneration = attaching.itemGeneration
        }
        applyDesiredVolume(to: host)
        applyDesiredRate(to: host)
        // Publish before wiring mirrors so subscribers see the AVPlayer before the first time update. Only emit on change: re-publishing the same instance retriggers the AVKit re-registration this reuse path avoids.
        if currentAVPlayer !== host.avPlayer {
            self.currentAVPlayer = host.avPlayer
        }

        nativeCancellables.removeAll()
        host.$currentTime
            .sink { [weak self] value in
                self?.applyNativeHostClockTick(value)
            }
            .store(in: &nativeCancellables)
        // sourceTime = AVPlayer's rendered position folded onto source PTS (same seam shift as playhead). Published during seeks so subtitle/scrub consumers follow the picture, not the scrub target (issue #49).
        host.$renderedTime
            .sink { [weak self] value in
                guard let self = self else { return }
                let shift = self.presentationAxis.shiftSeconds(atItemSeconds: value)
                    ?? self.playlistShiftSeconds
                // #93 PiP skips: AVKit-side seeks never reach the engine seek API; a far rendered-
                // time jump is the engine-visible signal to re-anchor the subtitle readers.
                if Self.isSubtitleReanchorJump(from: self.renderedPositionMirror.get(), to: value) {
                    self.scheduleNativeSubtitleReanchor()
                }
                // #93 retest: retire the pending recovery seek target when it lands (rendered
                // reaches its neighbourhood) or goes stale (organic progress far from it, i.e.
                // AVPlayer abandoned the seek and playback runs elsewhere).
                if let pending = self.pendingRecoverySeekClockTarget {
                    if self.settleRecoveryClockIfRenderedTargetLanded(
                        rendered: value,
                        shift: shift,
                        completionRenderedTimePublished:
                            self.nativeHost?.latestSeekRenderedTimePublished ?? false
                    ) {
                        // A late landing settled the clock onto the target; if the deadline loop held the
                        // clock at the target and returned without finalizing (slow-source spinner path),
                        // leave `.seeking` now that the frame is presented. Also where a seek that already
                        // gave up (`.stalled`) finally reports `.landed` (AE#38 follow-up).
                        self.finalizeLateRecoverySeekLanding(
                            rendered: PresentationAxis.display(sourcePTS: value + shift,
                                                               origin: self.sourcePresentationOrigin))
                    } else {
                        let prev = self.lastRenderedForPendingSeek
                        if value > prev, value - prev < 1.0 {
                            self.pendingSeekProgressAccum += (value - prev)
                            if Self.isPendingSeekStale(progressWhilePending: self.pendingSeekProgressAccum) {
                                EngineLog.emit(
                                    "[AetherEngine] pending recovery seek target "
                                    + String(format: "%.2f", pending)
                                    + "s dropped (playback resumed elsewhere)",
                                    category: .engine
                                )
                                self.setPendingRecoverySeekTarget(nil)
                                // Deliberately does NOT finalize the programmatic seek here. This branch
                                // only proves "organic playback moved on", which is also true while a seek
                                // is legitimately still suspended in its initial budget or an extension
                                // window (a slow source drains the old-position buffer for seconds while
                                // the seek is pending). Clearing `programmaticSeekInFlight` from here would
                                // drop `isSeeking` and the host's spinner mid-recovery, and the loop's own
                                // idempotent clear means it would never come back. The deadline loop owns
                                // that state on every one of its exits, including the parked give-up.
                            }
                        }
                        self.lastRenderedForPendingSeek = value
                    }
                }
                // AE#38 follow-up: a native scrub's in-flight window ends when the PICTURE reaches the
                // scrub target, not when the coalesced restart run drains.
                self.checkPendingScrubLanding(rendered: value)
                // #65: mirror AVPlayer's rendered (playlist-axis) position for off-main wedge re-anchoring.
                self.renderedPositionMirror.set(value)
                // #368: on a sequential origin the "source PTS" of a rendered frame is whatever the
                // current archive chunk and libavformat's wrap correction made of it, so publishing it
                // would break both the documented `sourceTime == currentTime in steady play` relation
                // and host-rendered sidecar cues (whose times are relative to the archive start, i.e.
                // the item axis). Every other source keeps true source PTS for cue alignment.
                self.clock.sourceTime = self.displayAxisIsItemAxis ? value : value + shift
                // bufferedPosition = the end of the contiguous safe range (origin -> disk), expressed on
                // the display axis as the playhead plus contiguously available seconds ahead of it: the
                // segments AVPlayer already fetched, plus the disk SegmentCache band above them, which is
                // what the Network Buffer setting controls. Replaces AVPlayer's shallow ~4 s
                // loadedTimeRanges end (pinned by preferredForwardBufferDuration), which did not move with
                // the setting. readAhead >= 0 keeps the #54 contract that bufferedPosition never trails the
                // rendered frame. Drawn against the 0-based duration, so map onto the display axis to keep
                // the buffer bar aligned with currentTime (0 off disc). AE#105, #207 follow-up.
                // See docs issue #33 follow-up.
                self.refreshNativeBufferedPosition(playlistSeconds: value)
            }
            .store(in: &nativeCancellables)
        startLiveWindowTimer(host: host)
        // AE#515: the same parse `loadRemoteHLS` mirrors, read here as an upgrade only. This route has a
        // probe, so `sourceVideoFormat` is already answered and `videoFormat` is the clamped label; what
        // the item adds is the one thing the clamp cannot know on a platform without a capability table,
        // namely that AVFoundation is playing a Dolby Vision sample entry. Mirroring the sink instead
        // would overwrite a tvOS label the panel answered for.
        host.$detectedVideoFormat
            .compactMap { $0 }
            .sink { [weak self] fmt in
                self?.applyDolbyVisionLabelUpgrade(itemFormat: fmt)
            }
            .store(in: &nativeCancellables)
        wireCommonHostSinks(
            duration: host.$duration,
            isReady: host.$isReady,
            failure: host.$failure,
            didReachEnd: host.$didReachEnd,
            videoReadyForDisplay: host.$isVideoReadyForDisplay,
            storeIn: &nativeCancellables
        )
        host.$timeControlStatus
            .sink { [weak self, weak host] status in
                guard let self = self else { return }
                // #93 residual: during active stall recovery AVPlayer can drop a SPURIOUS .paused
                // (rate 0, no wait reason, no user action). Latching it kills both recovery paths,
                // so re-assert play() within the bounded window instead (see stallRecoveryWindowUntil).
                if Self.shouldReassertPlayDuringRecovery(
                    statusIsPaused: status == .paused,
                    engineStateIsPlaying: self.state == .playing,
                    now: Date(), windowUntil: self.stallRecoveryWindowUntil,
                    reasserts: self.stallRecoveryReasserts
                ) {
                    self.stallRecoveryReasserts += 1
                    EngineLog.emit(
                        "[AetherEngine] #65 spurious pause during stall recovery; re-asserting play "
                        + "(\(self.stallRecoveryReasserts)/\(Self.maxStallRecoveryReasserts))",
                        category: .engine
                    )
                    host?.play()
                    return
                }
                // #65 pause false-positive: mirror AVPlayer's play intent for the off-main producer wedge detector.
                // != .paused covers both .playing and .waitingToPlay, so a deep rebuffer (wants to play, starved)
                // still reads as play-intent and can legitimately trip the breaker; only a real pause suspends it.
                self.playIntentMirror.set(status != .paused)
                // #35/#93 startup latch: the first true .playing (rate running, not .waitingToPlay) means
                // pre-roll is over and a frame is presenting. Arms the backpressure wedge detector, which
                // stays suspended before this so a slow DV-master pre-roll is never re-anchored. Latched
                // for the item (reset only by load()), so a later backward-seek wedge (#93) still trips.
                if status == .playing { self.hasRenderedFirstFrameMirror.set(true) }
                // Reconcile state with external transport commands (AVKit bar, Control Center, hardware button); without this togglePlayPause() is a no-op (swallowed press). .waitingToPlayAtSpecifiedRate maps to .playing so the icon doesn't flicker on rebuffer.
                // isBuffering only once playback has started (not during initial load spin-up).
                let startedPlaying = self.state == .playing || self.state == .paused
                self.isBuffering = startedPlaying
                    && Self.nativeWaitIsRebuffer(status: status, reason: host?.waitingReason)
                // AE#440: the rate is rolling. The autostart wrote `state = .playing` before AVPlayer had
                // moved anything, and on a live join AVPlayer can hold a presented first frame still for
                // seconds past that, so `playbackPhase` reports `.loading` until this latches.
                //
                // After the `isBuffering` write and before the `startedPlaying` guard, and both halves of
                // that placement are load-bearing: latching first would recompute the phase against the
                // hold's stale `isBuffering` and publish one tick of `.rebuffering` on the way to
                // `.playing`, and latching after the guard would strand the axis (with it the phase) on a
                // roll that arrives while `state` is still `.loading`.
                if status == .playing { self.hasTransportRolled = true }
                guard startedPlaying else { return }
                switch status {
                case .paused:
                    // AE#440: AVPlayer's pre-play .paused reading reaches this sink after the autostart
                    // has already declared .playing, so latching it before the first roll published a
                    // millisecond of `.paused` on every native start. Before the transport has moved
                    // once, a .paused is the status the item was mounted with, not a pause.
                    //
                    // A pause the engine was ASKED for is the exception, and it has the same shape: the
                    // background-return reload autostarts, the host pauses on the resumed frame before
                    // the rate rolls, and AVPlayer's pre-pause .waitingToPlayAtSpecifiedRate lands after
                    // that pause and re-declares .playing. Swallowing the .paused that follows left the
                    // session at `state == .playing` with no roll to come, which the phase reports as
                    // `.loading` forever: a host spinner over a black screen that only a Play press
                    // could clear.
                    if Self.publishesTransportPause(
                        hasTransportRolled: self.hasTransportRolled,
                        transportIntentIsPlaying: self.nativeHost?.transportIntentIsPlaying ?? true
                    ), self.state != .paused { self.state = .paused }
                case .playing, .waitingToPlayAtSpecifiedRate:
                    if self.state != .playing { self.state = .playing }
                @unknown default:
                    break
                }
            }
            .store(in: &nativeCancellables)
        // Sodalite#168: a resume's evaluation can turn into a real stall without a status edge.
        host.$waitingReason
            .sink { [weak self, weak host] reason in
                // A cleared reason arrives just ahead of the status that ends the wait; that edge settles it.
                guard let self, let host, reason != nil else { return }
                let startedPlaying = self.state == .playing || self.state == .paused
                self.isBuffering = startedPlaying
                    && Self.nativeWaitIsRebuffer(status: host.timeControlStatus, reason: reason)
            }
            .store(in: &nativeCancellables)

        // #93 residual: every stall opens the spurious-pause recovery window (a fresh stall resets
        // the re-assert budget; the pause can trail the stall by tens of seconds while fetches stay
        // silent) AND arms the fast re-engage watchdog: the producer-wedge chain needs ~60 s before
        // its nudge, but a dead consumer pipeline (-15628 signature: stall, then ZERO media fetches
        // while waitingToPlay) is detectable within seconds of the notification.
        host.$stallCount
            .dropFirst()
            .sink { [weak self, weak host] count in
                guard let self = self else { return }
                self.stallRecoveryWindowUntil = Date().addingTimeInterval(Self.stallRecoveryWindowSeconds)
                self.stallRecoveryReasserts = 0
                let fetchesAtStall = self.nativeVideoSession?.mediaFetchCountSnapshot ?? 0
                // #405: what the producer had finalized when the stall began, so stage 2 can ask
                // whether anything has been produced since. nil = no local producer to ask.
                let segmentsAtStall = self.nativeVideoSession?.liveSegmentCountSnapshot
                self.stallReengageTask?.cancel()
                self.stallReengageTask = Task { @MainActor [weak self, weak host] in
                    // Level re-watch (#65): fetch activity inside the grace window used to disarm
                    // this watchdog permanently, but a player that drains its remaining TAIL
                    // segments and then parks on a frozen playlist (fwd buffer non-empty, so
                    // playbackStalled never re-fires) was exactly that case, and nothing ever
                    // re-armed. Re-baseline and keep watching instead, bounded so trickling
                    // fetches on a merely slow session hand back to the producer-side arms.
                    var baseline = fetchesAtStall
                    var passes = 0
                    watch: while true {
                        try? await Task.sleep(
                            nanoseconds: UInt64(Self.stallReengageGraceSeconds * 1_000_000_000))
                        guard !Task.isCancelled, let self, let host,
                              host.stallCount == count,
                              let player = self.currentAVPlayer else { return }
                        let fetchesNow = self.nativeVideoSession?.mediaFetchCountSnapshot ?? 0
                        switch Self.stallWatchVerdict(
                            fetchesNow: fetchesNow,
                            baseline: baseline,
                            isWaitingToPlay:
                                player.timeControlStatus == .waitingToPlayAtSpecifiedRate,
                            itemFailed: player.currentItem?.status == .failed,
                            passesSoFar: passes,
                            cap: Self.maxStallWatchPasses
                        ) {
                        case .disarm:
                            return
                        case .escalate:
                            break watch
                        case .rewatch:
                            passes += 1
                            baseline = fetchesNow
                        }
                    }
                    guard let self, let host,
                          self.currentAVPlayer != nil else { return }
                    // Stage 1: nudge seek. Device-proven to reach AVPlayer (rate re-asserts)
                    // but NOT always to revive its loader; stage 2 covers that.
                    // AE#422: same read the wedge path already takes from the mirror. This one was
                    // the sync XPC round trip the reporter caught blocking the app for 13.3 s.
                    self.reengageStalledConsumer(
                        position: self.renderedPositionMirror.get(),
                        trigger: "stall + \(Int(Self.stallReengageGraceSeconds))s without fetches")
                    // Stage 2: the -15628 loader poison ignores seeks; only a fresh item resets
                    // it. Escalate when the consumer stays silent through a second grace window.
                    let fetchesAfterNudge = self.nativeVideoSession?.mediaFetchCountSnapshot ?? 0
                    try? await Task.sleep(
                        nanoseconds: UInt64(Self.stallReengageGraceSeconds * 1_000_000_000))
                    guard !Task.isCancelled, host.stallCount == count else { return }
                    let fetchesFinal = self.nativeVideoSession?.mediaFetchCountSnapshot ?? 0
                    guard fetchesFinal == fetchesAfterNudge,
                          let player2 = self.currentAVPlayer,
                          player2.timeControlStatus == .waitingToPlayAtSpecifiedRate,
                          player2.currentItem?.status != .failed else { return }
                    // Storm shape of the final rung: on a frozen live playlist each reload replays
                    // the tail and re-stalls within seconds, and the fresh stall supersedes this
                    // task BEFORE the post-reload rung below can run. The persistent gate spans
                    // stall events: reloads at the same frozen position exhaust it, then the only
                    // remaining move is the host's (fresh session against the server route).
                    let reloadPosition = player2.currentTime().seconds
                    // #405: stage 2 replaces the CONSUMER's item, which is the wrong tool when the
                    // producer behind it has been starved by its origin: the fresh item refills the
                    // same frozen tail, parks again, and costs two more grace windows before the
                    // final rung asks for the retune. The finalized-segment count is the one fact
                    // that separates a dead consumer from a starved producer, and the ladder had
                    // never consulted it. Skip straight to the retune when nothing was produced
                    // since the stall.
                    let segmentsNow = self.nativeVideoSession?.liveSegmentCountSnapshot
                    if Self.liveProducerIsStarved(isLive: self.isLive,
                                                  segmentsAtStall: segmentsAtStall,
                                                  segmentsNow: segmentsNow) {
                        let seg = segmentsNow.map(String.init) ?? "?"
                        // AE#443: "nothing finalized" has two causes and they point in opposite
                        // directions. A starved producer is waiting on its origin; a PARKED one is
                        // being held by this engine and is not even reading, so naming the source
                        // sends the reader to the wrong logs (it sent the reporter of #443 to his
                        // server three times).
                        let parked = self.nativeVideoSession?.liveProducerParkedSnapshot == true
                        EngineLog.emit(
                            "[AetherEngine] #65 stage-2 skipped: no segment finalized since the "
                            + "stall (producer still at seg\(seg)); the producer is "
                            + (parked ? "PARKED by this engine (live headroom cap), not starved by "
                                      + "its origin; see the HLSSegmentProducer park line"
                                      : "starved, not the consumer")
                            + "; publishing liveSourceReset to host",
                            category: .engine)
                        self.liveSourceReset.send()
                        return
                    }
                    if self.isLive, !self.stallReloadReviveGate.admit(position: reloadPosition) {
                        EngineLog.emit(
                            "[AetherEngine] #65 stage-2 reload budget exhausted at frozen "
                            + "\(String(format: "%.2f", reloadPosition))s; "
                            + "publishing liveSourceReset to host",
                            category: .engine)
                        self.liveSourceReset.send()
                        return
                    }
                    self.reloadStalledConsumerItem(position: reloadPosition)
                    // Final rung (#65, live only): a reload against a FROZEN playlist refills the
                    // same tail and parks again, with no notification left to re-fire. A rendered
                    // clock that has not moved a whole post-reload window later means the local
                    // session is unrecoverable consumer-side; only the host can retune.
                    let clockAtReload = host.renderedTime
                    try? await Task.sleep(
                        nanoseconds: UInt64(2 * Self.stallReengageGraceSeconds * 1_000_000_000))
                    guard !Task.isCancelled, host.stallCount == count,
                          Self.shouldPublishLiveSourceReset(
                              isLive: self.isLive,
                              clockAtReload: clockAtReload,
                              clockNow: host.renderedTime,
                              isWaitingToPlay: self.currentAVPlayer?.timeControlStatus
                                  == .waitingToPlayAtSpecifiedRate
                          ) else { return }
                    EngineLog.emit(
                        "[AetherEngine] #65 stage-2 reload did not move a frozen live clock; "
                        + "publishing liveSourceReset to host",
                        category: .engine)
                    self.liveSourceReset.send()
                }
            }
            .store(in: &nativeCancellables)

        // #93 round 3: accumulated -12889 media timeouts (a wedge-window segment outliving
        // AVPlayer's ~3.5 s time-to-first-byte watchdog) fire failedToPlayToEndTime and park the
        // item at rate 0 / tcs .paused with item.status often still readyToPlay. Every recovery
        // layer above reads that pause as user intent and disarms (producer wedge detector
        // suspends, nudge and stage-2 guard on .paused), which made the session terminal from the
        // couch. Item death is categorically NOT user intent: confirm it survived the deferred
        // window (a transient that resumes self-clears, same contract as the .failed KVO), then
        // reload through the stage-2 chain with the pause guard bypassed, bounded by the revive
        // gate (a frozen position across deaths exhausts; progress or a user seek restores).
        host.$endFailureCount
            .dropFirst()
            .sink { [weak self, weak host] count in
                guard let self, let host else { return }
                let clockAtFailure = host.renderedTime
                self.itemDeathConfirmTask?.cancel()
                self.itemDeathConfirmTask = Task { @MainActor [weak self, weak host] in
                    try? await Task.sleep(
                        nanoseconds: UInt64(Self.itemDeathConfirmSeconds * 1_000_000_000))
                    guard !Task.isCancelled, let self, let host,
                          host.endFailureCount == count else { return }
                    guard NativeAVPlayerHost.shouldSurfaceDeferredFailure(
                        isPlaying: host.timeControlStatus == .playing,
                        clockAtFailure: clockAtFailure,
                        clockNow: host.renderedTime) else { return }
                    let position = host.renderedTime
                    guard self.itemDeathReviveGate.admit(position: position) else {
                        EngineLog.emit(
                            "[AetherEngine] #93 item death (failedToPlayToEndTime) at "
                            + "\(String(format: "%.2f", position))s; revive budget exhausted",
                            category: .engine)
                        // AE#561: a frozen position across three reloads is the reload answering the
                        // same bytes three times. Offer the source to the engine's own decoder before
                        // the session is left dead.
                        //
                        // Its own task (audit CORE-1): the rebuild's load() cancels THIS task in its
                        // prologue, and a rebuild left running in a cancelled task turns every
                        // `try? await Task.sleep` poll on its way (the panel-switch wait) into a hot
                        // spin on the main actor. Supersession is answered by the load generation.
                        let request = SoftwarePathEscalation.Request(
                            domain: SoftwarePathEscalation.mediaErrorDomain,
                            code: 0,
                            message: "item death at a frozen position, revive budget exhausted",
                            positionSeconds: position.isFinite ? max(0, position) : 0
                        )
                        // AE#629: a host that declined the rung asked for exactly this failure. Left
                        // unsaid, the session sits dead, which is what 7.8.1 did here too.
                        guard self.loadedOptions.escalatesToSoftwarePath else {
                            EngineLog.emit(
                                "[AetherEngine] #629 the host declined the software-path rung; "
                                + "surfacing the item death", category: .engine)
                            self.publishError(Self.absorbedFailure(request))
                            return
                        }
                        self.hop(for: generation) { [weak self] in
                            await self?.escalateToSoftwarePath(request, expectedGeneration: generation)
                        }
                        return
                    }
                    EngineLog.emit(
                        "[AetherEngine] #93 item death (failedToPlayToEndTime) at "
                        + "\(String(format: "%.2f", position))s; reloading item through stage-2 "
                        + "recovery (attempt \(self.itemDeathReviveGate.attempts), pause guard bypassed)",
                        category: .engine)
                    self.reloadStalledConsumerItem(position: position, allowPausedConsumer: true)
                }
            }
            .store(in: &nativeCancellables)

        // #98: a display rejecting the served master fails the item at startup; reload the media
        // playlist in place instead of hard-failing. Gated + single-shot in fallBackToMediaPlaylist.
        host.$pendingDisplayRejection
            .compactMap { $0 }
            .sink { [weak self] rejection in
                self?.hop(for: generation) { [weak self] in
                    self?.fallBackToMediaPlaylist(rejection, expectedGeneration: generation)
                }
            }
            .store(in: &nativeCancellables)

        // AE#561: the last rung. Every recovery above reloads the same item against the same bytes,
        // which is no answer to a segment AVPlayer refuses on its merits. The engine's own decoder
        // reads the demuxer directly and answers a sample Apple's parser rejects by skipping one
        // frame, so it is offered the session before the failure is made terminal. Once per session,
        // and only for a verdict on the MEDIA (see SoftwarePathEscalation).
        let escalationBudget = softwarePathEscalationBudget
        let escalationPreferred = loadedOptions.preferredDecodePath
        let escalationRemoteHLS = loadedOptions.nativeRemoteHLS
        let escalationAllowed = loadedOptions.escalatesToSoftwarePath
        host.softwarePathAvailability = {
            SoftwarePathEscalation.Availability(
                alreadyEscalated: escalationBudget.isSpent,
                preferredDecodePath: escalationPreferred,
                nativeRemoteHLS: escalationRemoteHLS,
                hostAllowsEscalation: escalationAllowed
            )
        }
        wireSoftwarePathEscalation(host: host, generation: generation)

        // appliesPerFrameHDRDisplayMetadata unconditionally true: DV P5 has no HDR10 base layer, so the per-frame RPU is what AVPlayer's tone-mapper needs on a non-DV panel (DrHurt #4 2026-05-26). Prior servingMasterPlaylist gate broke P5. Apple's default is also true; explicit write surfaces the live value in diagnostics.
        // forwardBufferDuration default (4 s): deep buffer lets AVPlayer race to the live edge and hit the transcode warm-up gap head-on (-12888); 4 s PACES consumption. Verified: 8 s worsened startup pause (8-10 s vs ~1 s).
        // Live REJOIN: skip initial seek so AVPlayer picks edge-minus-holdback instead; seek-to-0 against the re-served backlog wedged the reloaded item in waitingToPlay (device repro: tvOS 26, Jellyfin stream.ts). See LiveReloadPolicy.
        // Sequential append playlist: AVPlayer treats the growing playlist as an EVENT and
        // defaults to edge-minus-holdback (~6 s in on a fresh session, more once the producer
        // has raced ahead). The load-time seek to 0 fires before readyToPlay and the item
        // re-anchors to the edge default afterwards, so queue a post-readiness seek through
        // the #127 replay instead - every segment stays retained, so 0 is always reachable.
        // A declared start position does not exempt it: the session produces from byte 0 either
        // way (HLSVideoEngine drops the resume anchor for a sequential origin), so leaving the
        // item on the EVENT edge default would start it mid-archive with no way back.
        if !isLive, loadedOptions.sequentialOrigin {
            pendingPreReadySeek = PendingPreReadySeek(seconds: 0.0, origin: .host)
        }
        // AE#851: build the first live window BEFORE AVPlayer is handed the item. Withheld behind the
        // playlist request instead, the wait runs on AVPlayer's playlist timer, which gives up after
        // about 20 s on tvOS (-16839, measured in the simulator) and failed every cushion a 1x origin
        // could not fill in that time. The gate is the same one the request would have waited on, so
        // the request is then answered at once.
        if isLive, let provider = nativeVideoSession?.provider {
            await Self.awaitFirstLiveWindow(provider)
            try checkLoadCurrent(generation)
        }
        // AE#158: consume-and-reset so only the load() that armed the handover swaps in place; audio-switch
        // and recovery reloads keep their own contracts.
        let inPlaceHandover = pendingInPlaceItemHandover
        pendingInPlaceItemHandover = false
        // #361: recorded here rather than after the loader returns, because on the paths that await
        // their host's load the session is ready before the return and this checkpoint would arrive
        // behind one it must precede. The generation guard is what keeps a superseded loader from
        // writing into its successor's sequence.
        if loadGeneration == generation { recordStartupCheckpoint(.sessionConstructed) }
        host.load(url: playbackURL,
                  startPosition: startPosition,
                  perFrameHDR: true,
                  skipInitialSeek: LiveReloadPolicy.skipInitialSeek(
                      isLive: isLive, isRejoin: liveRejoin),
                  inPlaceSwap: inPlaceHandover,
                  diagnosticContext: loadedOptions.sourceDiagnosticsContext,
                  contract: .init(
                      isLive: isLive,
                      // AE#440: the join tail, opt-in. The host itself gates this on `isLive`.
                      liveJoinStartsImmediately: loadedOptions.liveJoinStartsImmediately,
                      // AE#520: the session knows whether the bitstream it stream-copied carries JOC;
                      // the HDMI route cannot, because Atmos passthrough and a stereo LPCM route
                      // report the same two channels.
                      audioIsAtmosStreamCopy: nativeVideoSession?.audioIsAtmosStreamCopy == true,
                      nativeVideoFrameDiagnostics: loadedOptions.nativeVideoFrameDiagnostics,
                      nativeVideoFrameRecovery: loadedOptions.nativeVideoFrameRecovery))
        forceNativeLegibleDeselectedUntilHostSelects()
        // Sodalite#175: from the session's own pick, since a track-switch reload has no active index yet.
        let sessionAudioPick = nativeVideoSession.map(\.activeAudioSourceStreamIndex).flatMap { $0 >= 0 ? Int($0) : nil }
        let audioPick = sessionAudioPick ?? audioSourceStreamIndex.flatMap { Int(exactly: $0) } ?? activeAudioTrackIndex
        let pickTracks = nativeVideoSession.map(\.companionAudioTracks).flatMap { $0.isEmpty ? nil : $0 } ?? audioTracks
        SharedOutputCoordinator.shared.noteSourceChannels(
            audioPick.flatMap { index in pickTracks.first { $0.id == index }?.channels }
                .flatMap { $0 > 0 ? $0 : nil },
            for: ObjectIdentifier(self))
        // AE#458: what AVFoundation makes of the audio rendition this load just served, which is the
        // half of the exchange no log has ever carried.
        logAudibleReadback(host: host)
    }

    /// The active audio track's channel count from the published track list, nil when unknown.
    /// `audioSourceStreamIndex` is accepted because during a reload (track change) `activeAudioTrackIndex`
    /// is temporarily nil (cleared by stopInternal), so the published property cannot be relied on.
    func ownSourceChannels(audioSourceStreamIndex: Int32? = nil) -> Int? {
        let lookupIndex = audioSourceStreamIndex.flatMap { Int(exactly: $0) } ?? activeAudioTrackIndex
        if let index = lookupIndex, let track = audioTracks.first(where: { $0.id == index }), track.channels > 0 {
            return track.channels
        }
        return nil
    }

    /// Activate AVAudioSession for renderer paths (SoftwarePlaybackHost, audio hosts) that have no AVPlayerViewController. Native path deliberately skips this: AVKit activates per playback so tvOS can auto-negotiate the HDMI route (issue #24).
    ///
    /// Called once per load, and again when an interruption ends on a renderer path (AE#549): these
    /// paths own the session, so nobody else hands it back to them.
    ///
    /// The session calls run off the main actor and the load awaits them, so the session is active before the
    /// host that plays into it is built, as before. `setActive(true)` is an XPC round trip to mediaserverd, and
    /// iOS/tvOS 27 flag it as a hang risk on the main thread (AE#538): the same reasoning that moved `setCategory` off-main
    /// in #114 and the teardown deactivation in #215. Only the track lookup, which reads published state, stays here.
    func activateRendererAudioSession(audioSourceStreamIndex: Int32? = nil) async {
        guard rendererAudioSessionActivationEnabled else { return }
        #if os(iOS) || os(tvOS)
        // Resolve the active audio track's channel count from the already-published track list.
        // so the HDMI / AirPlay link negotiates at the correct channel count.
        // Accept an explicit stream index parameter because during a reload (track change)
        // `activeAudioTrackIndex` is temporarily nil (cleared by stopInternal), so the
        // published property cannot be relied on here.
        let sourceChannels = ownSourceChannels(audioSourceStreamIndex: audioSourceStreamIndex)
        SharedOutputCoordinator.shared.noteSourceChannels(sourceChannels, for: ObjectIdentifier(self))
        let preferred = SharedOutputCoordinator.shared.preferredSourceChannels ?? sourceChannels
        await performRendererAudioSessionActivation {
            AetherEngine.applyRendererAudioSession(sourceChannels: preferred)
        }
        #endif
    }

    /// Kept platform-independent so the ownership gate can be exercised without an audio session.
    func performRendererAudioSessionActivation(_ operation: @escaping @Sendable () async -> Void) async {
        guard rendererAudioSessionActivationEnabled else { return }
        await enqueueAudioSessionTransition(operation).value
    }

    #if os(iOS) || os(tvOS)
    /// The blocking half of `activateRendererAudioSession`: activation, then the channel preference, which
    /// only takes effect on an active session. Captures no engine state.
    nonisolated static func applyRendererAudioSession(sourceChannels: Int?) {
        let session = AVAudioSession.sharedInstance()
        do { try session.setActive(true) }
        catch {
            EngineLog.emit("[AetherEngine] activateRendererAudioSession error: \(error)", category: .engine)
        }
        let maxCh = session.maximumOutputNumberOfChannels
        let prefCh = preferredOutputChannels(sourceChannels: sourceChannels, maxOutput: maxCh)
        try? session.setPreferredOutputNumberOfChannels(prefCh)
        EngineLog.emit("[AetherEngine] renderer audio session active: sourceCh=\(sourceChannels?.formatted() ?? "unknown") maxChannels=\(maxCh) preferred=\(session.preferredOutputNumberOfChannels) output=\(session.outputNumberOfChannels)", category: .engine)
    }
    #endif

    func loadSoftware(
        url: URL,
        sourceHTTPHeaders: [String: String] = [:],
        startPosition: Double?,
        audioSourceStreamIndex: Int32?,
        isLive: Bool = false,
        dvrWindowSeconds: Double? = nil,
        preopenedDemuxer: Demuxer?,
        requiresDeinterlaceWarmup: Bool,
        generation: UInt64,
        elType: String? = nil
    ) async throws {
        try checkLoadCurrent(generation)
        sessionCacheStatusToken &+= 1
        diagnostics.sessionCacheStatus = .inactive
        let deinterlaceMode = loadedOptions.deinterlaceMode
        let waitStarted = DispatchTime.now()
        let warmupOutcome = await DeinterlaceHardwareWarmup.shared.waitIfNeeded(
            for: deinterlaceMode, sourceIsInterlaced: requiresDeinterlaceWarmup
        )
        try checkLoadCurrent(generation)
        if let outcome = warmupOutcome {
            let elapsed = Double(
                DispatchTime.now().uptimeNanoseconds - waitStarted.uptimeNanoseconds
            ) / 1_000_000_000
            if elapsed >= 0.05 {
                EngineLog.emit(
                    "[AetherEngine] software load waited "
                    + "\(String(format: "%.3f", elapsed))s for hardware "
                    + "deinterlace warm-up (\(outcome.rawValue))",
                    category: .swPlayback
                )
            }
        }

        await activateRendererAudioSession(audioSourceStreamIndex: audioSourceStreamIndex)
        try checkLoadCurrent(generation)
        // Drop the previous session's sinks BEFORE anything wires this one's. Standing further down,
        // between two groups of `.store(in:)` calls, this cancelled everything wired above it: the
        // SW-PiP cue mirror never delivered a cue after the frame compositor was armed. Both halves
        // of such a wiring work in isolation, which is why a dead sink here reads as a working one.
        softwareCancellables.removeAll()
        // #489: same contract as the native host two paths over, which re-applies `_videoGravity`
        // on every build. Without it a software host came up aspect-fit whatever the app had set,
        // and only a second write mid-session took effect.
        let host = SoftwarePlaybackHost(videoGravity: _videoGravity)
        let upscaleRebuild = UpscaleRouteDecision.forRebuild(
            sessionPlan: sourceUpscalePlan, optionOn: loadedOptions.upscalesLowResolutionVideo,
            disabled: sourceUpscaleDisabled)
        host.configuredDVProfile = sourceDVProfile
        host.dolbyVisionHandling = loadedOptions.dolbyVisionHandling
        host.preferDualLayerDolbyVision = loadedOptions.preferDualLayerDolbyVision
        host.upscalePlan = upscaleRebuild.plan
        host.elType = elType ?? sourceElType
        host.objectAudioRendering = loadedOptions.objectAudioRendering
        host.setAudioDelay(loadedOptions.audioDelaySeconds)   // AE#464: before the decoder opens
        host.audioShaping = loadedOptions.audioShaping        // AE#923: likewise
        if isLive { host.liveEdgeCushionSeconds = loadedOptions.liveEdgeCushionSeconds }
        // AE#813: a live ingest delivers whole segments, and the host's holdback follows their length.
        if isLive, let ingest = customReader as? LiveIngestSourceInfo {
            host.liveDeliveryUnit = { [weak ingest] in
                SoftwareLiveHoldback.deliveryUnit(segmentDuration: ingest?.upstreamSegmentDurationSeconds,
                                                  closedCadence: ingest?.closedLiveCadenceSeconds)
            }
        }
        host.deinterlaceConfig = DeinterlaceConfig(
            mode: loadedOptions.deinterlaceMode,
            fieldRate: loadedOptions.deinterlaceFieldRate
        )
        host.onFirstHDR10PlusDetected = { [weak self] in
            Task { @MainActor in self?.handleHDR10PlusDetected() }
        }
        host.onDecodedVideoFormat = { [weak self, weak host] format in
            Task { @MainActor in
                guard let self, let host, self.softwareHost === host else { return }
                self.decodedVideoFormat = format
            }
        }
        host.onClockHoldTransition = { [weak self, weak host] transition in
            Task { @MainActor in
                guard let self, let host, self.softwareHost === host else { return }
                self.applyClockHoldTransition(transition)
            }
        }
        // The clock's real session zero, for the chapter axis (`mediaChapters`).
        host.onClockSessionZero = { [weak self, weak host] zero in
            Task { @MainActor in
                guard let self, let host, self.softwareHost === host else { return }
                self.softwareClockSessionZero = zero
                self.republishMediaChapters()
            }
        }
        // SW host provides session-relative edge on each tick; publishLiveWindow is a no-op when liveWindow is nil.
        host.onLiveEdge = { [weak self] edge in
            self?.publishLiveWindow(edgeSessionTime: edge)
        }
        self.softwareHost = host
        noteVideoPresentationToHost()
        startSoftwareNowPlaying()
        armHeldPictureRelease(onSoftwareHost: host)
        // #311: a load builds a new host and a new renderer, so an observer installed once by the
        // host app has to be carried across the seam, exactly as the native session does at load.
        host.setVideoFrameTimeObserver(softwareVideoFrameTimeObserver)
        // #353: the settled picture size, wired next to the frame times because a host laying out an
        // overlay needs the rectangle as well as the clock, and both come off this renderer.
        mirrorSoftwareDisplaySize(from: host.$videoDisplaySize, storeIn: &softwareCancellables)
        host.$residentRanges
            .sink { [weak self, weak host] ranges in
                guard let self, let host, self.softwareHost === host,
                      self.loadGeneration == generation, !self.isLive else { return }
                self.residentRanges = ranges
            }
            .store(in: &softwareCancellables)
        // SW-PiP: publish the bridge once the session owns its layer (the layer object is stable for
        // the session; the host attaches it to the view and, on PiP start, to the system window).
        softwarePiPSource = SoftwarePiPSource(layer: host.displayLayer, isLive: isLive, engine: self)
        // SW-PiP Phase C: mirror the published cues (primary + secondary) into the renderer's frame
        // compositor; the PiP flag gates actual drawing (fullscreen stays host-overlay-only).
        Publishers.CombineLatest($subtitleCues, $secondarySubtitleCues)
            .sink { [weak self, weak host] primary, secondary in
                guard let self, let host else { return }
                host.updateSubtitleCompositor(cues: primary + secondary, enabled: self.pictureInPictureActive,
                                              delaySeconds: self.softwareSubtitleDelaySeconds)
            }
            .store(in: &softwareCancellables)
        // #131: no demuxable CC track on the SW path either: arm an A53 tap fed by decoded-frame
        // side data. Same lazy synthetic-track surfacing as the producer path.
        // Same synthetic-entry exclusion as setupClosedCaptionTapIfNeeded (via `demuxableClosedCaptionTrack`):
        // a stale A53 track from a prior session must not read as a demuxable CC stream on a no-reprobe reload.
        // Resets run unconditionally, hoisted above the arming guard: a SW-routed source WITH a real
        // demuxable c608 track otherwise inherits the previous session's tap/cue snapshot, and selecting
        // that track mirrors stale cross-session cues (`selectSubtitleTrack`'s CC branch does
        // `subtitleCues = ccCueSnapshot`).
        closedCaptionTap = nil
        ccCueSnapshot = []
        ccLastSnapshotSeq = 0
        ccNativeStore = nil
        if demuxableClosedCaptionTrack == nil {
            let ccTap = ClosedCaptionTap(engine: self, ccStreamIndex: Int32(Self.a53ClosedCaptionTrackID))
            closedCaptionTap = ccTap
            host.onA53Captions = { [weak ccTap] triplets, pts in
                ccTap?.ingestA53Ordered(triplets, ptsSeconds: pts)
            }
        }
        applyDesiredVolume(to: host)
        applyDesiredRate(to: host)
        // #112 rework: SW-host subtitle tap feeds a session packet store; the shared
        // playhead-paced drainer reads it exactly like the HLS session's store.
        let packetStore = SubtitlePacketStore()
        self.softwareSubtitlePacketStore = packetStore
        host.preserveASSMarkupForSubtitleTap = loadedOptions.preserveASSMarkup
        host.teletextPageForSubtitleTap = loadedOptions.teletextPage
        host.subtitleTapSink = { idx, pkt, tb, assembleSplitSets in
            packetStore.harvest(streamIndex: idx, packet: pkt, timeBase: tb,
                                assembleSplitDisplaySets: assembleSplitSets)
        }
        // SW path has no AVPlayer-clock fold; the host's synchronizer is the only clock.
        self.playlistShiftSeconds = 0
        self.setPresentationAxis(PresentationAxisMap())

        host.$currentTime
            .sink { [weak self] value in
                guard let self = self else { return }
                self.clock.currentTime = value
                // Both paths publish a real continuous cache frontier. Software VOD intersects
                // selected A/V packet PTS coverage; the decoded cushion remains the unknown fallback.
                self.clock.bufferedPosition = SoftwareBufferFrontier.bufferedPosition(
                    currentTime: value,
                    liveFrontier: host.bufferedSessionTime,
                    cushion: host.displayCushionSeconds,
                    cachedVODFrontier: host.cachedVODSessionTime)
            }
            .store(in: &softwareCancellables)
        // #107: sourceTime rides the RAW synchronizer clock (source axis) so subtitle cues
        // and the overlay drainer's packet-store scans line up on live / mid-stream-joined
        // sources. Identical to currentTime for zero-based sources (the historical SW behavior).
        host.$sourceClockSeconds
            .sink { [weak self] value in
                self?.clock.sourceTime = value
            }
            .store(in: &softwareCancellables)
        // The pumps pause the synchronizer to refill when the ring runs dry at the live edge (#107) or
        // the audio lead is exhausted on demand. Folded into `isBuffering` exactly as the audio host's
        // wait is, so `playbackPhase` reads `.rebuffering` from the moment the clock stops. Before, the
        // phase stayed `.playing` over a standing picture until the reader's own stall timeout promoted
        // it to `.stalled`, 20 s later on a live source that merely paused, and a host app watching the
        // clock reloaded the session in the meantime. Gated on the engine's own `.playing`: a paused
        // engine refilling stays `.paused`.
        host.$isRebuffering
            .sink { [weak self] rebuffering in
                guard let self else { return }
                if case .error = self.state { return }
                self.isBuffering = self.state == .playing && rebuffering
            }
            .store(in: &softwareCancellables)
        // The feeder's catch-up after an edge rebuffer that resumed behind a backlog: the engine's own
        // rejoin, not a scrub, so it is not bound by the scrubber's contract and lands like the AE#446
        // outage swap does.
        host.liveResumeCatchUp
            .sink { [weak self] target in
                self?.hop(for: generation) { [weak self] in
                    await self?.seek(to: target, origin: .liveRejoin)
                }
            }
            .store(in: &softwareCancellables)
        // AE#440: this path publishes no transport status to latch a roll from, and all of its
        // transport flows through the engine's own play()/pause(), so `state` IS its motion signal.
        // Crediting the roll here keeps `playbackPhase` on the software path exactly as it was.
        hasTransportRolled = true
        wireCommonHostSinks(
            duration: host.$duration,
            isReady: host.$isReady,
            failure: host.$failure,
            didReachEnd: host.$didReachEnd,
            videoReadyForDisplay: host.$isVideoReadyForDisplay,
            storeIn: &softwareCancellables
        )

        // Reuse probe demuxer when present (avoids second avformat_open_input; also required for forward-only custom sources). Detach the open so @MainActor keeps ticking.
        // Capture the caller's probe budget (#68) before the detach: loadedOptions is @MainActor-isolated and unreachable inside the closure. Only used on the fallback open (probe absent).
        let probesize = loadedOptions.probesize
        let maxAnalyzeDuration = loadedOptions.maxAnalyzeDuration
        let sequentialOrigin = loadedOptions.sequentialOrigin
        let heldSourceConnection = loadedOptions.heldSourceConnection
        let sourceOpenPolicy = loadedOptions.sourceOpenPolicy
        let diagnosticContext = loadedOptions.sourceDiagnosticsContext
        let declaredDuration = loadedOptions.declaredDurationSeconds
        // Built on the main actor, captured into the detach: surfaces source stall/reconnect to playbackPhase (#85).
        let networkPhaseSink: @Sendable (ReaderNetworkPhase) -> Void = { [weak self] phase in
            self?.hop(for: generation) { [weak self] in self?.setReaderNetworkPhase(phase) }   // audit Vcore-101
        }
        if loadGeneration == generation { recordStartupCheckpoint(.sessionConstructed) }   // #361
        let forwardBufferSegments = loadedOptions.forwardBufferSegments
        let sessionCacheByteBudget = loadedOptions.sessionCacheByteBudget
        let packetCacheStorage = loadedOptions.softwarePacketCacheStorage
        let dvrRetention = loadedOptions.softwareDVRRetention
        try await BlockingWork.detached(priority: .userInitiated) {
            [host, preopenedDemuxer, url, sourceHTTPHeaders, requestHeaders = sessionRequestHeaders, isLive, dvrWindowSeconds, probesize, maxAnalyzeDuration, sequentialOrigin, heldSourceConnection, declaredDuration, networkPhaseSink] in
            let dem: Demuxer
            if let pre = preopenedDemuxer {
                dem = pre
            } else {
                dem = Demuxer()
                try dem.open(url: url, extraHeaders: sourceHTTPHeaders, profile: .playback.withProbeBudget(probesize: probesize, maxAnalyzeDuration: maxAnalyzeDuration).withSequentialOrigin(sequentialOrigin, declaredDuration: declaredDuration).withHeldSourceConnection(heldSourceConnection).skippingAttachments().withSourceOpenPolicy(sourceOpenPolicy).withDiagnosticContext(diagnosticContext).withRequestHeaders(requestHeaders), isLive: isLive)
            }
            dem.onNetworkPhaseChanged = networkPhaseSink
            try await host.load(
                demuxer: dem,
                startPosition: startPosition,
                audioSourceStreamIndex: audioSourceStreamIndex,
                isLive: isLive,
                dvrWindowSeconds: dvrWindowSeconds,
                dvrRetention: dvrRetention,
                forwardBufferSegments: forwardBufferSegments,
                packetCacheStorage: packetCacheStorage,
                sessionCacheByteBudget: sessionCacheByteBudget
            )
        }.value
        // Superseded: stop idempotently to tear down the demuxer the detached closure opened, then unwind.
        if loadGeneration != generation {
            host.stop()
            try checkLoadCurrent(generation)
        }
        #if DEBUG
        softwareHostLoadedForTesting?(host)
        #endif
        if let status = upscaleRebuild.status { activeUpscale = status }
        wireUpscaleStatus(from: host)
        // The audio route is settled by `load`: an object-audio one keeps the HDMI link in Atmos.
        followAtmosOutput()
    }

    /// Open `AudioPlaybackHost` for an audio-only source. No HLS pipeline, display layer, or display-criteria handshake. Same lifecycle as `loadSoftware`.
    func loadAudio(
        url: URL,
        sourceHTTPHeaders: [String: String] = [:],
        startPosition: Double?,
        audioSourceStreamIndex: Int32?,
        preopenedDemuxer: Demuxer?,
        generation: UInt64
    ) async throws {
        await activateRendererAudioSession(audioSourceStreamIndex: audioSourceStreamIndex)
        try checkLoadCurrent(generation)
        let host = AudioPlaybackHost()
        host.audioShaping = loadedOptions.audioShaping
        self.audioHost = host
        applyDesiredVolume(to: host)
        applyDesiredRate(to: host)
        self.playlistShiftSeconds = 0
        self.setPresentationAxis(PresentationAxisMap())

        audioCancellables.removeAll()
        host.$currentTime
            .sink { [weak self] value in
                guard let self = self else { return }
                self.clock.currentTime = value
                self.clock.sourceTime = value
                // No buffer-ahead surface on this path; mirror playhead so bufferedPosition stays defined (#54).
                self.clock.bufferedPosition = value
            }
            .store(in: &audioCancellables)
        // AE#440: no AVPlayer transport status is reconciled on this path, so `state` is its motion
        // signal. Credited with the host, which leaves `playbackPhase` here exactly as it was.
        hasTransportRolled = true
        wireCommonHostSinks(
            duration: host.$duration,
            isReady: host.$isReady,
            failure: host.$failure,
            didReachEnd: host.$didReachEnd,
            storeIn: &audioCancellables
        )

        // Reuse probe demuxer (required for custom sources; no URL to reopen). Detach so @MainActor keeps ticking.
        // Caller's probe budget (#68) captured before the detach; only used on the fallback open (probe absent).
        let probesize = loadedOptions.probesize
        let maxAnalyzeDuration = loadedOptions.maxAnalyzeDuration
        let sequentialOrigin = loadedOptions.sequentialOrigin
        let heldSourceConnection = loadedOptions.heldSourceConnection
        let sourceOpenPolicy = loadedOptions.sourceOpenPolicy
        let diagnosticContext = loadedOptions.sourceDiagnosticsContext
        let declaredDuration = loadedOptions.declaredDurationSeconds
        // Built on the main actor, captured into the detach: surfaces source stall/reconnect to playbackPhase (#85).
        let networkPhaseSink: @Sendable (ReaderNetworkPhase) -> Void = { [weak self] phase in
            self?.hop(for: generation) { [weak self] in self?.setReaderNetworkPhase(phase) }   // audit Vcore-101
        }
        if loadGeneration == generation { recordStartupCheckpoint(.sessionConstructed) }   // #361
        try await BlockingWork.detached(priority: .userInitiated) {
            [host, preopenedDemuxer, url, sourceHTTPHeaders, requestHeaders = sessionRequestHeaders, probesize, maxAnalyzeDuration, sequentialOrigin, heldSourceConnection, declaredDuration, networkPhaseSink] in
            let dem: Demuxer
            if let pre = preopenedDemuxer {
                dem = pre
            } else {
                dem = Demuxer()
                try dem.open(url: url, extraHeaders: sourceHTTPHeaders, profile: .playback.withProbeBudget(probesize: probesize, maxAnalyzeDuration: maxAnalyzeDuration).withSequentialOrigin(sequentialOrigin, declaredDuration: declaredDuration).withHeldSourceConnection(heldSourceConnection).skippingAttachments().withSourceOpenPolicy(sourceOpenPolicy).withDiagnosticContext(diagnosticContext).withRequestHeaders(requestHeaders))
            }
            dem.onNetworkPhaseChanged = networkPhaseSink
            try await host.load(
                demuxer: dem,
                startPosition: startPosition,
                audioSourceStreamIndex: audioSourceStreamIndex
            )
        }.value
        // Superseded: re-stop detached host, then throw.
        if loadGeneration != generation {
            host.stop()
            try checkLoadCurrent(generation)
        }
    }

    /// Open `AudioAVPlayerHost` for AVPlayer-decodable audio. Energy-efficient native default; `loadAudio` (FFmpeg) is the fallback. Same lifecycle as `loadAudio`.
    func loadAudioNative(
        url: URL,
        startPosition: Double?,
        httpHeaders: [String: String],
        generation: UInt64
    ) async throws {
        // Reuse the persistent host (MPNowPlayingSession survives across tracks). host.load() swaps the item via replaceCurrentItem.
        await activateRendererAudioSession()
        try checkLoadCurrent(generation)
        let ownsNowPlaying = Self.ownsNowPlaying(hostOptIn: true, role: loadedOptions.sharedOutputRole)
        let host = audioAVPlayerHost ?? AudioAVPlayerHost(ownsNowPlaying: ownsNowPlaying)
        host.ownsNowPlaying = ownsNowPlaying
        self.audioAVPlayerHost = host
        applyDesiredVolume(to: host)
        self.audioAVPlayerActive = true
        // After the active flag: `maxSupportedRate` is 3.0 only once this session counts as audio-only,
        // and applyDesiredRate clamps against it (#436).
        applyDesiredRate(to: host)
        self.playlistShiftSeconds = 0
        self.setPresentationAxis(PresentationAxisMap())
        // Reclaim Now-Playing ownership for this session on each track start,
        // so the Home badge + remote commands stay bound across a pause.
        host.becomeActiveNowPlaying()
        host.setExternalMetadata(pendingExternalMetadata)
        #if os(iOS) || os(tvOS)
        host.setNowPlayingInfo(pendingAudioNowPlayingInfo)
        #endif

        audioNativeCancellables.removeAll()
        host.$currentTime
            .sink { [weak self] value in
                guard let self = self else { return }
                self.clock.currentTime = value
                self.clock.sourceTime = value
            }
            .store(in: &audioNativeCancellables)
        // AE#440: no AVPlayer transport status is reconciled on this path, so `state` is its motion
        // signal. Credited with the host, which leaves `playbackPhase` here exactly as it was.
        hasTransportRolled = true
        wireCommonHostSinks(
            duration: host.$duration,
            isReady: host.$isReady,
            failure: host.$failure,
            didReachEnd: host.$didReachEnd,
            storeIn: &audioNativeCancellables
        )
        // No timeControlStatus reconciliation on the audio path: all transport flows through engine play()/pause(). Feeding it back mis-latched a TRANSIENT .paused AVFoundation emits on background transition as a real pause, zeroing MPNowPlayingInfoPropertyPlaybackRate and breaking Now-Playing badge + Siri Remote routing.
        // The rebuffer axis is a different matter: it never touches `state`, only `isBuffering`, so
        // `playbackPhase` reads `.rebuffering` while a played item is starved (a dead progressive radio
        // stream, a slow origin). Gated on the engine's own `.playing`, like the native video sinks, so a
        // paused engine refilling its buffer stays `.paused`.
        host.$isRebuffering
            .sink { [weak self] rebuffering in
                guard let self else { return }
                if case .error = self.state { return }
                self.isBuffering = self.state == .playing && rebuffering
            }
            .store(in: &audioNativeCancellables)

        // No detached hop: AudioAVPlayerHost.load is MainActor + replaceCurrentItem-based (no blocking I/O), and the host is SHARED. Detaching opened a reorder window where a superseded load A's body ran after successor B, putting A's item back on the shared AVPlayer.
        try checkLoadCurrent(generation)
        recordStartupCheckpoint(.sessionConstructed)   // #361, past the guard above
        try await host.load(url: url, startPosition: startPosition, httpHeaders: httpHeaders)
        // Superseded: don't tear the shared host down (successor may be using it); just unwind before play()/state writes.
        try checkLoadCurrent(generation)
    }

    /// Reconcile published audio state with what the session ACTUALLY plays. Probe diverges in two live shapes: (1) demuxed-audio side demuxer (probe sees no audio), (2) live TS with empty codecpar (av_find_best_stream skips it, engine's codecpar repair picks it). Without this a host calling selectAudioTrack for the already-live track triggers a pointless stall-prone reload.
    func syncPublishedAudioStateFromNativeSession() {
        guard let session = nativeVideoSession else { return }
        // Demuxed-audio: publish the side demuxer's list so picker and active index share one stream numbering.
        let sideTracks = session.companionAudioTracks
        if !sideTracks.isEmpty {
            audioTracks = sideTracks
            applyConfirmedTrackFlags()   // #214 follow-up: a whole-list swap must not drop confirmed JOC
        }
        let active = session.activeAudioSourceStreamIndex
        let resolved: Int? = active >= 0 ? Int(active) : nil
        if activeAudioTrackIndex != resolved {
            EngineLog.emit(
                "[AetherEngine] published active audio reconciled to the session's real pick: "
                + "\(resolved.map(String.init) ?? "nil") "
                + "(was \(activeAudioTrackIndex.map(String.init) ?? "nil"))",
                category: .engine
            )
            activeAudioTrackIndex = resolved
        }
        if session.audioIsConfirmedDTSX, active >= 0 {
            recordConfirmedDTSX(streamIndex: active)
        }
    }

    /// Rebuild the pipeline at the current playhead with an optional audio stream override (nil = keep auto-picked). Re-arms the active subtitle source. Called by `selectAudioTrack` and `reloadAtCurrentPosition`. Snapshots subtitle + playhead INSIDE the task body: a chained `selectSubtitleTrack` lands on MainActor before the body runs; snapshotting at call-site would miss it.
    ///
    /// AE#460 follow-up: returns the error that killed the rebuild, or nil when the session came
    /// back (a supersede, which is not a failure, also returns nil: a newer load owns the engine).
    /// This path publishes its failure and used to return silently either way, so a caller could
    /// not tell a rebuilt session from a dead one; `reloadAtCurrentPosition(applying:)` is built on
    /// exactly that distinction. Callers that only drive UI keep discarding it.
    ///
    /// `resumePlaying` is the transport the rebuild comes back in; nil reads the session's own
    /// (`sessionRebuildResumesPlaying`, AE#464 round 2), which is what an audio or title pick wants.
    @discardableResult
    func reloadWithAudioOverride(
        url: URL,
        audioStreamIndex: Int32?,
        expectedGeneration: UInt64,
        discTitleIDOverride: Int? = nil,
        resumeOverride: Double? = nil,
        resumePlaying: Bool? = nil,
        restoredDeinterlaceWarmupDecision: Bool? = nil,
        keepsDisplayRefusedMediaRoute: Bool = false
    ) async -> Error? {
        // Liveness guard: a stop()/load() between scheduling and here would resurrect a dismissed session or kill the successor. Generation captured at schedule time; both stop() and load() invalidate it.
        guard loadGeneration == expectedGeneration, loadedURL != nil else {
            EngineLog.emit("[AetherEngine] reload superseded before start; ignored", category: .engine)
            return nil
        }
        // #227 round 2: this is a session-preserving rebuild exactly like `reloadAtCurrentPosition`'s
        // URL branch, and it tears down the very item the external-playback KVO watches, so it has to
        // hold the same edge. #227 put the hold on that one branch only, which left the three rebuilds
        // that come through here (the audio pick, the disc-title pick, and that function's own
        // custom-source branch) acting on an edge that describes a teardown rather than a route.
        //
        // Measured on an AirPlay route, device log 2026-09-19: the unheld `false` cleared
        // `airPlayActive` BEFORE `loadNative` read it, so the audio switch rebuilt the session on
        // 127.0.0.1, which a receiver cannot reach (the Apple TV never requested that port at all),
        // the receiver re-engaged, and the true edge paid for a SECOND full rebuild to get back onto
        // the LAN URL. One pick, two session rebuilds, the first one dead on arrival.
        let wasPreservingSession = sessionPreservingReloadInFlight
        sessionPreservingReloadInFlight = true
        defer {
            // Restored rather than cleared, and the reconcile belongs to the OUTERMOST rebuild alone:
            // a nested one that reconciled would start a reload inside the teardown of the rebuild
            // still running, which is #227's loop entered from the inside instead of from the KVO.
            sessionPreservingReloadInFlight = wasPreservingSession
            if AetherEngine.rebuildOwnsHeldExternalPlaybackEdge(wasAlreadyRebuilding: wasPreservingSession) {
                reconcileExternalPlaybackAfterReload()
            }
        }
        // Disc title to reopen with: an explicit override (selectTitle on a custom disc) wins, else the title
        // already playing so an audio switch / background-resume doesn't silently revert to the main title (#67).
        let outgoingDiscTitleID = activeDiscTitleID
        let titleToReopen = discTitleIDOverride ?? outgoingDiscTitleID
        // resumeOverride 0 restarts a title switch at the new title's head; nil keeps the current playhead.
        // AE#464 round 2: "the current playhead" is not `currentTime` while another load is in flight,
        // which has already zeroed that clock. See `AetherEngine.rebuildPosition`.
        let resumeAt = resumeOverride ?? positionForSessionRebuild
        let embeddedStreamToResume: Int32 = activeEmbeddedSubtitleStreamIndex
        let sidecarToResume: URL? = isSubtitleActive && activeEmbeddedSubtitleStreamIndex < 0
            ? loadedSidecarURL
            : nil
        // #170: stopInternal wipes the native-rendition pick; snapshot it for a post-reload
        // replay (mirroring the #65 recovery), or an audio switch during PiP/AirPlay strands
        // the receiver without subtitles. The active track id also routes an external (#88)
        // selection back through its synthetic id (the registry survives stopInternal here).
        let activeTrackToResume = activeSubtitleTrackIndex
        let reapplyOrdinalToRestore = nativeSubtitleReapplyOrdinal
        let reapplyMatchesActiveTrack = currentReapplyOrdinalMatchesActiveTrack()
        // #112 full umbau: an audio-track switch does not move the playhead, so the PGS line already on screen is
        // still valid. Snapshot the visible bitmap cues before stopInternal wipes them; they are restored after the
        // subtitle re-arm so the line stays up while the re-armed reader re-primes forward (old path reconstructed
        // from scratch and the line vanished for the reconstruct duration).
        //
        // #112 (audio-switch reanchor): the re-arm anchor is the source PTS at the resume position, mapped the same
        // way the seek landing maps its target (PresentationAxis.source). Do NOT read `clock.sourceTime` here: on the
        // native path it is written only by the $renderedTime sink and discrete seek landings, never by the
        // $currentTime tick (issue #49), so after a fast-forward that landed via a producer restart it stays pinned
        // at the fast-forward's landing PTS while currentTime moves on. ijuniorfu's device log: switch at
        // currentTime 1292.3 s (true source ~1304 s), but clock.sourceTime still 1211.7 s (the earlier FF landing),
        // ~92 s behind, so the re-armed PGS reader anchored ~92 s back, reconstructed a region already passed
        // (nothing showed) and flooded stale open-ended cues. resumeAt (== currentTime, or an explicit resume
        // override) is fresh, so map it onto the source axis for the true playhead. The switch does not move the
        // playhead, so this is the correct anchor for the reader re-arm and the preserved-cue snapshot.
        let preSwitchSourceTime = PresentationAxis.source(displayTime: resumeAt, origin: sourcePresentationOrigin)
        let preservedActiveImageCues = Self.activeImageCues(in: subtitleCues, at: preSwitchSourceTime)
        let secondaryToResume = secondarySelectionForRebuild
        EngineLog.emit(
            "[AetherEngine] reload begin: audioStream=\(audioStreamIndex.map(String.init) ?? "nil") resumeAt=\(String(format: "%.2f", resumeAt))s embeddedSub=\(embeddedStreamToResume) sidecar=\(sidecarToResume?.lastPathComponent ?? "nil")",
            category: .engine
        )

        // Audit LIF-102: read before `.loading`, which is the state this rebuild is about to hide the
        // session's transport behind. The audio pick never wrote it into `loadedOptions.autoplay`
        // (that is the mount flag there), so the rebuild used to end in an unconditional `play()`.
        let resumesPlaying = resumePlaying ?? sessionRebuildResumesPlaying
        state = .loading
        // AE#464 round 2: this branch reaches `loadSoftware` / `loadNative` rather than `load`, so it
        // parks its own rebuild position for anything that stacks behind it. Round 3 parks the
        // transport beside it.
        positionUnderReconstruction = resumeAt
        transportIntentUnderReconstruction = resumesPlaying
        let previousAudioIndex = activeAudioTrackIndex
        // Snapshot before stopInternal wipes state. Must reload on the same backend: loadNative on a SW-routed AV1 source throws unsupportedCodec (HLSVideoEngine only accepts HEVC / H.264 / VP9 / probed-AV1).
        let wasOnSoftwarePath = (playbackBackend == .software)
        // AE#461 follow-up: which host this rebuild hands the source to. This used to be
        // `wasOnSoftwarePath` alone, which made a `preferredDecodePath` correction on a custom source
        // accepted, logged as applied and then silently ignored: the option is read only inside
        // `load`, and a custom source never reaches it. The same pure policy `load` asks decides it
        // here, seeded with the backend the session is currently on.
        //
        // The one-way type is what makes re-routing safe on this path. `DecodePath` has no `.native`,
        // so the only flip reachable is native -> software, and the software path is the general one;
        // the reverse (the `unsupportedCodec` case the line above warns about) stays unreachable by
        // construction. What the software path cannot REPRESENT is refused before any teardown, in
        // `reloadAtCurrentPosition(applying:)`, because the guards that catch it in `load` run after
        // the routing decision and would fail a session this rebuild had already stopped.
        let targetSoftwarePath = VideoRoutingPolicy.usesSoftwarePath(
            routedSoftware: wasOnSoftwarePath, preferred: loadedOptions.preferredDecodePath)
        if targetSoftwarePath != wasOnSoftwarePath {
            EngineLog.emit(
                "[AetherEngine] #461: reload re-routing this session native -> software on the host's "
                + "preference (custom source: \(isCustomSource))",
                category: .engine
            )
        }
        // Preserve codec so the decoder label can be reconstructed without re-probing.
        let preservedVideoCodec = lastDetectedVideoCodec
        let preservedRequiresDeinterlaceWarmup =
            restoredDeinterlaceWarmupDecision ?? lastRequiresDeinterlaceWarmup
        let reloadStart = DispatchTime.now()
        EngineLog.emit("[AetherEngine] reload: stopInternal start", category: .engine)
        // resetDisplayCriteria: false: video format is unchanged; resetting triggers a full waitForSwitch Stage 2 timeout (5 s at the 2026-05-26 device test, ~2 s cap since #117; Bose SLIII A2DP + 4K HDR10 PQ: each switch added ~12 s black-screen). On the same route a panel SDR drop during the reset window failed the PQ variant with AVFoundationErrorDomain -11868 / CoreMediaErrorDomain -17223.
        // keepNativeHost: !targetSoftwarePath preserves the AVPlayer across the switch (issue #15).
        // It follows the TARGET route, not the previous one: a rebuild that flips to software renders
        // into its own layer, and a preserved host would leave AVKit bound to a stale player with
        // audio still flowing into the next load (the release `load()` does by hand on that branch).
        // Audit LIF-104: the AE#597 reset outranks the #15 reuse here exactly as it does in `load`,
        // or the first rebuild after a reset mounts its item on the invalidated AVPlayer.
        let mediaServicesWereReset = consumeMediaServicesReset()
        claimSoftwarePathTakeover()   // AE#629
        // Keep the current native item through an ordinary audio switch, but never reuse a host
        // invalidated by a media-services reset (audit LIF-104).
        let keepAudioSwitchItem = audioStreamIndex != nil && discTitleIDOverride == nil
            && !targetSoftwarePath && !mediaServicesWereReset && nativeHost?.avPlayer.currentItem != nil
        // The software path rebuilds its host and layer, and `stop()` flushes the old one to black.
        let holdsSoftwarePicture = audioStreamIndex != nil && discTitleIDOverride == nil
            && targetSoftwarePath && softwareHost != nil
        if keepAudioSwitchItem || holdsSoftwarePicture {
            if keepAudioSwitchItem { nativeHost?.pause() }
            let heldGeneration = loadGeneration
            await holdPictureAcrossItemSwap()
            // A stop() or load() that landed while the frame was read owns the engine now.
            guard loadGeneration == heldGeneration, !Task.isCancelled else {
                releaseHeldPicture(reason: "rebuild superseded")
                return nil
            }
        }
        // AE#849: read before the teardown resets it. See `MasterFallbackDecision.audioSwitchKeepsMediaRoute`.
        let keepsMediaRoute = keepsDisplayRefusedMediaRoute
            && MasterFallbackDecision.audioSwitchKeepsMediaRoute(
                outgoingServingMaster: nativeVideoSession?.servingMasterPlaylist ?? true,
                outgoingMasterRefusedByDisplay: masterRefusedByDisplay)
        stopInternal(resetDisplayCriteria: false,
                     keepNativeHost: !targetSoftwarePath && !mediaServicesWereReset,
                     keepCustomReader: true, keepCurrentItem: keepAudioSwitchItem)
        sessionCacheStatusToken &+= 1
        diagnostics.sessionCacheStatus = .inactive
        pendingInPlaceItemHandover = keepAudioSwitchItem
        // The rebuilt session starts on the media playlist and never falls back itself, so it inherits
        // the refusal, or the switch after this one would serve the master again.
        masterRefusedByDisplay = keepsMediaRoute
        if mediaServicesWereReset { dropAudioPlayerHostAfterMediaServicesReset() }
        EngineLog.emit("[AetherEngine] reload: stopInternal done (\(elapsedMs(since: reloadStart))ms)", category: .engine)
        let gen = loadGeneration
        // Audit LIF-101: the same settle point as `load`, for the same readiness waypoint.
        beginLoadInFlight(gen)
        defer { endLoadInFlight(gen) }
        loadedURL = url
        lastDetectedVideoCodec = preservedVideoCodec
        lastRequiresDeinterlaceWarmup = preservedRequiresDeinterlaceWarmup

        // Custom sources: no URL to reopen; rebuild on the retained reader. Demuxer opens at byte 0; loadSoftware/loadNative seek to startPosition.
        // Preserve the caller's probe budget (#68) across the reopen so an audio/title switch doesn't re-incur the full find_stream_info cost the caller paid to avoid.
        let reloadProfile = DemuxerOpenProfile.playback.withProbeBudget(
            probesize: loadedOptions.probesize, maxAnalyzeDuration: loadedOptions.maxAnalyzeDuration)
            .skippingAttachments()
            .withSourceOpenPolicy(loadedOptions.sourceOpenPolicy)
            .withDiagnosticContext(loadedOptions.sourceDiagnosticsContext)
        var customPreopened: Demuxer? = nil
        if isCustomSource, let reader = customReader {
            let hint = customFormatHint
            do {
                let isLiveReload = loadedOptions.isLive
                let discCacheKey = url.absoluteString
                customPreopened = try await BlockingWork.detached(priority: .userInitiated) {
                    let d = Demuxer()
                    // isLive preserved: a live custom source must not trigger SEEK_END on reopen.
                    // selectTitleID rebuilds the disc concat stream for the chosen title (#67).
                    // discCacheKey reuses the disc recognition cached at load so an audio switch on a
                    // remote ISO does not re-parse the UDF directory / playlists (#76).
                    try d.open(reader: reader, formatHint: hint, profile: reloadProfile, isLive: isLiveReload, selectTitleID: titleToReopen, discCacheKey: discCacheKey)
                    return d
                }.value
            } catch {
                // A superseded or caller-cancelled reopen is not a reload failure.
                if loadGeneration != gen || Task.isCancelled {
                    EngineLog.emit("[AetherEngine] reload superseded during custom reader reopen; unwinding", category: .engine)
                    return nil
                }
                EngineLog.emit("[AetherEngine] reload: custom reader reopen failed: \(error)", category: .engine)
                activeAudioTrackIndex = previousAudioIndex
                publishError(.reloadFailed, "Reload failed: \(error.localizedDescription)", underlying: error)
                return error
            }
            if loadGeneration != gen {
                customPreopened?.markClosed()
                if let d = customPreopened {
                    BlockingWork.detached { d.close() }
                }
                EngineLog.emit("[AetherEngine] reload superseded after reader reopen; unwinding", category: .engine)
                return nil
            }
        } else if titleToReopen != nil {
            // URL/local disc audio switch: the backend would otherwise reopen by URL with no title id and
            // silently revert to the main title. Preopen the disc demuxer with the title so the selection
            // survives the reload (#67). Non-disc URL sources keep customPreopened nil and reopen by URL.
            let headers = loadedOptions.httpHeaders
            do {
                customPreopened = try await BlockingWork.detached(priority: .userInitiated) {
                    let d = Demuxer()
                    try d.open(url: url, extraHeaders: headers, profile: reloadProfile, selectTitleID: titleToReopen)
                    return d
                }.value
            } catch {
                // A superseded or caller-cancelled reopen is not a reload failure.
                if loadGeneration != gen || Task.isCancelled {
                    EngineLog.emit("[AetherEngine] reload superseded during disc URL reopen; unwinding", category: .engine)
                    return nil
                }
                EngineLog.emit("[AetherEngine] reload: disc URL reopen failed: \(error)", category: .engine)
                activeAudioTrackIndex = previousAudioIndex
                publishError(.reloadFailed, "Reload failed: \(error.localizedDescription)", underlying: error)
                return error
            }
            if loadGeneration != gen {
                customPreopened?.markClosed()
                if let d = customPreopened {
                    BlockingWork.detached { d.close() }
                }
                EngineLog.emit("[AetherEngine] reload superseded after disc URL reopen; unwinding", category: .engine)
                return nil
            }
        }

        // Capture the reopened title's disc + track metadata before the backend consumes the demuxer
        // (start() nils preopenedDemuxer). Republished after the reload succeeds so a title switch updates
        // the picker; an audio switch / non-disc reload re-publishes identical values, a harmless no-op (#67).
        var reopenedDiscTitles: [TitleInfo] = []
        var reopenedDiscChapters: [ChapterInfo] = []
        var reopenedSelectedTitleID: Int? = nil
        var reopenedAudioTracks: [TrackInfo] = []
        var reopenedSubtitleTracks: [TrackInfo] = []
        var reopenedStartSeconds: Double = 0
        if let pre = customPreopened {
            reopenedDiscTitles = pre.discTitleInfos()
            if !reopenedDiscTitles.isEmpty {
                reopenedDiscChapters = pre.discChapterInfos()
                reopenedSelectedTitleID = pre.selectedDiscTitleID
                reopenedAudioTracks = pre.audioTrackInfos()
                reopenedSubtitleTracks = pre.subtitleTrackInfos()
                // stopInternal zeroed sourceStartSeconds; recapture the software-path chapter-seek base from
                // the reopened demuxer so a DVD chapter seek after an audio switch / custom reload still lands
                // (the native base self-heals via onPlaylistShiftChanged, this one does not). (#67)
                // Same resolved origin as the first load (see sourceStartSeconds).
                reopenedStartSeconds = pre.resolvedSourceStartOrigin
            }
        }

        // A same-title custom reload passes its title ID too. Keep any decoded progressive
        // verdict for that title; only a different title invalidates the saved probe evidence.
        // A background teardown already cleared the outgoing title; its same-source reload hands
        // back the parked decision explicitly. An actual title switch never supplies that value.
        let reopenedRequiresDeinterlaceWarmup: Bool = if restoredDeinterlaceWarmupDecision == nil,
                                                         titleToReopen != outgoingDiscTitleID,
                                                         let pre = customPreopened,
                                                         let stream = pre.stream(at: pre.videoStreamIndex),
                                                         let codecpar = stream.pointee.codecpar
        {
            VideoRoutingPolicy.requiresDeinterlaceWarmup(
                codecID: codecpar.pointee.codec_id,
                fieldOrder: codecpar.pointee.field_order,
                spsIndicatesInterlaced: VideoRoutingPolicy.spsIndicatesInterlaced(codecParameters: codecpar))
        } else {
            preservedRequiresDeinterlaceWarmup
        }
        // AE#983: a different title is a different stream; same declaration-only evidence as above.
        if restoredDeinterlaceWarmupDecision == nil, titleToReopen != outgoingDiscTitleID {
            if let pre = customPreopened,
               let stream = pre.stream(at: pre.videoStreamIndex),
               let codecpar = stream.pointee.codecpar {
                sourceVideoScan = VideoScan.resolve(
                    codecID: codecpar.pointee.codec_id,
                    fieldOrder: codecpar.pointee.field_order,
                    spsIndicatesInterlaced: VideoRoutingPolicy.spsIndicatesInterlaced(codecParameters: codecpar))
            } else {
                sourceVideoScan = .unknown
            }
        }

        do {
            let loadStart = DispatchTime.now()
            if targetSoftwarePath {
                EngineLog.emit("[AetherEngine] reload: loadSoftware enter audio=\(audioStreamIndex.map(String.init) ?? "nil") resumeAt=\(String(format: "%.2f", resumeAt))s", category: .engine)
                try await loadSoftware(
                    url: url,
                    sourceHTTPHeaders: loadedOptions.httpHeaders,
                    startPosition: LiveReloadPolicy.resumePosition(
                        isLive: loadedOptions.isLive, currentTime: resumeAt),
                    audioSourceStreamIndex: audioStreamIndex,
                    isLive: loadedOptions.isLive,
                    dvrWindowSeconds: loadedOptions.dvrWindowSeconds,
                    preopenedDemuxer: customPreopened,
                    requiresDeinterlaceWarmup: reopenedRequiresDeinterlaceWarmup,
                    generation: gen,
                    elType: sourceElType
                )
                EngineLog.emit("[AetherEngine] reload: loadSoftware done (\(elapsedMs(since: loadStart))ms)", category: .engine)
                playbackBackend = .software
                lastRequiresDeinterlaceWarmup = reopenedRequiresDeinterlaceWarmup
                activeAudioTrackIndex = audioStreamIndex.map { Int($0) }
                activeVideoDecoder = Self.videoDecoderLabel(
                    codecID: preservedVideoCodec,
                    isSoftware: !(softwareHost?.usesHardwareVideoDecoder ?? false)
                )
                // AE#462: the rebuilt host's own resolved index (see the load site).
                activeAudioDecoder = Self.softwareAudioDecoderLabel(
                    audioTracks: audioTracks, activeIndex: softwareHost?.audioStreamIndex ?? -1,
                    route: softwareHost?.audioRoute ?? .pcm
                )
                presentCurrentLayer()
                // Keep the latest transport intent if play/pause changed while the rebuild awaited I/O.
                if transportIntentUnderReconstruction ?? resumesPlaying { softwareHost?.play() }
                else { softwareHost?.pause() }
            } else {
                EngineLog.emit("[AetherEngine] reload: loadNative enter audio=\(audioStreamIndex.map(String.init) ?? "nil") resumeAt=\(String(format: "%.2f", resumeAt))s", category: .engine)
                // #339: the only write this reload can still produce is a sole-writer host's re-write on the
                // swapped item, which happens inside loadNative. Arm before it, or the gate below is again
                // reading a flag for a switch whose notifications it was not registered for.
                if !loadedOptions.engineWritesDisplayCriteria { displayCriteria.armSwitchObservation() }
                let reloadRoutingPanelHDR = Self.reloadRoutesAsHDRPanel(
                    hostAsserts: loadedOptions.panelIsInHDRMode,
                    criteriaReadoutAtLoad: sessionPanelHDRReadout,
                    attemptWhenUnproven: loadedOptions.attemptsHDRMasterOnUnprovenPanel,
                    displayEligibleForHDR: sessionDisplayEligibleForHDR,
                    panelRefusedHDRMaster: Self.panelRefusedHDRMaster)
                if reloadRoutingPanelHDR != loadedOptions.panelIsInHDRMode {
                    EngineLog.emit(
                        "[DisplayCriteria] AE#541 reload routes on the load's panel answer: panelIsHDR="
                        + "\(reloadRoutingPanelHDR) (hostAsserts=\(loadedOptions.panelIsInHDRMode) readoutAtLoad="
                        + (sessionPanelHDRReadout.map { "\($0)" } ?? "suppressed")
                        + " eligible=\(sessionDisplayEligibleForHDR) refusedLatch=\(Self.panelRefusedHDRMaster))",
                        category: .session)
                }
                let reloadDisplayCaps = Self.reloadDisplayCapabilities(
                    observedAtLoad: sessionObservedDisplayCaps,
                    hostAssertsDolbyVision: loadedOptions.panelPresentsDolbyVision,
                    readNow: { Self.displayCapabilities })
                // Read a second time for the log alone, never for the route: this is the one place the
                // revoked answer can be SEEN, and without the line a rebuild that kept its HDR route looks
                // the same as one that never met the window.
                let displayCapsNow = Self.displayCapabilities
                    .assertingDolbyVision(loadedOptions.panelPresentsDolbyVision)
                if displayCapsNow != reloadDisplayCaps {
                    EngineLog.emit(
                        "[DisplayCapabilities] AE#535 rebuild routes on the load's table: hdr="
                        + "\(reloadDisplayCaps.supportsHDR) hdr10=\(reloadDisplayCaps.supportsHDR10) "
                        + "hlg=\(reloadDisplayCaps.supportsHLG) dv=\(reloadDisplayCaps.supportsDolbyVision) "
                        + "(reading now: hdr=\(displayCapsNow.supportsHDR) hdr10=\(displayCapsNow.supportsHDR10) "
                        + "hlg=\(displayCapsNow.supportsHLG) dv=\(displayCapsNow.supportsDolbyVision))",
                        category: .session)
                }
                try await loadNative(
                    url: url,
                    sourceHTTPHeaders: loadedOptions.httpHeaders,
                    // Live rejoins at the live edge (see loadSoftware above).
                    startPosition: LiveReloadPolicy.resumePosition(
                        isLive: loadedOptions.isLive, currentTime: resumeAt),
                    audioSourceStreamIndex: audioStreamIndex,
                    keepDvh1TagWithoutDV: loadedOptions.keepDvh1TagWithoutDV,
                    forceDolbyVisionOnNonDVDisplay: loadedOptions.forceDolbyVisionOnNonDVDisplay,
                    dolbyVisionHandling: loadedOptions.dolbyVisionHandling,
                    // AE#532: the verdict the load reached, not a second audit: the source has not
                    // changed and the probe that could answer it is gone.
                    dolbyVisionRPUProfile: sourceDolbyVisionRPUProfile,
                    matchContentEnabled: loadedOptions.matchContentEnabled,
                    panelIsInHDRMode: reloadRoutingPanelHDR,
                    // AE#535: the load's table, for the same reason as the panel answer above.
                    sessionDisplayCaps: reloadDisplayCaps,
                    audioBridgeMode: loadedOptions.audioBridgeMode,
                    // isLive required: without it the reload rebuilds as VOD and HLSVideoEngine fails "cannot build segment plan" (device repro: KiKA).
                    isLive: loadedOptions.isLive,
                    dvrWindowSeconds: loadedOptions.dvrWindowSeconds,
                    // Live reload = live REJOIN: skip initial seek so AVPlayer joins at edge-minus-holdback, not the stale rebuilt start. See LiveReloadPolicy.
                    liveRejoin: loadedOptions.isLive,
                    preopenedDemuxer: customPreopened,
                    keepsMediaPlaylistRoute: keepsMediaRoute,
                    generation: gen
                )
                EngineLog.emit("[AetherEngine] reload: loadNative done (\(elapsedMs(since: loadStart))ms)", category: .engine)
                playbackBackend = .native
                lastRequiresDeinterlaceWarmup = reopenedRequiresDeinterlaceWarmup
                // Publish the session's actual pick (invalid override falls back to auto; demuxed-audio resolves in side-demuxer numbering).
                syncPublishedAudioStateFromNativeSession()
                activeVideoDecoder = Self.videoDecoderLabel(
                    codecID: preservedVideoCodec, isSoftware: false
                )
                activeAudioDecoder = nativeVideoSession?.audioPipelineDescription
                presentCurrentLayer()
                // Wait for pending AVKit display-criteria handshake before resuming (first frame must not hit a mid-transition panel).
                // #274: this reload preserved the criteria (resetDisplayCriteria: false) and re-applies none,
                // so only a sole-writer host's re-write on the swapped item can still switch anything; the
                // published (panel-clamped) format decides whether that can be a dynamic-range switch.
                await displayCriteria.waitForSwitch(
                    startGrace: Self.playGateGrace(
                        criteriaUnchanged: false,
                        criteriaWrittenBeforeLoad: !loadedOptions.awaitsInboundCriteriaWrite,
                        formatKnown: true,
                        effectiveFormat: videoFormat,
                        noWriterExpected: loadedOptions.sharedOutputRole == .secondary
                    ),
                    settleCap: loadedOptions.isLive ? .standard : .awaitObservedEnd,
                    isCurrent: { self.loadGeneration == gen })
                try checkLoadCurrent(gen)
                if transportIntentUnderReconstruction ?? resumesPlaying { nativeHost?.play() }
                else { nativeHost?.pause() }
            }
            try checkLoadCurrent(gen)
            state = (transportIntentUnderReconstruction ?? resumesPlaying) ? .playing : .paused
            // Re-arm samplers: stopInternal nilled them, and the reload path bypasses public load() that normally restarts them. Without this, liveTelemetry stays nil and the stats overlay shows "-" after every audio switch.
            startMemoryProbe()
            startLiveTelemetrySampler()
            // Safety net for the live rejoin: if the rebuilt AVPlayer item
            // never reaches readyToPlay although the producer is serving,
            // fail the reload like a load error instead of leaving the user
            // on an indefinitely frozen frame. Scoped to live reloads on the
            // native path; initial joins and VOD reloads never arm it.
            if loadedOptions.isLive, !targetSoftwarePath {
                armLiveReloadWatchdog(generation: gen)
            }
            EngineLog.emit("[AetherEngine] reload: state=\(state == .playing ? ".playing" : ".paused") total=\(elapsedMs(since: reloadStart))ms", category: .engine)
        } catch is CancellationError {
            // Superseded by a newer load/stop: it owns the engine state.
            return nil
        } catch {
            guard loadGeneration == gen, !Task.isCancelled else { return nil }
            releaseHeldPicture(reason: "rebuild failed")
            EngineLog.emit(
                "[AetherEngine] selectAudioTrack reload failed: \(error), playback stopped",
                category: .engine
            )
            activeAudioTrackIndex = previousAudioIndex
            publishError(.audioTrackSwitchFailed, "Audio track switch failed: \(error.localizedDescription)", underlying: error)
            return error
        }

        // Reload succeeded (failure paths returned above). Re-establish disc state stopInternal wiped.
        // Gate the plain id on the same non-empty check as the published picker so the two can never disagree
        // (a non-disc reload leaves both cleared); selectedDiscTitleID is non-nil whenever titles exist (#67).
        if !reopenedDiscTitles.isEmpty {
            activeDiscTitleID = reopenedSelectedTitleID
            discTitles = reopenedDiscTitles
            discChapters = reopenedDiscChapters
            selectedDiscTitle = reopenedSelectedTitleID.flatMap { id in reopenedDiscTitles.first { $0.id == id } }
            sourceStartSeconds = reopenedStartSeconds
            // A title switch changes the title's stream set. The native path already republished the session's
            // real list via syncPublishedAudioStateFromNativeSession above; only the software path, which does
            // not reconcile tracks post-load, needs the probe-derived lists re-applied here.
            if targetSoftwarePath {
                audioTracks = reopenedAudioTracks
                applyConfirmedTrackFlags()   // #214 follow-up: a title switch re-applies probe lists
                subtitleTracks = reopenedSubtitleTracks
            }
        } else {
            activeDiscTitleID = nil
        }

        // Re-arm subtitle: sidecar branch wins because loadedSidecarURL is set only for sidecar sources.
        if let sidecar = sidecarToResume {
            // #170: an active external track (#88) re-arms through its synthetic id so the
            // published selection stays on the track (the registry survives stopInternal on this
            // path); one-shot sidecar selections keep the URL-only route.
            if let active = activeTrackToResume, externalSubtitleRegistry[active] != nil {
                selectSubtitleTrack(index: active, startAt: preSwitchSourceTime)
            } else {
                selectSidecarSubtitle(url: sidecar)
            }
        } else if embeddedStreamToResume >= 0 {
            // #112 (audio-switch reanchor): pass the pre-stopInternal source PTS explicitly; the parameterless form
            // reads the live sourceTime, which has collapsed to the playlist axis here (shift reset, not yet
            // republished) and would re-arm the reader ~shift seconds behind the line.
            selectSubtitleTrack(index: Int(embeddedStreamToResume), startAt: preSwitchSourceTime)
            // #112 full umbau: re-seed the on-screen bitmap line the switch would otherwise drop. selectSubtitleTrack
            // cleared subtitleCues and spawned a fresh reader; restore the pre-switch visible cues so the line stays
            // up until the reader's reconstruction pass republishes it (its first composition trims these cleanly).
            if !preservedActiveImageCues.isEmpty, subtitleCues.isEmpty {
                subtitleCues = preservedActiveImageCues
            }
        }
        restoreSecondarySubtitleAfterRebuild(
            externalID: secondaryToResume.externalID, sidecarURL: secondaryToResume.sidecarURL,
            embeddedIndex: secondaryToResume.embeddedIndex, startAt: preSwitchSourceTime)
        // #170: replay the native-rendition pick onto the rebuilt item, the way the #65 recovery
        // does; the table was rebuilt from the preserved track list, so a rendering-derived
        // ordinal recomputes to the same rendition and a host-positional one replays as-is.
        if let ordinal = Self.nativeOrdinalToReplay(
            previousOrdinal: reapplyOrdinalToRestore,
            matchesActiveTrack: reapplyMatchesActiveTrack,
            previousActiveTrack: activeTrackToResume,
            currentOrdinal: nativeSubtitleReapplyOrdinal,
            table: nativeSubtitleTrackTable
        ) {
            EngineLog.emit(
                "[AetherEngine] #170 re-applying native subtitle ordinal=\(ordinal) after audio-switch reload",
                category: .engine
            )
            setNativeSubtitleSelected(track: ordinal)
        }
        return nil
    }

    private func elapsedMs(since start: DispatchTime) -> Int {
        Int(Double(DispatchTime.now().uptimeNanoseconds - start.uptimeNanoseconds) / 1_000_000)
    }

    /// Watchdog for live RELOAD only (not initial joins). Guards the device-verified wedge where the rebuilt AVPlayer item fetched init.mp4 + all segments but never reached `readyToPlay`, leaving a frozen frame forever. Polls 1 Hz; 10 s readiness budget starts only once liveSegmentCount >= 2 AND serverLifetimeBytesSent > 0 (so slow upstreams never misfire). On expiry: stopInternal + state = .error. Hard 60 s lifetime.
    func armLiveReloadWatchdog(generation: UInt64) {
        liveReloadWatchdogTask?.cancel()
        liveReloadWatchdogTask = Task { @MainActor [weak self] in
            let readinessBudget: TimeInterval = 10
            let overallBudget: TimeInterval = 60
            let started = Date()
            var servingSince: Date? = nil
            while true {
                try? await Task.sleep(nanoseconds: 1_000_000_000)
                if Task.isCancelled { return }
                guard let self else { return }
                guard self.loadGeneration == generation else { return }
                guard self.playbackBackend == .native,
                      let host = self.nativeHost else { return }
                if case .error = self.state { return }
                if self.state == .idle || self.state == .ended { return }
                if host.isReady { return }
                if servingSince == nil,
                   let session = self.nativeVideoSession,
                   session.liveSegmentCount >= 2,
                   session.serverLifetimeBytesSent > 0 {
                    servingSince = Date()
                }
                if let serving = servingSince,
                   Date().timeIntervalSince(serving) >= readinessBudget {
                    EngineLog.emit(
                        "[AetherEngine] live reload watchdog: AVPlayer item never reached "
                        + "readyToPlay \(Int(readinessBudget))s after the producer started "
                        + "serving (segments=\(self.nativeVideoSession?.liveSegmentCount ?? -1), "
                        + "serverBytes=\(self.nativeVideoSession?.serverLifetimeBytesSent ?? -1)); "
                        + "failing the reload so the host can retune",
                        category: .engine
                    )
                    self.stopInternal()
                    self.publishError(.liveReloadNeverReady, "Live reload failed: player never became ready")
                    return
                }
                if Date().timeIntervalSince(started) >= overallBudget { return }
            }
        }
    }

    /// Called once per session on T.35 detection. Only upgrades .hdr10 states: a DV / HLG / SDR-clamped session that carries HDR10+ metadata stays on its current format (no evidence the panel is rendering an HDR10 base layer). A Dolby Vision source clamped to its HDR10 base does read `.hdr10`, so it is upgraded too: that base is where the payload rides.
    @MainActor
    func handleHDR10PlusDetected() {
        sourceCarriesHDR10PlusMetadata = true
        // sourceVideoFormat upgrade is unconditional: a T.35 payload is a source property even when the panel clamps the output to SDR.
        if sourceVideoFormat == .hdr10 {
            sourceVideoFormat = .hdr10Plus
        }
        guard videoFormat == .hdr10 else { return }
        EngineLog.emit("[AetherEngine] HDR10+ T.35 detected, upgrading videoFormat .hdr10 → .hdr10Plus", category: .engine)
        videoFormat = .hdr10Plus
    }

    /// AE#515: republish a clamped Dolby Vision label once the item AVFoundation is playing says so.
    /// Called from the loopback route's item-format sink; `dolbyVisionLabelUpgrade` carries the rule and
    /// the reason for every term. `sourceVideoFormat` is untouched: the probe answered that one already,
    /// and better than a sample entry can.
    @MainActor
    private func applyDolbyVisionLabelUpgrade(itemFormat: VideoFormat) {
        guard let upgraded = Self.dolbyVisionLabelUpgrade(
            publishedFormat: videoFormat,
            sourceFormat: sourceVideoFormat,
            itemFormat: itemFormat,
            perModeCapabilitiesObservable: Self.perModeDisplayCapabilitiesObservable
        ) else { return }
        EngineLog.emit(
            "[AetherEngine] item carries a Dolby Vision sample entry, upgrading videoFormat "
            + "\(videoFormat) → \(upgraded); this display reports no per-mode capabilities and the "
            + "clamp had nothing to read (#515)",
            category: .engine)
        videoFormat = upgraded
    }
}

// Shared by picture ticks and the independent cache sampler. A paused picture
// keeps its source-axis position while the real contiguous cache can advance.
extension AetherEngine {
    func refreshNativeBufferedPosition(playlistSeconds rendered: Double) {
        // A native seek publishes its target as `currentTime` up front and holds it there until the
        // picture lands, while AVPlayer still renders the frame it left. Measuring from that frame put
        // the buffer on another axis than the playhead: thousands of seconds "ahead" after a backward
        // scrub, below the playhead after a forward one (StreamX, 7.48.0). Measure from the target.
        let value = pendingRecoverySeekClockTarget ?? rendered
        let shift = presentationAxis.shiftSeconds(atItemSeconds: value)
            ?? playlistShiftSeconds
        let anchorDisplay = isLive && videoRoute == .loopback
            ? value + liveSessionShiftSeconds + liveItemAxisOffsetSeconds
            : PresentationAxis.display(
                sourcePTS: value + shift, origin: displayOrigin(forShift: shift))
        let readAhead = nativeVideoSession?
            .contiguousForwardReadAheadSeconds(playlistSeconds: value) ?? 0
        clock.bufferedPosition = max(clock.currentTime, anchorDisplay + max(0, readAhead))
    }
}

extension AetherEngine {
    /// A paused picture does not tick, but the native segment cache can still grow or evict.
    func refreshNativeBufferedPosition() {
        guard let host = nativeHost else { return }
        if nativeVideoSession != nil {
            refreshNativeBufferedPosition(playlistSeconds: host.renderedTime)
        } else {
            refreshRemoteHLSBufferedPosition(rendered: host.renderedTime, ranges: host.loadedVideoRanges)
        }
    }

    /// AE#935: no engine cache on the bypass, so the frontier is AVPlayer's own contiguous loaded
    /// range. Item axis with shift 0, the axis `currentTime` is published on here. Takes the values
    /// rather than the host because a `@Published` sink runs before the host's property is set.
    /// Guarded by route because a reroute to loopback keeps the host and only drops these sinks
    /// after its first await.
    func refreshRemoteHLSBufferedPosition(rendered: Double, ranges: [(Double, Double)]) {
        guard videoRoute == .remoteBypass else { return }
        let anchor = pendingRecoverySeekClockTarget ?? rendered
        let end = NativeAVPlayerHost.contiguousBufferedEnd(ranges: ranges, now: anchor)
        clock.bufferedPosition = max(clock.currentTime, end)
    }
}

extension AetherEngine {
    /// Republishes a session's playlist shift on the engine. The session holds this closure, so it holds the
    /// session weakly: a strong capture made a cycle that kept every played HLS session alive after `stop`, with
    /// its ingest reader, URL session and caches.
    func installPlaylistShiftRelay(on session: HLSVideoEngine, generation: UInt64) {
        session.onPlaylistShiftChanged = { [weak self, weak session] seconds, seamItemSeconds in
            self?.hop(for: generation) { [weak self, weak session] in
                guard let self = self else { return }
                let prevShift = self.playlistShiftSeconds
                let delta = seconds - prevShift
                // AE#105 / AE#270: `duration` is 0-based for every source, so the published playhead has to
                // be too. The origin is the source PTS of the item's first frame: a disc re-reads it from
                // every publish (constant STC base), any other VOD source latches the first one (its later
                // shifts carry producer drift), live keeps 0. See `PresentationOriginPolicy`.
                self.sourcePresentationOrigin = PresentationOriginPolicy.origin(
                    latched: self.latchedPresentationOrigin,
                    publishedShift: seconds,
                    isLive: self.isLive,
                    isDisc: !self.discTitles.isEmpty
                )
                self.latchedPresentationOrigin = self.sourcePresentationOrigin
                // #260: a live retune/reopen replaces the whole timeline (nothing older comes back on screen), so
                // the history re-anchors. A VOD producer only writes from `seamItemSeconds` forward; whatever sits
                // below that on the item axis was muxed by the previous producer, can still be in AVPlayer's
                // buffer, and has to keep folding with the previous shift. Collapsing the history here (as this
                // did before) hands every consumer the new shift for old-epoch bytes.
                if self.isLive {
                    if self.liveDisplayShiftSeconds == nil {
                        self.liveDisplayShiftSeconds = seconds
                    }
                    self.setPresentationAxis(.anchored(shiftSeconds: seconds))
                } else {
                    var map = self.presentationAxis
                    map.appendSeam(shiftSeconds: seconds, activatingAtItemSeconds: seamItemSeconds)
                    self.setPresentationAxis(map)
                }
                // Fold with the shift in effect AT the raw clock, not with the newest one: while old-epoch buffer
                // is still on screen those differ, and the picture is what the clock has to describe.
                let activeShift = self.presentationAxis.shiftSeconds(atItemSeconds: self.nativeClockSeconds) ?? seconds
                if activeShift != self.playlistShiftSeconds { self.playlistShiftSeconds = activeShift }
                // The cache did not move, but the fold onto the display axis did. Re-publish the band
                // from the raw spans so it does not carry the retired epoch's offset until the next
                // segment lands (AE#468 follow-up).
                self.republishResidentRanges()
                // AE#422: read off-main before building the line (see `avPlayerBufferAheadSeconds`).
                let avBufAhead = await self.avPlayerBufferAheadSeconds()
                // Re-fold immediately so currentTime doesn't lag the next periodic tick (origin-corrected).
                self.clock.currentTime = self.isLive && self.videoRoute == .loopback
                    ? self.nativeClockSeconds + self.liveSessionShiftSeconds
                        + self.liveItemAxisOffsetSeconds
                    : PresentationAxis.display(
                        sourcePTS: self.nativeClockSeconds + activeShift,
                        origin: self.displayOrigin(forShift: activeShift))
                // sourceTime re-folds on next $renderedTime tick; keeping it there tracks the rendered picture, not the optimistic clock (#49).
                EngineLog.emit(
                    "[AetherEngine] VOD shift published: \(String(format: "%.3f", seconds))s "
                    + "(prev \(String(format: "%.3f", prevShift))s, delta \(String(format: "%.3f", delta))s, "
                    + "changed=\(abs(delta) > 0.001 ? "YES" : "no")) "
                    + "seamAt=\(String(format: "%.3f", seamItemSeconds))s "
                    + "seams=\(self.presentationAxis.seams.count) "
                    + "foldShift=\(String(format: "%.3f", activeShift))s "
                    + "presentationOrigin=\(String(format: "%.3f", self.sourcePresentationOrigin))s "
                    + "rawClock=\(String(format: "%.2f", self.nativeClockSeconds))s "
                    + "avBufAhead=\(String(format: "%.2f", avBufAhead))s",
                    category: .session
                )
                // AE#418 round 3: a fetch is not a placement. The composition assumed AVPlayer's
                // timeline was carrying the last axis this side published; the item's own loaded
                // ranges say whether it was. Live rebases the whole timeline at a program boundary
                // and nothing older comes back on screen, so it composes nothing and checks nothing.
                if !self.isLive, let session {
                    self.verifyPlacementAgainstLoadedRanges(session: session)
                }
            }
        }
    }
}
