VHS – legacy FFmpeg LGPL relinking materials (local preparation, not published)

This kit contains the exact original FFmpeg n8.1.2 source archive, build flags,
LGPL license, the existing bridge relocation objects for all six shipped target
architectures, the public C interface, privacy manifest and packaging scripts.
No Swift app source or private Objective-C bridge implementation source is included.
The native VHS app can remain proprietary while these library materials are supplied
under their respective terms. See RELINK-PERMISSION.txt.

Requirements: macOS, Xcode and its command-line tools, make, a C toolchain.
From this directory, run:
  python3 Tools/rebuild-library.py --output /path/to/new/BWGFFmpegLegacy.xcframework

The script builds the FFmpeg libraries from the included source and links them with
the supplied bridge objects. Set PLAYER_FFMPEG_SOURCE to your modified FFmpeg source
directory to rebuild a compatible changed version instead. --skip-build is only for
checking a rebuild when all matching FFmpeg install directories already exist.
Outputs must be new paths. Existing app/vendor binaries are never replaced by this kit.

A replacement framework must expose the original BWGFF C interface and use the
original @rpath/BWGFFmpeg.framework/BWGFFmpeg install name. Signing and installation
of a modified app copy are separate steps subject to the target platform's tools.
This kit is not proof that Apple distribution obligations are all satisfied.

Before distributing VHS, make the required library source and relinking materials
available to recipients through an actual distribution/source delivery arrangement.
No delivery URL or developer contact address has been invented. This local copy is
not yet an available source/relink offer to external testers.
