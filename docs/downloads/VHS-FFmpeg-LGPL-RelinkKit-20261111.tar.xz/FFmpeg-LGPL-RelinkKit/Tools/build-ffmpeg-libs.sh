#!/bin/zsh
set -euo pipefail
PLAYER_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PLAYER_SOURCE="${PLAYER_FFMPEG_SOURCE:-/private/tmp/bwg-ffmpeg-n8.1.2}"
PLAYER_PLATFORM="${1:?platform: appletvos, appletvsimulator, iphoneos, iphonesimulator or macosx}"
PLAYER_ARCH="${2:?architecture}"
PLAYER_BUILD="/private/tmp/bwg-ffmpeg-8.1.2-build-$PLAYER_PLATFORM-$PLAYER_ARCH"
PLAYER_PREFIX="/private/tmp/bwg-ffmpeg-8.1.2-install-$PLAYER_PLATFORM-$PLAYER_ARCH"
PLAYER_SDK="$(xcrun --sdk "$PLAYER_PLATFORM" --show-sdk-path)"
PLAYER_CC="$(xcrun --sdk "$PLAYER_PLATFORM" -f clang)"
case "$PLAYER_PLATFORM" in
  appletvos) PLAYER_TARGET="$PLAYER_ARCH-apple-tvos26.0" ;;
  appletvsimulator) PLAYER_TARGET="$PLAYER_ARCH-apple-tvos26.0-simulator" ;;
  iphoneos) PLAYER_TARGET="$PLAYER_ARCH-apple-ios26.0" ;;
  iphonesimulator) PLAYER_TARGET="$PLAYER_ARCH-apple-ios26.0-simulator" ;;
  macosx) PLAYER_TARGET="$PLAYER_ARCH-apple-macos14.0" ;;
  *) exit 1 ;;
esac
if [[ ! -f "$PLAYER_SOURCE/configure" ]]; then
 PLAYER_ARCHIVE="$PLAYER_ROOT/Vendor/FFmpeg/ffmpeg-n8.1.2-source.tar.xz"
 [[ "$(shasum -a 256 "$PLAYER_ARCHIVE" | awk '{print $1}')" == 1fa0786e62b6d09bcc2e0e365d77ea728275d535399e96e670596207c3e7ff14 ]]
 mkdir -p "$PLAYER_SOURCE"
 tar -xJf "$PLAYER_ARCHIVE" -C "$PLAYER_SOURCE"
fi
if [[ -d "$PLAYER_SOURCE/.git" ]]; then
 [[ "$(git -C "$PLAYER_SOURCE" rev-parse HEAD)" == 38b88335f99e76ed89ff3c93f877fdefce736c13 ]]
fi
mkdir -p "$PLAYER_BUILD"
cd "$PLAYER_BUILD"
PLAYER_PROGRAMS=(--disable-programs)
[[ "$PLAYER_PLATFORM" != macosx ]] || PLAYER_PROGRAMS=(--enable-ffmpeg --disable-ffplay --disable-ffprobe --enable-avfilter --enable-avdevice --enable-indev=lavfi --enable-filter=testsrc2,sine,format,aresample,null,anull --enable-muxer=mpegts,hls --enable-encoder=mpeg4,aac,pcm_s16le --enable-decoder=wrapped_avframe)
"$PLAYER_SOURCE/configure" --prefix="$PLAYER_PREFIX" --target-os=darwin --arch="$PLAYER_ARCH" --cc="$PLAYER_CC" \
 --sysroot="$PLAYER_SDK" --enable-cross-compile --extra-cflags="-target $PLAYER_TARGET -fPIC" --extra-ldflags="-target $PLAYER_TARGET" \
 --disable-autodetect --disable-everything --disable-doc --disable-debug --disable-shared --enable-static --disable-asm \
 --disable-gpl --disable-nonfree --enable-pic --enable-pthreads --enable-network --enable-securetransport --enable-zlib --enable-bzlib \
 --enable-avcodec --enable-avformat --enable-avutil --enable-swresample --enable-swscale --disable-avdevice --disable-avfilter \
 --enable-videotoolbox --enable-hwaccel=h264_videotoolbox,hevc_videotoolbox \
 --enable-decoder=h264,hevc,aac,ac3,eac3,truehd,dca,flac,opus,vorbis,mp3,mpeg4,pcm_s16le,pcm_s24le,pcm_f32le,ass,ssa,srt,subrip,webvtt,text,mov_text,pgssub,dvdsub,dvbsub \
 --enable-parser=h264,hevc,aac,ac3,dca,mlp,flac,mpegaudio,mpeg4video,opus,vorbis \
 --enable-demuxer=hls,matroska,mov,mpegts,aac,mp3,flac,srt,ass,sup --enable-muxer=matroska,mp4,mov,srt,sup \
 --enable-protocol=file,http,https,tcp,tls,crypto --enable-bsf=h264_mp4toannexb,hevc_mp4toannexb,extract_extradata,aac_adtstoasc \
 "${PLAYER_PROGRAMS[@]}"
make -j4
make install
