#!/usr/bin/env python3
"""Rebuild only the legacy FFmpeg framework using the supplied bridge objects."""
import argparse, plistlib, shutil, subprocess, tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output',required=True,type=Path)
parser.add_argument('--skip-build',action='store_true',help='Use matching libraries already installed by build-ffmpeg-libs.sh.')
parser.add_argument('--install-root',type=Path,default=Path('/private/tmp'),help='Component install root for --skip-build.')
args=parser.parse_args()
if args.install_root!=Path('/private/tmp') and not args.skip_build:parser.error('--install-root requires --skip-build')
output=args.output.resolve()
if output.exists():raise SystemExit('Choose a new output path; existing outputs are never replaced.')
info=plistlib.loads((root/'StaticLibraryLayout.plist').read_bytes())
with tempfile.TemporaryDirectory(prefix='vhs-ffmpeg-relink-') as temporary:
    static=Path(temporary)/'BWGFFmpeg.xcframework';static.mkdir()
    (static/'Info.plist').write_bytes(plistlib.dumps(info))
    for item in info['AvailableLibraries']:
        key=item['LibraryIdentifier'];folder=static/key;folder.mkdir()
        headers=folder/'Headers';headers.mkdir()
        shutil.copy2(root/'Vendor/FFmpeg/BWGFFmpeg.h',headers/'BWGFFmpeg.h')
        shutil.copy2(root/'Vendor/FFmpeg/module.modulemap',headers/'module.modulemap')
        simulator=item.get('SupportedPlatformVariant')=='simulator'
        sdk={('ios',False):'iphoneos',('ios',True):'iphonesimulator',('tvos',False):'appletvos',('tvos',True):'appletvsimulator'}[(item['SupportedPlatform'],simulator)]
        archives=[]
        for arch in item['SupportedArchitectures']:
            if not args.skip_build:
                subprocess.run(['zsh',str(root/'Tools/build-ffmpeg-libs.sh'),sdk,arch],check=True)
            prefix=args.install_root/('bwg-ffmpeg-8.1.2-install-'+sdk+'-'+arch)
            libraries=[prefix/'lib'/('lib'+name+'.a') for name in ['avformat','avcodec','avutil','swresample','swscale']]
            bridge=root/'Vendor/FFmpeg/RelinkObjects'/key/arch/'BWGFFmpeg.o'
            missing=[str(p) for p in [bridge,*libraries] if not p.is_file()]
            if missing:raise SystemExit('Missing rebuild inputs: '+', '.join(missing))
            target=Path(temporary)/(key+'-'+arch+'.a');archives.append(target)
            subprocess.run(['xcrun','libtool','-static','-o',str(target),str(bridge),*map(str,libraries)],check=True)
        target=folder/item['LibraryPath']
        if len(archives)==1:shutil.copy2(archives[0],target)
        else:subprocess.run(['xcrun','lipo','-create',*map(str,archives),'-output',str(target)],check=True)
    subprocess.run(['python3',str(root/'Tools/package-legacy-ffmpeg.py'),'--source',str(static),'--output',str(output)],check=True)
print(output)
