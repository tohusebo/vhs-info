#!/usr/bin/env python3
"""Isolate legacy FFmpeg behind BWGFF* exports before linking Aether's FFmpeg.
Repackages our existing static archive without changing/rebuilding its source.
Run on macOS with Xcode: python3 Tools/package-legacy-ffmpeg.py
"""
import argparse, plistlib, subprocess, tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
source=root/'Vendor/FFmpeg/BWGFFmpeg.xcframework'
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output',type=Path,default=root/'Vendor/FFmpeg/BWGFFmpegLegacy.xcframework',help='New output path; existing outputs are never replaced.')
parser.add_argument('--source',type=Path,default=source,help='Static XCFramework to wrap behind the unchanged bridge ABI.')
args=parser.parse_args()
source=args.source.resolve()
output=args.output.resolve()
if output.exists(): raise SystemExit(f'Remove the previous generated output explicitly before rebuilding: {output}')
def run(*args): return subprocess.check_output(args,text=True).strip()
with tempfile.TemporaryDirectory(prefix='bwg-legacy-') as tmp:
    tmp=Path(tmp); frameworks=[]
    for platform,sdk,variant,archs in [('tvos','appletvos','', ['arm64']),('tvos','appletvsimulator','-simulator',['arm64','x86_64']),('ios','iphoneos','',['arm64']),('ios','iphonesimulator','-simulator',['arm64','x86_64'])]:
        key=platform+'-'+'_'.join(archs)+variant
        archive=source/key/'libBWGFFmpeg.a'
        fw=tmp/key/'BWGFFmpeg.framework';(fw/'Headers').mkdir(parents=True);(fw/'Modules').mkdir()
        (fw/'Headers/BWGFFmpeg.h').write_bytes((source/key/'Headers/BWGFFmpeg.h').read_bytes())
        # Each dynamic library carries its own required-reason declarations.
        (fw/'PrivacyInfo.xcprivacy').write_bytes((root/'Vendor/FFmpeg/PrivacyInfo.xcprivacy').read_bytes())
        (fw/'Modules/module.modulemap').write_text('framework module BWGFFmpeg { umbrella header "BWGFFmpeg.h" export * }\n')
        exports=tmp/(key+'.exports')
        names=set(line.split()[-1] for line in run('xcrun','nm','-gjU',str(archive)).splitlines() if line.startswith('_BWGFF'))
        assert names,'No bridge exports found'
        exports.write_text('\n'.join(sorted(names))+'\n')
        binaries=[]
        for arch in archs:
            binary=tmp/(key+'.'+arch);binaries.append(str(binary))
            subprocess.run(['xcrun','--sdk',sdk,'clang','-target',arch+'-apple-'+platform+'26.0'+variant,'-isysroot',run('xcrun','--sdk',sdk,'--show-sdk-path'),'-dynamiclib','-Wl,-all_load',str(archive),'-Wl,-exported_symbols_list,'+str(exports),'-install_name','@rpath/BWGFFmpeg.framework/BWGFFmpeg','-framework','Foundation','-framework','AVFoundation','-framework','CoreMedia','-framework','CoreVideo','-framework','VideoToolbox','-framework','AudioToolbox','-framework','Security','-lz','-lbz2','-liconv','-o',str(binary)],check=True)
        subprocess.run(['xcrun','lipo','-create',*binaries,'-output',str(fw/'BWGFFmpeg')],check=True)
        info={'CFBundleExecutable':'BWGFFmpeg','CFBundleIdentifier':'no.bwgstream.ffmpeg.legacy','CFBundleName':'BWGFFmpeg','CFBundlePackageType':'FMWK','CFBundleShortVersionString':'1.0','CFBundleVersion':'1','MinimumOSVersion':'26.0','CFBundleSupportedPlatforms':[{'appletvos':'AppleTVOS','appletvsimulator':'AppleTVSimulator','iphoneos':'iPhoneOS','iphonesimulator':'iPhoneSimulator'}[sdk]]}
        (fw/'Info.plist').write_bytes(plistlib.dumps(info));frameworks+=['-framework',str(fw)]
    subprocess.run(['xcodebuild','-create-xcframework',*frameworks,'-output',str(output)],check=True)
print(output)
